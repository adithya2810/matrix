webpackHotUpdate_N_E("pages/home",{

/***/ "./src/components/founder/Founder.tsx":
/*!********************************************!*\
  !*** ./src/components/founder/Founder.tsx ***!
  \********************************************/
/*! exports provided: Founder */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Founder", function() { return Founder; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var C_Users_KARTHIK_Documents_workspace_matrix_cms_ui_development_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @components */ "./src/components/index.ts");
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-slick */ "./node_modules/react-slick/lib/index.js");
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_slick__WEBPACK_IMPORTED_MODULE_4__);



var _jsxFileName = "C:\\Users\\KARTHIK\\Documents\\workspace\\matrix-cms-ui-development\\src\\components\\founder\\Founder.tsx",
    _this = undefined;

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { Object(C_Users_KARTHIK_Documents_workspace_matrix_cms_ui_development_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__["default"])(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }




var Founder = function Founder(_ref) {
  var className = _ref.className,
      _ref$style = _ref.style,
      style = _ref$style === void 0 ? {} : _ref$style;
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_slick__WEBPACK_IMPORTED_MODULE_4___default.a, {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "".concat(className),
      style: _objectSpread({
        width: 615.94,
        height: 863.91,
        position: "relative"
      }, style),
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "",
        style: {
          width: 571,
          height: 762,
          position: "absolute",
          background: "#083A4A",
          bottom: 50,
          left: 0
        }
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 26,
        columnNumber: 9
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "",
        style: {
          width: 594,
          height: 788,
          bottom: 65,
          left: 15,
          position: "absolute",
          display: "flex",
          flexDirection: "column"
        },
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_3__["Image"], {
          src: "/icons/Bhavish_image.svg",
          alt: "founder image",
          style: {
            flexGrow: 1
          }
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 49,
          columnNumber: 11
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_3__["Image"], {
          src: "/icons/rectangle.svg",
          alt: "reactangle",
          className: "absolute",
          style: {
            left: 38,
            bottom: 254
          }
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 54,
          columnNumber: 11
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          style: {
            height: 209,
            background: "#01576E"
          },
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "text-center flex items-center",
            style: {
              height: 118,
              borderBottom: "1px solid #EBEBE9"
            },
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h6", {
              className: "font-bold text-secondary",
              style: {
                fontSize: 32,
                lineHeight: "36px",
                letterSpacing: "0.05em",
                marginLeft: 31,
                marginRight: 8
              },
              children: "BHAVISH"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 66,
              columnNumber: 15
            }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h6", {
              className: "font-light text-secondary",
              style: {
                fontSize: 32,
                lineHeight: "36px",
                letterSpacing: "0.05em"
              },
              children: "AGGARWAL"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 78,
              columnNumber: 15
            }, _this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 62,
            columnNumber: 13
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "flex justify-between items-center",
            style: {
              height: 88
            },
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              style: {
                marginLeft: 31
              },
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                className: "text-secondary font-medium text-lg leading-6",
                children: " Mobility"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 92,
                columnNumber: 17
              }, _this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 91,
              columnNumber: 15
            }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_3__["Image"], {
              src: "/icons/ola.svg",
              alt: "ola",
              style: {
                marginRight: 57
              }
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 94,
              columnNumber: 15
            }, _this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 90,
            columnNumber: 13
          }, _this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 61,
          columnNumber: 11
        }, _this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 37,
        columnNumber: 9
      }, _this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 17,
      columnNumber: 7
    }, _this)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 16,
    columnNumber: 5
  }, _this);
};
_c = Founder;

var _c;

$RefreshReg$(_c, "Founder");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vc3JjL2NvbXBvbmVudHMvZm91bmRlci9Gb3VuZGVyLnRzeCJdLCJuYW1lcyI6WyJGb3VuZGVyIiwiY2xhc3NOYW1lIiwic3R5bGUiLCJ3aWR0aCIsImhlaWdodCIsInBvc2l0aW9uIiwiYmFja2dyb3VuZCIsImJvdHRvbSIsImxlZnQiLCJkaXNwbGF5IiwiZmxleERpcmVjdGlvbiIsImZsZXhHcm93IiwiYm9yZGVyQm90dG9tIiwiZm9udFNpemUiLCJsaW5lSGVpZ2h0IiwibGV0dGVyU3BhY2luZyIsIm1hcmdpbkxlZnQiLCJtYXJnaW5SaWdodCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBV08sSUFBTUEsT0FBd0IsR0FBRyxTQUEzQkEsT0FBMkIsT0FBK0I7QUFBQSxNQUE1QkMsU0FBNEIsUUFBNUJBLFNBQTRCO0FBQUEsd0JBQWpCQyxLQUFpQjtBQUFBLE1BQWpCQSxLQUFpQiwyQkFBVCxFQUFTO0FBQ3JFLHNCQUNFLHFFQUFDLGtEQUFEO0FBQUEsMkJBQ0U7QUFDRSxlQUFTLFlBQUtELFNBQUwsQ0FEWDtBQUVFLFdBQUs7QUFDSEUsYUFBSyxFQUFFLE1BREo7QUFFSEMsY0FBTSxFQUFFLE1BRkw7QUFHSEMsZ0JBQVEsRUFBRTtBQUhQLFNBSUFILEtBSkEsQ0FGUDtBQUFBLDhCQVNFO0FBQ0UsaUJBQVMsRUFBQyxFQURaO0FBRUUsYUFBSyxFQUFFO0FBQ0xDLGVBQUssRUFBRSxHQURGO0FBRUxDLGdCQUFNLEVBQUUsR0FGSDtBQUdMQyxrQkFBUSxFQUFFLFVBSEw7QUFJTEMsb0JBQVUsRUFBRSxTQUpQO0FBS0xDLGdCQUFNLEVBQUUsRUFMSDtBQU1MQyxjQUFJLEVBQUU7QUFORDtBQUZUO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFURixlQW9CRTtBQUNFLGlCQUFTLEVBQUMsRUFEWjtBQUVFLGFBQUssRUFBRTtBQUNMTCxlQUFLLEVBQUUsR0FERjtBQUVMQyxnQkFBTSxFQUFFLEdBRkg7QUFHTEcsZ0JBQU0sRUFBRSxFQUhIO0FBSUxDLGNBQUksRUFBRSxFQUpEO0FBS0xILGtCQUFRLEVBQUUsVUFMTDtBQU1MSSxpQkFBTyxFQUFFLE1BTko7QUFPTEMsdUJBQWEsRUFBRTtBQVBWLFNBRlQ7QUFBQSxnQ0FZRSxxRUFBQyxpREFBRDtBQUNFLGFBQUcsRUFBQywwQkFETjtBQUVFLGFBQUcsRUFBQyxlQUZOO0FBR0UsZUFBSyxFQUFFO0FBQUVDLG9CQUFRLEVBQUU7QUFBWjtBQUhUO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBWkYsZUFpQkUscUVBQUMsaURBQUQ7QUFDRSxhQUFHLEVBQUMsc0JBRE47QUFFRSxhQUFHLEVBQUUsWUFGUDtBQUdFLG1CQUFTLEVBQUMsVUFIWjtBQUlFLGVBQUssRUFBRTtBQUFFSCxnQkFBSSxFQUFFLEVBQVI7QUFBWUQsa0JBQU0sRUFBRTtBQUFwQjtBQUpUO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBakJGLGVBd0JFO0FBQUssZUFBSyxFQUFFO0FBQUVILGtCQUFNLEVBQUUsR0FBVjtBQUFlRSxzQkFBVSxFQUFFO0FBQTNCLFdBQVo7QUFBQSxrQ0FDRTtBQUNFLHFCQUFTLEVBQUMsK0JBRFo7QUFFRSxpQkFBSyxFQUFFO0FBQUVGLG9CQUFNLEVBQUUsR0FBVjtBQUFlUSwwQkFBWSxFQUFFO0FBQTdCLGFBRlQ7QUFBQSxvQ0FJRTtBQUNFLHVCQUFTLEVBQUMsMEJBRFo7QUFFRSxtQkFBSyxFQUFFO0FBQ0xDLHdCQUFRLEVBQUUsRUFETDtBQUVMQywwQkFBVSxFQUFFLE1BRlA7QUFHTEMsNkJBQWEsRUFBRSxRQUhWO0FBSUxDLDBCQUFVLEVBQUUsRUFKUDtBQUtMQywyQkFBVyxFQUFFO0FBTFIsZUFGVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFKRixlQWdCRTtBQUNFLHVCQUFTLEVBQUMsMkJBRFo7QUFFRSxtQkFBSyxFQUFFO0FBQ0xKLHdCQUFRLEVBQUUsRUFETDtBQUVMQywwQkFBVSxFQUFFLE1BRlA7QUFHTEMsNkJBQWEsRUFBRTtBQUhWLGVBRlQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFERixlQTZCRTtBQUFLLHFCQUFTLEVBQUMsbUNBQWY7QUFBbUQsaUJBQUssRUFBRTtBQUFFWCxvQkFBTSxFQUFFO0FBQVYsYUFBMUQ7QUFBQSxvQ0FDRTtBQUFLLG1CQUFLLEVBQUU7QUFBRVksMEJBQVUsRUFBRTtBQUFkLGVBQVo7QUFBQSxxQ0FDRTtBQUFNLHlCQUFTLEVBQUMsOENBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFERixlQUlFLHFFQUFDLGlEQUFEO0FBQ0UsaUJBQUcsRUFBRSxnQkFEUDtBQUVFLGlCQUFHLEVBQUUsS0FGUDtBQUdFLG1CQUFLLEVBQUU7QUFBRUMsMkJBQVcsRUFBRTtBQUFmO0FBSFQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBN0JGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkF4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBcEJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FERjtBQTJGRCxDQTVGTTtLQUFNakIsTyIsImZpbGUiOiJzdGF0aWMvd2VicGFjay9wYWdlcy9ob21lLjE3YTRhZTc5OGVlZWFhZDhjMmE1LmhvdC11cGRhdGUuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBJbWFnZSB9IGZyb20gXCJAY29tcG9uZW50c1wiO1xuaW1wb3J0IENhcm91c2VsIGZyb20gXCJyZWFjdC1zbGlja1wiO1xuXG5leHBvcnQgdHlwZSBQcm9wcyA9IHtcbiAgbmFtZXM/OiBBcnJheTxzdHJpbmc+O1xuICBiYWNrZ3JvdW5kX3VybD86IHN0cmluZztcbiAgdGFncz86IEFycmF5PHN0cmluZz47XG4gIGxvZ28/OiBzdHJpbmc7XG4gIGNsYXNzTmFtZT86IHN0cmluZztcbiAgc3R5bGU/OiBhbnk7XG59O1xuXG5leHBvcnQgY29uc3QgRm91bmRlcjogUmVhY3QuRkM8UHJvcHM+ID0gKHsgY2xhc3NOYW1lLCBzdHlsZSA9IHt9IH0pID0+IHtcbiAgcmV0dXJuIChcbiAgICA8Q2Fyb3VzZWw+XG4gICAgICA8ZGl2XG4gICAgICAgIGNsYXNzTmFtZT17YCR7Y2xhc3NOYW1lfWB9XG4gICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgd2lkdGg6IDYxNS45NCxcbiAgICAgICAgICBoZWlnaHQ6IDg2My45MSxcbiAgICAgICAgICBwb3NpdGlvbjogXCJyZWxhdGl2ZVwiLFxuICAgICAgICAgIC4uLnN0eWxlLFxuICAgICAgICB9fVxuICAgICAgPlxuICAgICAgICA8ZGl2XG4gICAgICAgICAgY2xhc3NOYW1lPVwiXCJcbiAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgd2lkdGg6IDU3MSxcbiAgICAgICAgICAgIGhlaWdodDogNzYyLFxuICAgICAgICAgICAgcG9zaXRpb246IFwiYWJzb2x1dGVcIixcbiAgICAgICAgICAgIGJhY2tncm91bmQ6IFwiIzA4M0E0QVwiLFxuICAgICAgICAgICAgYm90dG9tOiA1MCxcbiAgICAgICAgICAgIGxlZnQ6IDAsXG4gICAgICAgICAgfX1cbiAgICAgICAgPjwvZGl2PlxuICAgICAgICA8ZGl2XG4gICAgICAgICAgY2xhc3NOYW1lPVwiXCJcbiAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgd2lkdGg6IDU5NCxcbiAgICAgICAgICAgIGhlaWdodDogNzg4LFxuICAgICAgICAgICAgYm90dG9tOiA2NSxcbiAgICAgICAgICAgIGxlZnQ6IDE1LFxuICAgICAgICAgICAgcG9zaXRpb246IFwiYWJzb2x1dGVcIixcbiAgICAgICAgICAgIGRpc3BsYXk6IFwiZmxleFwiLFxuICAgICAgICAgICAgZmxleERpcmVjdGlvbjogXCJjb2x1bW5cIixcbiAgICAgICAgICB9fVxuICAgICAgICA+XG4gICAgICAgICAgPEltYWdlXG4gICAgICAgICAgICBzcmM9XCIvaWNvbnMvQmhhdmlzaF9pbWFnZS5zdmdcIlxuICAgICAgICAgICAgYWx0PVwiZm91bmRlciBpbWFnZVwiXG4gICAgICAgICAgICBzdHlsZT17eyBmbGV4R3JvdzogMSB9fVxuICAgICAgICAgID48L0ltYWdlPlxuICAgICAgICAgIDxJbWFnZVxuICAgICAgICAgICAgc3JjPVwiL2ljb25zL3JlY3RhbmdsZS5zdmdcIlxuICAgICAgICAgICAgYWx0PXtcInJlYWN0YW5nbGVcIn1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImFic29sdXRlXCJcbiAgICAgICAgICAgIHN0eWxlPXt7IGxlZnQ6IDM4LCBib3R0b206IDI1NCB9fVxuICAgICAgICAgIC8+XG5cbiAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGhlaWdodDogMjA5LCBiYWNrZ3JvdW5kOiBcIiMwMTU3NkVcIiB9fT5cbiAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgZmxleCBpdGVtcy1jZW50ZXJcIlxuICAgICAgICAgICAgICBzdHlsZT17eyBoZWlnaHQ6IDExOCwgYm9yZGVyQm90dG9tOiBcIjFweCBzb2xpZCAjRUJFQkU5XCIgfX1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgPGg2XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtc2Vjb25kYXJ5XCJcbiAgICAgICAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgICAgICAgZm9udFNpemU6IDMyLFxuICAgICAgICAgICAgICAgICAgbGluZUhlaWdodDogXCIzNnB4XCIsXG4gICAgICAgICAgICAgICAgICBsZXR0ZXJTcGFjaW5nOiBcIjAuMDVlbVwiLFxuICAgICAgICAgICAgICAgICAgbWFyZ2luTGVmdDogMzEsXG4gICAgICAgICAgICAgICAgICBtYXJnaW5SaWdodDogOCxcbiAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgQkhBVklTSFxuICAgICAgICAgICAgPC9oNj5cbiAgICAgICAgICAgICAgPGg2XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZm9udC1saWdodCB0ZXh0LXNlY29uZGFyeVwiXG4gICAgICAgICAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICAgICAgICAgIGZvbnRTaXplOiAzMixcbiAgICAgICAgICAgICAgICAgIGxpbmVIZWlnaHQ6IFwiMzZweFwiLFxuICAgICAgICAgICAgICAgICAgbGV0dGVyU3BhY2luZzogXCIwLjA1ZW1cIixcbiAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgQUdHQVJXQUxcbiAgICAgICAgICAgIDwvaDY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXJcIiBzdHlsZT17eyBoZWlnaHQ6IDg4IH19PlxuICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IG1hcmdpbkxlZnQ6IDMxIH19PlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2Vjb25kYXJ5IGZvbnQtbWVkaXVtIHRleHQtbGcgbGVhZGluZy02XCI+IE1vYmlsaXR5PC9zcGFuPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPEltYWdlXG4gICAgICAgICAgICAgICAgc3JjPXtcIi9pY29ucy9vbGEuc3ZnXCJ9XG4gICAgICAgICAgICAgICAgYWx0PXtcIm9sYVwifVxuICAgICAgICAgICAgICAgIHN0eWxlPXt7IG1hcmdpblJpZ2h0OiA1NyB9fVxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICA8L0Nhcm91c2VsPlxuICApO1xufTtcbiJdLCJzb3VyY2VSb290IjoiIn0=