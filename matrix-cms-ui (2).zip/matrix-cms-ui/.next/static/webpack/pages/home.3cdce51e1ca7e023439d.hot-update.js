webpackHotUpdate_N_E("pages/home",{

/***/ "./src/modules/home/homeCarousal/HomeCarousal.tsx":
/*!********************************************************!*\
  !*** ./src/modules/home/homeCarousal/HomeCarousal.tsx ***!
  \********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var C_Users_KARTHIK_Documents_workspace_matrix_cms_ui_development_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @components */ "./src/components/index.ts");
/* harmony import */ var _components_founder_FounderDetail__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @components/founder/FounderDetail */ "./src/components/founder/FounderDetail.tsx");
/* harmony import */ var react_responsive_carousel_lib_styles_carousel_min_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react-responsive-carousel/lib/styles/carousel.min.css */ "./node_modules/react-responsive-carousel/lib/styles/carousel.min.css");
/* harmony import */ var react_responsive_carousel_lib_styles_carousel_min_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_responsive_carousel_lib_styles_carousel_min_css__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_responsive_carousel__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react-responsive-carousel */ "./node_modules/react-responsive-carousel/lib/js/index.js");
/* harmony import */ var react_responsive_carousel__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_responsive_carousel__WEBPACK_IMPORTED_MODULE_6__);



var _jsxFileName = "C:\\Users\\KARTHIK\\Documents\\workspace\\matrix-cms-ui-development\\src\\modules\\home\\homeCarousal\\HomeCarousal.tsx",
    _this = undefined,
    _s = $RefreshSig$();




 // requires a loader


var data = [{
  image_url: "/icons/content1.svg",
  title: "From both sides of the table : Kunal Bahl unplugged",
  author: "TARUN DAVDA",
  content_id: "abcdef",
  content_type: "blog",
  read_duration: "4 MIN"
}, {
  image_url: "/icons/content1.svg",
  title: "From both sides of the table : Kunal Bahl unplugged",
  author: "TARUN DAVDA",
  content_id: "abcdefg",
  content_type: "blog",
  read_duration: "4 MIN"
}];

var HomeCarousal = function HomeCarousal() {
  _s();

  var _React$useState = react__WEBPACK_IMPORTED_MODULE_2___default.a.useState("/icons/backgroundCarousalImage.png"),
      _React$useState2 = Object(C_Users_KARTHIK_Documents_workspace_matrix_cms_ui_development_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_1__["default"])(_React$useState, 2),
      backgroundUrl = _React$useState2[0],
      setBackgroundUrl = _React$useState2[1];

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_responsive_carousel__WEBPACK_IMPORTED_MODULE_6__["Carousel"], {
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "relative",
      style: {
        height: 1080
      },
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "absolute h-full w-full flex flex-col",
        style: {
          backgroundImage: "url(".concat(backgroundUrl, ")"),
          backgroundSize: "cover"
        },
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "flex",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_3__["Image"], {
            src: "/icons/leftArrow.svg",
            alt: "right Icon",
            height: 73,
            width: 37,
            style: {
              marginLeft: 179
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 42,
            columnNumber: 13
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            style: {
              width: 533,
              marginLeft: 100
            },
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              style: {
                fontWeight: 300,
                fontSize: "100px",
                lineHeight: "120px",
                letterSpacing: "-0.01em",
                opacity: 0.35,
                marginTop: 117
              },
              children: [" ", "01/05"]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 50,
              columnNumber: 15
            }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "text-secondary-light",
              style: {
                fontWeight: 200,
                fontSize: "85px",
                lineHeight: "95px",
                opacity: 1,
                marginTop: 151,
                minWidth: 545
              },
              children: ["Tech-enabled", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 75,
                columnNumber: 15
              }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                className: "font-bold",
                children: " Student housing"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 76,
                columnNumber: 17
              }, _this), " ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 76,
                columnNumber: 69
              }, _this), "Platform"]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 63,
              columnNumber: 15
            }, _this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 49,
            columnNumber: 13
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_founder_FounderDetail__WEBPACK_IMPORTED_MODULE_4__["FounderDetail"], {
            style: {
              marginTop: 36,
              marginLeft: 103
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 80,
            columnNumber: 13
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_3__["Image"], {
            src: "/icons/rightArrow.large.svg",
            alt: "right Icon",
            height: 73,
            width: 37,
            style: {
              marginLeft: 103
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 81,
            columnNumber: 13
          }, _this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 41,
          columnNumber: 11
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "absolute bg-accent",
          style: {
            bottom: 33,
            left: 269,
            height: 246,
            width: 564
          },
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
            className: "text-secondary font-medium text-lg leading-6 text-center h-full flex justify-center items-center",
            style: {
              writingMode: "vertical-lr",
              width: 56
            },
            children: [" ", "Hospitality Sector", " "]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 93,
            columnNumber: 13
          }, _this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 89,
          columnNumber: 11
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_3__["ContentSlider"], {
          style: {
            left: 325,
            background: "#EBEBE9",
            border: "1px solid #EBEBE9",
            boxSizing: "border-box",
            fontSize: 28,
            lineHeight: "34px",
            paddingTop: 24,
            paddingLeft: 34
          },
          contentList: data,
          className: "absolute bottom-0 right-0 text-primary-dark",
          header: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
            children: ["Dive into the ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
              className: "text-accent",
              children: "Matrix Moments"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 114,
              columnNumber: 41
            }, _this), " series"]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 114,
            columnNumber: 21
          }, _this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 101,
          columnNumber: 11
        }, _this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 34,
        columnNumber: 9
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 33,
      columnNumber: 7
    }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "relative",
      style: {
        height: 1080
      },
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "absolute h-full w-full flex flex-col",
        style: {
          backgroundImage: "url(".concat(backgroundUrl, ")"),
          backgroundSize: "cover"
        },
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "flex",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_3__["Image"], {
            src: "/icons/leftArrow.svg",
            alt: "right Icon",
            height: 73,
            width: 37,
            style: {
              marginLeft: 179
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 128,
            columnNumber: 13
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            style: {
              width: 533,
              marginLeft: 100
            },
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              style: {
                fontWeight: 300,
                fontSize: "100px",
                lineHeight: "120px",
                letterSpacing: "-0.01em",
                opacity: 0.35,
                marginTop: 117
              },
              children: [" ", "01/05"]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 136,
              columnNumber: 15
            }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "text-secondary-light",
              style: {
                fontWeight: 200,
                fontSize: "85px",
                lineHeight: "95px",
                opacity: 1,
                marginTop: 151,
                minWidth: 545
              },
              children: ["Tech-enabled", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 161,
                columnNumber: 15
              }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                className: "font-bold",
                children: " Student housing"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 162,
                columnNumber: 17
              }, _this), " ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 162,
                columnNumber: 69
              }, _this), "Platform"]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 149,
              columnNumber: 15
            }, _this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 135,
            columnNumber: 13
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_founder_FounderDetail__WEBPACK_IMPORTED_MODULE_4__["FounderDetail"], {
            style: {
              marginTop: 36,
              marginLeft: 103
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 166,
            columnNumber: 13
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_3__["Image"], {
            src: "/icons/rightArrow.large.svg",
            alt: "right Icon",
            height: 73,
            width: 37,
            style: {
              marginLeft: 103
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 167,
            columnNumber: 13
          }, _this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 127,
          columnNumber: 11
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "absolute bg-accent",
          style: {
            bottom: 33,
            left: 269,
            height: 246,
            width: 564
          },
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
            className: "text-secondary font-medium text-lg leading-6 text-center h-full flex justify-center items-center",
            style: {
              writingMode: "vertical-lr",
              width: 56
            },
            children: [" ", "Hospitality Sector", " "]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 179,
            columnNumber: 13
          }, _this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 175,
          columnNumber: 11
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_3__["ContentSlider"], {
          style: {
            left: 325,
            background: "#EBEBE9",
            border: "1px solid #EBEBE9",
            boxSizing: "border-box",
            fontSize: 28,
            lineHeight: "34px",
            paddingTop: 24,
            paddingLeft: 34
          },
          contentList: data,
          className: "absolute bottom-0 right-0 text-primary-dark",
          header: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
            children: ["Dive into the ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
              className: "text-accent",
              children: "Matrix Moments"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 200,
              columnNumber: 41
            }, _this), " series"]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 200,
            columnNumber: 21
          }, _this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 187,
          columnNumber: 11
        }, _this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 120,
        columnNumber: 9
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 119,
      columnNumber: 7
    }, _this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 32,
    columnNumber: 5
  }, _this);
};

_s(HomeCarousal, "zzogb7U4cw9IdhqzvwsqoFa+QS0=");

_c = HomeCarousal;
/* harmony default export */ __webpack_exports__["default"] = (HomeCarousal);

var _c;

$RefreshReg$(_c, "HomeCarousal");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vc3JjL21vZHVsZXMvaG9tZS9ob21lQ2Fyb3VzYWwvSG9tZUNhcm91c2FsLnRzeCJdLCJuYW1lcyI6WyJkYXRhIiwiaW1hZ2VfdXJsIiwidGl0bGUiLCJhdXRob3IiLCJjb250ZW50X2lkIiwiY29udGVudF90eXBlIiwicmVhZF9kdXJhdGlvbiIsIkhvbWVDYXJvdXNhbCIsIlJlYWN0IiwidXNlU3RhdGUiLCJiYWNrZ3JvdW5kVXJsIiwic2V0QmFja2dyb3VuZFVybCIsImhlaWdodCIsImJhY2tncm91bmRJbWFnZSIsImJhY2tncm91bmRTaXplIiwibWFyZ2luTGVmdCIsIndpZHRoIiwiZm9udFdlaWdodCIsImZvbnRTaXplIiwibGluZUhlaWdodCIsImxldHRlclNwYWNpbmciLCJvcGFjaXR5IiwibWFyZ2luVG9wIiwibWluV2lkdGgiLCJib3R0b20iLCJsZWZ0Iiwid3JpdGluZ01vZGUiLCJiYWNrZ3JvdW5kIiwiYm9yZGVyIiwiYm94U2l6aW5nIiwicGFkZGluZ1RvcCIsInBhZGRpbmdMZWZ0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtDQUNnRTs7QUFDaEU7QUFFQSxJQUFNQSxJQUFJLEdBQUcsQ0FDWDtBQUNFQyxXQUFTLEVBQUUscUJBRGI7QUFFRUMsT0FBSyxFQUFFLHFEQUZUO0FBR0VDLFFBQU0sRUFBRSxhQUhWO0FBSUVDLFlBQVUsRUFBRSxRQUpkO0FBS0VDLGNBQVksRUFBRSxNQUxoQjtBQU1FQyxlQUFhLEVBQUU7QUFOakIsQ0FEVyxFQVNYO0FBQ0VMLFdBQVMsRUFBRSxxQkFEYjtBQUVFQyxPQUFLLEVBQUUscURBRlQ7QUFHRUMsUUFBTSxFQUFFLGFBSFY7QUFJRUMsWUFBVSxFQUFFLFNBSmQ7QUFLRUMsY0FBWSxFQUFFLE1BTGhCO0FBTUVDLGVBQWEsRUFBRTtBQU5qQixDQVRXLENBQWI7O0FBb0JBLElBQU1DLFlBQVksR0FBRyxTQUFmQSxZQUFlLEdBQU07QUFBQTs7QUFBQSx3QkFDaUJDLDRDQUFLLENBQUNDLFFBQU4sQ0FDeEMsb0NBRHdDLENBRGpCO0FBQUE7QUFBQSxNQUNsQkMsYUFEa0I7QUFBQSxNQUNIQyxnQkFERzs7QUFJekIsc0JBQ0UscUVBQUMsa0VBQUQ7QUFBQSw0QkFDRTtBQUFLLGVBQVMsRUFBQyxVQUFmO0FBQTBCLFdBQUssRUFBRTtBQUFFQyxjQUFNLEVBQUU7QUFBVixPQUFqQztBQUFBLDZCQUNFO0FBQ0UsaUJBQVMsRUFBQyxzQ0FEWjtBQUVFLGFBQUssRUFBRTtBQUNMQyx5QkFBZSxnQkFBU0gsYUFBVCxNQURWO0FBRUxJLHdCQUFjLEVBQUU7QUFGWCxTQUZUO0FBQUEsZ0NBT0U7QUFBSyxtQkFBUyxFQUFDLE1BQWY7QUFBQSxrQ0FDRSxxRUFBQyxpREFBRDtBQUNFLGVBQUcsRUFBQyxzQkFETjtBQUVFLGVBQUcsRUFBRSxZQUZQO0FBR0Usa0JBQU0sRUFBRSxFQUhWO0FBSUUsaUJBQUssRUFBRSxFQUpUO0FBS0UsaUJBQUssRUFBRTtBQUFFQyx3QkFBVSxFQUFFO0FBQWQ7QUFMVDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURGLGVBUUU7QUFBSyxpQkFBSyxFQUFFO0FBQUVDLG1CQUFLLEVBQUUsR0FBVDtBQUFjRCx3QkFBVSxFQUFFO0FBQTFCLGFBQVo7QUFBQSxvQ0FDRTtBQUNFLG1CQUFLLEVBQUU7QUFDTEUsMEJBQVUsRUFBRSxHQURQO0FBRUxDLHdCQUFRLEVBQUUsT0FGTDtBQUdMQywwQkFBVSxFQUFFLE9BSFA7QUFJTEMsNkJBQWEsRUFBRSxTQUpWO0FBS0xDLHVCQUFPLEVBQUUsSUFMSjtBQU1MQyx5QkFBUyxFQUFFO0FBTk4sZUFEVDtBQUFBLHlCQVVHLEdBVkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQURGLGVBY0U7QUFDRSx1QkFBUyxFQUFDLHNCQURaO0FBRUUsbUJBQUssRUFBRTtBQUNMTCwwQkFBVSxFQUFFLEdBRFA7QUFFTEMsd0JBQVEsRUFBRSxNQUZMO0FBR0xDLDBCQUFVLEVBQUUsTUFIUDtBQUlMRSx1QkFBTyxFQUFFLENBSko7QUFLTEMseUJBQVMsRUFBRSxHQUxOO0FBTUxDLHdCQUFRLEVBQUU7QUFOTCxlQUZUO0FBQUEsc0RBWUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFaQSxlQWFFO0FBQU0seUJBQVMsRUFBQyxXQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFiRixvQkFhc0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFidEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFSRixlQXVDRSxxRUFBQywrRUFBRDtBQUFlLGlCQUFLLEVBQUU7QUFBRUQsdUJBQVMsRUFBRSxFQUFiO0FBQWlCUCx3QkFBVSxFQUFFO0FBQTdCO0FBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBdkNGLGVBd0NFLHFFQUFDLGlEQUFEO0FBQ0UsZUFBRyxFQUFDLDZCQUROO0FBRUUsZUFBRyxFQUFFLFlBRlA7QUFHRSxrQkFBTSxFQUFFLEVBSFY7QUFJRSxpQkFBSyxFQUFFLEVBSlQ7QUFLRSxpQkFBSyxFQUFFO0FBQUVBLHdCQUFVLEVBQUU7QUFBZDtBQUxUO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBeENGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFQRixlQXVERTtBQUNFLG1CQUFTLEVBQUMsb0JBRFo7QUFFRSxlQUFLLEVBQUU7QUFBRVMsa0JBQU0sRUFBRSxFQUFWO0FBQWNDLGdCQUFJLEVBQUUsR0FBcEI7QUFBeUJiLGtCQUFNLEVBQUUsR0FBakM7QUFBc0NJLGlCQUFLLEVBQUU7QUFBN0MsV0FGVDtBQUFBLGlDQUlFO0FBQ0UscUJBQVMsRUFBQyxrR0FEWjtBQUVFLGlCQUFLLEVBQUU7QUFBRVUseUJBQVcsRUFBRSxhQUFmO0FBQThCVixtQkFBSyxFQUFFO0FBQXJDLGFBRlQ7QUFBQSx1QkFJRyxHQUpILHdCQUttQixHQUxuQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXZERixlQW1FRSxxRUFBQyx5REFBRDtBQUNFLGVBQUssRUFBRTtBQUNMUyxnQkFBSSxFQUFFLEdBREQ7QUFFTEUsc0JBQVUsRUFBRSxTQUZQO0FBR0xDLGtCQUFNLEVBQUUsbUJBSEg7QUFJTEMscUJBQVMsRUFBRSxZQUpOO0FBS0xYLG9CQUFRLEVBQUUsRUFMTDtBQU1MQyxzQkFBVSxFQUFFLE1BTlA7QUFPTFcsc0JBQVUsRUFBRSxFQVBQO0FBUUxDLHVCQUFXLEVBQUU7QUFSUixXQURUO0FBV0UscUJBQVcsRUFBRS9CLElBWGY7QUFZRSxtQkFBUyxFQUFDLDZDQVpaO0FBYUUsZ0JBQU0sZUFBRTtBQUFBLHNEQUFvQjtBQUFNLHVCQUFTLEVBQUMsYUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQWJWO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBbkVGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFERixlQXVGRTtBQUFLLGVBQVMsRUFBQyxVQUFmO0FBQTBCLFdBQUssRUFBRTtBQUFFWSxjQUFNLEVBQUU7QUFBVixPQUFqQztBQUFBLDZCQUNFO0FBQ0UsaUJBQVMsRUFBQyxzQ0FEWjtBQUVFLGFBQUssRUFBRTtBQUNMQyx5QkFBZSxnQkFBU0gsYUFBVCxNQURWO0FBRUxJLHdCQUFjLEVBQUU7QUFGWCxTQUZUO0FBQUEsZ0NBT0U7QUFBSyxtQkFBUyxFQUFDLE1BQWY7QUFBQSxrQ0FDRSxxRUFBQyxpREFBRDtBQUNFLGVBQUcsRUFBQyxzQkFETjtBQUVFLGVBQUcsRUFBRSxZQUZQO0FBR0Usa0JBQU0sRUFBRSxFQUhWO0FBSUUsaUJBQUssRUFBRSxFQUpUO0FBS0UsaUJBQUssRUFBRTtBQUFFQyx3QkFBVSxFQUFFO0FBQWQ7QUFMVDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURGLGVBUUU7QUFBSyxpQkFBSyxFQUFFO0FBQUVDLG1CQUFLLEVBQUUsR0FBVDtBQUFjRCx3QkFBVSxFQUFFO0FBQTFCLGFBQVo7QUFBQSxvQ0FDRTtBQUNFLG1CQUFLLEVBQUU7QUFDTEUsMEJBQVUsRUFBRSxHQURQO0FBRUxDLHdCQUFRLEVBQUUsT0FGTDtBQUdMQywwQkFBVSxFQUFFLE9BSFA7QUFJTEMsNkJBQWEsRUFBRSxTQUpWO0FBS0xDLHVCQUFPLEVBQUUsSUFMSjtBQU1MQyx5QkFBUyxFQUFFO0FBTk4sZUFEVDtBQUFBLHlCQVVHLEdBVkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQURGLGVBY0U7QUFDRSx1QkFBUyxFQUFDLHNCQURaO0FBRUUsbUJBQUssRUFBRTtBQUNMTCwwQkFBVSxFQUFFLEdBRFA7QUFFTEMsd0JBQVEsRUFBRSxNQUZMO0FBR0xDLDBCQUFVLEVBQUUsTUFIUDtBQUlMRSx1QkFBTyxFQUFFLENBSko7QUFLTEMseUJBQVMsRUFBRSxHQUxOO0FBTUxDLHdCQUFRLEVBQUU7QUFOTCxlQUZUO0FBQUEsc0RBWUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFaQSxlQWFFO0FBQU0seUJBQVMsRUFBQyxXQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFiRixvQkFhc0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFidEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFSRixlQXVDRSxxRUFBQywrRUFBRDtBQUFlLGlCQUFLLEVBQUU7QUFBRUQsdUJBQVMsRUFBRSxFQUFiO0FBQWlCUCx3QkFBVSxFQUFFO0FBQTdCO0FBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBdkNGLGVBd0NFLHFFQUFDLGlEQUFEO0FBQ0UsZUFBRyxFQUFDLDZCQUROO0FBRUUsZUFBRyxFQUFFLFlBRlA7QUFHRSxrQkFBTSxFQUFFLEVBSFY7QUFJRSxpQkFBSyxFQUFFLEVBSlQ7QUFLRSxpQkFBSyxFQUFFO0FBQUVBLHdCQUFVLEVBQUU7QUFBZDtBQUxUO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBeENGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFQRixlQXVERTtBQUNFLG1CQUFTLEVBQUMsb0JBRFo7QUFFRSxlQUFLLEVBQUU7QUFBRVMsa0JBQU0sRUFBRSxFQUFWO0FBQWNDLGdCQUFJLEVBQUUsR0FBcEI7QUFBeUJiLGtCQUFNLEVBQUUsR0FBakM7QUFBc0NJLGlCQUFLLEVBQUU7QUFBN0MsV0FGVDtBQUFBLGlDQUlFO0FBQ0UscUJBQVMsRUFBQyxrR0FEWjtBQUVFLGlCQUFLLEVBQUU7QUFBRVUseUJBQVcsRUFBRSxhQUFmO0FBQThCVixtQkFBSyxFQUFFO0FBQXJDLGFBRlQ7QUFBQSx1QkFJRyxHQUpILHdCQUttQixHQUxuQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXZERixlQW1FRSxxRUFBQyx5REFBRDtBQUNFLGVBQUssRUFBRTtBQUNMUyxnQkFBSSxFQUFFLEdBREQ7QUFFTEUsc0JBQVUsRUFBRSxTQUZQO0FBR0xDLGtCQUFNLEVBQUUsbUJBSEg7QUFJTEMscUJBQVMsRUFBRSxZQUpOO0FBS0xYLG9CQUFRLEVBQUUsRUFMTDtBQU1MQyxzQkFBVSxFQUFFLE1BTlA7QUFPTFcsc0JBQVUsRUFBRSxFQVBQO0FBUUxDLHVCQUFXLEVBQUU7QUFSUixXQURUO0FBV0UscUJBQVcsRUFBRS9CLElBWGY7QUFZRSxtQkFBUyxFQUFDLDZDQVpaO0FBYUUsZ0JBQU0sZUFBRTtBQUFBLHNEQUFvQjtBQUFNLHVCQUFTLEVBQUMsYUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQWJWO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBbkVGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF2RkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBREY7QUFnTEQsQ0FwTEQ7O0dBQU1PLFk7O0tBQUFBLFk7QUFzTFNBLDJFQUFmIiwiZmlsZSI6InN0YXRpYy93ZWJwYWNrL3BhZ2VzL2hvbWUuM2NkY2U1MWUxY2E3ZTAyMzQzOWQuaG90LXVwZGF0ZS5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IEltYWdlLCBDb250ZW50U2xpZGVyIH0gZnJvbSBcIkBjb21wb25lbnRzXCI7XG5pbXBvcnQgeyBGb3VuZGVyRGV0YWlsIH0gZnJvbSBcIkBjb21wb25lbnRzL2ZvdW5kZXIvRm91bmRlckRldGFpbFwiO1xuaW1wb3J0IFwicmVhY3QtcmVzcG9uc2l2ZS1jYXJvdXNlbC9saWIvc3R5bGVzL2Nhcm91c2VsLm1pbi5jc3NcIjsgLy8gcmVxdWlyZXMgYSBsb2FkZXJcbmltcG9ydCB7IENhcm91c2VsIH0gZnJvbSAncmVhY3QtcmVzcG9uc2l2ZS1jYXJvdXNlbCc7XG5cbmNvbnN0IGRhdGEgPSBbXG4gIHtcbiAgICBpbWFnZV91cmw6IFwiL2ljb25zL2NvbnRlbnQxLnN2Z1wiLFxuICAgIHRpdGxlOiBcIkZyb20gYm90aCBzaWRlcyBvZiB0aGUgdGFibGUgOiBLdW5hbCBCYWhsIHVucGx1Z2dlZFwiLFxuICAgIGF1dGhvcjogXCJUQVJVTiBEQVZEQVwiLFxuICAgIGNvbnRlbnRfaWQ6IFwiYWJjZGVmXCIsXG4gICAgY29udGVudF90eXBlOiBcImJsb2dcIixcbiAgICByZWFkX2R1cmF0aW9uOiBcIjQgTUlOXCIsXG4gIH0sXG4gIHtcbiAgICBpbWFnZV91cmw6IFwiL2ljb25zL2NvbnRlbnQxLnN2Z1wiLFxuICAgIHRpdGxlOiBcIkZyb20gYm90aCBzaWRlcyBvZiB0aGUgdGFibGUgOiBLdW5hbCBCYWhsIHVucGx1Z2dlZFwiLFxuICAgIGF1dGhvcjogXCJUQVJVTiBEQVZEQVwiLFxuICAgIGNvbnRlbnRfaWQ6IFwiYWJjZGVmZ1wiLFxuICAgIGNvbnRlbnRfdHlwZTogXCJibG9nXCIsXG4gICAgcmVhZF9kdXJhdGlvbjogXCI0IE1JTlwiLFxuICB9LFxuXG5dO1xuXG5jb25zdCBIb21lQ2Fyb3VzYWwgPSAoKSA9PiB7XG4gIGNvbnN0IFtiYWNrZ3JvdW5kVXJsLCBzZXRCYWNrZ3JvdW5kVXJsXSA9IFJlYWN0LnVzZVN0YXRlKFxuICAgIFwiL2ljb25zL2JhY2tncm91bmRDYXJvdXNhbEltYWdlLnBuZ1wiXG4gICk7XG4gIHJldHVybiAoXG4gICAgPENhcm91c2VsPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZVwiIHN0eWxlPXt7IGhlaWdodDogMTA4MCB9fT5cbiAgICAgICAgPGRpdlxuICAgICAgICAgIGNsYXNzTmFtZT1cImFic29sdXRlIGgtZnVsbCB3LWZ1bGwgZmxleCBmbGV4LWNvbFwiXG4gICAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICAgIGJhY2tncm91bmRJbWFnZTogYHVybCgke2JhY2tncm91bmRVcmx9KWAsXG4gICAgICAgICAgICBiYWNrZ3JvdW5kU2l6ZTogXCJjb3ZlclwiLFxuICAgICAgICAgIH19XG4gICAgICAgID5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXhcIj5cbiAgICAgICAgICAgIDxJbWFnZVxuICAgICAgICAgICAgICBzcmM9XCIvaWNvbnMvbGVmdEFycm93LnN2Z1wiXG4gICAgICAgICAgICAgIGFsdD17XCJyaWdodCBJY29uXCJ9XG4gICAgICAgICAgICAgIGhlaWdodD17NzN9XG4gICAgICAgICAgICAgIHdpZHRoPXszN31cbiAgICAgICAgICAgICAgc3R5bGU9e3sgbWFyZ2luTGVmdDogMTc5IH19XG4gICAgICAgICAgICAvPlxuICAgICAgICAgICAgPGRpdiBzdHlsZT17eyB3aWR0aDogNTMzLCBtYXJnaW5MZWZ0OiAxMDAgfX0+XG4gICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgICAgICAgZm9udFdlaWdodDogMzAwLFxuICAgICAgICAgICAgICAgICAgZm9udFNpemU6IFwiMTAwcHhcIixcbiAgICAgICAgICAgICAgICAgIGxpbmVIZWlnaHQ6IFwiMTIwcHhcIixcbiAgICAgICAgICAgICAgICAgIGxldHRlclNwYWNpbmc6IFwiLTAuMDFlbVwiLFxuICAgICAgICAgICAgICAgICAgb3BhY2l0eTogMC4zNSxcbiAgICAgICAgICAgICAgICAgIG1hcmdpblRvcDogMTE3LFxuICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICB7XCIgXCJ9XG4gICAgICAgICAgICAgIDAxLzA1XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtc2Vjb25kYXJ5LWxpZ2h0XCJcbiAgICAgICAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgICAgICAgZm9udFdlaWdodDogMjAwLFxuICAgICAgICAgICAgICAgICAgZm9udFNpemU6IFwiODVweFwiLFxuICAgICAgICAgICAgICAgICAgbGluZUhlaWdodDogXCI5NXB4XCIsXG4gICAgICAgICAgICAgICAgICBvcGFjaXR5OiAxLFxuICAgICAgICAgICAgICAgICAgbWFyZ2luVG9wOiAxNTEsXG4gICAgICAgICAgICAgICAgICBtaW5XaWR0aDogNTQ1LFxuICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICBUZWNoLWVuYWJsZWRcbiAgICAgICAgICAgICAgPGJyIC8+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkXCI+IFN0dWRlbnQgaG91c2luZzwvc3Bhbj4gPGJyIC8+XG4gICAgICAgICAgICAgIFBsYXRmb3JtXG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPEZvdW5kZXJEZXRhaWwgc3R5bGU9e3sgbWFyZ2luVG9wOiAzNiwgbWFyZ2luTGVmdDogMTAzIH19IC8+XG4gICAgICAgICAgICA8SW1hZ2VcbiAgICAgICAgICAgICAgc3JjPVwiL2ljb25zL3JpZ2h0QXJyb3cubGFyZ2Uuc3ZnXCJcbiAgICAgICAgICAgICAgYWx0PXtcInJpZ2h0IEljb25cIn1cbiAgICAgICAgICAgICAgaGVpZ2h0PXs3M31cbiAgICAgICAgICAgICAgd2lkdGg9ezM3fVxuICAgICAgICAgICAgICBzdHlsZT17eyBtYXJnaW5MZWZ0OiAxMDMgfX1cbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdlxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiYWJzb2x1dGUgYmctYWNjZW50XCJcbiAgICAgICAgICAgIHN0eWxlPXt7IGJvdHRvbTogMzMsIGxlZnQ6IDI2OSwgaGVpZ2h0OiAyNDYsIHdpZHRoOiA1NjQgfX1cbiAgICAgICAgICA+XG4gICAgICAgICAgICA8c3BhblxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXNlY29uZGFyeSBmb250LW1lZGl1bSB0ZXh0LWxnIGxlYWRpbmctNiB0ZXh0LWNlbnRlciBoLWZ1bGwgZmxleCBqdXN0aWZ5LWNlbnRlciBpdGVtcy1jZW50ZXJcIlxuICAgICAgICAgICAgICBzdHlsZT17eyB3cml0aW5nTW9kZTogXCJ2ZXJ0aWNhbC1sclwiLCB3aWR0aDogNTYgfX1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAge1wiIFwifVxuICAgICAgICAgICAgSG9zcGl0YWxpdHkgU2VjdG9ye1wiIFwifVxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxDb250ZW50U2xpZGVyXG4gICAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgICBsZWZ0OiAzMjUsXG4gICAgICAgICAgICAgIGJhY2tncm91bmQ6IFwiI0VCRUJFOVwiLFxuICAgICAgICAgICAgICBib3JkZXI6IFwiMXB4IHNvbGlkICNFQkVCRTlcIixcbiAgICAgICAgICAgICAgYm94U2l6aW5nOiBcImJvcmRlci1ib3hcIixcbiAgICAgICAgICAgICAgZm9udFNpemU6IDI4LFxuICAgICAgICAgICAgICBsaW5lSGVpZ2h0OiBcIjM0cHhcIixcbiAgICAgICAgICAgICAgcGFkZGluZ1RvcDogMjQsXG4gICAgICAgICAgICAgIHBhZGRpbmdMZWZ0OiAzNCxcbiAgICAgICAgICAgIH19XG4gICAgICAgICAgICBjb250ZW50TGlzdD17ZGF0YX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImFic29sdXRlIGJvdHRvbS0wIHJpZ2h0LTAgdGV4dC1wcmltYXJ5LWRhcmtcIlxuICAgICAgICAgICAgaGVhZGVyPXs8c3Bhbj5EaXZlIGludG8gdGhlIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtYWNjZW50XCI+TWF0cml4IE1vbWVudHM8L3NwYW4+IHNlcmllczwvc3Bhbj59XG4gICAgICAgICAgLz5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgIDwvZGl2PlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZVwiIHN0eWxlPXt7IGhlaWdodDogMTA4MCB9fT5cbiAgICAgICAgPGRpdlxuICAgICAgICAgIGNsYXNzTmFtZT1cImFic29sdXRlIGgtZnVsbCB3LWZ1bGwgZmxleCBmbGV4LWNvbFwiXG4gICAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICAgIGJhY2tncm91bmRJbWFnZTogYHVybCgke2JhY2tncm91bmRVcmx9KWAsXG4gICAgICAgICAgICBiYWNrZ3JvdW5kU2l6ZTogXCJjb3ZlclwiLFxuICAgICAgICAgIH19XG4gICAgICAgID5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXhcIj5cbiAgICAgICAgICAgIDxJbWFnZVxuICAgICAgICAgICAgICBzcmM9XCIvaWNvbnMvbGVmdEFycm93LnN2Z1wiXG4gICAgICAgICAgICAgIGFsdD17XCJyaWdodCBJY29uXCJ9XG4gICAgICAgICAgICAgIGhlaWdodD17NzN9XG4gICAgICAgICAgICAgIHdpZHRoPXszN31cbiAgICAgICAgICAgICAgc3R5bGU9e3sgbWFyZ2luTGVmdDogMTc5IH19XG4gICAgICAgICAgICAvPlxuICAgICAgICAgICAgPGRpdiBzdHlsZT17eyB3aWR0aDogNTMzLCBtYXJnaW5MZWZ0OiAxMDAgfX0+XG4gICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgICAgICAgZm9udFdlaWdodDogMzAwLFxuICAgICAgICAgICAgICAgICAgZm9udFNpemU6IFwiMTAwcHhcIixcbiAgICAgICAgICAgICAgICAgIGxpbmVIZWlnaHQ6IFwiMTIwcHhcIixcbiAgICAgICAgICAgICAgICAgIGxldHRlclNwYWNpbmc6IFwiLTAuMDFlbVwiLFxuICAgICAgICAgICAgICAgICAgb3BhY2l0eTogMC4zNSxcbiAgICAgICAgICAgICAgICAgIG1hcmdpblRvcDogMTE3LFxuICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICB7XCIgXCJ9XG4gICAgICAgICAgICAgIDAxLzA1XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtc2Vjb25kYXJ5LWxpZ2h0XCJcbiAgICAgICAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgICAgICAgZm9udFdlaWdodDogMjAwLFxuICAgICAgICAgICAgICAgICAgZm9udFNpemU6IFwiODVweFwiLFxuICAgICAgICAgICAgICAgICAgbGluZUhlaWdodDogXCI5NXB4XCIsXG4gICAgICAgICAgICAgICAgICBvcGFjaXR5OiAxLFxuICAgICAgICAgICAgICAgICAgbWFyZ2luVG9wOiAxNTEsXG4gICAgICAgICAgICAgICAgICBtaW5XaWR0aDogNTQ1LFxuICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICBUZWNoLWVuYWJsZWRcbiAgICAgICAgICAgICAgPGJyIC8+XG4gICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkXCI+IFN0dWRlbnQgaG91c2luZzwvc3Bhbj4gPGJyIC8+XG4gICAgICAgICAgICAgIFBsYXRmb3JtXG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPEZvdW5kZXJEZXRhaWwgc3R5bGU9e3sgbWFyZ2luVG9wOiAzNiwgbWFyZ2luTGVmdDogMTAzIH19IC8+XG4gICAgICAgICAgICA8SW1hZ2VcbiAgICAgICAgICAgICAgc3JjPVwiL2ljb25zL3JpZ2h0QXJyb3cubGFyZ2Uuc3ZnXCJcbiAgICAgICAgICAgICAgYWx0PXtcInJpZ2h0IEljb25cIn1cbiAgICAgICAgICAgICAgaGVpZ2h0PXs3M31cbiAgICAgICAgICAgICAgd2lkdGg9ezM3fVxuICAgICAgICAgICAgICBzdHlsZT17eyBtYXJnaW5MZWZ0OiAxMDMgfX1cbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdlxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiYWJzb2x1dGUgYmctYWNjZW50XCJcbiAgICAgICAgICAgIHN0eWxlPXt7IGJvdHRvbTogMzMsIGxlZnQ6IDI2OSwgaGVpZ2h0OiAyNDYsIHdpZHRoOiA1NjQgfX1cbiAgICAgICAgICA+XG4gICAgICAgICAgICA8c3BhblxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXNlY29uZGFyeSBmb250LW1lZGl1bSB0ZXh0LWxnIGxlYWRpbmctNiB0ZXh0LWNlbnRlciBoLWZ1bGwgZmxleCBqdXN0aWZ5LWNlbnRlciBpdGVtcy1jZW50ZXJcIlxuICAgICAgICAgICAgICBzdHlsZT17eyB3cml0aW5nTW9kZTogXCJ2ZXJ0aWNhbC1sclwiLCB3aWR0aDogNTYgfX1cbiAgICAgICAgICAgID5cbiAgICAgICAgICAgICAge1wiIFwifVxuICAgICAgICAgICAgSG9zcGl0YWxpdHkgU2VjdG9ye1wiIFwifVxuICAgICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxDb250ZW50U2xpZGVyXG4gICAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgICBsZWZ0OiAzMjUsXG4gICAgICAgICAgICAgIGJhY2tncm91bmQ6IFwiI0VCRUJFOVwiLFxuICAgICAgICAgICAgICBib3JkZXI6IFwiMXB4IHNvbGlkICNFQkVCRTlcIixcbiAgICAgICAgICAgICAgYm94U2l6aW5nOiBcImJvcmRlci1ib3hcIixcbiAgICAgICAgICAgICAgZm9udFNpemU6IDI4LFxuICAgICAgICAgICAgICBsaW5lSGVpZ2h0OiBcIjM0cHhcIixcbiAgICAgICAgICAgICAgcGFkZGluZ1RvcDogMjQsXG4gICAgICAgICAgICAgIHBhZGRpbmdMZWZ0OiAzNCxcbiAgICAgICAgICAgIH19XG4gICAgICAgICAgICBjb250ZW50TGlzdD17ZGF0YX1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImFic29sdXRlIGJvdHRvbS0wIHJpZ2h0LTAgdGV4dC1wcmltYXJ5LWRhcmtcIlxuICAgICAgICAgICAgaGVhZGVyPXs8c3Bhbj5EaXZlIGludG8gdGhlIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtYWNjZW50XCI+TWF0cml4IE1vbWVudHM8L3NwYW4+IHNlcmllczwvc3Bhbj59XG4gICAgICAgICAgLz5cbiAgICAgICAgPC9kaXY+XG5cbiAgICAgIDwvZGl2PlxuICAgIDwvQ2Fyb3VzZWw+XG4gICk7XG59O1xuXG5leHBvcnQgZGVmYXVsdCBIb21lQ2Fyb3VzYWw7XG4iXSwic291cmNlUm9vdCI6IiJ9