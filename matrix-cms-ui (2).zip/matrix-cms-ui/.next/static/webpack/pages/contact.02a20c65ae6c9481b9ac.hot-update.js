webpackHotUpdate_N_E("pages/contact",{

/***/ "./src/modules/contact/form.tsx":
/*!**************************************!*\
  !*** ./src/modules/contact/form.tsx ***!
  \**************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_button_PrimaryButtonIconRight__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @components/button/PrimaryButtonIconRight */ "./src/components/button/PrimaryButtonIconRight.tsx");


var _jsxFileName = "C:\\Users\\KARTHIK\\Documents\\workspace\\matrix-cms-ui-development\\src\\modules\\contact\\form.tsx",
    _this = undefined;




var ContactForm = function ContactForm() {
  var details = [{
    city: "Bangalore",
    address: ['197, 6th Main, 1st Cross,', 'HAL 2nd Stage, Indira Nagar,', 'Bengaluru 560038', '+91-80-25196000']
  }, {
    city: "DELHI",
    address: ['4th Floor, Aria Towers, ', 'JW Marriott, Asset Area 4,', 'Aerocity, New Delhi, 110037', '+91-11-49495000']
  }, {
    city: "MUMBAI",
    address: ['601-602, Ceejay House,', 'Dr Annie Besant Road, Worli,', 'Mumbai 400018', '+91-22-67680000']
  }];
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: "relative m-auto w-11/12\t",
    style: {
      marginTop: 100,
      marginBottom: 150
    },
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "row",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        style: {
          flex: '60%'
        },
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h1", {
          className: "main-txt text-4xl  font-bold",
          children: "Vist our India Advisory Team Offices"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 19,
          columnNumber: 11
        }, _this), details.map(function (data) {
          return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "row ",
            style: {
              marginTop: '50px'
            },
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              style: {
                flex: '66%'
              },
              className: "col-span-8 contact-address",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "map-info border-b-2 mr-5 pb-5",
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                  href: "#",
                  className: "uppercase font-bold text-xl border-b-3 bbc",
                  children: data.city
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 24,
                  columnNumber: 19
                }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("hr", {
                  className: "under-line"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 25,
                  columnNumber: 19
                }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
                  children: [data.address[0], " ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 26,
                    columnNumber: 40
                  }, _this), data.address[1], " ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 26,
                    columnNumber: 64
                  }, _this), " data.address[2] ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 26,
                    columnNumber: 87
                  }, _this), " ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 26,
                    columnNumber: 94
                  }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                    href: data.address[3],
                    children: data.address[3]
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 26,
                    columnNumber: 100
                  }, _this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 26,
                  columnNumber: 19
                }, _this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 23,
                columnNumber: 17
              }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "direction-link",
                children: ["GET DIRECTION ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
                    src: "/icons/blackArrow.svg"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 28,
                    columnNumber: 70
                  }, _this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 28,
                  columnNumber: 64
                }, _this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 28,
                columnNumber: 17
              }, _this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 22,
              columnNumber: 15
            }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              style: {
                flex: '44%'
              },
              className: "col-span-4 relative",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "city-overlay",
                children: data.city
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 31,
                columnNumber: 17
              }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
                className: "contact-img",
                src: "../../img/image 26.png",
                alt: ""
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 32,
                columnNumber: 17
              }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "contact-bg-overlay "
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 33,
                columnNumber: 17
              }, _this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 30,
              columnNumber: 15
            }, _this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 21,
            columnNumber: 13
          }, _this);
        })]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 18,
        columnNumber: 9
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        style: {
          flex: '40%'
        },
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h1", {
          className: "main-txt text-4xl lg:text-3xl font-bold form-heading",
          children: "Share your Business Plans"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 39,
          columnNumber: 11
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("form", {
          className: "contact-form",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("label", {
            children: "Name"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 41,
            columnNumber: 13
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("input", {
            type: "text",
            placeholder: "Name"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 42,
            columnNumber: 13
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("label", {
            children: "Company Name"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 43,
            columnNumber: 13
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("input", {
            type: "text",
            placeholder: "Company Name"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 44,
            columnNumber: 13
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("label", {
            children: "What are you building?"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 45,
            columnNumber: 13
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("textarea", {
            placeholder: "Company Brief"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 46,
            columnNumber: 13
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("label", {
            children: "File Attachment"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 47,
            columnNumber: 13
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("input", {
            type: "file"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 48,
            columnNumber: 13
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("label", {
            children: "Email Id"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 49,
            columnNumber: 13
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("input", {
            type: "email",
            placeholder: "Contact Email"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 50,
            columnNumber: 13
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("label", {
            children: "Mobile Number"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 51,
            columnNumber: 13
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("input", {
            type: "text",
            placeholder: "Contact Number"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 52,
            columnNumber: 13
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_button_PrimaryButtonIconRight__WEBPACK_IMPORTED_MODULE_2__["default"], {
            title: "Apply",
            url: "/icons/rightArrow.svg",
            onClick: function onClick() {
              return console.log("subscribe");
            },
            className: "text-lg leading-6"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 53,
            columnNumber: 13
          }, _this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 40,
          columnNumber: 11
        }, _this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 38,
        columnNumber: 9
      }, _this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 17,
      columnNumber: 7
    }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h1", {
      className: "main-txt text-4xl  font-bold",
      style: {
        marginTop: '50px'
      },
      children: "Matrix Partners Global"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 63,
      columnNumber: 7
    }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "row",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        style: {
          flex: '25%'
        },
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
          className: "main-txt text-3xl font-bold",
          children: "USA"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 66,
          columnNumber: 11
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("hr", {
          className: "under-line"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 67,
          columnNumber: 11
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
          children: "BOSTON"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 68,
          columnNumber: 11
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
          children: "PALO ALTO"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 69,
          columnNumber: 11
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
          children: "SAN FRANCISCO"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 70,
          columnNumber: 11
        }, _this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 65,
        columnNumber: 9
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        style: {
          flex: '50%'
        },
        children: "sdfds"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 72,
        columnNumber: 9
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        style: {
          flex: '25%'
        },
        children: "sdfds"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 75,
        columnNumber: 9
      }, _this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 64,
      columnNumber: 7
    }, _this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 16,
    columnNumber: 5
  }, _this);
};

_c = ContactForm;
/* harmony default export */ __webpack_exports__["default"] = (ContactForm);

var _c;

$RefreshReg$(_c, "ContactForm");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vc3JjL21vZHVsZXMvY29udGFjdC9mb3JtLnRzeCJdLCJuYW1lcyI6WyJDb250YWN0Rm9ybSIsImRldGFpbHMiLCJjaXR5IiwiYWRkcmVzcyIsIm1hcmdpblRvcCIsIm1hcmdpbkJvdHRvbSIsImZsZXgiLCJtYXAiLCJkYXRhIiwiY29uc29sZSIsImxvZyJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTs7QUFFQSxJQUFNQSxXQUFxQixHQUFHLFNBQXhCQSxXQUF3QixHQUFNO0FBQ2xDLE1BQU1DLE9BQU8sR0FBRyxDQUFDO0FBQ2ZDLFFBQUksRUFBRSxXQURTO0FBRWZDLFdBQU8sRUFBRSxDQUFDLDJCQUFELEVBQThCLDhCQUE5QixFQUE4RCxrQkFBOUQsRUFBa0YsaUJBQWxGO0FBRk0sR0FBRCxFQUdiO0FBQ0RELFFBQUksRUFBRSxPQURMO0FBRURDLFdBQU8sRUFBRSxDQUFDLDBCQUFELEVBQTZCLDRCQUE3QixFQUEyRCw2QkFBM0QsRUFBMEYsaUJBQTFGO0FBRlIsR0FIYSxFQU1iO0FBQ0RELFFBQUksRUFBRSxRQURMO0FBRURDLFdBQU8sRUFBRSxDQUFDLHdCQUFELEVBQTJCLDhCQUEzQixFQUEyRCxlQUEzRCxFQUE0RSxpQkFBNUU7QUFGUixHQU5hLENBQWhCO0FBVUEsc0JBQ0U7QUFBSyxhQUFTLEVBQUMsMkJBQWY7QUFBMEMsU0FBSyxFQUFFO0FBQUVDLGVBQVMsRUFBRSxHQUFiO0FBQWtCQyxrQkFBWSxFQUFFO0FBQWhDLEtBQWpEO0FBQUEsNEJBQ0U7QUFBSyxlQUFTLEVBQUMsS0FBZjtBQUFBLDhCQUNFO0FBQUssYUFBSyxFQUFFO0FBQUVDLGNBQUksRUFBRTtBQUFSLFNBQVo7QUFBQSxnQ0FDRTtBQUFJLG1CQUFTLEVBQUMsOEJBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBREYsRUFFR0wsT0FBTyxDQUFDTSxHQUFSLENBQVksVUFBQ0MsSUFBRDtBQUFBLDhCQUNYO0FBQUsscUJBQVMsRUFBQyxNQUFmO0FBQXNCLGlCQUFLLEVBQUU7QUFBRUosdUJBQVMsRUFBRTtBQUFiLGFBQTdCO0FBQUEsb0NBQ0U7QUFBSyxtQkFBSyxFQUFFO0FBQUVFLG9CQUFJLEVBQUU7QUFBUixlQUFaO0FBQTZCLHVCQUFTLEVBQUMsNEJBQXZDO0FBQUEsc0NBQ0U7QUFBSyx5QkFBUyxFQUFDLCtCQUFmO0FBQUEsd0NBQ0U7QUFBRyxzQkFBSSxFQUFDLEdBQVI7QUFBWSwyQkFBUyxFQUFDLDRDQUF0QjtBQUFBLDRCQUFvRUUsSUFBSSxDQUFDTjtBQUF6RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQURGLGVBRUU7QUFBSSwyQkFBUyxFQUFDO0FBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFGRixlQUdFO0FBQUEsNkJBQUlNLElBQUksQ0FBQ0wsT0FBTCxDQUFhLENBQWIsQ0FBSixvQkFBcUI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBckIsRUFBNEJLLElBQUksQ0FBQ0wsT0FBTCxDQUFhLENBQWIsQ0FBNUIsb0JBQTZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTdDLG9DQUFvRTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFwRSxvQkFBMkU7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBM0UsZUFBaUY7QUFBRyx3QkFBSSxFQUFFSyxJQUFJLENBQUNMLE9BQUwsQ0FBYSxDQUFiLENBQVQ7QUFBQSw4QkFBMkJLLElBQUksQ0FBQ0wsT0FBTCxDQUFhLENBQWI7QUFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBakY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFERixlQU1FO0FBQUsseUJBQVMsRUFBQyxnQkFBZjtBQUFBLDBEQUErQztBQUFBLHlDQUFNO0FBQUssdUJBQUcsRUFBQztBQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBTjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUEvQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQURGLGVBU0U7QUFBSyxtQkFBSyxFQUFFO0FBQUVHLG9CQUFJLEVBQUU7QUFBUixlQUFaO0FBQTZCLHVCQUFTLEVBQUMscUJBQXZDO0FBQUEsc0NBQ0U7QUFBSyx5QkFBUyxFQUFDLGNBQWY7QUFBQSwwQkFBK0JFLElBQUksQ0FBQ047QUFBcEM7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFERixlQUVFO0FBQUsseUJBQVMsRUFBQyxhQUFmO0FBQTZCLG1CQUFHLEVBQUMsd0JBQWpDO0FBQTBELG1CQUFHLEVBQUM7QUFBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFGRixlQUdFO0FBQUsseUJBQVMsRUFBQztBQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFEVztBQUFBLFNBQVosQ0FGSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERixlQXFCRTtBQUFLLGFBQUssRUFBRTtBQUFFSSxjQUFJLEVBQUU7QUFBUixTQUFaO0FBQUEsZ0NBQ0U7QUFBSSxtQkFBUyxFQUFDLHNEQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURGLGVBRUU7QUFBTSxtQkFBUyxFQUFDLGNBQWhCO0FBQUEsa0NBQ0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREYsZUFFRTtBQUFPLGdCQUFJLEVBQUMsTUFBWjtBQUFtQix1QkFBVyxFQUFDO0FBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRkYsZUFHRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFIRixlQUlFO0FBQU8sZ0JBQUksRUFBQyxNQUFaO0FBQW1CLHVCQUFXLEVBQUM7QUFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFKRixlQUtFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUxGLGVBTUU7QUFBVSx1QkFBVyxFQUFDO0FBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBTkYsZUFPRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFQRixlQVFFO0FBQU8sZ0JBQUksRUFBQztBQUFaO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUkYsZUFTRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFURixlQVVFO0FBQU8sZ0JBQUksRUFBQyxPQUFaO0FBQW9CLHVCQUFXLEVBQUM7QUFBaEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFWRixlQVdFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVhGLGVBWUU7QUFBTyxnQkFBSSxFQUFDLE1BQVo7QUFBbUIsdUJBQVcsRUFBQztBQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVpGLGVBYUUscUVBQUMsaUZBQUQ7QUFDRSxpQkFBSyxFQUFDLE9BRFI7QUFFRSxlQUFHLEVBQUMsdUJBRk47QUFHRSxtQkFBTyxFQUFFO0FBQUEscUJBQU1HLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFdBQVosQ0FBTjtBQUFBLGFBSFg7QUFJRSxxQkFBUyxFQUFDO0FBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFiRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBckJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQURGLGVBK0NFO0FBQUksZUFBUyxFQUFDLDhCQUFkO0FBQTZDLFdBQUssRUFBRTtBQUFFTixpQkFBUyxFQUFFO0FBQWIsT0FBcEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUEvQ0YsZUFnREU7QUFBSyxlQUFTLEVBQUMsS0FBZjtBQUFBLDhCQUNFO0FBQUssYUFBSyxFQUFFO0FBQUVFLGNBQUksRUFBRTtBQUFSLFNBQVo7QUFBQSxnQ0FDRTtBQUFHLG1CQUFTLEVBQUMsNkJBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBREYsZUFFRTtBQUFJLG1CQUFTLEVBQUM7QUFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUZGLGVBR0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSEYsZUFJRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFKRixlQUtFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGLGVBUUU7QUFBSyxhQUFLLEVBQUU7QUFBRUEsY0FBSSxFQUFFO0FBQVIsU0FBWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVJGLGVBV0U7QUFBSyxhQUFLLEVBQUU7QUFBRUEsY0FBSSxFQUFFO0FBQVIsU0FBWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVhGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWhERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FERjtBQW9FRCxDQS9FRDs7S0FBTU4sVztBQWdGU0EsMEVBQWYiLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvY29udGFjdC4wMmEyMGM2NWFlNmM5NDgxYjlhYy5ob3QtdXBkYXRlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IEJ1dHRvbiBmcm9tIFwiQGNvbXBvbmVudHMvYnV0dG9uL1ByaW1hcnlCdXR0b25JY29uUmlnaHRcIjtcblxuY29uc3QgQ29udGFjdEZvcm06IFJlYWN0LkZDID0gKCkgPT4ge1xuICBjb25zdCBkZXRhaWxzID0gW3tcbiAgICBjaXR5OiBcIkJhbmdhbG9yZVwiLFxuICAgIGFkZHJlc3M6IFsnMTk3LCA2dGggTWFpbiwgMXN0IENyb3NzLCcsICdIQUwgMm5kIFN0YWdlLCBJbmRpcmEgTmFnYXIsJywgJ0JlbmdhbHVydSA1NjAwMzgnLCAnKzkxLTgwLTI1MTk2MDAwJ11cbiAgfSwge1xuICAgIGNpdHk6IFwiREVMSElcIixcbiAgICBhZGRyZXNzOiBbJzR0aCBGbG9vciwgQXJpYSBUb3dlcnMsICcsICdKVyBNYXJyaW90dCwgQXNzZXQgQXJlYSA0LCcsICdBZXJvY2l0eSwgTmV3IERlbGhpLCAxMTAwMzcnLCAnKzkxLTExLTQ5NDk1MDAwJ11cbiAgfSwge1xuICAgIGNpdHk6IFwiTVVNQkFJXCIsXG4gICAgYWRkcmVzczogWyc2MDEtNjAyLCBDZWVqYXkgSG91c2UsJywgJ0RyIEFubmllIEJlc2FudCBSb2FkLCBXb3JsaSwnLCAnTXVtYmFpIDQwMDAxOCcsICcrOTEtMjItNjc2ODAwMDAnXVxuICB9XVxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgbS1hdXRvIHctMTEvMTJcdFwiIHN0eWxlPXt7IG1hcmdpblRvcDogMTAwLCBtYXJnaW5Cb3R0b206IDE1MCB9fT5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm93XCI+XG4gICAgICAgIDxkaXYgc3R5bGU9e3sgZmxleDogJzYwJScgfX0+XG4gICAgICAgICAgPGgxIGNsYXNzTmFtZT1cIm1haW4tdHh0IHRleHQtNHhsICBmb250LWJvbGRcIj5WaXN0IG91ciBJbmRpYSBBZHZpc29yeSBUZWFtIE9mZmljZXM8L2gxPlxuICAgICAgICAgIHtkZXRhaWxzLm1hcCgoZGF0YSkgPT4gKFxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3cgXCIgc3R5bGU9e3sgbWFyZ2luVG9wOiAnNTBweCcgfX0+XG4gICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZmxleDogJzY2JScgfX0gY2xhc3NOYW1lPVwiY29sLXNwYW4tOCBjb250YWN0LWFkZHJlc3NcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1hcC1pbmZvIGJvcmRlci1iLTIgbXItNSBwYi01XCI+XG4gICAgICAgICAgICAgICAgICA8YSBocmVmPVwiI1wiIGNsYXNzTmFtZT1cInVwcGVyY2FzZSBmb250LWJvbGQgdGV4dC14bCBib3JkZXItYi0zIGJiY1wiPntkYXRhLmNpdHl9PC9hPlxuICAgICAgICAgICAgICAgICAgPGhyIGNsYXNzTmFtZT1cInVuZGVyLWxpbmVcIiAvPlxuICAgICAgICAgICAgICAgICAgPHA+e2RhdGEuYWRkcmVzc1swXX0gPGJyIC8+e2RhdGEuYWRkcmVzc1sxXX0gPGJyIC8+IGRhdGEuYWRkcmVzc1syXSA8YnIgLz4gPGJyIC8+PGEgaHJlZj17ZGF0YS5hZGRyZXNzWzNdfT57ZGF0YS5hZGRyZXNzWzNdfTwvYT48L3A+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkaXJlY3Rpb24tbGlua1wiID5HRVQgRElSRUNUSU9OIDxzcGFuPjxpbWcgc3JjPScvaWNvbnMvYmxhY2tBcnJvdy5zdmcnIC8+PC9zcGFuPjwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBmbGV4OiAnNDQlJyB9fSBjbGFzc05hbWU9XCJjb2wtc3Bhbi00IHJlbGF0aXZlXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9J2NpdHktb3ZlcmxheSc+e2RhdGEuY2l0eX08L2Rpdj5cbiAgICAgICAgICAgICAgICA8aW1nIGNsYXNzTmFtZT0nY29udGFjdC1pbWcnIHNyYz1cIi4uLy4uL2ltZy9pbWFnZSAyNi5wbmdcIiBhbHQ9XCJcIiAvPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGFjdC1iZy1vdmVybGF5IFwiPjwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICkpfVxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBzdHlsZT17eyBmbGV4OiAnNDAlJyB9fT5cbiAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwibWFpbi10eHQgdGV4dC00eGwgbGc6dGV4dC0zeGwgZm9udC1ib2xkIGZvcm0taGVhZGluZ1wiPlNoYXJlIHlvdXIgQnVzaW5lc3MgUGxhbnM8L2gxPlxuICAgICAgICAgIDxmb3JtIGNsYXNzTmFtZT0nY29udGFjdC1mb3JtJz5cbiAgICAgICAgICAgIDxsYWJlbCA+TmFtZTwvbGFiZWw+XG4gICAgICAgICAgICA8aW5wdXQgdHlwZT1cInRleHRcIiBwbGFjZWhvbGRlcj1cIk5hbWVcIiAvPlxuICAgICAgICAgICAgPGxhYmVsID5Db21wYW55IE5hbWU8L2xhYmVsPlxuICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJ0ZXh0XCIgcGxhY2Vob2xkZXI9XCJDb21wYW55IE5hbWVcIiAvPlxuICAgICAgICAgICAgPGxhYmVsID5XaGF0IGFyZSB5b3UgYnVpbGRpbmc/PC9sYWJlbD5cbiAgICAgICAgICAgIDx0ZXh0YXJlYSBwbGFjZWhvbGRlcj1cIkNvbXBhbnkgQnJpZWZcIiAvPlxuICAgICAgICAgICAgPGxhYmVsID5GaWxlIEF0dGFjaG1lbnQ8L2xhYmVsPlxuICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJmaWxlXCIgLz5cbiAgICAgICAgICAgIDxsYWJlbCA+RW1haWwgSWQ8L2xhYmVsPlxuICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJlbWFpbFwiIHBsYWNlaG9sZGVyPVwiQ29udGFjdCBFbWFpbFwiIC8+XG4gICAgICAgICAgICA8bGFiZWwgPk1vYmlsZSBOdW1iZXI8L2xhYmVsPlxuICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJ0ZXh0XCIgcGxhY2Vob2xkZXI9XCJDb250YWN0IE51bWJlclwiIC8+XG4gICAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICAgIHRpdGxlPVwiQXBwbHlcIlxuICAgICAgICAgICAgICB1cmw9XCIvaWNvbnMvcmlnaHRBcnJvdy5zdmdcIlxuICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBjb25zb2xlLmxvZyhcInN1YnNjcmliZVwiKX1cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1sZyBsZWFkaW5nLTZcIlxuICAgICAgICAgICAgLz5cbiAgICAgICAgICA8L2Zvcm0+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIDxoMSBjbGFzc05hbWU9XCJtYWluLXR4dCB0ZXh0LTR4bCAgZm9udC1ib2xkXCIgc3R5bGU9e3sgbWFyZ2luVG9wOiAnNTBweCcgfX0+TWF0cml4IFBhcnRuZXJzIEdsb2JhbDwvaDE+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT0ncm93Jz5cbiAgICAgICAgPGRpdiBzdHlsZT17eyBmbGV4OiAnMjUlJyB9fT5cbiAgICAgICAgICA8cCBjbGFzc05hbWU9J21haW4tdHh0IHRleHQtM3hsIGZvbnQtYm9sZCc+VVNBPC9wPlxuICAgICAgICAgIDxociBjbGFzc05hbWU9XCJ1bmRlci1saW5lXCIgLz5cbiAgICAgICAgICA8cD5CT1NUT048L3A+XG4gICAgICAgICAgPHA+UEFMTyBBTFRPPC9wPlxuICAgICAgICAgIDxwPlNBTiBGUkFOQ0lTQ088L3A+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IHN0eWxlPXt7IGZsZXg6ICc1MCUnIH19PlxuICAgICAgICAgIHNkZmRzXG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IHN0eWxlPXt7IGZsZXg6ICcyNSUnIH19PlxuICAgICAgICAgIHNkZmRzXG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cblxuICAgIDwvZGl2PlxuICApXG59XG5leHBvcnQgZGVmYXVsdCBDb250YWN0Rm9ybTtcbiJdLCJzb3VyY2VSb290IjoiIn0=