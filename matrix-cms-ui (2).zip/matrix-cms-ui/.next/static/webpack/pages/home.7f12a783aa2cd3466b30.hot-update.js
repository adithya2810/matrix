webpackHotUpdate_N_E("pages/home",{

/***/ "./src/components/founder/Founder.tsx":
/*!********************************************!*\
  !*** ./src/components/founder/Founder.tsx ***!
  \********************************************/
/*! exports provided: Founder */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Founder", function() { return Founder; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var C_Users_KARTHIK_Documents_workspace_matrix_cms_ui_development_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @components */ "./src/components/index.ts");
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-slick */ "./node_modules/react-slick/lib/index.js");
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_slick__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! slick-carousel/slick/slick.css */ "./node_modules/slick-carousel/slick/slick.css");
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! slick-carousel/slick/slick-theme.css */ "./node_modules/slick-carousel/slick/slick-theme.css");
/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_6__);



var _jsxFileName = "C:\\Users\\KARTHIK\\Documents\\workspace\\matrix-cms-ui-development\\src\\components\\founder\\Founder.tsx",
    _this = undefined;

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { Object(C_Users_KARTHIK_Documents_workspace_matrix_cms_ui_development_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__["default"])(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }






var Founder = function Founder(_ref) {
  var className = _ref.className,
      _ref$style = _ref.style,
      style = _ref$style === void 0 ? {} : _ref$style;
  var heros = [{
    firstName: 'Bhavish',
    lastName: 'AGGARWAL',
    firstName1: null,
    lastName1: null,
    caption: 'Mobility',
    caption1: 'Electric Cars',
    logo: '/icons/ola.svg',
    image: '/icons/Bhavish_image.svg'
  }, {
    firstName: 'ROHIT',
    lastName: 'M.A.',
    firstName1: null,
    lastName1: null,
    caption: 'Healthcare',
    caption1: null,
    logo: '/icons/Cloudnine.svg',
    image: '/icons/Rohit_Treatment.svg'
  }, {
    firstName: 'ANINDYA',
    lastName: 'DUTTA',
    firstName1: 'SANDEEP',
    lastName1: 'DALMIA',
    caption: 'Student Housing Platform',
    caption1: null,
    logo: '/icons/Stanza.svg',
    image: '/icons/Anindya.svg'
  }, {
    firstName: 'Asish',
    lastName: 'MOHAPATRA',
    firstName1: null,
    lastName1: null,
    caption: 'Fintech',
    caption1: 'SME Lending',
    logo: '/icons/OfBusiness.svg',
    image: '/icons/Asish.svg'
  }, {
    firstName: 'Mr.',
    lastName: 'LAKSHIPATHY',
    firstName1: null,
    lastName1: null,
    caption: 'Fintech',
    caption1: 'NBFC',
    logo: '/icons/mx.svg',
    image: '/icons/Laxmipathy.svg'
  }, {
    firstName: 'CHAKRADHAR',
    lastName: 'GADE',
    firstName1: 'NITIN',
    lastName1: 'KAUSHAL',
    caption: 'Fintech',
    caption1: 'NBFC',
    logo: '/icons/Country.svg',
    image: '/icons/Chakradhar.svg'
  }];
  var settings = {
    dots: true,
    infinite: true,
    speed: 500,
    // autoplaySpeed: 2000,
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true
  };
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_slick__WEBPACK_IMPORTED_MODULE_4___default.a, _objectSpread(_objectSpread({}, settings), {}, {
    children: heros.map(function (hero) {
      return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "flex justify-between items-center",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "".concat(className),
          style: _objectSpread({
            width: 615.94,
            height: 863.91,
            position: "relative"
          }, style),
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "",
            style: {
              width: 571,
              height: 762,
              position: "absolute",
              background: "#083A4A",
              bottom: 50,
              left: 0
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 87,
            columnNumber: 13
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "",
            style: {
              width: 594,
              height: 788,
              bottom: 65,
              left: 15,
              position: "absolute",
              display: "flex",
              flexDirection: "column"
            },
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_3__["Image"], {
              src: hero.image,
              alt: "founder image",
              style: {
                flexGrow: 1
              }
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 91,
              columnNumber: 15
            }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_3__["Image"], {
              src: "/icons/rectangle.svg",
              alt: "reactangle",
              className: "absolute",
              style: {
                left: 38,
                bottom: 254
              }
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 92,
              columnNumber: 15
            }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              style: {
                height: 209,
                background: "#01576E"
              },
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "text-center flex items-center",
                style: {
                  height: 118,
                  borderBottom: "1px solid #EBEBE9"
                },
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h6", {
                  className: "font-bold text-secondary",
                  style: {
                    fontSize: 32,
                    lineHeight: "36px",
                    letterSpacing: "0.05em",
                    marginLeft: 31,
                    marginRight: 8
                  },
                  children: hero.firstName
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 96,
                  columnNumber: 19
                }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h6", {
                  className: "font-light text-secondary",
                  style: {
                    fontSize: 32,
                    lineHeight: "36px",
                    letterSpacing: "0.05em"
                  },
                  children: hero.lastName
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 99,
                  columnNumber: 19
                }, _this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 95,
                columnNumber: 17
              }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "flex justify-between items-center",
                style: {
                  height: 88
                },
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  style: {
                    marginLeft: 31,
                    display: 'flex',
                    justifyContent: 'space-around'
                  },
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                    className: "text-secondary font-medium text-lg leading-6",
                    children: [" ", hero.caption]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 106,
                    columnNumber: 21
                  }, _this), hero.caption1 && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                    className: "text-secondary font-medium text-lg leading-6",
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("hr", {
                      style: {
                        width: 30,
                        transform: 'rotate(90deg)'
                      }
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 107,
                      columnNumber: 102
                    }, _this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 107,
                    columnNumber: 39
                  }, _this), hero.caption1 && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                    className: "text-secondary font-medium text-lg leading-6",
                    children: [" ", hero.caption1]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 108,
                    columnNumber: 39
                  }, _this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 105,
                  columnNumber: 19
                }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_3__["Image"], {
                  src: hero.logo,
                  alt: "ola",
                  style: {
                    marginRight: 57
                  }
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 110,
                  columnNumber: 19
                }, _this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 104,
                columnNumber: 17
              }, _this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 94,
              columnNumber: 15
            }, _this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 88,
            columnNumber: 13
          }, _this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 86,
          columnNumber: 11
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h1", {
            children: "dgahag"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 115,
            columnNumber: 16
          }, _this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 115,
          columnNumber: 11
        }, _this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 85,
        columnNumber: 17
      }, _this);
    })
  }), void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 83,
    columnNumber: 5
  }, _this);
};
_c = Founder;

var _c;

$RefreshReg$(_c, "Founder");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vc3JjL2NvbXBvbmVudHMvZm91bmRlci9Gb3VuZGVyLnRzeCJdLCJuYW1lcyI6WyJGb3VuZGVyIiwiY2xhc3NOYW1lIiwic3R5bGUiLCJoZXJvcyIsImZpcnN0TmFtZSIsImxhc3ROYW1lIiwiZmlyc3ROYW1lMSIsImxhc3ROYW1lMSIsImNhcHRpb24iLCJjYXB0aW9uMSIsImxvZ28iLCJpbWFnZSIsInNldHRpbmdzIiwiZG90cyIsImluZmluaXRlIiwic3BlZWQiLCJzbGlkZXNUb1Nob3ciLCJzbGlkZXNUb1Njcm9sbCIsImF1dG9wbGF5IiwibWFwIiwiaGVybyIsIndpZHRoIiwiaGVpZ2h0IiwicG9zaXRpb24iLCJiYWNrZ3JvdW5kIiwiYm90dG9tIiwibGVmdCIsImRpc3BsYXkiLCJmbGV4RGlyZWN0aW9uIiwiZmxleEdyb3ciLCJib3JkZXJCb3R0b20iLCJmb250U2l6ZSIsImxpbmVIZWlnaHQiLCJsZXR0ZXJTcGFjaW5nIiwibWFyZ2luTGVmdCIsIm1hcmdpblJpZ2h0IiwianVzdGlmeUNvbnRlbnQiLCJ0cmFuc2Zvcm0iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBV08sSUFBTUEsT0FBd0IsR0FBRyxTQUEzQkEsT0FBMkIsT0FBK0I7QUFBQSxNQUE1QkMsU0FBNEIsUUFBNUJBLFNBQTRCO0FBQUEsd0JBQWpCQyxLQUFpQjtBQUFBLE1BQWpCQSxLQUFpQiwyQkFBVCxFQUFTO0FBQ3JFLE1BQU1DLEtBQUssR0FBRyxDQUFDO0FBQ2JDLGFBQVMsRUFBRSxTQURFO0FBRWJDLFlBQVEsRUFBRSxVQUZHO0FBR2JDLGNBQVUsRUFBRSxJQUhDO0FBSWJDLGFBQVMsRUFBRSxJQUpFO0FBS2JDLFdBQU8sRUFBRSxVQUxJO0FBTWJDLFlBQVEsRUFBRSxlQU5HO0FBT2JDLFFBQUksRUFBRSxnQkFQTztBQVFiQyxTQUFLLEVBQUU7QUFSTSxHQUFELEVBU1g7QUFDRFAsYUFBUyxFQUFFLE9BRFY7QUFFREMsWUFBUSxFQUFFLE1BRlQ7QUFHREMsY0FBVSxFQUFFLElBSFg7QUFJREMsYUFBUyxFQUFFLElBSlY7QUFLREMsV0FBTyxFQUFFLFlBTFI7QUFNREMsWUFBUSxFQUFFLElBTlQ7QUFPREMsUUFBSSxFQUFFLHNCQVBMO0FBUURDLFNBQUssRUFBRTtBQVJOLEdBVFcsRUFrQlg7QUFDRFAsYUFBUyxFQUFFLFNBRFY7QUFFREMsWUFBUSxFQUFFLE9BRlQ7QUFHREMsY0FBVSxFQUFFLFNBSFg7QUFJREMsYUFBUyxFQUFFLFFBSlY7QUFLREMsV0FBTyxFQUFFLDBCQUxSO0FBTURDLFlBQVEsRUFBRSxJQU5UO0FBT0RDLFFBQUksRUFBRSxtQkFQTDtBQVFEQyxTQUFLLEVBQUU7QUFSTixHQWxCVyxFQTJCWDtBQUNEUCxhQUFTLEVBQUUsT0FEVjtBQUVEQyxZQUFRLEVBQUUsV0FGVDtBQUdEQyxjQUFVLEVBQUUsSUFIWDtBQUlEQyxhQUFTLEVBQUUsSUFKVjtBQUtEQyxXQUFPLEVBQUUsU0FMUjtBQU1EQyxZQUFRLEVBQUUsYUFOVDtBQU9EQyxRQUFJLEVBQUUsdUJBUEw7QUFRREMsU0FBSyxFQUFFO0FBUk4sR0EzQlcsRUFvQ1g7QUFDRFAsYUFBUyxFQUFFLEtBRFY7QUFFREMsWUFBUSxFQUFFLGFBRlQ7QUFHREMsY0FBVSxFQUFFLElBSFg7QUFJREMsYUFBUyxFQUFFLElBSlY7QUFLREMsV0FBTyxFQUFFLFNBTFI7QUFNREMsWUFBUSxFQUFFLE1BTlQ7QUFPREMsUUFBSSxFQUFFLGVBUEw7QUFRREMsU0FBSyxFQUFFO0FBUk4sR0FwQ1csRUE2Q1g7QUFDRFAsYUFBUyxFQUFFLFlBRFY7QUFFREMsWUFBUSxFQUFFLE1BRlQ7QUFHREMsY0FBVSxFQUFFLE9BSFg7QUFJREMsYUFBUyxFQUFFLFNBSlY7QUFLREMsV0FBTyxFQUFFLFNBTFI7QUFNREMsWUFBUSxFQUFFLE1BTlQ7QUFPREMsUUFBSSxFQUFFLG9CQVBMO0FBUURDLFNBQUssRUFBRTtBQVJOLEdBN0NXLENBQWQ7QUF3REEsTUFBTUMsUUFBUSxHQUFHO0FBQ2ZDLFFBQUksRUFBRSxJQURTO0FBRWZDLFlBQVEsRUFBRSxJQUZLO0FBR2ZDLFNBQUssRUFBRSxHQUhRO0FBSWY7QUFDQUMsZ0JBQVksRUFBRSxDQUxDO0FBTWZDLGtCQUFjLEVBQUUsQ0FORDtBQU9mQyxZQUFRLEVBQUU7QUFQSyxHQUFqQjtBQVNBLHNCQUNFLHFFQUFDLGtEQUFELGtDQUFZTixRQUFaO0FBQUEsY0FDR1QsS0FBSyxDQUFDZ0IsR0FBTixDQUFVLFVBQUFDLElBQUksRUFBSTtBQUNqQiwwQkFBUTtBQUFLLGlCQUFTLEVBQUMsbUNBQWY7QUFBQSxnQ0FDTjtBQUFLLG1CQUFTLFlBQUtuQixTQUFMLENBQWQ7QUFBZ0MsZUFBSztBQUFJb0IsaUJBQUssRUFBRSxNQUFYO0FBQW1CQyxrQkFBTSxFQUFFLE1BQTNCO0FBQW1DQyxvQkFBUSxFQUFFO0FBQTdDLGFBQTREckIsS0FBNUQsQ0FBckM7QUFBQSxrQ0FDRTtBQUFLLHFCQUFTLEVBQUMsRUFBZjtBQUFrQixpQkFBSyxFQUFFO0FBQUVtQixtQkFBSyxFQUFFLEdBQVQ7QUFBY0Msb0JBQU0sRUFBRSxHQUF0QjtBQUEyQkMsc0JBQVEsRUFBRSxVQUFyQztBQUFpREMsd0JBQVUsRUFBRSxTQUE3RDtBQUF3RUMsb0JBQU0sRUFBRSxFQUFoRjtBQUFvRkMsa0JBQUksRUFBRTtBQUExRjtBQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURGLGVBRUU7QUFDRSxxQkFBUyxFQUFDLEVBRFo7QUFFRSxpQkFBSyxFQUFFO0FBQUVMLG1CQUFLLEVBQUUsR0FBVDtBQUFjQyxvQkFBTSxFQUFFLEdBQXRCO0FBQTJCRyxvQkFBTSxFQUFFLEVBQW5DO0FBQXVDQyxrQkFBSSxFQUFFLEVBQTdDO0FBQWlESCxzQkFBUSxFQUFFLFVBQTNEO0FBQXVFSSxxQkFBTyxFQUFFLE1BQWhGO0FBQXdGQywyQkFBYSxFQUFFO0FBQXZHLGFBRlQ7QUFBQSxvQ0FHRSxxRUFBQyxpREFBRDtBQUFPLGlCQUFHLEVBQUVSLElBQUksQ0FBQ1QsS0FBakI7QUFBd0IsaUJBQUcsRUFBQyxlQUE1QjtBQUE0QyxtQkFBSyxFQUFFO0FBQUVrQix3QkFBUSxFQUFFO0FBQVo7QUFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFIRixlQUlFLHFFQUFDLGlEQUFEO0FBQU8saUJBQUcsRUFBQyxzQkFBWDtBQUFrQyxpQkFBRyxFQUFFLFlBQXZDO0FBQXFELHVCQUFTLEVBQUMsVUFBL0Q7QUFBMEUsbUJBQUssRUFBRTtBQUFFSCxvQkFBSSxFQUFFLEVBQVI7QUFBWUQsc0JBQU0sRUFBRTtBQUFwQjtBQUFqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUpGLGVBTUU7QUFBSyxtQkFBSyxFQUFFO0FBQUVILHNCQUFNLEVBQUUsR0FBVjtBQUFlRSwwQkFBVSxFQUFFO0FBQTNCLGVBQVo7QUFBQSxzQ0FDRTtBQUFLLHlCQUFTLEVBQUMsK0JBQWY7QUFBK0MscUJBQUssRUFBRTtBQUFFRix3QkFBTSxFQUFFLEdBQVY7QUFBZVEsOEJBQVksRUFBRTtBQUE3QixpQkFBdEQ7QUFBQSx3Q0FDRTtBQUFJLDJCQUFTLEVBQUMsMEJBQWQ7QUFBeUMsdUJBQUssRUFBRTtBQUFFQyw0QkFBUSxFQUFFLEVBQVo7QUFBZ0JDLDhCQUFVLEVBQUUsTUFBNUI7QUFBb0NDLGlDQUFhLEVBQUUsUUFBbkQ7QUFBNkRDLDhCQUFVLEVBQUUsRUFBekU7QUFBNkVDLCtCQUFXLEVBQUU7QUFBMUYsbUJBQWhEO0FBQUEsNEJBQ0dmLElBQUksQ0FBQ2hCO0FBRFI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFERixlQUlFO0FBQUksMkJBQVMsRUFBQywyQkFBZDtBQUEwQyx1QkFBSyxFQUFFO0FBQUUyQiw0QkFBUSxFQUFFLEVBQVo7QUFBZ0JDLDhCQUFVLEVBQUUsTUFBNUI7QUFBb0NDLGlDQUFhLEVBQUU7QUFBbkQsbUJBQWpEO0FBQUEsNEJBQ0diLElBQUksQ0FBQ2Y7QUFEUjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFERixlQVVFO0FBQUsseUJBQVMsRUFBQyxtQ0FBZjtBQUFtRCxxQkFBSyxFQUFFO0FBQUVpQix3QkFBTSxFQUFFO0FBQVYsaUJBQTFEO0FBQUEsd0NBQ0U7QUFBSyx1QkFBSyxFQUFFO0FBQUVZLDhCQUFVLEVBQUUsRUFBZDtBQUFrQlAsMkJBQU8sRUFBRSxNQUEzQjtBQUFtQ1Msa0NBQWMsRUFBRTtBQUFuRCxtQkFBWjtBQUFBLDBDQUNFO0FBQU0sNkJBQVMsRUFBQyw4Q0FBaEI7QUFBQSxvQ0FBaUVoQixJQUFJLENBQUNaLE9BQXRFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFERixFQUVHWSxJQUFJLENBQUNYLFFBQUwsaUJBQWlCO0FBQU0sNkJBQVMsRUFBQyw4Q0FBaEI7QUFBQSwyQ0FBK0Q7QUFBSSwyQkFBSyxFQUFFO0FBQUVZLDZCQUFLLEVBQUUsRUFBVDtBQUFhZ0IsaUNBQVMsRUFBRTtBQUF4QjtBQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFGcEIsRUFHR2pCLElBQUksQ0FBQ1gsUUFBTCxpQkFBaUI7QUFBTSw2QkFBUyxFQUFDLDhDQUFoQjtBQUFBLG9DQUFpRVcsSUFBSSxDQUFDWCxRQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBSHBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFERixlQU1FLHFFQUFDLGlEQUFEO0FBQU8scUJBQUcsRUFBRVcsSUFBSSxDQUFDVixJQUFqQjtBQUF1QixxQkFBRyxFQUFFLEtBQTVCO0FBQW1DLHVCQUFLLEVBQUU7QUFBRXlCLCtCQUFXLEVBQUU7QUFBZjtBQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFETSxlQThCTjtBQUFBLGlDQUFLO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUw7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkE5Qk07QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQVI7QUFnQ0QsS0FqQ0E7QUFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBREY7QUEwQ0QsQ0E1R007S0FBTW5DLE8iLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvaG9tZS43ZjEyYTc4M2FhMmNkMzQ2NmIzMC5ob3QtdXBkYXRlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgSW1hZ2UgfSBmcm9tIFwiQGNvbXBvbmVudHNcIjtcbmltcG9ydCBTbGlkZXIgZnJvbSBcInJlYWN0LXNsaWNrXCI7XG5pbXBvcnQgXCJzbGljay1jYXJvdXNlbC9zbGljay9zbGljay5jc3NcIjtcbmltcG9ydCBcInNsaWNrLWNhcm91c2VsL3NsaWNrL3NsaWNrLXRoZW1lLmNzc1wiO1xuXG5leHBvcnQgdHlwZSBQcm9wcyA9IHtcbiAgbmFtZXM/OiBBcnJheTxzdHJpbmc+O1xuICBiYWNrZ3JvdW5kX3VybD86IHN0cmluZztcbiAgdGFncz86IEFycmF5PHN0cmluZz47XG4gIGxvZ28/OiBzdHJpbmc7XG4gIGNsYXNzTmFtZT86IHN0cmluZztcbiAgc3R5bGU/OiBhbnk7XG59O1xuXG5leHBvcnQgY29uc3QgRm91bmRlcjogUmVhY3QuRkM8UHJvcHM+ID0gKHsgY2xhc3NOYW1lLCBzdHlsZSA9IHt9IH0pID0+IHtcbiAgY29uc3QgaGVyb3MgPSBbe1xuICAgIGZpcnN0TmFtZTogJ0JoYXZpc2gnLFxuICAgIGxhc3ROYW1lOiAnQUdHQVJXQUwnLFxuICAgIGZpcnN0TmFtZTE6IG51bGwsXG4gICAgbGFzdE5hbWUxOiBudWxsLFxuICAgIGNhcHRpb246ICdNb2JpbGl0eScsXG4gICAgY2FwdGlvbjE6ICdFbGVjdHJpYyBDYXJzJyxcbiAgICBsb2dvOiAnL2ljb25zL29sYS5zdmcnLFxuICAgIGltYWdlOiAnL2ljb25zL0JoYXZpc2hfaW1hZ2Uuc3ZnJ1xuICB9LCB7XG4gICAgZmlyc3ROYW1lOiAnUk9ISVQnLFxuICAgIGxhc3ROYW1lOiAnTS5BLicsXG4gICAgZmlyc3ROYW1lMTogbnVsbCxcbiAgICBsYXN0TmFtZTE6IG51bGwsXG4gICAgY2FwdGlvbjogJ0hlYWx0aGNhcmUnLFxuICAgIGNhcHRpb24xOiBudWxsLFxuICAgIGxvZ286ICcvaWNvbnMvQ2xvdWRuaW5lLnN2ZycsXG4gICAgaW1hZ2U6ICcvaWNvbnMvUm9oaXRfVHJlYXRtZW50LnN2ZydcbiAgfSwge1xuICAgIGZpcnN0TmFtZTogJ0FOSU5EWUEnLFxuICAgIGxhc3ROYW1lOiAnRFVUVEEnLFxuICAgIGZpcnN0TmFtZTE6ICdTQU5ERUVQJyxcbiAgICBsYXN0TmFtZTE6ICdEQUxNSUEnLFxuICAgIGNhcHRpb246ICdTdHVkZW50IEhvdXNpbmcgUGxhdGZvcm0nLFxuICAgIGNhcHRpb24xOiBudWxsLFxuICAgIGxvZ286ICcvaWNvbnMvU3RhbnphLnN2ZycsXG4gICAgaW1hZ2U6ICcvaWNvbnMvQW5pbmR5YS5zdmcnXG4gIH0sIHtcbiAgICBmaXJzdE5hbWU6ICdBc2lzaCcsXG4gICAgbGFzdE5hbWU6ICdNT0hBUEFUUkEnLFxuICAgIGZpcnN0TmFtZTE6IG51bGwsXG4gICAgbGFzdE5hbWUxOiBudWxsLFxuICAgIGNhcHRpb246ICdGaW50ZWNoJyxcbiAgICBjYXB0aW9uMTogJ1NNRSBMZW5kaW5nJyxcbiAgICBsb2dvOiAnL2ljb25zL09mQnVzaW5lc3Muc3ZnJyxcbiAgICBpbWFnZTogJy9pY29ucy9Bc2lzaC5zdmcnXG4gIH0sIHtcbiAgICBmaXJzdE5hbWU6ICdNci4nLFxuICAgIGxhc3ROYW1lOiAnTEFLU0hJUEFUSFknLFxuICAgIGZpcnN0TmFtZTE6IG51bGwsXG4gICAgbGFzdE5hbWUxOiBudWxsLFxuICAgIGNhcHRpb246ICdGaW50ZWNoJyxcbiAgICBjYXB0aW9uMTogJ05CRkMnLFxuICAgIGxvZ286ICcvaWNvbnMvbXguc3ZnJyxcbiAgICBpbWFnZTogJy9pY29ucy9MYXhtaXBhdGh5LnN2ZydcbiAgfSwge1xuICAgIGZpcnN0TmFtZTogJ0NIQUtSQURIQVInLFxuICAgIGxhc3ROYW1lOiAnR0FERScsXG4gICAgZmlyc3ROYW1lMTogJ05JVElOJyxcbiAgICBsYXN0TmFtZTE6ICdLQVVTSEFMJyxcbiAgICBjYXB0aW9uOiAnRmludGVjaCcsXG4gICAgY2FwdGlvbjE6ICdOQkZDJyxcbiAgICBsb2dvOiAnL2ljb25zL0NvdW50cnkuc3ZnJyxcbiAgICBpbWFnZTogJy9pY29ucy9DaGFrcmFkaGFyLnN2ZydcbiAgfV1cblxuICBjb25zdCBzZXR0aW5ncyA9IHtcbiAgICBkb3RzOiB0cnVlLFxuICAgIGluZmluaXRlOiB0cnVlLFxuICAgIHNwZWVkOiA1MDAsXG4gICAgLy8gYXV0b3BsYXlTcGVlZDogMjAwMCxcbiAgICBzbGlkZXNUb1Nob3c6IDEsXG4gICAgc2xpZGVzVG9TY3JvbGw6IDEsXG4gICAgYXV0b3BsYXk6IHRydWVcbiAgfTtcbiAgcmV0dXJuIChcbiAgICA8U2xpZGVyIHsuLi5zZXR0aW5nc30+XG4gICAgICB7aGVyb3MubWFwKGhlcm8gPT4ge1xuICAgICAgICByZXR1cm4gKDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyXCI+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2Ake2NsYXNzTmFtZX1gfSBzdHlsZT17eyB3aWR0aDogNjE1Ljk0LCBoZWlnaHQ6IDg2My45MSwgcG9zaXRpb246IFwicmVsYXRpdmVcIiwgLi4uc3R5bGUsIH19PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJcIiBzdHlsZT17eyB3aWR0aDogNTcxLCBoZWlnaHQ6IDc2MiwgcG9zaXRpb246IFwiYWJzb2x1dGVcIiwgYmFja2dyb3VuZDogXCIjMDgzQTRBXCIsIGJvdHRvbTogNTAsIGxlZnQ6IDAsIH19PjwvZGl2PlxuICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJcIlxuICAgICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogNTk0LCBoZWlnaHQ6IDc4OCwgYm90dG9tOiA2NSwgbGVmdDogMTUsIHBvc2l0aW9uOiBcImFic29sdXRlXCIsIGRpc3BsYXk6IFwiZmxleFwiLCBmbGV4RGlyZWN0aW9uOiBcImNvbHVtblwiLCB9fT5cbiAgICAgICAgICAgICAgPEltYWdlIHNyYz17aGVyby5pbWFnZX0gYWx0PVwiZm91bmRlciBpbWFnZVwiIHN0eWxlPXt7IGZsZXhHcm93OiAxIH19PjwvSW1hZ2U+XG4gICAgICAgICAgICAgIDxJbWFnZSBzcmM9XCIvaWNvbnMvcmVjdGFuZ2xlLnN2Z1wiIGFsdD17XCJyZWFjdGFuZ2xlXCJ9IGNsYXNzTmFtZT1cImFic29sdXRlXCIgc3R5bGU9e3sgbGVmdDogMzgsIGJvdHRvbTogMjU0IH19IC8+XG5cbiAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBoZWlnaHQ6IDIwOSwgYmFja2dyb3VuZDogXCIjMDE1NzZFXCIgfX0+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBmbGV4IGl0ZW1zLWNlbnRlclwiIHN0eWxlPXt7IGhlaWdodDogMTE4LCBib3JkZXJCb3R0b206IFwiMXB4IHNvbGlkICNFQkVCRTlcIiB9fT5cbiAgICAgICAgICAgICAgICAgIDxoNiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zZWNvbmRhcnlcIiBzdHlsZT17eyBmb250U2l6ZTogMzIsIGxpbmVIZWlnaHQ6IFwiMzZweFwiLCBsZXR0ZXJTcGFjaW5nOiBcIjAuMDVlbVwiLCBtYXJnaW5MZWZ0OiAzMSwgbWFyZ2luUmlnaHQ6IDgsIH19PlxuICAgICAgICAgICAgICAgICAgICB7aGVyby5maXJzdE5hbWV9XG4gICAgICAgICAgICAgICAgICA8L2g2PlxuICAgICAgICAgICAgICAgICAgPGg2IGNsYXNzTmFtZT1cImZvbnQtbGlnaHQgdGV4dC1zZWNvbmRhcnlcIiBzdHlsZT17eyBmb250U2l6ZTogMzIsIGxpbmVIZWlnaHQ6IFwiMzZweFwiLCBsZXR0ZXJTcGFjaW5nOiBcIjAuMDVlbVwiLCB9fT5cbiAgICAgICAgICAgICAgICAgICAge2hlcm8ubGFzdE5hbWV9XG4gICAgICAgICAgICAgICAgICA8L2g2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXJcIiBzdHlsZT17eyBoZWlnaHQ6IDg4IH19PlxuICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBtYXJnaW5MZWZ0OiAzMSwgZGlzcGxheTogJ2ZsZXgnLCBqdXN0aWZ5Q29udGVudDogJ3NwYWNlLWFyb3VuZCcgfX0+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2Vjb25kYXJ5IGZvbnQtbWVkaXVtIHRleHQtbGcgbGVhZGluZy02XCI+IHtoZXJvLmNhcHRpb259PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICB7aGVyby5jYXB0aW9uMSAmJiA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNlY29uZGFyeSBmb250LW1lZGl1bSB0ZXh0LWxnIGxlYWRpbmctNlwiPjxociBzdHlsZT17eyB3aWR0aDogMzAsIHRyYW5zZm9ybTogJ3JvdGF0ZSg5MGRlZyknIH19IC8+PC9zcGFuPn1cbiAgICAgICAgICAgICAgICAgICAge2hlcm8uY2FwdGlvbjEgJiYgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zZWNvbmRhcnkgZm9udC1tZWRpdW0gdGV4dC1sZyBsZWFkaW5nLTZcIj4ge2hlcm8uY2FwdGlvbjF9PC9zcGFuPn1cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPEltYWdlIHNyYz17aGVyby5sb2dvfSBhbHQ9e1wib2xhXCJ9IHN0eWxlPXt7IG1hcmdpblJpZ2h0OiA1NyB9fSAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXY+PGgxPmRnYWhhZzwvaDE+PC9kaXY+XG4gICAgICAgIDwvZGl2PilcbiAgICAgIH0pfVxuXG5cblxuXG4gICAgPC9TbGlkZXI+XG4gICk7XG59O1xuIl0sInNvdXJjZVJvb3QiOiIifQ==