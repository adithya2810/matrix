webpackHotUpdate_N_E("pages/home",{

/***/ "./src/components/founder/Founder.tsx":
/*!********************************************!*\
  !*** ./src/components/founder/Founder.tsx ***!
  \********************************************/
/*! exports provided: Founder */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Founder", function() { return Founder; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var C_Users_KARTHIK_Documents_workspace_matrix_cms_ui_development_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @components */ "./src/components/index.ts");
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-slick */ "./node_modules/react-slick/lib/index.js");
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_slick__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! slick-carousel/slick/slick.css */ "./node_modules/slick-carousel/slick/slick.css");
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! slick-carousel/slick/slick-theme.css */ "./node_modules/slick-carousel/slick/slick-theme.css");
/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_6__);



var _jsxFileName = "C:\\Users\\KARTHIK\\Documents\\workspace\\matrix-cms-ui-development\\src\\components\\founder\\Founder.tsx",
    _this = undefined;

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { Object(C_Users_KARTHIK_Documents_workspace_matrix_cms_ui_development_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__["default"])(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }






var Founder = function Founder(_ref) {
  var className = _ref.className,
      _ref$style = _ref.style,
      style = _ref$style === void 0 ? {} : _ref$style;
  var heros = [{
    firstName: 'Bhavish',
    lastName: 'AGGARWAL',
    firstName1: null,
    lastName1: null,
    caption: 'Mobility',
    caption1: 'Electric Cars',
    logo: '/icons/ola.svg',
    image: '/icons/Bhavish_image.svg'
  }, {
    firstName: 'ROHIT',
    lastName: 'M.A.',
    firstName1: null,
    lastName1: null,
    caption: 'Healthcare',
    caption1: null,
    logo: '/icons/Cloudnine.svg',
    image: '/icons/Rohit_Treatment.svg'
  }, {
    firstName: 'ANINDYA',
    lastName: 'DUTTA',
    firstName1: 'SANDEEP',
    lastName1: 'DALMIA',
    caption: 'Student Housing Platform',
    caption1: null,
    logo: '/icons/Stanza.svg',
    image: '/icons/Anindya.svg'
  }, {
    firstName: 'Asish',
    lastName: 'MOHAPATRA',
    firstName1: null,
    lastName1: null,
    caption: 'Fintech',
    caption1: 'SME Lending',
    logo: '/icons/OfBusiness.svg',
    image: '/icons/Asish.svg'
  }, {
    firstName: 'Mr.',
    lastName: 'LAKSHIPATHY',
    firstName1: null,
    lastName1: null,
    caption: 'Fintech',
    caption1: 'NBFC',
    logo: '/icons/mx.svg',
    image: '/icons/Laxmipathy.svg'
  }, {
    firstName: 'CHAKRADHAR',
    lastName: 'GADE',
    firstName1: 'NITIN',
    lastName1: 'KAUSHAL',
    caption: 'Fintech',
    caption1: 'NBFC',
    logo: '/icons/Country.svg',
    image: '/icons/Chakradhar.svg'
  }];
  var settings = {
    dots: true,
    infinite: true,
    speed: 500,
    autoplaySpeed: 5000,
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true
  };
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_slick__WEBPACK_IMPORTED_MODULE_4___default.a, _objectSpread(_objectSpread({}, settings), {}, {
    children: heros.map(function (hero) {
      return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "row",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "col",
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "".concat(className, " col"),
            style: _objectSpread({
              width: 615.94,
              height: 863.91,
              position: "relative"
            }, style),
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "",
              style: {
                width: 571,
                height: 762,
                position: "absolute",
                background: "#083A4A",
                bottom: 50,
                left: 0
              }
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 88,
              columnNumber: 15
            }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "",
              style: {
                width: 594,
                height: 788,
                bottom: 65,
                left: 15,
                position: "absolute",
                display: "flex",
                flexDirection: "column"
              },
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_3__["Image"], {
                src: hero.image,
                alt: "founder image",
                style: {
                  flexGrow: 1
                }
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 92,
                columnNumber: 17
              }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_3__["Image"], {
                src: "/icons/rectangle.svg",
                alt: "reactangle",
                className: "absolute",
                style: {
                  left: 38,
                  bottom: 254
                }
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 93,
                columnNumber: 17
              }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                style: {
                  height: 209,
                  background: "#01576E"
                },
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "text-center flex items-center",
                  style: {
                    height: 118,
                    borderBottom: "1px solid #EBEBE9"
                  },
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h6", {
                    className: "font-bold text-secondary",
                    style: {
                      fontSize: 32,
                      lineHeight: "36px",
                      letterSpacing: "0.05em",
                      marginLeft: 31,
                      marginRight: 8
                    },
                    children: hero.firstName
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 97,
                    columnNumber: 21
                  }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h6", {
                    className: "font-light text-secondary",
                    style: {
                      fontSize: 32,
                      lineHeight: "36px",
                      letterSpacing: "0.05em"
                    },
                    children: hero.lastName
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 100,
                    columnNumber: 21
                  }, _this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 96,
                  columnNumber: 19
                }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  className: "flex justify-between items-center",
                  style: {
                    height: 88
                  },
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                    style: {
                      marginLeft: 31,
                      display: 'flex',
                      justifyContent: 'space-around'
                    },
                    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                      className: "text-secondary font-medium text-lg leading-6",
                      children: [" ", hero.caption]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 107,
                      columnNumber: 23
                    }, _this), hero.caption1 && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                      className: "text-secondary font-medium text-lg leading-6",
                      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("hr", {
                        style: {
                          width: 30,
                          transform: 'rotate(90deg)'
                        }
                      }, void 0, false, {
                        fileName: _jsxFileName,
                        lineNumber: 108,
                        columnNumber: 104
                      }, _this)
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 108,
                      columnNumber: 41
                    }, _this), hero.caption1 && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                      className: "text-secondary font-medium text-lg leading-6",
                      children: [" ", hero.caption1]
                    }, void 0, true, {
                      fileName: _jsxFileName,
                      lineNumber: 109,
                      columnNumber: 41
                    }, _this)]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 106,
                    columnNumber: 21
                  }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_3__["Image"], {
                    src: hero.logo,
                    alt: "ola",
                    style: {
                      marginRight: 57
                    }
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 111,
                    columnNumber: 21
                  }, _this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 105,
                  columnNumber: 19
                }, _this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 95,
                columnNumber: 17
              }, _this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 89,
              columnNumber: 15
            }, _this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 87,
            columnNumber: 13
          }, _this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 86,
          columnNumber: 11
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "col",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "col",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h1", {
              children: "kathik"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 118,
              columnNumber: 34
            }, _this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 118,
            columnNumber: 13
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "col",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h1", {
              children: "kathik"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 119,
              columnNumber: 34
            }, _this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 119,
            columnNumber: 13
          }, _this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 117,
          columnNumber: 11
        }, _this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 85,
        columnNumber: 17
      }, _this);
    })
  }), void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 83,
    columnNumber: 5
  }, _this);
};
_c = Founder;

var _c;

$RefreshReg$(_c, "Founder");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vc3JjL2NvbXBvbmVudHMvZm91bmRlci9Gb3VuZGVyLnRzeCJdLCJuYW1lcyI6WyJGb3VuZGVyIiwiY2xhc3NOYW1lIiwic3R5bGUiLCJoZXJvcyIsImZpcnN0TmFtZSIsImxhc3ROYW1lIiwiZmlyc3ROYW1lMSIsImxhc3ROYW1lMSIsImNhcHRpb24iLCJjYXB0aW9uMSIsImxvZ28iLCJpbWFnZSIsInNldHRpbmdzIiwiZG90cyIsImluZmluaXRlIiwic3BlZWQiLCJhdXRvcGxheVNwZWVkIiwic2xpZGVzVG9TaG93Iiwic2xpZGVzVG9TY3JvbGwiLCJhdXRvcGxheSIsIm1hcCIsImhlcm8iLCJ3aWR0aCIsImhlaWdodCIsInBvc2l0aW9uIiwiYmFja2dyb3VuZCIsImJvdHRvbSIsImxlZnQiLCJkaXNwbGF5IiwiZmxleERpcmVjdGlvbiIsImZsZXhHcm93IiwiYm9yZGVyQm90dG9tIiwiZm9udFNpemUiLCJsaW5lSGVpZ2h0IiwibGV0dGVyU3BhY2luZyIsIm1hcmdpbkxlZnQiLCJtYXJnaW5SaWdodCIsImp1c3RpZnlDb250ZW50IiwidHJhbnNmb3JtIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQVdPLElBQU1BLE9BQXdCLEdBQUcsU0FBM0JBLE9BQTJCLE9BQStCO0FBQUEsTUFBNUJDLFNBQTRCLFFBQTVCQSxTQUE0QjtBQUFBLHdCQUFqQkMsS0FBaUI7QUFBQSxNQUFqQkEsS0FBaUIsMkJBQVQsRUFBUztBQUNyRSxNQUFNQyxLQUFLLEdBQUcsQ0FBQztBQUNiQyxhQUFTLEVBQUUsU0FERTtBQUViQyxZQUFRLEVBQUUsVUFGRztBQUdiQyxjQUFVLEVBQUUsSUFIQztBQUliQyxhQUFTLEVBQUUsSUFKRTtBQUtiQyxXQUFPLEVBQUUsVUFMSTtBQU1iQyxZQUFRLEVBQUUsZUFORztBQU9iQyxRQUFJLEVBQUUsZ0JBUE87QUFRYkMsU0FBSyxFQUFFO0FBUk0sR0FBRCxFQVNYO0FBQ0RQLGFBQVMsRUFBRSxPQURWO0FBRURDLFlBQVEsRUFBRSxNQUZUO0FBR0RDLGNBQVUsRUFBRSxJQUhYO0FBSURDLGFBQVMsRUFBRSxJQUpWO0FBS0RDLFdBQU8sRUFBRSxZQUxSO0FBTURDLFlBQVEsRUFBRSxJQU5UO0FBT0RDLFFBQUksRUFBRSxzQkFQTDtBQVFEQyxTQUFLLEVBQUU7QUFSTixHQVRXLEVBa0JYO0FBQ0RQLGFBQVMsRUFBRSxTQURWO0FBRURDLFlBQVEsRUFBRSxPQUZUO0FBR0RDLGNBQVUsRUFBRSxTQUhYO0FBSURDLGFBQVMsRUFBRSxRQUpWO0FBS0RDLFdBQU8sRUFBRSwwQkFMUjtBQU1EQyxZQUFRLEVBQUUsSUFOVDtBQU9EQyxRQUFJLEVBQUUsbUJBUEw7QUFRREMsU0FBSyxFQUFFO0FBUk4sR0FsQlcsRUEyQlg7QUFDRFAsYUFBUyxFQUFFLE9BRFY7QUFFREMsWUFBUSxFQUFFLFdBRlQ7QUFHREMsY0FBVSxFQUFFLElBSFg7QUFJREMsYUFBUyxFQUFFLElBSlY7QUFLREMsV0FBTyxFQUFFLFNBTFI7QUFNREMsWUFBUSxFQUFFLGFBTlQ7QUFPREMsUUFBSSxFQUFFLHVCQVBMO0FBUURDLFNBQUssRUFBRTtBQVJOLEdBM0JXLEVBb0NYO0FBQ0RQLGFBQVMsRUFBRSxLQURWO0FBRURDLFlBQVEsRUFBRSxhQUZUO0FBR0RDLGNBQVUsRUFBRSxJQUhYO0FBSURDLGFBQVMsRUFBRSxJQUpWO0FBS0RDLFdBQU8sRUFBRSxTQUxSO0FBTURDLFlBQVEsRUFBRSxNQU5UO0FBT0RDLFFBQUksRUFBRSxlQVBMO0FBUURDLFNBQUssRUFBRTtBQVJOLEdBcENXLEVBNkNYO0FBQ0RQLGFBQVMsRUFBRSxZQURWO0FBRURDLFlBQVEsRUFBRSxNQUZUO0FBR0RDLGNBQVUsRUFBRSxPQUhYO0FBSURDLGFBQVMsRUFBRSxTQUpWO0FBS0RDLFdBQU8sRUFBRSxTQUxSO0FBTURDLFlBQVEsRUFBRSxNQU5UO0FBT0RDLFFBQUksRUFBRSxvQkFQTDtBQVFEQyxTQUFLLEVBQUU7QUFSTixHQTdDVyxDQUFkO0FBd0RBLE1BQU1DLFFBQVEsR0FBRztBQUNmQyxRQUFJLEVBQUUsSUFEUztBQUVmQyxZQUFRLEVBQUUsSUFGSztBQUdmQyxTQUFLLEVBQUUsR0FIUTtBQUlmQyxpQkFBYSxFQUFFLElBSkE7QUFLZkMsZ0JBQVksRUFBRSxDQUxDO0FBTWZDLGtCQUFjLEVBQUUsQ0FORDtBQU9mQyxZQUFRLEVBQUU7QUFQSyxHQUFqQjtBQVNBLHNCQUNFLHFFQUFDLGtEQUFELGtDQUFZUCxRQUFaO0FBQUEsY0FDR1QsS0FBSyxDQUFDaUIsR0FBTixDQUFVLFVBQUFDLElBQUksRUFBSTtBQUNqQiwwQkFBUTtBQUFLLGlCQUFTLEVBQUMsS0FBZjtBQUFBLGdDQUNOO0FBQUssbUJBQVMsRUFBQyxLQUFmO0FBQUEsaUNBQ0U7QUFBSyxxQkFBUyxZQUFLcEIsU0FBTCxTQUFkO0FBQW9DLGlCQUFLO0FBQUlxQixtQkFBSyxFQUFFLE1BQVg7QUFBbUJDLG9CQUFNLEVBQUUsTUFBM0I7QUFBbUNDLHNCQUFRLEVBQUU7QUFBN0MsZUFBNER0QixLQUE1RCxDQUF6QztBQUFBLG9DQUNFO0FBQUssdUJBQVMsRUFBQyxFQUFmO0FBQWtCLG1CQUFLLEVBQUU7QUFBRW9CLHFCQUFLLEVBQUUsR0FBVDtBQUFjQyxzQkFBTSxFQUFFLEdBQXRCO0FBQTJCQyx3QkFBUSxFQUFFLFVBQXJDO0FBQWlEQywwQkFBVSxFQUFFLFNBQTdEO0FBQXdFQyxzQkFBTSxFQUFFLEVBQWhGO0FBQW9GQyxvQkFBSSxFQUFFO0FBQTFGO0FBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREYsZUFFRTtBQUNFLHVCQUFTLEVBQUMsRUFEWjtBQUVFLG1CQUFLLEVBQUU7QUFBRUwscUJBQUssRUFBRSxHQUFUO0FBQWNDLHNCQUFNLEVBQUUsR0FBdEI7QUFBMkJHLHNCQUFNLEVBQUUsRUFBbkM7QUFBdUNDLG9CQUFJLEVBQUUsRUFBN0M7QUFBaURILHdCQUFRLEVBQUUsVUFBM0Q7QUFBdUVJLHVCQUFPLEVBQUUsTUFBaEY7QUFBd0ZDLDZCQUFhLEVBQUU7QUFBdkcsZUFGVDtBQUFBLHNDQUdFLHFFQUFDLGlEQUFEO0FBQU8sbUJBQUcsRUFBRVIsSUFBSSxDQUFDVixLQUFqQjtBQUF3QixtQkFBRyxFQUFDLGVBQTVCO0FBQTRDLHFCQUFLLEVBQUU7QUFBRW1CLDBCQUFRLEVBQUU7QUFBWjtBQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUhGLGVBSUUscUVBQUMsaURBQUQ7QUFBTyxtQkFBRyxFQUFDLHNCQUFYO0FBQWtDLG1CQUFHLEVBQUUsWUFBdkM7QUFBcUQseUJBQVMsRUFBQyxVQUEvRDtBQUEwRSxxQkFBSyxFQUFFO0FBQUVILHNCQUFJLEVBQUUsRUFBUjtBQUFZRCx3QkFBTSxFQUFFO0FBQXBCO0FBQWpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBSkYsZUFNRTtBQUFLLHFCQUFLLEVBQUU7QUFBRUgsd0JBQU0sRUFBRSxHQUFWO0FBQWVFLDRCQUFVLEVBQUU7QUFBM0IsaUJBQVo7QUFBQSx3Q0FDRTtBQUFLLDJCQUFTLEVBQUMsK0JBQWY7QUFBK0MsdUJBQUssRUFBRTtBQUFFRiwwQkFBTSxFQUFFLEdBQVY7QUFBZVEsZ0NBQVksRUFBRTtBQUE3QixtQkFBdEQ7QUFBQSwwQ0FDRTtBQUFJLDZCQUFTLEVBQUMsMEJBQWQ7QUFBeUMseUJBQUssRUFBRTtBQUFFQyw4QkFBUSxFQUFFLEVBQVo7QUFBZ0JDLGdDQUFVLEVBQUUsTUFBNUI7QUFBb0NDLG1DQUFhLEVBQUUsUUFBbkQ7QUFBNkRDLGdDQUFVLEVBQUUsRUFBekU7QUFBNkVDLGlDQUFXLEVBQUU7QUFBMUYscUJBQWhEO0FBQUEsOEJBQ0dmLElBQUksQ0FBQ2pCO0FBRFI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFERixlQUlFO0FBQUksNkJBQVMsRUFBQywyQkFBZDtBQUEwQyx5QkFBSyxFQUFFO0FBQUU0Qiw4QkFBUSxFQUFFLEVBQVo7QUFBZ0JDLGdDQUFVLEVBQUUsTUFBNUI7QUFBb0NDLG1DQUFhLEVBQUU7QUFBbkQscUJBQWpEO0FBQUEsOEJBQ0diLElBQUksQ0FBQ2hCO0FBRFI7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBREYsZUFVRTtBQUFLLDJCQUFTLEVBQUMsbUNBQWY7QUFBbUQsdUJBQUssRUFBRTtBQUFFa0IsMEJBQU0sRUFBRTtBQUFWLG1CQUExRDtBQUFBLDBDQUNFO0FBQUsseUJBQUssRUFBRTtBQUFFWSxnQ0FBVSxFQUFFLEVBQWQ7QUFBa0JQLDZCQUFPLEVBQUUsTUFBM0I7QUFBbUNTLG9DQUFjLEVBQUU7QUFBbkQscUJBQVo7QUFBQSw0Q0FDRTtBQUFNLCtCQUFTLEVBQUMsOENBQWhCO0FBQUEsc0NBQWlFaEIsSUFBSSxDQUFDYixPQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBREYsRUFFR2EsSUFBSSxDQUFDWixRQUFMLGlCQUFpQjtBQUFNLCtCQUFTLEVBQUMsOENBQWhCO0FBQUEsNkNBQStEO0FBQUksNkJBQUssRUFBRTtBQUFFYSwrQkFBSyxFQUFFLEVBQVQ7QUFBYWdCLG1DQUFTLEVBQUU7QUFBeEI7QUFBWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQS9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBRnBCLEVBR0dqQixJQUFJLENBQUNaLFFBQUwsaUJBQWlCO0FBQU0sK0JBQVMsRUFBQyw4Q0FBaEI7QUFBQSxzQ0FBaUVZLElBQUksQ0FBQ1osUUFBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUhwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBREYsZUFNRSxxRUFBQyxpREFBRDtBQUFPLHVCQUFHLEVBQUVZLElBQUksQ0FBQ1gsSUFBakI7QUFBdUIsdUJBQUcsRUFBRSxLQUE1QjtBQUFtQyx5QkFBSyxFQUFFO0FBQUUwQixpQ0FBVyxFQUFFO0FBQWY7QUFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFORjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURNLGVBZ0NOO0FBQUssbUJBQVMsRUFBQyxLQUFmO0FBQUEsa0NBQ0U7QUFBSyxxQkFBUyxFQUFDLEtBQWY7QUFBQSxtQ0FBcUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFERixlQUVFO0FBQUsscUJBQVMsRUFBQyxLQUFmO0FBQUEsbUNBQXFCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQXJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQWhDTTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBUjtBQXFDRCxLQXRDQTtBQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FERjtBQStDRCxDQWpITTtLQUFNcEMsTyIsImZpbGUiOiJzdGF0aWMvd2VicGFjay9wYWdlcy9ob21lLjQ0YWQ3OTRiOTM3MDAxYWQyM2FmLmhvdC11cGRhdGUuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBJbWFnZSB9IGZyb20gXCJAY29tcG9uZW50c1wiO1xuaW1wb3J0IFNsaWRlciBmcm9tIFwicmVhY3Qtc2xpY2tcIjtcbmltcG9ydCBcInNsaWNrLWNhcm91c2VsL3NsaWNrL3NsaWNrLmNzc1wiO1xuaW1wb3J0IFwic2xpY2stY2Fyb3VzZWwvc2xpY2svc2xpY2stdGhlbWUuY3NzXCI7XG5cbmV4cG9ydCB0eXBlIFByb3BzID0ge1xuICBuYW1lcz86IEFycmF5PHN0cmluZz47XG4gIGJhY2tncm91bmRfdXJsPzogc3RyaW5nO1xuICB0YWdzPzogQXJyYXk8c3RyaW5nPjtcbiAgbG9nbz86IHN0cmluZztcbiAgY2xhc3NOYW1lPzogc3RyaW5nO1xuICBzdHlsZT86IGFueTtcbn07XG5cbmV4cG9ydCBjb25zdCBGb3VuZGVyOiBSZWFjdC5GQzxQcm9wcz4gPSAoeyBjbGFzc05hbWUsIHN0eWxlID0ge30gfSkgPT4ge1xuICBjb25zdCBoZXJvcyA9IFt7XG4gICAgZmlyc3ROYW1lOiAnQmhhdmlzaCcsXG4gICAgbGFzdE5hbWU6ICdBR0dBUldBTCcsXG4gICAgZmlyc3ROYW1lMTogbnVsbCxcbiAgICBsYXN0TmFtZTE6IG51bGwsXG4gICAgY2FwdGlvbjogJ01vYmlsaXR5JyxcbiAgICBjYXB0aW9uMTogJ0VsZWN0cmljIENhcnMnLFxuICAgIGxvZ286ICcvaWNvbnMvb2xhLnN2ZycsXG4gICAgaW1hZ2U6ICcvaWNvbnMvQmhhdmlzaF9pbWFnZS5zdmcnXG4gIH0sIHtcbiAgICBmaXJzdE5hbWU6ICdST0hJVCcsXG4gICAgbGFzdE5hbWU6ICdNLkEuJyxcbiAgICBmaXJzdE5hbWUxOiBudWxsLFxuICAgIGxhc3ROYW1lMTogbnVsbCxcbiAgICBjYXB0aW9uOiAnSGVhbHRoY2FyZScsXG4gICAgY2FwdGlvbjE6IG51bGwsXG4gICAgbG9nbzogJy9pY29ucy9DbG91ZG5pbmUuc3ZnJyxcbiAgICBpbWFnZTogJy9pY29ucy9Sb2hpdF9UcmVhdG1lbnQuc3ZnJ1xuICB9LCB7XG4gICAgZmlyc3ROYW1lOiAnQU5JTkRZQScsXG4gICAgbGFzdE5hbWU6ICdEVVRUQScsXG4gICAgZmlyc3ROYW1lMTogJ1NBTkRFRVAnLFxuICAgIGxhc3ROYW1lMTogJ0RBTE1JQScsXG4gICAgY2FwdGlvbjogJ1N0dWRlbnQgSG91c2luZyBQbGF0Zm9ybScsXG4gICAgY2FwdGlvbjE6IG51bGwsXG4gICAgbG9nbzogJy9pY29ucy9TdGFuemEuc3ZnJyxcbiAgICBpbWFnZTogJy9pY29ucy9BbmluZHlhLnN2ZydcbiAgfSwge1xuICAgIGZpcnN0TmFtZTogJ0FzaXNoJyxcbiAgICBsYXN0TmFtZTogJ01PSEFQQVRSQScsXG4gICAgZmlyc3ROYW1lMTogbnVsbCxcbiAgICBsYXN0TmFtZTE6IG51bGwsXG4gICAgY2FwdGlvbjogJ0ZpbnRlY2gnLFxuICAgIGNhcHRpb24xOiAnU01FIExlbmRpbmcnLFxuICAgIGxvZ286ICcvaWNvbnMvT2ZCdXNpbmVzcy5zdmcnLFxuICAgIGltYWdlOiAnL2ljb25zL0FzaXNoLnN2ZydcbiAgfSwge1xuICAgIGZpcnN0TmFtZTogJ01yLicsXG4gICAgbGFzdE5hbWU6ICdMQUtTSElQQVRIWScsXG4gICAgZmlyc3ROYW1lMTogbnVsbCxcbiAgICBsYXN0TmFtZTE6IG51bGwsXG4gICAgY2FwdGlvbjogJ0ZpbnRlY2gnLFxuICAgIGNhcHRpb24xOiAnTkJGQycsXG4gICAgbG9nbzogJy9pY29ucy9teC5zdmcnLFxuICAgIGltYWdlOiAnL2ljb25zL0xheG1pcGF0aHkuc3ZnJ1xuICB9LCB7XG4gICAgZmlyc3ROYW1lOiAnQ0hBS1JBREhBUicsXG4gICAgbGFzdE5hbWU6ICdHQURFJyxcbiAgICBmaXJzdE5hbWUxOiAnTklUSU4nLFxuICAgIGxhc3ROYW1lMTogJ0tBVVNIQUwnLFxuICAgIGNhcHRpb246ICdGaW50ZWNoJyxcbiAgICBjYXB0aW9uMTogJ05CRkMnLFxuICAgIGxvZ286ICcvaWNvbnMvQ291bnRyeS5zdmcnLFxuICAgIGltYWdlOiAnL2ljb25zL0NoYWtyYWRoYXIuc3ZnJ1xuICB9XVxuXG4gIGNvbnN0IHNldHRpbmdzID0ge1xuICAgIGRvdHM6IHRydWUsXG4gICAgaW5maW5pdGU6IHRydWUsXG4gICAgc3BlZWQ6IDUwMCxcbiAgICBhdXRvcGxheVNwZWVkOiA1MDAwLFxuICAgIHNsaWRlc1RvU2hvdzogMSxcbiAgICBzbGlkZXNUb1Njcm9sbDogMSxcbiAgICBhdXRvcGxheTogdHJ1ZVxuICB9O1xuICByZXR1cm4gKFxuICAgIDxTbGlkZXIgey4uLnNldHRpbmdzfT5cbiAgICAgIHtoZXJvcy5tYXAoaGVybyA9PiB7XG4gICAgICAgIHJldHVybiAoPGRpdiBjbGFzc05hbWU9J3Jvdyc+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9J2NvbCc+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YCR7Y2xhc3NOYW1lfSBjb2xgfSBzdHlsZT17eyB3aWR0aDogNjE1Ljk0LCBoZWlnaHQ6IDg2My45MSwgcG9zaXRpb246IFwicmVsYXRpdmVcIiwgLi4uc3R5bGUsIH19PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIlwiIHN0eWxlPXt7IHdpZHRoOiA1NzEsIGhlaWdodDogNzYyLCBwb3NpdGlvbjogXCJhYnNvbHV0ZVwiLCBiYWNrZ3JvdW5kOiBcIiMwODNBNEFcIiwgYm90dG9tOiA1MCwgbGVmdDogMCwgfX0+PC9kaXY+XG4gICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJcIlxuICAgICAgICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiA1OTQsIGhlaWdodDogNzg4LCBib3R0b206IDY1LCBsZWZ0OiAxNSwgcG9zaXRpb246IFwiYWJzb2x1dGVcIiwgZGlzcGxheTogXCJmbGV4XCIsIGZsZXhEaXJlY3Rpb246IFwiY29sdW1uXCIsIH19PlxuICAgICAgICAgICAgICAgIDxJbWFnZSBzcmM9e2hlcm8uaW1hZ2V9IGFsdD1cImZvdW5kZXIgaW1hZ2VcIiBzdHlsZT17eyBmbGV4R3JvdzogMSB9fT48L0ltYWdlPlxuICAgICAgICAgICAgICAgIDxJbWFnZSBzcmM9XCIvaWNvbnMvcmVjdGFuZ2xlLnN2Z1wiIGFsdD17XCJyZWFjdGFuZ2xlXCJ9IGNsYXNzTmFtZT1cImFic29sdXRlXCIgc3R5bGU9e3sgbGVmdDogMzgsIGJvdHRvbTogMjU0IH19IC8+XG5cbiAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGhlaWdodDogMjA5LCBiYWNrZ3JvdW5kOiBcIiMwMTU3NkVcIiB9fT5cbiAgICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgZmxleCBpdGVtcy1jZW50ZXJcIiBzdHlsZT17eyBoZWlnaHQ6IDExOCwgYm9yZGVyQm90dG9tOiBcIjFweCBzb2xpZCAjRUJFQkU5XCIgfX0+XG4gICAgICAgICAgICAgICAgICAgIDxoNiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zZWNvbmRhcnlcIiBzdHlsZT17eyBmb250U2l6ZTogMzIsIGxpbmVIZWlnaHQ6IFwiMzZweFwiLCBsZXR0ZXJTcGFjaW5nOiBcIjAuMDVlbVwiLCBtYXJnaW5MZWZ0OiAzMSwgbWFyZ2luUmlnaHQ6IDgsIH19PlxuICAgICAgICAgICAgICAgICAgICAgIHtoZXJvLmZpcnN0TmFtZX1cbiAgICAgICAgICAgICAgICAgICAgPC9oNj5cbiAgICAgICAgICAgICAgICAgICAgPGg2IGNsYXNzTmFtZT1cImZvbnQtbGlnaHQgdGV4dC1zZWNvbmRhcnlcIiBzdHlsZT17eyBmb250U2l6ZTogMzIsIGxpbmVIZWlnaHQ6IFwiMzZweFwiLCBsZXR0ZXJTcGFjaW5nOiBcIjAuMDVlbVwiLCB9fT5cbiAgICAgICAgICAgICAgICAgICAgICB7aGVyby5sYXN0TmFtZX1cbiAgICAgICAgICAgICAgICAgICAgPC9oNj5cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlclwiIHN0eWxlPXt7IGhlaWdodDogODggfX0+XG4gICAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgbWFyZ2luTGVmdDogMzEsIGRpc3BsYXk6ICdmbGV4JywganVzdGlmeUNvbnRlbnQ6ICdzcGFjZS1hcm91bmQnIH19PlxuICAgICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2Vjb25kYXJ5IGZvbnQtbWVkaXVtIHRleHQtbGcgbGVhZGluZy02XCI+IHtoZXJvLmNhcHRpb259PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICAgIHtoZXJvLmNhcHRpb24xICYmIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2Vjb25kYXJ5IGZvbnQtbWVkaXVtIHRleHQtbGcgbGVhZGluZy02XCI+PGhyIHN0eWxlPXt7IHdpZHRoOiAzMCwgdHJhbnNmb3JtOiAncm90YXRlKDkwZGVnKScgfX0gLz48L3NwYW4+fVxuICAgICAgICAgICAgICAgICAgICAgIHtoZXJvLmNhcHRpb24xICYmIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2Vjb25kYXJ5IGZvbnQtbWVkaXVtIHRleHQtbGcgbGVhZGluZy02XCI+IHtoZXJvLmNhcHRpb24xfTwvc3Bhbj59XG4gICAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgICA8SW1hZ2Ugc3JjPXtoZXJvLmxvZ299IGFsdD17XCJvbGFcIn0gc3R5bGU9e3sgbWFyZ2luUmlnaHQ6IDU3IH19IC8+XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT0nY29sJz5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPSdjb2wnPjxoMT5rYXRoaWs8L2gxPjwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9J2NvbCc+PGgxPmthdGhpazwvaDE+PC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PilcbiAgICAgIH0pfVxuXG5cblxuXG4gICAgPC9TbGlkZXI+XG4gICk7XG59O1xuIl0sInNvdXJjZVJvb3QiOiIifQ==