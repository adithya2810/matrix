webpackHotUpdate_N_E("pages/contact",{

/***/ "./src/modules/contact/form.tsx":
/*!**************************************!*\
  !*** ./src/modules/contact/form.tsx ***!
  \**************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_button_PrimaryButtonIconRight__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @components/button/PrimaryButtonIconRight */ "./src/components/button/PrimaryButtonIconRight.tsx");


var _jsxFileName = "C:\\Users\\KARTHIK\\Documents\\workspace\\matrix-cms-ui-development\\src\\modules\\contact\\form.tsx",
    _this = undefined;




var ContactForm = function ContactForm() {
  var details = [{
    city: "Bangalore",
    address: ['197, 6th Main, 1st Cross,', 'HAL 2nd Stage, Indira Nagar,', 'Bengaluru 560038', '+91-80-25196000']
  }, {
    city: "DELHI",
    address: ['4th Floor, Aria Towers, ', 'JW Marriott, Asset Area 4,', 'Aerocity, New Delhi, 110037', '+91-11-49495000']
  }, {
    city: "MUMBAI",
    address: ['601-602, Ceejay House,', 'Dr Annie Besant Road, Worli,', 'Mumbai 400018', '+91-22-67680000']
  }];
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: "relative m-auto w-11/12\t",
    style: {
      marginTop: 100,
      marginBottom: 150
    },
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "row",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        style: {
          flex: '60%'
        },
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h1", {
          className: "main-txt text-4xl  font-bold",
          children: "Vist our India Advisory Team Offices"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 19,
          columnNumber: 11
        }, _this), details.map(function (data) {
          return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "row ",
            style: {
              marginTop: '50px'
            },
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              style: {
                flex: '66%'
              },
              className: "col-span-8 contact-address",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "map-info border-b-2 mr-5 pb-5",
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                  href: "#",
                  className: "uppercase font-bold text-xl border-b-3 bbc",
                  children: data.city
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 24,
                  columnNumber: 19
                }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("hr", {
                  className: "under-line"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 25,
                  columnNumber: 19
                }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
                  children: [data.address[0], " ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 26,
                    columnNumber: 40
                  }, _this), data.address[1], " ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 26,
                    columnNumber: 64
                  }, _this), " data.address[2] ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 26,
                    columnNumber: 87
                  }, _this), " ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 26,
                    columnNumber: 94
                  }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                    href: data.address[3],
                    children: data.address[3]
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 26,
                    columnNumber: 100
                  }, _this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 26,
                  columnNumber: 19
                }, _this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 23,
                columnNumber: 17
              }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "direction-link",
                children: ["GET DIRECTION ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
                    src: "/icons/blackArrow.svg"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 28,
                    columnNumber: 70
                  }, _this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 28,
                  columnNumber: 64
                }, _this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 28,
                columnNumber: 17
              }, _this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 22,
              columnNumber: 15
            }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              style: {
                flex: '44%'
              },
              className: "col-span-4 relative",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "city-overlay",
                children: data.city
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 31,
                columnNumber: 17
              }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
                className: "contact-img",
                src: "../../img/image 26.png",
                alt: ""
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 32,
                columnNumber: 17
              }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "contact-bg-overlay "
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 33,
                columnNumber: 17
              }, _this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 30,
              columnNumber: 15
            }, _this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 21,
            columnNumber: 13
          }, _this);
        })]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 18,
        columnNumber: 9
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        style: {
          flex: '40%'
        },
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h1", {
          className: "main-txt text-4xl lg:text-3xl font-bold form-heading",
          children: "Share your Business Plans"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 39,
          columnNumber: 11
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("form", {
          className: "contact-form",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("label", {
            children: "Name"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 41,
            columnNumber: 13
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("input", {
            type: "text",
            placeholder: "Name"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 42,
            columnNumber: 13
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("label", {
            children: "Company Name"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 43,
            columnNumber: 13
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("input", {
            type: "text",
            placeholder: "Company Name"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 44,
            columnNumber: 13
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("label", {
            children: "What are you building?"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 45,
            columnNumber: 13
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("textarea", {
            placeholder: "Company Brief"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 46,
            columnNumber: 13
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("label", {
            children: "File Attachment"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 47,
            columnNumber: 13
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("input", {
            type: "file"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 48,
            columnNumber: 13
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("label", {
            children: "Email Id"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 49,
            columnNumber: 13
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("input", {
            type: "email",
            placeholder: "Contact Email"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 50,
            columnNumber: 13
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("label", {
            children: "Mobile Number"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 51,
            columnNumber: 13
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("input", {
            type: "text",
            placeholder: "Contact Number"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 52,
            columnNumber: 13
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_button_PrimaryButtonIconRight__WEBPACK_IMPORTED_MODULE_2__["default"], {
            title: "Apply",
            url: "/icons/rightArrow.svg",
            onClick: function onClick() {
              return console.log("subscribe");
            },
            className: "text-lg leading-6"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 53,
            columnNumber: 13
          }, _this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 40,
          columnNumber: 11
        }, _this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 38,
        columnNumber: 9
      }, _this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 17,
      columnNumber: 7
    }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h1", {
      className: "main-txt text-4xl contact-heading  font-bold",
      style: {
        marginTop: '50px'
      },
      children: "Matrix Partners Global"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 63,
      columnNumber: 7
    }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "row",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        style: {
          flex: '25%'
        },
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
          className: "main-txt text-3xl contact-subHeading font-bold",
          children: "USA"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 66,
          columnNumber: 11
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("hr", {
          style: {
            width: '80%',
            margin: '15px 0 32px 0'
          }
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 67,
          columnNumber: 11
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
          children: "BOSTON"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 68,
          columnNumber: 11
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 68,
          columnNumber: 24
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
          children: "PALO ALTO"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 69,
          columnNumber: 11
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 69,
          columnNumber: 27
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
          children: "SAN FRANCISCO"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 70,
          columnNumber: 11
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 70,
          columnNumber: 31
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "website-link",
          style: {
            display: 'flex'
          },
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
            children: "Visit USA Website"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 71,
            columnNumber: 69
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
            style: {
              marginLeft: '15px'
            },
            src: "/icons/-_.svg"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 71,
            columnNumber: 93
          }, _this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 71,
          columnNumber: 11
        }, _this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 65,
        columnNumber: 9
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        style: {
          flex: '50%'
        },
        children: "sdfds"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 73,
        columnNumber: 9
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        style: {
          flex: '25%'
        },
        children: "sdfds"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 76,
        columnNumber: 9
      }, _this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 64,
      columnNumber: 7
    }, _this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 16,
    columnNumber: 5
  }, _this);
};

_c = ContactForm;
/* harmony default export */ __webpack_exports__["default"] = (ContactForm);

var _c;

$RefreshReg$(_c, "ContactForm");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vc3JjL21vZHVsZXMvY29udGFjdC9mb3JtLnRzeCJdLCJuYW1lcyI6WyJDb250YWN0Rm9ybSIsImRldGFpbHMiLCJjaXR5IiwiYWRkcmVzcyIsIm1hcmdpblRvcCIsIm1hcmdpbkJvdHRvbSIsImZsZXgiLCJtYXAiLCJkYXRhIiwiY29uc29sZSIsImxvZyIsIndpZHRoIiwibWFyZ2luIiwiZGlzcGxheSIsIm1hcmdpbkxlZnQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7O0FBRUEsSUFBTUEsV0FBcUIsR0FBRyxTQUF4QkEsV0FBd0IsR0FBTTtBQUNsQyxNQUFNQyxPQUFPLEdBQUcsQ0FBQztBQUNmQyxRQUFJLEVBQUUsV0FEUztBQUVmQyxXQUFPLEVBQUUsQ0FBQywyQkFBRCxFQUE4Qiw4QkFBOUIsRUFBOEQsa0JBQTlELEVBQWtGLGlCQUFsRjtBQUZNLEdBQUQsRUFHYjtBQUNERCxRQUFJLEVBQUUsT0FETDtBQUVEQyxXQUFPLEVBQUUsQ0FBQywwQkFBRCxFQUE2Qiw0QkFBN0IsRUFBMkQsNkJBQTNELEVBQTBGLGlCQUExRjtBQUZSLEdBSGEsRUFNYjtBQUNERCxRQUFJLEVBQUUsUUFETDtBQUVEQyxXQUFPLEVBQUUsQ0FBQyx3QkFBRCxFQUEyQiw4QkFBM0IsRUFBMkQsZUFBM0QsRUFBNEUsaUJBQTVFO0FBRlIsR0FOYSxDQUFoQjtBQVVBLHNCQUNFO0FBQUssYUFBUyxFQUFDLDJCQUFmO0FBQTBDLFNBQUssRUFBRTtBQUFFQyxlQUFTLEVBQUUsR0FBYjtBQUFrQkMsa0JBQVksRUFBRTtBQUFoQyxLQUFqRDtBQUFBLDRCQUNFO0FBQUssZUFBUyxFQUFDLEtBQWY7QUFBQSw4QkFDRTtBQUFLLGFBQUssRUFBRTtBQUFFQyxjQUFJLEVBQUU7QUFBUixTQUFaO0FBQUEsZ0NBQ0U7QUFBSSxtQkFBUyxFQUFDLDhCQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURGLEVBRUdMLE9BQU8sQ0FBQ00sR0FBUixDQUFZLFVBQUNDLElBQUQ7QUFBQSw4QkFDWDtBQUFLLHFCQUFTLEVBQUMsTUFBZjtBQUFzQixpQkFBSyxFQUFFO0FBQUVKLHVCQUFTLEVBQUU7QUFBYixhQUE3QjtBQUFBLG9DQUNFO0FBQUssbUJBQUssRUFBRTtBQUFFRSxvQkFBSSxFQUFFO0FBQVIsZUFBWjtBQUE2Qix1QkFBUyxFQUFDLDRCQUF2QztBQUFBLHNDQUNFO0FBQUsseUJBQVMsRUFBQywrQkFBZjtBQUFBLHdDQUNFO0FBQUcsc0JBQUksRUFBQyxHQUFSO0FBQVksMkJBQVMsRUFBQyw0Q0FBdEI7QUFBQSw0QkFBb0VFLElBQUksQ0FBQ047QUFBekU7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFERixlQUVFO0FBQUksMkJBQVMsRUFBQztBQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRkYsZUFHRTtBQUFBLDZCQUFJTSxJQUFJLENBQUNMLE9BQUwsQ0FBYSxDQUFiLENBQUosb0JBQXFCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQXJCLEVBQTRCSyxJQUFJLENBQUNMLE9BQUwsQ0FBYSxDQUFiLENBQTVCLG9CQUE2QztBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUE3QyxvQ0FBb0U7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBcEUsb0JBQTJFO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTNFLGVBQWlGO0FBQUcsd0JBQUksRUFBRUssSUFBSSxDQUFDTCxPQUFMLENBQWEsQ0FBYixDQUFUO0FBQUEsOEJBQTJCSyxJQUFJLENBQUNMLE9BQUwsQ0FBYSxDQUFiO0FBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQWpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFIRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBREYsZUFNRTtBQUFLLHlCQUFTLEVBQUMsZ0JBQWY7QUFBQSwwREFBK0M7QUFBQSx5Q0FBTTtBQUFLLHVCQUFHLEVBQUM7QUFBVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFERixlQVNFO0FBQUssbUJBQUssRUFBRTtBQUFFRyxvQkFBSSxFQUFFO0FBQVIsZUFBWjtBQUE2Qix1QkFBUyxFQUFDLHFCQUF2QztBQUFBLHNDQUNFO0FBQUsseUJBQVMsRUFBQyxjQUFmO0FBQUEsMEJBQStCRSxJQUFJLENBQUNOO0FBQXBDO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBREYsZUFFRTtBQUFLLHlCQUFTLEVBQUMsYUFBZjtBQUE2QixtQkFBRyxFQUFDLHdCQUFqQztBQUEwRCxtQkFBRyxFQUFDO0FBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRkYsZUFHRTtBQUFLLHlCQUFTLEVBQUM7QUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFURjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRFc7QUFBQSxTQUFaLENBRkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREYsZUFxQkU7QUFBSyxhQUFLLEVBQUU7QUFBRUksY0FBSSxFQUFFO0FBQVIsU0FBWjtBQUFBLGdDQUNFO0FBQUksbUJBQVMsRUFBQyxzREFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFERixlQUVFO0FBQU0sbUJBQVMsRUFBQyxjQUFoQjtBQUFBLGtDQUNFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURGLGVBRUU7QUFBTyxnQkFBSSxFQUFDLE1BQVo7QUFBbUIsdUJBQVcsRUFBQztBQUEvQjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUZGLGVBR0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSEYsZUFJRTtBQUFPLGdCQUFJLEVBQUMsTUFBWjtBQUFtQix1QkFBVyxFQUFDO0FBQS9CO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSkYsZUFLRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFMRixlQU1FO0FBQVUsdUJBQVcsRUFBQztBQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU5GLGVBT0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBUEYsZUFRRTtBQUFPLGdCQUFJLEVBQUM7QUFBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVJGLGVBU0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBVEYsZUFVRTtBQUFPLGdCQUFJLEVBQUMsT0FBWjtBQUFvQix1QkFBVyxFQUFDO0FBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBVkYsZUFXRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFYRixlQVlFO0FBQU8sZ0JBQUksRUFBQyxNQUFaO0FBQW1CLHVCQUFXLEVBQUM7QUFBL0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFaRixlQWFFLHFFQUFDLGlGQUFEO0FBQ0UsaUJBQUssRUFBQyxPQURSO0FBRUUsZUFBRyxFQUFDLHVCQUZOO0FBR0UsbUJBQU8sRUFBRTtBQUFBLHFCQUFNRyxPQUFPLENBQUNDLEdBQVIsQ0FBWSxXQUFaLENBQU47QUFBQSxhQUhYO0FBSUUscUJBQVMsRUFBQztBQUpaO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQXJCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFERixlQStDRTtBQUFJLGVBQVMsRUFBQyw4Q0FBZDtBQUE2RCxXQUFLLEVBQUU7QUFBRU4saUJBQVMsRUFBRTtBQUFiLE9BQXBFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBL0NGLGVBZ0RFO0FBQUssZUFBUyxFQUFDLEtBQWY7QUFBQSw4QkFDRTtBQUFLLGFBQUssRUFBRTtBQUFFRSxjQUFJLEVBQUU7QUFBUixTQUFaO0FBQUEsZ0NBQ0U7QUFBRyxtQkFBUyxFQUFDLGdEQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURGLGVBRUU7QUFBSSxlQUFLLEVBQUU7QUFBRUssaUJBQUssRUFBRSxLQUFUO0FBQWdCQyxrQkFBTSxFQUFFO0FBQXhCO0FBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFGRixlQUdFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUhGLGVBR2U7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFIZixlQUlFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUpGLGVBSWtCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSmxCLGVBS0U7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBTEYsZUFLc0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFMdEIsZUFNRTtBQUFLLG1CQUFTLEVBQUMsY0FBZjtBQUE4QixlQUFLLEVBQUU7QUFBRUMsbUJBQU8sRUFBRTtBQUFYLFdBQXJDO0FBQUEsa0NBQTBEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUExRCxlQUFrRjtBQUFLLGlCQUFLLEVBQUU7QUFBRUMsd0JBQVUsRUFBRTtBQUFkLGFBQVo7QUFBb0MsZUFBRyxFQUFDO0FBQXhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQWxGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFORjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERixlQVNFO0FBQUssYUFBSyxFQUFFO0FBQUVSLGNBQUksRUFBRTtBQUFSLFNBQVo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFURixlQVlFO0FBQUssYUFBSyxFQUFFO0FBQUVBLGNBQUksRUFBRTtBQUFSLFNBQVo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFaRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFoREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBREY7QUFxRUQsQ0FoRkQ7O0tBQU1OLFc7QUFpRlNBLDBFQUFmIiwiZmlsZSI6InN0YXRpYy93ZWJwYWNrL3BhZ2VzL2NvbnRhY3QuM2I2Nzg4NGE0ZDdmOTcxNGJhMWQuaG90LXVwZGF0ZS5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCBCdXR0b24gZnJvbSBcIkBjb21wb25lbnRzL2J1dHRvbi9QcmltYXJ5QnV0dG9uSWNvblJpZ2h0XCI7XG5cbmNvbnN0IENvbnRhY3RGb3JtOiBSZWFjdC5GQyA9ICgpID0+IHtcbiAgY29uc3QgZGV0YWlscyA9IFt7XG4gICAgY2l0eTogXCJCYW5nYWxvcmVcIixcbiAgICBhZGRyZXNzOiBbJzE5NywgNnRoIE1haW4sIDFzdCBDcm9zcywnLCAnSEFMIDJuZCBTdGFnZSwgSW5kaXJhIE5hZ2FyLCcsICdCZW5nYWx1cnUgNTYwMDM4JywgJys5MS04MC0yNTE5NjAwMCddXG4gIH0sIHtcbiAgICBjaXR5OiBcIkRFTEhJXCIsXG4gICAgYWRkcmVzczogWyc0dGggRmxvb3IsIEFyaWEgVG93ZXJzLCAnLCAnSlcgTWFycmlvdHQsIEFzc2V0IEFyZWEgNCwnLCAnQWVyb2NpdHksIE5ldyBEZWxoaSwgMTEwMDM3JywgJys5MS0xMS00OTQ5NTAwMCddXG4gIH0sIHtcbiAgICBjaXR5OiBcIk1VTUJBSVwiLFxuICAgIGFkZHJlc3M6IFsnNjAxLTYwMiwgQ2VlamF5IEhvdXNlLCcsICdEciBBbm5pZSBCZXNhbnQgUm9hZCwgV29ybGksJywgJ011bWJhaSA0MDAwMTgnLCAnKzkxLTIyLTY3NjgwMDAwJ11cbiAgfV1cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIG0tYXV0byB3LTExLzEyXHRcIiBzdHlsZT17eyBtYXJnaW5Ub3A6IDEwMCwgbWFyZ2luQm90dG9tOiAxNTAgfX0+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvd1wiPlxuICAgICAgICA8ZGl2IHN0eWxlPXt7IGZsZXg6ICc2MCUnIH19PlxuICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJtYWluLXR4dCB0ZXh0LTR4bCAgZm9udC1ib2xkXCI+VmlzdCBvdXIgSW5kaWEgQWR2aXNvcnkgVGVhbSBPZmZpY2VzPC9oMT5cbiAgICAgICAgICB7ZGV0YWlscy5tYXAoKGRhdGEpID0+IChcbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm93IFwiIHN0eWxlPXt7IG1hcmdpblRvcDogJzUwcHgnIH19PlxuICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZsZXg6ICc2NiUnIH19IGNsYXNzTmFtZT1cImNvbC1zcGFuLTggY29udGFjdC1hZGRyZXNzXCI+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYXAtaW5mbyBib3JkZXItYi0yIG1yLTUgcGItNVwiPlxuICAgICAgICAgICAgICAgICAgPGEgaHJlZj1cIiNcIiBjbGFzc05hbWU9XCJ1cHBlcmNhc2UgZm9udC1ib2xkIHRleHQteGwgYm9yZGVyLWItMyBiYmNcIj57ZGF0YS5jaXR5fTwvYT5cbiAgICAgICAgICAgICAgICAgIDxociBjbGFzc05hbWU9XCJ1bmRlci1saW5lXCIgLz5cbiAgICAgICAgICAgICAgICAgIDxwPntkYXRhLmFkZHJlc3NbMF19IDxiciAvPntkYXRhLmFkZHJlc3NbMV19IDxiciAvPiBkYXRhLmFkZHJlc3NbMl0gPGJyIC8+IDxiciAvPjxhIGhyZWY9e2RhdGEuYWRkcmVzc1szXX0+e2RhdGEuYWRkcmVzc1szXX08L2E+PC9wPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZGlyZWN0aW9uLWxpbmtcIiA+R0VUIERJUkVDVElPTiA8c3Bhbj48aW1nIHNyYz0nL2ljb25zL2JsYWNrQXJyb3cuc3ZnJyAvPjwvc3Bhbj48L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgZmxleDogJzQ0JScgfX0gY2xhc3NOYW1lPVwiY29sLXNwYW4tNCByZWxhdGl2ZVwiPlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPSdjaXR5LW92ZXJsYXknPntkYXRhLmNpdHl9PC9kaXY+XG4gICAgICAgICAgICAgICAgPGltZyBjbGFzc05hbWU9J2NvbnRhY3QtaW1nJyBzcmM9XCIuLi8uLi9pbWcvaW1hZ2UgMjYucG5nXCIgYWx0PVwiXCIgLz5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbnRhY3QtYmctb3ZlcmxheSBcIj48L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICApKX1cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgc3R5bGU9e3sgZmxleDogJzQwJScgfX0+XG4gICAgICAgICAgPGgxIGNsYXNzTmFtZT1cIm1haW4tdHh0IHRleHQtNHhsIGxnOnRleHQtM3hsIGZvbnQtYm9sZCBmb3JtLWhlYWRpbmdcIj5TaGFyZSB5b3VyIEJ1c2luZXNzIFBsYW5zPC9oMT5cbiAgICAgICAgICA8Zm9ybSBjbGFzc05hbWU9J2NvbnRhY3QtZm9ybSc+XG4gICAgICAgICAgICA8bGFiZWwgPk5hbWU8L2xhYmVsPlxuICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJ0ZXh0XCIgcGxhY2Vob2xkZXI9XCJOYW1lXCIgLz5cbiAgICAgICAgICAgIDxsYWJlbCA+Q29tcGFueSBOYW1lPC9sYWJlbD5cbiAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIHBsYWNlaG9sZGVyPVwiQ29tcGFueSBOYW1lXCIgLz5cbiAgICAgICAgICAgIDxsYWJlbCA+V2hhdCBhcmUgeW91IGJ1aWxkaW5nPzwvbGFiZWw+XG4gICAgICAgICAgICA8dGV4dGFyZWEgcGxhY2Vob2xkZXI9XCJDb21wYW55IEJyaWVmXCIgLz5cbiAgICAgICAgICAgIDxsYWJlbCA+RmlsZSBBdHRhY2htZW50PC9sYWJlbD5cbiAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwiZmlsZVwiIC8+XG4gICAgICAgICAgICA8bGFiZWwgPkVtYWlsIElkPC9sYWJlbD5cbiAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwiZW1haWxcIiBwbGFjZWhvbGRlcj1cIkNvbnRhY3QgRW1haWxcIiAvPlxuICAgICAgICAgICAgPGxhYmVsID5Nb2JpbGUgTnVtYmVyPC9sYWJlbD5cbiAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIHBsYWNlaG9sZGVyPVwiQ29udGFjdCBOdW1iZXJcIiAvPlxuICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICB0aXRsZT1cIkFwcGx5XCJcbiAgICAgICAgICAgICAgdXJsPVwiL2ljb25zL3JpZ2h0QXJyb3cuc3ZnXCJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gY29uc29sZS5sb2coXCJzdWJzY3JpYmVcIil9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtbGcgbGVhZGluZy02XCJcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9mb3JtPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICA8aDEgY2xhc3NOYW1lPVwibWFpbi10eHQgdGV4dC00eGwgY29udGFjdC1oZWFkaW5nICBmb250LWJvbGRcIiBzdHlsZT17eyBtYXJnaW5Ub3A6ICc1MHB4JyB9fT5NYXRyaXggUGFydG5lcnMgR2xvYmFsPC9oMT5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPSdyb3cnPlxuICAgICAgICA8ZGl2IHN0eWxlPXt7IGZsZXg6ICcyNSUnIH19PlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT0nbWFpbi10eHQgdGV4dC0zeGwgY29udGFjdC1zdWJIZWFkaW5nIGZvbnQtYm9sZCc+VVNBPC9wPlxuICAgICAgICAgIDxociBzdHlsZT17eyB3aWR0aDogJzgwJScsIG1hcmdpbjogJzE1cHggMCAzMnB4IDAnIH19IC8+XG4gICAgICAgICAgPHA+Qk9TVE9OPC9wPjxiciAvPlxuICAgICAgICAgIDxwPlBBTE8gQUxUTzwvcD48YnIgLz5cbiAgICAgICAgICA8cD5TQU4gRlJBTkNJU0NPPC9wPjxiciAvPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPSd3ZWJzaXRlLWxpbmsnIHN0eWxlPXt7IGRpc3BsYXk6ICdmbGV4JyB9fT48YT5WaXNpdCBVU0EgV2Vic2l0ZTwvYT48aW1nIHN0eWxlPXt7IG1hcmdpbkxlZnQ6ICcxNXB4JyB9fSBzcmM9Jy9pY29ucy8tXy5zdmcnIC8+PC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IHN0eWxlPXt7IGZsZXg6ICc1MCUnIH19PlxuICAgICAgICAgIHNkZmRzXG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IHN0eWxlPXt7IGZsZXg6ICcyNSUnIH19PlxuICAgICAgICAgIHNkZmRzXG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cblxuICAgIDwvZGl2PlxuICApXG59XG5leHBvcnQgZGVmYXVsdCBDb250YWN0Rm9ybTtcbiJdLCJzb3VyY2VSb290IjoiIn0=