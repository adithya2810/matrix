webpackHotUpdate_N_E("pages/home",{

/***/ "./src/components/founder/Founder.tsx":
/*!********************************************!*\
  !*** ./src/components/founder/Founder.tsx ***!
  \********************************************/
/*! exports provided: Founder */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Founder", function() { return Founder; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var C_Users_KARTHIK_Documents_workspace_matrix_cms_ui_development_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @components */ "./src/components/index.ts");
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-slick */ "./node_modules/react-slick/lib/index.js");
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_slick__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! slick-carousel/slick/slick.css */ "./node_modules/slick-carousel/slick/slick.css");
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! slick-carousel/slick/slick-theme.css */ "./node_modules/slick-carousel/slick/slick-theme.css");
/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_6__);



var _jsxFileName = "C:\\Users\\KARTHIK\\Documents\\workspace\\matrix-cms-ui-development\\src\\components\\founder\\Founder.tsx",
    _this = undefined;

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { Object(C_Users_KARTHIK_Documents_workspace_matrix_cms_ui_development_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__["default"])(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }






var Founder = function Founder(_ref) {
  var className = _ref.className,
      _ref$style = _ref.style,
      style = _ref$style === void 0 ? {} : _ref$style;
  var heros = [{
    firstName: 'Bhavish',
    lastName: 'AGGARWAL',
    firstName1: null,
    lastName1: null,
    caption: 'Mobility',
    caption1: 'Electric Cars',
    logo: '/icons/ola.svg',
    image: '/icons/Bhavish_image.svg'
  }, {
    firstName: 'ROHIT',
    lastName: 'M.A.',
    firstName1: null,
    lastName1: null,
    caption: 'Healthcare',
    caption1: null,
    logo: '/icons/Cloudnine.svg',
    image: '/icons/Rohit_Treatment.svg'
  }, {
    firstName: 'ANINDYA',
    lastName: 'DUTTA',
    firstName1: 'SANDEEP',
    lastName1: 'DALMIA',
    caption: 'Student Housing Platform',
    caption1: null,
    logo: '/icons/Stanza.svg',
    image: '/icons/Anindya.svg'
  }, {
    firstName: 'Asish',
    lastName: 'MOHAPATRA',
    firstName1: null,
    lastName1: null,
    caption: 'Fintech',
    caption1: 'SME Lending',
    logo: '/icons/OfBusiness.svg',
    image: '/icons/Asish.svg'
  }, {
    firstName: 'Mr.',
    lastName: 'LAKSHIPATHY',
    firstName1: null,
    lastName1: null,
    caption: 'Fintech',
    caption1: 'NBFC',
    logo: '/icons/mx.svg',
    image: '/icons/Laxmipathy.svg'
  }, {
    firstName: 'CHAKRADHAR',
    lastName: 'GADE',
    firstName1: 'NITIN',
    lastName1: 'KAUSHAL',
    caption: 'Fintech',
    caption1: 'NBFC',
    logo: '/icons/Country.svg',
    image: '/icons/Chakradhar.svg'
  }];
  var settings = {
    dots: true,
    infinite: true,
    speed: 500,
    autoplaySpeed: 5000,
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true
  };
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_slick__WEBPACK_IMPORTED_MODULE_4___default.a, _objectSpread(_objectSpread({}, settings), {}, {
    children: heros.map(function (hero) {
      return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "".concat(className),
          style: _objectSpread({
            width: 615.94,
            height: 863.91,
            position: "relative"
          }, style),
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "",
            style: {
              width: 571,
              height: 762,
              position: "absolute",
              background: "#083A4A",
              bottom: 50,
              left: 0
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 87,
            columnNumber: 13
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "",
            style: {
              width: 594,
              height: 788,
              bottom: 65,
              left: 15,
              position: "absolute",
              display: "flex",
              flexDirection: "column"
            },
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_3__["Image"], {
              src: hero.image,
              alt: "founder image",
              style: {
                flexGrow: 1
              }
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 89,
              columnNumber: 15
            }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_3__["Image"], {
              src: "/icons/rectangle.svg",
              alt: "reactangle",
              className: "absolute",
              style: {
                left: 38,
                bottom: 254
              }
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 90,
              columnNumber: 15
            }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              style: {
                height: 209,
                background: "#01576E"
              },
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "text-center flex items-center",
                style: {
                  height: 118,
                  borderBottom: "1px solid #EBEBE9"
                },
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h6", {
                  className: "font-bold text-secondary",
                  style: {
                    fontSize: 32,
                    lineHeight: "36px",
                    letterSpacing: "0.05em",
                    marginLeft: 31,
                    marginRight: 8
                  },
                  children: hero.firstName
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 94,
                  columnNumber: 19
                }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h6", {
                  className: "font-light text-secondary",
                  style: {
                    fontSize: 32,
                    lineHeight: "36px",
                    letterSpacing: "0.05em"
                  },
                  children: hero.lastName
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 97,
                  columnNumber: 19
                }, _this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 93,
                columnNumber: 17
              }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "flex justify-between items-center",
                style: {
                  height: 88
                },
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  style: {
                    marginLeft: 31,
                    display: 'flex',
                    justifyContent: 'space-around'
                  },
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                    className: "text-secondary font-medium text-lg leading-6",
                    children: [" ", hero.caption]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 104,
                    columnNumber: 21
                  }, _this), hero.caption1 && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                    className: "text-secondary font-medium text-lg leading-6",
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("hr", {
                      style: {
                        width: 30,
                        transform: 'rotate(90deg)'
                      }
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 105,
                      columnNumber: 102
                    }, _this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 105,
                    columnNumber: 39
                  }, _this), hero.caption1 && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                    className: "text-secondary font-medium text-lg leading-6",
                    children: [" ", hero.caption1]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 106,
                    columnNumber: 39
                  }, _this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 103,
                  columnNumber: 19
                }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_3__["Image"], {
                  src: hero.logo,
                  alt: "ola",
                  style: {
                    marginRight: 57
                  }
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 108,
                  columnNumber: 19
                }, _this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 102,
                columnNumber: 17
              }, _this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 92,
              columnNumber: 15
            }, _this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 88,
            columnNumber: 13
          }, _this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 86,
          columnNumber: 11
        }, _this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 85,
        columnNumber: 17
      }, _this);
    })
  }), void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 83,
    columnNumber: 5
  }, _this);
};
_c = Founder;

var _c;

$RefreshReg$(_c, "Founder");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vc3JjL2NvbXBvbmVudHMvZm91bmRlci9Gb3VuZGVyLnRzeCJdLCJuYW1lcyI6WyJGb3VuZGVyIiwiY2xhc3NOYW1lIiwic3R5bGUiLCJoZXJvcyIsImZpcnN0TmFtZSIsImxhc3ROYW1lIiwiZmlyc3ROYW1lMSIsImxhc3ROYW1lMSIsImNhcHRpb24iLCJjYXB0aW9uMSIsImxvZ28iLCJpbWFnZSIsInNldHRpbmdzIiwiZG90cyIsImluZmluaXRlIiwic3BlZWQiLCJhdXRvcGxheVNwZWVkIiwic2xpZGVzVG9TaG93Iiwic2xpZGVzVG9TY3JvbGwiLCJhdXRvcGxheSIsIm1hcCIsImhlcm8iLCJ3aWR0aCIsImhlaWdodCIsInBvc2l0aW9uIiwiYmFja2dyb3VuZCIsImJvdHRvbSIsImxlZnQiLCJkaXNwbGF5IiwiZmxleERpcmVjdGlvbiIsImZsZXhHcm93IiwiYm9yZGVyQm90dG9tIiwiZm9udFNpemUiLCJsaW5lSGVpZ2h0IiwibGV0dGVyU3BhY2luZyIsIm1hcmdpbkxlZnQiLCJtYXJnaW5SaWdodCIsImp1c3RpZnlDb250ZW50IiwidHJhbnNmb3JtIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQVdPLElBQU1BLE9BQXdCLEdBQUcsU0FBM0JBLE9BQTJCLE9BQStCO0FBQUEsTUFBNUJDLFNBQTRCLFFBQTVCQSxTQUE0QjtBQUFBLHdCQUFqQkMsS0FBaUI7QUFBQSxNQUFqQkEsS0FBaUIsMkJBQVQsRUFBUztBQUNyRSxNQUFNQyxLQUFLLEdBQUcsQ0FBQztBQUNiQyxhQUFTLEVBQUUsU0FERTtBQUViQyxZQUFRLEVBQUUsVUFGRztBQUdiQyxjQUFVLEVBQUUsSUFIQztBQUliQyxhQUFTLEVBQUUsSUFKRTtBQUtiQyxXQUFPLEVBQUUsVUFMSTtBQU1iQyxZQUFRLEVBQUUsZUFORztBQU9iQyxRQUFJLEVBQUUsZ0JBUE87QUFRYkMsU0FBSyxFQUFFO0FBUk0sR0FBRCxFQVNYO0FBQ0RQLGFBQVMsRUFBRSxPQURWO0FBRURDLFlBQVEsRUFBRSxNQUZUO0FBR0RDLGNBQVUsRUFBRSxJQUhYO0FBSURDLGFBQVMsRUFBRSxJQUpWO0FBS0RDLFdBQU8sRUFBRSxZQUxSO0FBTURDLFlBQVEsRUFBRSxJQU5UO0FBT0RDLFFBQUksRUFBRSxzQkFQTDtBQVFEQyxTQUFLLEVBQUU7QUFSTixHQVRXLEVBa0JYO0FBQ0RQLGFBQVMsRUFBRSxTQURWO0FBRURDLFlBQVEsRUFBRSxPQUZUO0FBR0RDLGNBQVUsRUFBRSxTQUhYO0FBSURDLGFBQVMsRUFBRSxRQUpWO0FBS0RDLFdBQU8sRUFBRSwwQkFMUjtBQU1EQyxZQUFRLEVBQUUsSUFOVDtBQU9EQyxRQUFJLEVBQUUsbUJBUEw7QUFRREMsU0FBSyxFQUFFO0FBUk4sR0FsQlcsRUEyQlg7QUFDRFAsYUFBUyxFQUFFLE9BRFY7QUFFREMsWUFBUSxFQUFFLFdBRlQ7QUFHREMsY0FBVSxFQUFFLElBSFg7QUFJREMsYUFBUyxFQUFFLElBSlY7QUFLREMsV0FBTyxFQUFFLFNBTFI7QUFNREMsWUFBUSxFQUFFLGFBTlQ7QUFPREMsUUFBSSxFQUFFLHVCQVBMO0FBUURDLFNBQUssRUFBRTtBQVJOLEdBM0JXLEVBb0NYO0FBQ0RQLGFBQVMsRUFBRSxLQURWO0FBRURDLFlBQVEsRUFBRSxhQUZUO0FBR0RDLGNBQVUsRUFBRSxJQUhYO0FBSURDLGFBQVMsRUFBRSxJQUpWO0FBS0RDLFdBQU8sRUFBRSxTQUxSO0FBTURDLFlBQVEsRUFBRSxNQU5UO0FBT0RDLFFBQUksRUFBRSxlQVBMO0FBUURDLFNBQUssRUFBRTtBQVJOLEdBcENXLEVBNkNYO0FBQ0RQLGFBQVMsRUFBRSxZQURWO0FBRURDLFlBQVEsRUFBRSxNQUZUO0FBR0RDLGNBQVUsRUFBRSxPQUhYO0FBSURDLGFBQVMsRUFBRSxTQUpWO0FBS0RDLFdBQU8sRUFBRSxTQUxSO0FBTURDLFlBQVEsRUFBRSxNQU5UO0FBT0RDLFFBQUksRUFBRSxvQkFQTDtBQVFEQyxTQUFLLEVBQUU7QUFSTixHQTdDVyxDQUFkO0FBd0RBLE1BQU1DLFFBQVEsR0FBRztBQUNmQyxRQUFJLEVBQUUsSUFEUztBQUVmQyxZQUFRLEVBQUUsSUFGSztBQUdmQyxTQUFLLEVBQUUsR0FIUTtBQUlmQyxpQkFBYSxFQUFFLElBSkE7QUFLZkMsZ0JBQVksRUFBRSxDQUxDO0FBTWZDLGtCQUFjLEVBQUUsQ0FORDtBQU9mQyxZQUFRLEVBQUU7QUFQSyxHQUFqQjtBQVNBLHNCQUNFLHFFQUFDLGtEQUFELGtDQUFZUCxRQUFaO0FBQUEsY0FDR1QsS0FBSyxDQUFDaUIsR0FBTixDQUFVLFVBQUFDLElBQUksRUFBSTtBQUNqQiwwQkFBUTtBQUFBLCtCQUNOO0FBQUssbUJBQVMsWUFBS3BCLFNBQUwsQ0FBZDtBQUFnQyxlQUFLO0FBQUlxQixpQkFBSyxFQUFFLE1BQVg7QUFBbUJDLGtCQUFNLEVBQUUsTUFBM0I7QUFBbUNDLG9CQUFRLEVBQUU7QUFBN0MsYUFBNER0QixLQUE1RCxDQUFyQztBQUFBLGtDQUNFO0FBQUsscUJBQVMsRUFBQyxFQUFmO0FBQWtCLGlCQUFLLEVBQUU7QUFBRW9CLG1CQUFLLEVBQUUsR0FBVDtBQUFjQyxvQkFBTSxFQUFFLEdBQXRCO0FBQTJCQyxzQkFBUSxFQUFFLFVBQXJDO0FBQWlEQyx3QkFBVSxFQUFFLFNBQTdEO0FBQXdFQyxvQkFBTSxFQUFFLEVBQWhGO0FBQW9GQyxrQkFBSSxFQUFFO0FBQTFGO0FBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREYsZUFFRTtBQUFLLHFCQUFTLEVBQUMsRUFBZjtBQUFrQixpQkFBSyxFQUFFO0FBQUVMLG1CQUFLLEVBQUUsR0FBVDtBQUFjQyxvQkFBTSxFQUFFLEdBQXRCO0FBQTJCRyxvQkFBTSxFQUFFLEVBQW5DO0FBQXVDQyxrQkFBSSxFQUFFLEVBQTdDO0FBQWlESCxzQkFBUSxFQUFFLFVBQTNEO0FBQXVFSSxxQkFBTyxFQUFFLE1BQWhGO0FBQXdGQywyQkFBYSxFQUFFO0FBQXZHLGFBQXpCO0FBQUEsb0NBQ0UscUVBQUMsaURBQUQ7QUFBTyxpQkFBRyxFQUFFUixJQUFJLENBQUNWLEtBQWpCO0FBQXdCLGlCQUFHLEVBQUMsZUFBNUI7QUFBNEMsbUJBQUssRUFBRTtBQUFFbUIsd0JBQVEsRUFBRTtBQUFaO0FBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREYsZUFFRSxxRUFBQyxpREFBRDtBQUFPLGlCQUFHLEVBQUMsc0JBQVg7QUFBa0MsaUJBQUcsRUFBRSxZQUF2QztBQUFxRCx1QkFBUyxFQUFDLFVBQS9EO0FBQTBFLG1CQUFLLEVBQUU7QUFBRUgsb0JBQUksRUFBRSxFQUFSO0FBQVlELHNCQUFNLEVBQUU7QUFBcEI7QUFBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFGRixlQUlFO0FBQUssbUJBQUssRUFBRTtBQUFFSCxzQkFBTSxFQUFFLEdBQVY7QUFBZUUsMEJBQVUsRUFBRTtBQUEzQixlQUFaO0FBQUEsc0NBQ0U7QUFBSyx5QkFBUyxFQUFDLCtCQUFmO0FBQStDLHFCQUFLLEVBQUU7QUFBRUYsd0JBQU0sRUFBRSxHQUFWO0FBQWVRLDhCQUFZLEVBQUU7QUFBN0IsaUJBQXREO0FBQUEsd0NBQ0U7QUFBSSwyQkFBUyxFQUFDLDBCQUFkO0FBQXlDLHVCQUFLLEVBQUU7QUFBRUMsNEJBQVEsRUFBRSxFQUFaO0FBQWdCQyw4QkFBVSxFQUFFLE1BQTVCO0FBQW9DQyxpQ0FBYSxFQUFFLFFBQW5EO0FBQTZEQyw4QkFBVSxFQUFFLEVBQXpFO0FBQTZFQywrQkFBVyxFQUFFO0FBQTFGLG1CQUFoRDtBQUFBLDRCQUNHZixJQUFJLENBQUNqQjtBQURSO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBREYsZUFJRTtBQUFJLDJCQUFTLEVBQUMsMkJBQWQ7QUFBMEMsdUJBQUssRUFBRTtBQUFFNEIsNEJBQVEsRUFBRSxFQUFaO0FBQWdCQyw4QkFBVSxFQUFFLE1BQTVCO0FBQW9DQyxpQ0FBYSxFQUFFO0FBQW5ELG1CQUFqRDtBQUFBLDRCQUNHYixJQUFJLENBQUNoQjtBQURSO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQURGLGVBVUU7QUFBSyx5QkFBUyxFQUFDLG1DQUFmO0FBQW1ELHFCQUFLLEVBQUU7QUFBRWtCLHdCQUFNLEVBQUU7QUFBVixpQkFBMUQ7QUFBQSx3Q0FDRTtBQUFLLHVCQUFLLEVBQUU7QUFBRVksOEJBQVUsRUFBRSxFQUFkO0FBQWtCUCwyQkFBTyxFQUFFLE1BQTNCO0FBQW1DUyxrQ0FBYyxFQUFFO0FBQW5ELG1CQUFaO0FBQUEsMENBQ0U7QUFBTSw2QkFBUyxFQUFDLDhDQUFoQjtBQUFBLG9DQUFpRWhCLElBQUksQ0FBQ2IsT0FBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQURGLEVBRUdhLElBQUksQ0FBQ1osUUFBTCxpQkFBaUI7QUFBTSw2QkFBUyxFQUFDLDhDQUFoQjtBQUFBLDJDQUErRDtBQUFJLDJCQUFLLEVBQUU7QUFBRWEsNkJBQUssRUFBRSxFQUFUO0FBQWFnQixpQ0FBUyxFQUFFO0FBQXhCO0FBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUZwQixFQUdHakIsSUFBSSxDQUFDWixRQUFMLGlCQUFpQjtBQUFNLDZCQUFTLEVBQUMsOENBQWhCO0FBQUEsb0NBQWlFWSxJQUFJLENBQUNaLFFBQXRFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFIcEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQURGLGVBTUUscUVBQUMsaURBQUQ7QUFBTyxxQkFBRyxFQUFFWSxJQUFJLENBQUNYLElBQWpCO0FBQXVCLHFCQUFHLEVBQUUsS0FBNUI7QUFBbUMsdUJBQUssRUFBRTtBQUFFMEIsK0JBQVcsRUFBRTtBQUFmO0FBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRE07QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFSO0FBNkJELEtBOUJBO0FBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQURGO0FBdUNELENBekdNO0tBQU1wQyxPIiwiZmlsZSI6InN0YXRpYy93ZWJwYWNrL3BhZ2VzL2hvbWUuMTA2MWE0ZDRiOTFlYTE4ODkzNDUuaG90LXVwZGF0ZS5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IEltYWdlIH0gZnJvbSBcIkBjb21wb25lbnRzXCI7XG5pbXBvcnQgU2xpZGVyIGZyb20gXCJyZWFjdC1zbGlja1wiO1xuaW1wb3J0IFwic2xpY2stY2Fyb3VzZWwvc2xpY2svc2xpY2suY3NzXCI7XG5pbXBvcnQgXCJzbGljay1jYXJvdXNlbC9zbGljay9zbGljay10aGVtZS5jc3NcIjtcblxuZXhwb3J0IHR5cGUgUHJvcHMgPSB7XG4gIG5hbWVzPzogQXJyYXk8c3RyaW5nPjtcbiAgYmFja2dyb3VuZF91cmw/OiBzdHJpbmc7XG4gIHRhZ3M/OiBBcnJheTxzdHJpbmc+O1xuICBsb2dvPzogc3RyaW5nO1xuICBjbGFzc05hbWU/OiBzdHJpbmc7XG4gIHN0eWxlPzogYW55O1xufTtcblxuZXhwb3J0IGNvbnN0IEZvdW5kZXI6IFJlYWN0LkZDPFByb3BzPiA9ICh7IGNsYXNzTmFtZSwgc3R5bGUgPSB7fSB9KSA9PiB7XG4gIGNvbnN0IGhlcm9zID0gW3tcbiAgICBmaXJzdE5hbWU6ICdCaGF2aXNoJyxcbiAgICBsYXN0TmFtZTogJ0FHR0FSV0FMJyxcbiAgICBmaXJzdE5hbWUxOiBudWxsLFxuICAgIGxhc3ROYW1lMTogbnVsbCxcbiAgICBjYXB0aW9uOiAnTW9iaWxpdHknLFxuICAgIGNhcHRpb24xOiAnRWxlY3RyaWMgQ2FycycsXG4gICAgbG9nbzogJy9pY29ucy9vbGEuc3ZnJyxcbiAgICBpbWFnZTogJy9pY29ucy9CaGF2aXNoX2ltYWdlLnN2ZydcbiAgfSwge1xuICAgIGZpcnN0TmFtZTogJ1JPSElUJyxcbiAgICBsYXN0TmFtZTogJ00uQS4nLFxuICAgIGZpcnN0TmFtZTE6IG51bGwsXG4gICAgbGFzdE5hbWUxOiBudWxsLFxuICAgIGNhcHRpb246ICdIZWFsdGhjYXJlJyxcbiAgICBjYXB0aW9uMTogbnVsbCxcbiAgICBsb2dvOiAnL2ljb25zL0Nsb3VkbmluZS5zdmcnLFxuICAgIGltYWdlOiAnL2ljb25zL1JvaGl0X1RyZWF0bWVudC5zdmcnXG4gIH0sIHtcbiAgICBmaXJzdE5hbWU6ICdBTklORFlBJyxcbiAgICBsYXN0TmFtZTogJ0RVVFRBJyxcbiAgICBmaXJzdE5hbWUxOiAnU0FOREVFUCcsXG4gICAgbGFzdE5hbWUxOiAnREFMTUlBJyxcbiAgICBjYXB0aW9uOiAnU3R1ZGVudCBIb3VzaW5nIFBsYXRmb3JtJyxcbiAgICBjYXB0aW9uMTogbnVsbCxcbiAgICBsb2dvOiAnL2ljb25zL1N0YW56YS5zdmcnLFxuICAgIGltYWdlOiAnL2ljb25zL0FuaW5keWEuc3ZnJ1xuICB9LCB7XG4gICAgZmlyc3ROYW1lOiAnQXNpc2gnLFxuICAgIGxhc3ROYW1lOiAnTU9IQVBBVFJBJyxcbiAgICBmaXJzdE5hbWUxOiBudWxsLFxuICAgIGxhc3ROYW1lMTogbnVsbCxcbiAgICBjYXB0aW9uOiAnRmludGVjaCcsXG4gICAgY2FwdGlvbjE6ICdTTUUgTGVuZGluZycsXG4gICAgbG9nbzogJy9pY29ucy9PZkJ1c2luZXNzLnN2ZycsXG4gICAgaW1hZ2U6ICcvaWNvbnMvQXNpc2guc3ZnJ1xuICB9LCB7XG4gICAgZmlyc3ROYW1lOiAnTXIuJyxcbiAgICBsYXN0TmFtZTogJ0xBS1NISVBBVEhZJyxcbiAgICBmaXJzdE5hbWUxOiBudWxsLFxuICAgIGxhc3ROYW1lMTogbnVsbCxcbiAgICBjYXB0aW9uOiAnRmludGVjaCcsXG4gICAgY2FwdGlvbjE6ICdOQkZDJyxcbiAgICBsb2dvOiAnL2ljb25zL214LnN2ZycsXG4gICAgaW1hZ2U6ICcvaWNvbnMvTGF4bWlwYXRoeS5zdmcnXG4gIH0sIHtcbiAgICBmaXJzdE5hbWU6ICdDSEFLUkFESEFSJyxcbiAgICBsYXN0TmFtZTogJ0dBREUnLFxuICAgIGZpcnN0TmFtZTE6ICdOSVRJTicsXG4gICAgbGFzdE5hbWUxOiAnS0FVU0hBTCcsXG4gICAgY2FwdGlvbjogJ0ZpbnRlY2gnLFxuICAgIGNhcHRpb24xOiAnTkJGQycsXG4gICAgbG9nbzogJy9pY29ucy9Db3VudHJ5LnN2ZycsXG4gICAgaW1hZ2U6ICcvaWNvbnMvQ2hha3JhZGhhci5zdmcnXG4gIH1dXG5cbiAgY29uc3Qgc2V0dGluZ3MgPSB7XG4gICAgZG90czogdHJ1ZSxcbiAgICBpbmZpbml0ZTogdHJ1ZSxcbiAgICBzcGVlZDogNTAwLFxuICAgIGF1dG9wbGF5U3BlZWQ6IDUwMDAsXG4gICAgc2xpZGVzVG9TaG93OiAxLFxuICAgIHNsaWRlc1RvU2Nyb2xsOiAxLFxuICAgIGF1dG9wbGF5OiB0cnVlXG4gIH07XG4gIHJldHVybiAoXG4gICAgPFNsaWRlciB7Li4uc2V0dGluZ3N9PlxuICAgICAge2hlcm9zLm1hcChoZXJvID0+IHtcbiAgICAgICAgcmV0dXJuICg8ZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgJHtjbGFzc05hbWV9YH0gc3R5bGU9e3sgd2lkdGg6IDYxNS45NCwgaGVpZ2h0OiA4NjMuOTEsIHBvc2l0aW9uOiBcInJlbGF0aXZlXCIsIC4uLnN0eWxlLCB9fT5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiXCIgc3R5bGU9e3sgd2lkdGg6IDU3MSwgaGVpZ2h0OiA3NjIsIHBvc2l0aW9uOiBcImFic29sdXRlXCIsIGJhY2tncm91bmQ6IFwiIzA4M0E0QVwiLCBib3R0b206IDUwLCBsZWZ0OiAwLCB9fT48L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiXCIgc3R5bGU9e3sgd2lkdGg6IDU5NCwgaGVpZ2h0OiA3ODgsIGJvdHRvbTogNjUsIGxlZnQ6IDE1LCBwb3NpdGlvbjogXCJhYnNvbHV0ZVwiLCBkaXNwbGF5OiBcImZsZXhcIiwgZmxleERpcmVjdGlvbjogXCJjb2x1bW5cIiwgfX0+XG4gICAgICAgICAgICAgIDxJbWFnZSBzcmM9e2hlcm8uaW1hZ2V9IGFsdD1cImZvdW5kZXIgaW1hZ2VcIiBzdHlsZT17eyBmbGV4R3JvdzogMSB9fT48L0ltYWdlPlxuICAgICAgICAgICAgICA8SW1hZ2Ugc3JjPVwiL2ljb25zL3JlY3RhbmdsZS5zdmdcIiBhbHQ9e1wicmVhY3RhbmdsZVwifSBjbGFzc05hbWU9XCJhYnNvbHV0ZVwiIHN0eWxlPXt7IGxlZnQ6IDM4LCBib3R0b206IDI1NCB9fSAvPlxuXG4gICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgaGVpZ2h0OiAyMDksIGJhY2tncm91bmQ6IFwiIzAxNTc2RVwiIH19PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgZmxleCBpdGVtcy1jZW50ZXJcIiBzdHlsZT17eyBoZWlnaHQ6IDExOCwgYm9yZGVyQm90dG9tOiBcIjFweCBzb2xpZCAjRUJFQkU5XCIgfX0+XG4gICAgICAgICAgICAgICAgICA8aDYgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtc2Vjb25kYXJ5XCIgc3R5bGU9e3sgZm9udFNpemU6IDMyLCBsaW5lSGVpZ2h0OiBcIjM2cHhcIiwgbGV0dGVyU3BhY2luZzogXCIwLjA1ZW1cIiwgbWFyZ2luTGVmdDogMzEsIG1hcmdpblJpZ2h0OiA4LCB9fT5cbiAgICAgICAgICAgICAgICAgICAge2hlcm8uZmlyc3ROYW1lfVxuICAgICAgICAgICAgICAgICAgPC9oNj5cbiAgICAgICAgICAgICAgICAgIDxoNiBjbGFzc05hbWU9XCJmb250LWxpZ2h0IHRleHQtc2Vjb25kYXJ5XCIgc3R5bGU9e3sgZm9udFNpemU6IDMyLCBsaW5lSGVpZ2h0OiBcIjM2cHhcIiwgbGV0dGVyU3BhY2luZzogXCIwLjA1ZW1cIiwgfX0+XG4gICAgICAgICAgICAgICAgICAgIHtoZXJvLmxhc3ROYW1lfVxuICAgICAgICAgICAgICAgICAgPC9oNj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyXCIgc3R5bGU9e3sgaGVpZ2h0OiA4OCB9fT5cbiAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgbWFyZ2luTGVmdDogMzEsIGRpc3BsYXk6ICdmbGV4JywganVzdGlmeUNvbnRlbnQ6ICdzcGFjZS1hcm91bmQnIH19PlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNlY29uZGFyeSBmb250LW1lZGl1bSB0ZXh0LWxnIGxlYWRpbmctNlwiPiB7aGVyby5jYXB0aW9ufTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAge2hlcm8uY2FwdGlvbjEgJiYgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zZWNvbmRhcnkgZm9udC1tZWRpdW0gdGV4dC1sZyBsZWFkaW5nLTZcIj48aHIgc3R5bGU9e3sgd2lkdGg6IDMwLCB0cmFuc2Zvcm06ICdyb3RhdGUoOTBkZWcpJyB9fSAvPjwvc3Bhbj59XG4gICAgICAgICAgICAgICAgICAgIHtoZXJvLmNhcHRpb24xICYmIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2Vjb25kYXJ5IGZvbnQtbWVkaXVtIHRleHQtbGcgbGVhZGluZy02XCI+IHtoZXJvLmNhcHRpb24xfTwvc3Bhbj59XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxJbWFnZSBzcmM9e2hlcm8ubG9nb30gYWx0PXtcIm9sYVwifSBzdHlsZT17eyBtYXJnaW5SaWdodDogNTcgfX0gLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+KVxuICAgICAgfSl9XG5cblxuXG5cbiAgICA8L1NsaWRlcj5cbiAgKTtcbn07XG4iXSwic291cmNlUm9vdCI6IiJ9