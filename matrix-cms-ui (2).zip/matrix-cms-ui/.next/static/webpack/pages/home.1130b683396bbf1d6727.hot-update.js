webpackHotUpdate_N_E("pages/home",{

/***/ "./node_modules/next/dist/compiled/css-loader/cjs.js?!./node_modules/next/dist/compiled/postcss-loader/cjs.js?!./node_modules/react-responsive-carousel/lib/styles/carousel.min.css":
false,

/***/ "./node_modules/react-responsive-carousel/lib/styles/carousel.min.css":
false,

/***/ "./src/modules/home/homeCarousal/HomeCarousal.tsx":
/*!********************************************************!*\
  !*** ./src/modules/home/homeCarousal/HomeCarousal.tsx ***!
  \********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var C_Users_KARTHIK_Documents_workspace_matrix_cms_ui_development_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @components */ "./src/components/index.ts");
/* harmony import */ var _components_founder_FounderDetail__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @components/founder/FounderDetail */ "./src/components/founder/FounderDetail.tsx");



var _jsxFileName = "C:\\Users\\KARTHIK\\Documents\\workspace\\matrix-cms-ui-development\\src\\modules\\home\\homeCarousal\\HomeCarousal.tsx",
    _this = undefined,
    _s = $RefreshSig$();




var data = [{
  image_url: "/icons/content1.svg",
  title: "From both sides of the table : Kunal Bahl unplugged",
  author: "TARUN DAVDA",
  content_id: "abcdef",
  content_type: "blog",
  read_duration: "4 MIN"
}, {
  image_url: "/icons/content1.svg",
  title: "From both sides of the table : Kunal Bahl unplugged",
  author: "TARUN DAVDA",
  content_id: "abcdefg",
  content_type: "blog",
  read_duration: "4 MIN"
}];
var heros = [{
  firstName: 'ROHIT',
  lastName: 'M.A.',
  firstName1: null,
  lastName1: null,
  caption: 'At Cloudnine, we believe that a child is life’s greatest gift and pregnancy is one of the most magical experiences nature can offer. ',
  logo: '/icons/Cloudnine.svg',
  image: '/icons/Rohit_Treatment.svg',
  heading: ['Leading chain of ', 'maternity hospitals', ''],
  bg: ''
}, {
  firstName: 'ANINDYA',
  lastName: 'DUTTA',
  firstName1: 'SANDEEP',
  lastName1: 'DALMIA',
  caption: 'Stanza Living provides fully-managed shared living accommodations to students and young professionals.',
  logo: '/icons/Stanza.svg',
  image: '/icons/Anindya.svg',
  heading: ['Tech-enabled ', 'student housing', 'platform'],
  bg: ''
}, {
  firstName: 'Asish',
  lastName: 'MOHAPATRA',
  firstName1: null,
  lastName1: null,
  caption: 'OFB Tech (OfBusiness) is a tech-enabled platform that facilitates raw material procurement and credit for SMEs,',
  logo: '/icons/OfBusiness.svg',
  image: '/icons/Asish.svg',
  heading: ['SME', 'lending', '']
}, {
  firstName: 'Mr.',
  lastName: 'LAKSHIPATHY',
  firstName1: null,
  lastName1: null,
  caption: 'A specialized financial services company funding the people who were perceived to be unfundable',
  logo: '/icons/mx.svg',
  image: '/icons/Laxmipathy.svg',
  heading: ['Credit led', 'B2B marketplace', '']
}, {
  firstName: 'CHAKRADHAR',
  lastName: 'GADE',
  firstName1: 'NITIN',
  lastName1: 'KAUSHAL',
  caption: 'Country Delight aims to bring back the basics of Milk. It promises natural, fresh and unadulterated milk directly to the doorstep of the consumer.',
  logo: '/icons/Country.svg',
  heading: ['D2C', 'dairy & fresh foods', 'brand'],
  image: '/icons/Chakradhar.svg'
}, {
  firstName: 'Bhavish',
  lastName: 'AGGARWAL',
  firstName1: null,
  lastName1: null,
  caption: 'Ola is India’s largest mobility platform and one of the world’s largest ride-hailing companies, serving 250+ cities across India, Australia, New Zealand, and the UK.',
  logo: '/icons/ola.svg',
  image: '/icons/Bhavish_image.svg',
  heading: ['India’s leading', 'mobility', 'player']
}];

var HomeCarousal = function HomeCarousal() {
  _s();

  var _React$useState = react__WEBPACK_IMPORTED_MODULE_2___default.a.useState("/icons/backgroundCarousalImage.png"),
      _React$useState2 = Object(C_Users_KARTHIK_Documents_workspace_matrix_cms_ui_development_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_1__["default"])(_React$useState, 2),
      backgroundUrl = _React$useState2[0],
      setBackgroundUrl = _React$useState2[1];

  return (
    /*#__PURE__*/
    // <Carousel>
    Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "relative",
      style: {
        height: 1080
      },
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "absolute h-full w-full flex flex-col",
        style: {
          backgroundImage: "url(".concat(backgroundUrl, ")"),
          backgroundSize: "cover"
        },
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "flex",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_3__["Image"], {
            src: "/icons/leftArrow.svg",
            alt: "right Icon",
            height: 73,
            width: 37,
            style: {
              marginLeft: 179
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 99,
            columnNumber: 11
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            style: {
              width: 533,
              marginLeft: 100
            },
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              style: {
                fontWeight: 300,
                fontSize: "100px",
                lineHeight: "120px",
                letterSpacing: "-0.01em",
                opacity: 0.35,
                marginTop: 117
              },
              children: [" ", "01/05"]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 107,
              columnNumber: 13
            }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "text-secondary-light",
              style: {
                fontWeight: 200,
                fontSize: "85px",
                lineHeight: "95px",
                opacity: 1,
                marginTop: 151,
                minWidth: 545
              },
              children: ["Tech-enabled", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 132,
                columnNumber: 15
              }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                className: "font-bold",
                children: " Student housing"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 133,
                columnNumber: 15
              }, _this), " ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 133,
                columnNumber: 67
              }, _this), "Platform"]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 120,
              columnNumber: 13
            }, _this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 106,
            columnNumber: 11
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_founder_FounderDetail__WEBPACK_IMPORTED_MODULE_4__["FounderDetail"], {
            style: {
              marginTop: 36,
              marginLeft: 103
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 137,
            columnNumber: 11
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_3__["Image"], {
            src: "/icons/rightArrow.large.svg",
            alt: "right Icon",
            height: 73,
            width: 37,
            style: {
              marginLeft: 103
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 138,
            columnNumber: 11
          }, _this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 98,
          columnNumber: 9
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "absolute bg-accent",
          style: {
            bottom: 33,
            left: 269,
            height: 246,
            width: 564
          },
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
            className: "text-secondary font-medium text-lg leading-6 text-center h-full flex justify-center items-center",
            style: {
              writingMode: "vertical-lr",
              width: 56
            },
            children: [" ", "Hospitality Sector", " "]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 150,
            columnNumber: 11
          }, _this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 146,
          columnNumber: 9
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_3__["ContentSlider"], {
          style: {
            left: 325,
            background: "#EBEBE9",
            border: "1px solid #EBEBE9",
            boxSizing: "border-box",
            fontSize: 28,
            lineHeight: "34px",
            paddingTop: 24,
            paddingLeft: 34
          },
          contentList: data,
          className: "absolute bottom-0 right-0 text-primary-dark",
          header: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
            children: ["Dive into the ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
              className: "text-accent",
              children: "Matrix Moments"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 171,
              columnNumber: 39
            }, _this), " series"]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 171,
            columnNumber: 19
          }, _this)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 158,
          columnNumber: 9
        }, _this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 91,
        columnNumber: 7
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 90,
      columnNumber: 5
    }, _this) // </Carousel>

  );
};

_s(HomeCarousal, "zzogb7U4cw9IdhqzvwsqoFa+QS0=");

_c = HomeCarousal;
/* harmony default export */ __webpack_exports__["default"] = (HomeCarousal);

var _c;

$RefreshReg$(_c, "HomeCarousal");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vc3JjL21vZHVsZXMvaG9tZS9ob21lQ2Fyb3VzYWwvSG9tZUNhcm91c2FsLnRzeCJdLCJuYW1lcyI6WyJkYXRhIiwiaW1hZ2VfdXJsIiwidGl0bGUiLCJhdXRob3IiLCJjb250ZW50X2lkIiwiY29udGVudF90eXBlIiwicmVhZF9kdXJhdGlvbiIsImhlcm9zIiwiZmlyc3ROYW1lIiwibGFzdE5hbWUiLCJmaXJzdE5hbWUxIiwibGFzdE5hbWUxIiwiY2FwdGlvbiIsImxvZ28iLCJpbWFnZSIsImhlYWRpbmciLCJiZyIsIkhvbWVDYXJvdXNhbCIsIlJlYWN0IiwidXNlU3RhdGUiLCJiYWNrZ3JvdW5kVXJsIiwic2V0QmFja2dyb3VuZFVybCIsImhlaWdodCIsImJhY2tncm91bmRJbWFnZSIsImJhY2tncm91bmRTaXplIiwibWFyZ2luTGVmdCIsIndpZHRoIiwiZm9udFdlaWdodCIsImZvbnRTaXplIiwibGluZUhlaWdodCIsImxldHRlclNwYWNpbmciLCJvcGFjaXR5IiwibWFyZ2luVG9wIiwibWluV2lkdGgiLCJib3R0b20iLCJsZWZ0Iiwid3JpdGluZ01vZGUiLCJiYWNrZ3JvdW5kIiwiYm9yZGVyIiwiYm94U2l6aW5nIiwicGFkZGluZ1RvcCIsInBhZGRpbmdMZWZ0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBR0EsSUFBTUEsSUFBSSxHQUFHLENBQ1g7QUFDRUMsV0FBUyxFQUFFLHFCQURiO0FBRUVDLE9BQUssRUFBRSxxREFGVDtBQUdFQyxRQUFNLEVBQUUsYUFIVjtBQUlFQyxZQUFVLEVBQUUsUUFKZDtBQUtFQyxjQUFZLEVBQUUsTUFMaEI7QUFNRUMsZUFBYSxFQUFFO0FBTmpCLENBRFcsRUFTWDtBQUNFTCxXQUFTLEVBQUUscUJBRGI7QUFFRUMsT0FBSyxFQUFFLHFEQUZUO0FBR0VDLFFBQU0sRUFBRSxhQUhWO0FBSUVDLFlBQVUsRUFBRSxTQUpkO0FBS0VDLGNBQVksRUFBRSxNQUxoQjtBQU1FQyxlQUFhLEVBQUU7QUFOakIsQ0FUVyxDQUFiO0FBb0JBLElBQU1DLEtBQUssR0FBRyxDQUFDO0FBQ2JDLFdBQVMsRUFBRSxPQURFO0FBRWJDLFVBQVEsRUFBRSxNQUZHO0FBR2JDLFlBQVUsRUFBRSxJQUhDO0FBSWJDLFdBQVMsRUFBRSxJQUpFO0FBS2JDLFNBQU8sRUFBRSx1SUFMSTtBQU1iQyxNQUFJLEVBQUUsc0JBTk87QUFPYkMsT0FBSyxFQUFFLDRCQVBNO0FBUWJDLFNBQU8sRUFBRSxDQUFDLG1CQUFELEVBQXNCLHFCQUF0QixFQUE2QyxFQUE3QyxDQVJJO0FBU2JDLElBQUUsRUFBRTtBQVRTLENBQUQsRUFVWDtBQUNEUixXQUFTLEVBQUUsU0FEVjtBQUVEQyxVQUFRLEVBQUUsT0FGVDtBQUdEQyxZQUFVLEVBQUUsU0FIWDtBQUlEQyxXQUFTLEVBQUUsUUFKVjtBQUtEQyxTQUFPLEVBQUUsd0dBTFI7QUFNREMsTUFBSSxFQUFFLG1CQU5MO0FBT0RDLE9BQUssRUFBRSxvQkFQTjtBQVFEQyxTQUFPLEVBQUUsQ0FBQyxlQUFELEVBQWtCLGlCQUFsQixFQUFxQyxVQUFyQyxDQVJSO0FBU0RDLElBQUUsRUFBRTtBQVRILENBVlcsRUFvQlg7QUFDRFIsV0FBUyxFQUFFLE9BRFY7QUFFREMsVUFBUSxFQUFFLFdBRlQ7QUFHREMsWUFBVSxFQUFFLElBSFg7QUFJREMsV0FBUyxFQUFFLElBSlY7QUFLREMsU0FBTyxFQUFFLGlIQUxSO0FBTURDLE1BQUksRUFBRSx1QkFOTDtBQU9EQyxPQUFLLEVBQUUsa0JBUE47QUFRREMsU0FBTyxFQUFFLENBQUMsS0FBRCxFQUFRLFNBQVIsRUFBbUIsRUFBbkI7QUFSUixDQXBCVyxFQTZCWDtBQUNEUCxXQUFTLEVBQUUsS0FEVjtBQUVEQyxVQUFRLEVBQUUsYUFGVDtBQUdEQyxZQUFVLEVBQUUsSUFIWDtBQUlEQyxXQUFTLEVBQUUsSUFKVjtBQUtEQyxTQUFPLEVBQUUsaUdBTFI7QUFNREMsTUFBSSxFQUFFLGVBTkw7QUFPREMsT0FBSyxFQUFFLHVCQVBOO0FBUURDLFNBQU8sRUFBRSxDQUFDLFlBQUQsRUFBZSxpQkFBZixFQUFrQyxFQUFsQztBQVJSLENBN0JXLEVBc0NYO0FBQ0RQLFdBQVMsRUFBRSxZQURWO0FBRURDLFVBQVEsRUFBRSxNQUZUO0FBR0RDLFlBQVUsRUFBRSxPQUhYO0FBSURDLFdBQVMsRUFBRSxTQUpWO0FBS0RDLFNBQU8sRUFBRSxvSkFMUjtBQU1EQyxNQUFJLEVBQUUsb0JBTkw7QUFPREUsU0FBTyxFQUFFLENBQUMsS0FBRCxFQUFRLHFCQUFSLEVBQStCLE9BQS9CLENBUFI7QUFRREQsT0FBSyxFQUFFO0FBUk4sQ0F0Q1csRUErQ1g7QUFDRE4sV0FBUyxFQUFFLFNBRFY7QUFFREMsVUFBUSxFQUFFLFVBRlQ7QUFHREMsWUFBVSxFQUFFLElBSFg7QUFJREMsV0FBUyxFQUFFLElBSlY7QUFLREMsU0FBTyxFQUFFLHVLQUxSO0FBTURDLE1BQUksRUFBRSxnQkFOTDtBQU9EQyxPQUFLLEVBQUUsMEJBUE47QUFRREMsU0FBTyxFQUFFLENBQUMsaUJBQUQsRUFBb0IsVUFBcEIsRUFBZ0MsUUFBaEM7QUFSUixDQS9DVyxDQUFkOztBQTBEQSxJQUFNRSxZQUFZLEdBQUcsU0FBZkEsWUFBZSxHQUFNO0FBQUE7O0FBQUEsd0JBQ2lCQyw0Q0FBSyxDQUFDQyxRQUFOLENBQ3hDLG9DQUR3QyxDQURqQjtBQUFBO0FBQUEsTUFDbEJDLGFBRGtCO0FBQUEsTUFDSEMsZ0JBREc7O0FBSXpCO0FBQUE7QUFDRTtBQUNBO0FBQUssZUFBUyxFQUFDLFVBQWY7QUFBMEIsV0FBSyxFQUFFO0FBQUVDLGNBQU0sRUFBRTtBQUFWLE9BQWpDO0FBQUEsNkJBQ0U7QUFDRSxpQkFBUyxFQUFDLHNDQURaO0FBRUUsYUFBSyxFQUFFO0FBQ0xDLHlCQUFlLGdCQUFTSCxhQUFULE1BRFY7QUFFTEksd0JBQWMsRUFBRTtBQUZYLFNBRlQ7QUFBQSxnQ0FPRTtBQUFLLG1CQUFTLEVBQUMsTUFBZjtBQUFBLGtDQUNFLHFFQUFDLGlEQUFEO0FBQ0UsZUFBRyxFQUFDLHNCQUROO0FBRUUsZUFBRyxFQUFFLFlBRlA7QUFHRSxrQkFBTSxFQUFFLEVBSFY7QUFJRSxpQkFBSyxFQUFFLEVBSlQ7QUFLRSxpQkFBSyxFQUFFO0FBQUVDLHdCQUFVLEVBQUU7QUFBZDtBQUxUO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREYsZUFRRTtBQUFLLGlCQUFLLEVBQUU7QUFBRUMsbUJBQUssRUFBRSxHQUFUO0FBQWNELHdCQUFVLEVBQUU7QUFBMUIsYUFBWjtBQUFBLG9DQUNFO0FBQ0UsbUJBQUssRUFBRTtBQUNMRSwwQkFBVSxFQUFFLEdBRFA7QUFFTEMsd0JBQVEsRUFBRSxPQUZMO0FBR0xDLDBCQUFVLEVBQUUsT0FIUDtBQUlMQyw2QkFBYSxFQUFFLFNBSlY7QUFLTEMsdUJBQU8sRUFBRSxJQUxKO0FBTUxDLHlCQUFTLEVBQUU7QUFOTixlQURUO0FBQUEseUJBVUcsR0FWSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREYsZUFjRTtBQUNFLHVCQUFTLEVBQUMsc0JBRFo7QUFFRSxtQkFBSyxFQUFFO0FBQ0xMLDBCQUFVLEVBQUUsR0FEUDtBQUVMQyx3QkFBUSxFQUFFLE1BRkw7QUFHTEMsMEJBQVUsRUFBRSxNQUhQO0FBSUxFLHVCQUFPLEVBQUUsQ0FKSjtBQUtMQyx5QkFBUyxFQUFFLEdBTE47QUFNTEMsd0JBQVEsRUFBRTtBQU5MLGVBRlQ7QUFBQSxzREFZRTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQVpGLGVBYUU7QUFBTSx5QkFBUyxFQUFDLFdBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWJGLG9CQWFzRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQWJ0RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBZEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVJGLGVBdUNFLHFFQUFDLCtFQUFEO0FBQWUsaUJBQUssRUFBRTtBQUFFRCx1QkFBUyxFQUFFLEVBQWI7QUFBaUJQLHdCQUFVLEVBQUU7QUFBN0I7QUFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF2Q0YsZUF3Q0UscUVBQUMsaURBQUQ7QUFDRSxlQUFHLEVBQUMsNkJBRE47QUFFRSxlQUFHLEVBQUUsWUFGUDtBQUdFLGtCQUFNLEVBQUUsRUFIVjtBQUlFLGlCQUFLLEVBQUUsRUFKVDtBQUtFLGlCQUFLLEVBQUU7QUFBRUEsd0JBQVUsRUFBRTtBQUFkO0FBTFQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF4Q0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVBGLGVBdURFO0FBQ0UsbUJBQVMsRUFBQyxvQkFEWjtBQUVFLGVBQUssRUFBRTtBQUFFUyxrQkFBTSxFQUFFLEVBQVY7QUFBY0MsZ0JBQUksRUFBRSxHQUFwQjtBQUF5QmIsa0JBQU0sRUFBRSxHQUFqQztBQUFzQ0ksaUJBQUssRUFBRTtBQUE3QyxXQUZUO0FBQUEsaUNBSUU7QUFDRSxxQkFBUyxFQUFDLGtHQURaO0FBRUUsaUJBQUssRUFBRTtBQUFFVSx5QkFBVyxFQUFFLGFBQWY7QUFBOEJWLG1CQUFLLEVBQUU7QUFBckMsYUFGVDtBQUFBLHVCQUlHLEdBSkgsd0JBS3FCLEdBTHJCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBdkRGLGVBbUVFLHFFQUFDLHlEQUFEO0FBQ0UsZUFBSyxFQUFFO0FBQ0xTLGdCQUFJLEVBQUUsR0FERDtBQUVMRSxzQkFBVSxFQUFFLFNBRlA7QUFHTEMsa0JBQU0sRUFBRSxtQkFISDtBQUlMQyxxQkFBUyxFQUFFLFlBSk47QUFLTFgsb0JBQVEsRUFBRSxFQUxMO0FBTUxDLHNCQUFVLEVBQUUsTUFOUDtBQU9MVyxzQkFBVSxFQUFFLEVBUFA7QUFRTEMsdUJBQVcsRUFBRTtBQVJSLFdBRFQ7QUFXRSxxQkFBVyxFQUFFekMsSUFYZjtBQVlFLG1CQUFTLEVBQUMsNkNBWlo7QUFhRSxnQkFBTSxlQUFFO0FBQUEsc0RBQW9CO0FBQU0sdUJBQVMsRUFBQyxhQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBYlY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFuRUY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUZGLENBd0ZFOztBQXhGRjtBQTBGRCxDQTlGRDs7R0FBTWlCLFk7O0tBQUFBLFk7QUFnR1NBLDJFQUFmIiwiZmlsZSI6InN0YXRpYy93ZWJwYWNrL3BhZ2VzL2hvbWUuMTEzMGI2ODMzOTZiYmYxZDY3MjcuaG90LXVwZGF0ZS5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IEltYWdlLCBDb250ZW50U2xpZGVyIH0gZnJvbSBcIkBjb21wb25lbnRzXCI7XG5pbXBvcnQgeyBGb3VuZGVyRGV0YWlsIH0gZnJvbSBcIkBjb21wb25lbnRzL2ZvdW5kZXIvRm91bmRlckRldGFpbFwiO1xuaW1wb3J0IENhcm91c2VsIGZyb20gXCJyZWFjdC1zbGlja1wiO1xuXG5jb25zdCBkYXRhID0gW1xuICB7XG4gICAgaW1hZ2VfdXJsOiBcIi9pY29ucy9jb250ZW50MS5zdmdcIixcbiAgICB0aXRsZTogXCJGcm9tIGJvdGggc2lkZXMgb2YgdGhlIHRhYmxlIDogS3VuYWwgQmFobCB1bnBsdWdnZWRcIixcbiAgICBhdXRob3I6IFwiVEFSVU4gREFWREFcIixcbiAgICBjb250ZW50X2lkOiBcImFiY2RlZlwiLFxuICAgIGNvbnRlbnRfdHlwZTogXCJibG9nXCIsXG4gICAgcmVhZF9kdXJhdGlvbjogXCI0IE1JTlwiLFxuICB9LFxuICB7XG4gICAgaW1hZ2VfdXJsOiBcIi9pY29ucy9jb250ZW50MS5zdmdcIixcbiAgICB0aXRsZTogXCJGcm9tIGJvdGggc2lkZXMgb2YgdGhlIHRhYmxlIDogS3VuYWwgQmFobCB1bnBsdWdnZWRcIixcbiAgICBhdXRob3I6IFwiVEFSVU4gREFWREFcIixcbiAgICBjb250ZW50X2lkOiBcImFiY2RlZmdcIixcbiAgICBjb250ZW50X3R5cGU6IFwiYmxvZ1wiLFxuICAgIHJlYWRfZHVyYXRpb246IFwiNCBNSU5cIixcbiAgfSxcblxuXTtcblxuY29uc3QgaGVyb3MgPSBbe1xuICBmaXJzdE5hbWU6ICdST0hJVCcsXG4gIGxhc3ROYW1lOiAnTS5BLicsXG4gIGZpcnN0TmFtZTE6IG51bGwsXG4gIGxhc3ROYW1lMTogbnVsbCxcbiAgY2FwdGlvbjogJ0F0IENsb3VkbmluZSwgd2UgYmVsaWV2ZSB0aGF0IGEgY2hpbGQgaXMgbGlmZeKAmXMgZ3JlYXRlc3QgZ2lmdCBhbmQgcHJlZ25hbmN5IGlzIG9uZSBvZiB0aGUgbW9zdCBtYWdpY2FsIGV4cGVyaWVuY2VzIG5hdHVyZSBjYW4gb2ZmZXIuICcsXG4gIGxvZ286ICcvaWNvbnMvQ2xvdWRuaW5lLnN2ZycsXG4gIGltYWdlOiAnL2ljb25zL1JvaGl0X1RyZWF0bWVudC5zdmcnLFxuICBoZWFkaW5nOiBbJ0xlYWRpbmcgY2hhaW4gb2YgJywgJ21hdGVybml0eSBob3NwaXRhbHMnLCAnJ10sXG4gIGJnOiAnJ1xufSwge1xuICBmaXJzdE5hbWU6ICdBTklORFlBJyxcbiAgbGFzdE5hbWU6ICdEVVRUQScsXG4gIGZpcnN0TmFtZTE6ICdTQU5ERUVQJyxcbiAgbGFzdE5hbWUxOiAnREFMTUlBJyxcbiAgY2FwdGlvbjogJ1N0YW56YSBMaXZpbmcgcHJvdmlkZXMgZnVsbHktbWFuYWdlZCBzaGFyZWQgbGl2aW5nIGFjY29tbW9kYXRpb25zIHRvIHN0dWRlbnRzIGFuZCB5b3VuZyBwcm9mZXNzaW9uYWxzLicsXG4gIGxvZ286ICcvaWNvbnMvU3RhbnphLnN2ZycsXG4gIGltYWdlOiAnL2ljb25zL0FuaW5keWEuc3ZnJyxcbiAgaGVhZGluZzogWydUZWNoLWVuYWJsZWQgJywgJ3N0dWRlbnQgaG91c2luZycsICdwbGF0Zm9ybSddLFxuICBiZzogJydcbn0sIHtcbiAgZmlyc3ROYW1lOiAnQXNpc2gnLFxuICBsYXN0TmFtZTogJ01PSEFQQVRSQScsXG4gIGZpcnN0TmFtZTE6IG51bGwsXG4gIGxhc3ROYW1lMTogbnVsbCxcbiAgY2FwdGlvbjogJ09GQiBUZWNoIChPZkJ1c2luZXNzKSBpcyBhIHRlY2gtZW5hYmxlZCBwbGF0Zm9ybSB0aGF0IGZhY2lsaXRhdGVzIHJhdyBtYXRlcmlhbCBwcm9jdXJlbWVudCBhbmQgY3JlZGl0IGZvciBTTUVzLCcsXG4gIGxvZ286ICcvaWNvbnMvT2ZCdXNpbmVzcy5zdmcnLFxuICBpbWFnZTogJy9pY29ucy9Bc2lzaC5zdmcnLFxuICBoZWFkaW5nOiBbJ1NNRScsICdsZW5kaW5nJywgJyddXG59LCB7XG4gIGZpcnN0TmFtZTogJ01yLicsXG4gIGxhc3ROYW1lOiAnTEFLU0hJUEFUSFknLFxuICBmaXJzdE5hbWUxOiBudWxsLFxuICBsYXN0TmFtZTE6IG51bGwsXG4gIGNhcHRpb246ICdBIHNwZWNpYWxpemVkIGZpbmFuY2lhbCBzZXJ2aWNlcyBjb21wYW55IGZ1bmRpbmcgdGhlIHBlb3BsZSB3aG8gd2VyZSBwZXJjZWl2ZWQgdG8gYmUgdW5mdW5kYWJsZScsXG4gIGxvZ286ICcvaWNvbnMvbXguc3ZnJyxcbiAgaW1hZ2U6ICcvaWNvbnMvTGF4bWlwYXRoeS5zdmcnLFxuICBoZWFkaW5nOiBbJ0NyZWRpdCBsZWQnLCAnQjJCIG1hcmtldHBsYWNlJywgJyddXG59LCB7XG4gIGZpcnN0TmFtZTogJ0NIQUtSQURIQVInLFxuICBsYXN0TmFtZTogJ0dBREUnLFxuICBmaXJzdE5hbWUxOiAnTklUSU4nLFxuICBsYXN0TmFtZTE6ICdLQVVTSEFMJyxcbiAgY2FwdGlvbjogJ0NvdW50cnkgRGVsaWdodCBhaW1zIHRvIGJyaW5nIGJhY2sgdGhlIGJhc2ljcyBvZiBNaWxrLiBJdCBwcm9taXNlcyBuYXR1cmFsLCBmcmVzaCBhbmQgdW5hZHVsdGVyYXRlZCBtaWxrIGRpcmVjdGx5IHRvIHRoZSBkb29yc3RlcCBvZiB0aGUgY29uc3VtZXIuJyxcbiAgbG9nbzogJy9pY29ucy9Db3VudHJ5LnN2ZycsXG4gIGhlYWRpbmc6IFsnRDJDJywgJ2RhaXJ5ICYgZnJlc2ggZm9vZHMnLCAnYnJhbmQnXSxcbiAgaW1hZ2U6ICcvaWNvbnMvQ2hha3JhZGhhci5zdmcnXG59LCB7XG4gIGZpcnN0TmFtZTogJ0JoYXZpc2gnLFxuICBsYXN0TmFtZTogJ0FHR0FSV0FMJyxcbiAgZmlyc3ROYW1lMTogbnVsbCxcbiAgbGFzdE5hbWUxOiBudWxsLFxuICBjYXB0aW9uOiAnT2xhIGlzIEluZGlh4oCZcyBsYXJnZXN0IG1vYmlsaXR5IHBsYXRmb3JtIGFuZCBvbmUgb2YgdGhlIHdvcmxk4oCZcyBsYXJnZXN0IHJpZGUtaGFpbGluZyBjb21wYW5pZXMsIHNlcnZpbmcgMjUwKyBjaXRpZXMgYWNyb3NzIEluZGlhLCBBdXN0cmFsaWEsIE5ldyBaZWFsYW5kLCBhbmQgdGhlIFVLLicsXG4gIGxvZ286ICcvaWNvbnMvb2xhLnN2ZycsXG4gIGltYWdlOiAnL2ljb25zL0JoYXZpc2hfaW1hZ2Uuc3ZnJyxcbiAgaGVhZGluZzogWydJbmRpYeKAmXMgbGVhZGluZycsICdtb2JpbGl0eScsICdwbGF5ZXInXVxufSxdXG5cbmNvbnN0IEhvbWVDYXJvdXNhbCA9ICgpID0+IHtcbiAgY29uc3QgW2JhY2tncm91bmRVcmwsIHNldEJhY2tncm91bmRVcmxdID0gUmVhY3QudXNlU3RhdGUoXG4gICAgXCIvaWNvbnMvYmFja2dyb3VuZENhcm91c2FsSW1hZ2UucG5nXCJcbiAgKTtcbiAgcmV0dXJuIChcbiAgICAvLyA8Q2Fyb3VzZWw+XG4gICAgPGRpdiBjbGFzc05hbWU9XCJyZWxhdGl2ZVwiIHN0eWxlPXt7IGhlaWdodDogMTA4MCB9fT5cbiAgICAgIDxkaXZcbiAgICAgICAgY2xhc3NOYW1lPVwiYWJzb2x1dGUgaC1mdWxsIHctZnVsbCBmbGV4IGZsZXgtY29sXCJcbiAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICBiYWNrZ3JvdW5kSW1hZ2U6IGB1cmwoJHtiYWNrZ3JvdW5kVXJsfSlgLFxuICAgICAgICAgIGJhY2tncm91bmRTaXplOiBcImNvdmVyXCIsXG4gICAgICAgIH19XG4gICAgICA+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleFwiPlxuICAgICAgICAgIDxJbWFnZVxuICAgICAgICAgICAgc3JjPVwiL2ljb25zL2xlZnRBcnJvdy5zdmdcIlxuICAgICAgICAgICAgYWx0PXtcInJpZ2h0IEljb25cIn1cbiAgICAgICAgICAgIGhlaWdodD17NzN9XG4gICAgICAgICAgICB3aWR0aD17Mzd9XG4gICAgICAgICAgICBzdHlsZT17eyBtYXJnaW5MZWZ0OiAxNzkgfX1cbiAgICAgICAgICAvPlxuICAgICAgICAgIDxkaXYgc3R5bGU9e3sgd2lkdGg6IDUzMywgbWFyZ2luTGVmdDogMTAwIH19PlxuICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgICAgIGZvbnRXZWlnaHQ6IDMwMCxcbiAgICAgICAgICAgICAgICBmb250U2l6ZTogXCIxMDBweFwiLFxuICAgICAgICAgICAgICAgIGxpbmVIZWlnaHQ6IFwiMTIwcHhcIixcbiAgICAgICAgICAgICAgICBsZXR0ZXJTcGFjaW5nOiBcIi0wLjAxZW1cIixcbiAgICAgICAgICAgICAgICBvcGFjaXR5OiAwLjM1LFxuICAgICAgICAgICAgICAgIG1hcmdpblRvcDogMTE3LFxuICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICB7XCIgXCJ9XG4gICAgICAgICAgICAgIDAxLzA1XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1zZWNvbmRhcnktbGlnaHRcIlxuICAgICAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgICAgIGZvbnRXZWlnaHQ6IDIwMCxcbiAgICAgICAgICAgICAgICBmb250U2l6ZTogXCI4NXB4XCIsXG4gICAgICAgICAgICAgICAgbGluZUhlaWdodDogXCI5NXB4XCIsXG4gICAgICAgICAgICAgICAgb3BhY2l0eTogMSxcbiAgICAgICAgICAgICAgICBtYXJnaW5Ub3A6IDE1MSxcbiAgICAgICAgICAgICAgICBtaW5XaWR0aDogNTQ1LFxuICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgPlxuICAgICAgICAgICAgICBUZWNoLWVuYWJsZWRcbiAgICAgICAgICAgICAgPGJyIC8+XG4gICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZFwiPiBTdHVkZW50IGhvdXNpbmc8L3NwYW4+IDxiciAvPlxuICAgICAgICAgICAgICBQbGF0Zm9ybVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPEZvdW5kZXJEZXRhaWwgc3R5bGU9e3sgbWFyZ2luVG9wOiAzNiwgbWFyZ2luTGVmdDogMTAzIH19IC8+XG4gICAgICAgICAgPEltYWdlXG4gICAgICAgICAgICBzcmM9XCIvaWNvbnMvcmlnaHRBcnJvdy5sYXJnZS5zdmdcIlxuICAgICAgICAgICAgYWx0PXtcInJpZ2h0IEljb25cIn1cbiAgICAgICAgICAgIGhlaWdodD17NzN9XG4gICAgICAgICAgICB3aWR0aD17Mzd9XG4gICAgICAgICAgICBzdHlsZT17eyBtYXJnaW5MZWZ0OiAxMDMgfX1cbiAgICAgICAgICAvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdlxuICAgICAgICAgIGNsYXNzTmFtZT1cImFic29sdXRlIGJnLWFjY2VudFwiXG4gICAgICAgICAgc3R5bGU9e3sgYm90dG9tOiAzMywgbGVmdDogMjY5LCBoZWlnaHQ6IDI0Niwgd2lkdGg6IDU2NCB9fVxuICAgICAgICA+XG4gICAgICAgICAgPHNwYW5cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtc2Vjb25kYXJ5IGZvbnQtbWVkaXVtIHRleHQtbGcgbGVhZGluZy02IHRleHQtY2VudGVyIGgtZnVsbCBmbGV4IGp1c3RpZnktY2VudGVyIGl0ZW1zLWNlbnRlclwiXG4gICAgICAgICAgICBzdHlsZT17eyB3cml0aW5nTW9kZTogXCJ2ZXJ0aWNhbC1sclwiLCB3aWR0aDogNTYgfX1cbiAgICAgICAgICA+XG4gICAgICAgICAgICB7XCIgXCJ9XG4gICAgICAgICAgICBIb3NwaXRhbGl0eSBTZWN0b3J7XCIgXCJ9XG4gICAgICAgICAgPC9zcGFuPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPENvbnRlbnRTbGlkZXJcbiAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgbGVmdDogMzI1LFxuICAgICAgICAgICAgYmFja2dyb3VuZDogXCIjRUJFQkU5XCIsXG4gICAgICAgICAgICBib3JkZXI6IFwiMXB4IHNvbGlkICNFQkVCRTlcIixcbiAgICAgICAgICAgIGJveFNpemluZzogXCJib3JkZXItYm94XCIsXG4gICAgICAgICAgICBmb250U2l6ZTogMjgsXG4gICAgICAgICAgICBsaW5lSGVpZ2h0OiBcIjM0cHhcIixcbiAgICAgICAgICAgIHBhZGRpbmdUb3A6IDI0LFxuICAgICAgICAgICAgcGFkZGluZ0xlZnQ6IDM0LFxuICAgICAgICAgIH19XG4gICAgICAgICAgY29udGVudExpc3Q9e2RhdGF9XG4gICAgICAgICAgY2xhc3NOYW1lPVwiYWJzb2x1dGUgYm90dG9tLTAgcmlnaHQtMCB0ZXh0LXByaW1hcnktZGFya1wiXG4gICAgICAgICAgaGVhZGVyPXs8c3Bhbj5EaXZlIGludG8gdGhlIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtYWNjZW50XCI+TWF0cml4IE1vbWVudHM8L3NwYW4+IHNlcmllczwvc3Bhbj59XG4gICAgICAgIC8+XG4gICAgICA8L2Rpdj5cblxuICAgIDwvZGl2PlxuICAgIC8vIDwvQ2Fyb3VzZWw+XG4gICk7XG59O1xuXG5leHBvcnQgZGVmYXVsdCBIb21lQ2Fyb3VzYWw7XG4iXSwic291cmNlUm9vdCI6IiJ9