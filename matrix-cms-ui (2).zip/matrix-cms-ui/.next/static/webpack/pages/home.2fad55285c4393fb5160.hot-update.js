webpackHotUpdate_N_E("pages/home",{

/***/ "./src/components/founder/Founder.tsx":
/*!********************************************!*\
  !*** ./src/components/founder/Founder.tsx ***!
  \********************************************/
/*! exports provided: Founder */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Founder", function() { return Founder; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var C_Users_KARTHIK_Documents_workspace_matrix_cms_ui_development_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @components */ "./src/components/index.ts");
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-slick */ "./node_modules/react-slick/lib/index.js");
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_slick__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! slick-carousel/slick/slick.css */ "./node_modules/slick-carousel/slick/slick.css");
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! slick-carousel/slick/slick-theme.css */ "./node_modules/slick-carousel/slick/slick-theme.css");
/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_6__);



var _jsxFileName = "C:\\Users\\KARTHIK\\Documents\\workspace\\matrix-cms-ui-development\\src\\components\\founder\\Founder.tsx",
    _this = undefined;

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { Object(C_Users_KARTHIK_Documents_workspace_matrix_cms_ui_development_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__["default"])(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }






var Founder = function Founder(_ref) {
  var className = _ref.className,
      _ref$style = _ref.style,
      style = _ref$style === void 0 ? {} : _ref$style;
  var settings = {
    dots: true,
    infinite: true,
    speed: 500,
    // autoplaySpeed: 2000,
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true
  };
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_slick__WEBPACK_IMPORTED_MODULE_4___default.a, _objectSpread(_objectSpread({}, settings), {}, {
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "".concat(className),
        style: _objectSpread({
          width: 615.94,
          height: 863.91,
          position: "relative"
        }, style),
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "",
          style: {
            width: 571,
            height: 762,
            position: "absolute",
            background: "#083A4A",
            bottom: 50,
            left: 0
          }
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 30,
          columnNumber: 11
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "",
          style: {
            width: 594,
            height: 788,
            bottom: 65,
            left: 15,
            position: "absolute",
            display: "flex",
            flexDirection: "column"
          },
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_3__["Image"], {
            src: "/icons/Bhavish_image.svg",
            alt: "founder image",
            style: {
              flexGrow: 1
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 34,
            columnNumber: 13
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_3__["Image"], {
            src: "/icons/rectangle.svg",
            alt: "reactangle",
            className: "absolute",
            style: {
              left: 38,
              bottom: 254
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 35,
            columnNumber: 13
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            style: {
              height: 209,
              background: "#01576E"
            },
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "text-center flex items-center",
              style: {
                height: 118,
                borderBottom: "1px solid #EBEBE9"
              },
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h6", {
                className: "font-bold text-secondary",
                style: {
                  fontSize: 32,
                  lineHeight: "36px",
                  letterSpacing: "0.05em",
                  marginLeft: 31,
                  marginRight: 8
                },
                children: "BHAVISH"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 39,
                columnNumber: 17
              }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h6", {
                className: "font-light text-secondary",
                style: {
                  fontSize: 32,
                  lineHeight: "36px",
                  letterSpacing: "0.05em"
                },
                children: "AGGARWAL"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 42,
                columnNumber: 17
              }, _this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 38,
              columnNumber: 15
            }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "flex justify-between items-center",
              style: {
                height: 88
              },
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                style: {
                  marginLeft: 31,
                  display: 'flex',
                  justifyContent: 'space-around'
                },
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                  className: "text-secondary font-medium text-lg leading-6",
                  children: " Mobility"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 49,
                  columnNumber: 19
                }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                  className: "text-secondary font-medium text-lg leading-6",
                  children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("hr", {
                    style: {
                      width: 30,
                      transform: 'rotate(90deg)'
                    }
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 51,
                    columnNumber: 82
                  }, _this)
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 51,
                  columnNumber: 19
                }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                  className: "text-secondary font-medium text-lg leading-6",
                  children: " Electric Cars"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 52,
                  columnNumber: 19
                }, _this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 48,
                columnNumber: 17
              }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_3__["Image"], {
                src: "/icons/ola.svg",
                alt: "ola",
                style: {
                  marginRight: 57
                }
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 54,
                columnNumber: 17
              }, _this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 47,
              columnNumber: 15
            }, _this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 37,
            columnNumber: 13
          }, _this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 31,
          columnNumber: 11
        }, _this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 29,
        columnNumber: 9
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 28,
      columnNumber: 7
    }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "".concat(className),
        style: _objectSpread({
          width: 615.94,
          height: 863.91,
          position: "relative"
        }, style),
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "",
          style: {
            width: 571,
            height: 762,
            position: "absolute",
            background: "#083A4A",
            bottom: 50,
            left: 0
          }
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 65,
          columnNumber: 11
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "",
          style: {
            width: 594,
            height: 788,
            bottom: 65,
            left: 15,
            position: "absolute",
            display: "flex",
            flexDirection: "column"
          },
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_3__["Image"], {
            src: "/icons/Bhavish_image.svg",
            alt: "founder image",
            style: {
              flexGrow: 1
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 69,
            columnNumber: 13
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_3__["Image"], {
            src: "/icons/rectangle.svg",
            alt: "reactangle",
            className: "absolute",
            style: {
              left: 38,
              bottom: 254
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 70,
            columnNumber: 13
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            style: {
              height: 209,
              background: "#01576E"
            },
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "text-center flex items-center",
              style: {
                height: 118,
                borderBottom: "1px solid #EBEBE9"
              },
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h6", {
                className: "font-bold text-secondary",
                style: {
                  fontSize: 32,
                  lineHeight: "36px",
                  letterSpacing: "0.05em",
                  marginLeft: 31,
                  marginRight: 8
                },
                children: "jhgbjhbjhbjh"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 74,
                columnNumber: 17
              }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h6", {
                className: "font-light text-secondary",
                style: {
                  fontSize: 32,
                  lineHeight: "36px",
                  letterSpacing: "0.05em"
                },
                children: "AGGARWAL"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 77,
                columnNumber: 17
              }, _this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 73,
              columnNumber: 15
            }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "flex justify-between items-center",
              style: {
                height: 88
              },
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                style: {
                  marginLeft: 31
                },
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                  className: "text-secondary font-medium text-lg leading-6",
                  children: " Mobility"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 84,
                  columnNumber: 19
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 83,
                columnNumber: 17
              }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_3__["Image"], {
                src: "/icons/ola.svg",
                alt: "ola",
                style: {
                  marginRight: 57
                }
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 86,
                columnNumber: 17
              }, _this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 82,
              columnNumber: 15
            }, _this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 72,
            columnNumber: 13
          }, _this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 66,
          columnNumber: 11
        }, _this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 64,
        columnNumber: 9
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 63,
      columnNumber: 7
    }, _this)]
  }), void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 27,
    columnNumber: 5
  }, _this);
};
_c = Founder;

var _c;

$RefreshReg$(_c, "Founder");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vc3JjL2NvbXBvbmVudHMvZm91bmRlci9Gb3VuZGVyLnRzeCJdLCJuYW1lcyI6WyJGb3VuZGVyIiwiY2xhc3NOYW1lIiwic3R5bGUiLCJzZXR0aW5ncyIsImRvdHMiLCJpbmZpbml0ZSIsInNwZWVkIiwic2xpZGVzVG9TaG93Iiwic2xpZGVzVG9TY3JvbGwiLCJhdXRvcGxheSIsIndpZHRoIiwiaGVpZ2h0IiwicG9zaXRpb24iLCJiYWNrZ3JvdW5kIiwiYm90dG9tIiwibGVmdCIsImRpc3BsYXkiLCJmbGV4RGlyZWN0aW9uIiwiZmxleEdyb3ciLCJib3JkZXJCb3R0b20iLCJmb250U2l6ZSIsImxpbmVIZWlnaHQiLCJsZXR0ZXJTcGFjaW5nIiwibWFyZ2luTGVmdCIsIm1hcmdpblJpZ2h0IiwianVzdGlmeUNvbnRlbnQiLCJ0cmFuc2Zvcm0iXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBV08sSUFBTUEsT0FBd0IsR0FBRyxTQUEzQkEsT0FBMkIsT0FBK0I7QUFBQSxNQUE1QkMsU0FBNEIsUUFBNUJBLFNBQTRCO0FBQUEsd0JBQWpCQyxLQUFpQjtBQUFBLE1BQWpCQSxLQUFpQiwyQkFBVCxFQUFTO0FBQ3JFLE1BQU1DLFFBQVEsR0FBRztBQUNmQyxRQUFJLEVBQUUsSUFEUztBQUVmQyxZQUFRLEVBQUUsSUFGSztBQUdmQyxTQUFLLEVBQUUsR0FIUTtBQUlmO0FBQ0FDLGdCQUFZLEVBQUUsQ0FMQztBQU1mQyxrQkFBYyxFQUFFLENBTkQ7QUFPZkMsWUFBUSxFQUFFO0FBUEssR0FBakI7QUFTQSxzQkFDRSxxRUFBQyxrREFBRCxrQ0FBWU4sUUFBWjtBQUFBLDRCQUNFO0FBQUEsNkJBQ0U7QUFBSyxpQkFBUyxZQUFLRixTQUFMLENBQWQ7QUFBZ0MsYUFBSztBQUFJUyxlQUFLLEVBQUUsTUFBWDtBQUFtQkMsZ0JBQU0sRUFBRSxNQUEzQjtBQUFtQ0Msa0JBQVEsRUFBRTtBQUE3QyxXQUE0RFYsS0FBNUQsQ0FBckM7QUFBQSxnQ0FDRTtBQUFLLG1CQUFTLEVBQUMsRUFBZjtBQUFrQixlQUFLLEVBQUU7QUFBRVEsaUJBQUssRUFBRSxHQUFUO0FBQWNDLGtCQUFNLEVBQUUsR0FBdEI7QUFBMkJDLG9CQUFRLEVBQUUsVUFBckM7QUFBaURDLHNCQUFVLEVBQUUsU0FBN0Q7QUFBd0VDLGtCQUFNLEVBQUUsRUFBaEY7QUFBb0ZDLGdCQUFJLEVBQUU7QUFBMUY7QUFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFERixlQUVFO0FBQ0UsbUJBQVMsRUFBQyxFQURaO0FBRUUsZUFBSyxFQUFFO0FBQUVMLGlCQUFLLEVBQUUsR0FBVDtBQUFjQyxrQkFBTSxFQUFFLEdBQXRCO0FBQTJCRyxrQkFBTSxFQUFFLEVBQW5DO0FBQXVDQyxnQkFBSSxFQUFFLEVBQTdDO0FBQWlESCxvQkFBUSxFQUFFLFVBQTNEO0FBQXVFSSxtQkFBTyxFQUFFLE1BQWhGO0FBQXdGQyx5QkFBYSxFQUFFO0FBQXZHLFdBRlQ7QUFBQSxrQ0FHRSxxRUFBQyxpREFBRDtBQUFPLGVBQUcsRUFBQywwQkFBWDtBQUFzQyxlQUFHLEVBQUMsZUFBMUM7QUFBMEQsaUJBQUssRUFBRTtBQUFFQyxzQkFBUSxFQUFFO0FBQVo7QUFBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFIRixlQUlFLHFFQUFDLGlEQUFEO0FBQU8sZUFBRyxFQUFDLHNCQUFYO0FBQWtDLGVBQUcsRUFBRSxZQUF2QztBQUFxRCxxQkFBUyxFQUFDLFVBQS9EO0FBQTBFLGlCQUFLLEVBQUU7QUFBRUgsa0JBQUksRUFBRSxFQUFSO0FBQVlELG9CQUFNLEVBQUU7QUFBcEI7QUFBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFKRixlQU1FO0FBQUssaUJBQUssRUFBRTtBQUFFSCxvQkFBTSxFQUFFLEdBQVY7QUFBZUUsd0JBQVUsRUFBRTtBQUEzQixhQUFaO0FBQUEsb0NBQ0U7QUFBSyx1QkFBUyxFQUFDLCtCQUFmO0FBQStDLG1CQUFLLEVBQUU7QUFBRUYsc0JBQU0sRUFBRSxHQUFWO0FBQWVRLDRCQUFZLEVBQUU7QUFBN0IsZUFBdEQ7QUFBQSxzQ0FDRTtBQUFJLHlCQUFTLEVBQUMsMEJBQWQ7QUFBeUMscUJBQUssRUFBRTtBQUFFQywwQkFBUSxFQUFFLEVBQVo7QUFBZ0JDLDRCQUFVLEVBQUUsTUFBNUI7QUFBb0NDLCtCQUFhLEVBQUUsUUFBbkQ7QUFBNkRDLDRCQUFVLEVBQUUsRUFBekU7QUFBNkVDLDZCQUFXLEVBQUU7QUFBMUYsaUJBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQURGLGVBSUU7QUFBSSx5QkFBUyxFQUFDLDJCQUFkO0FBQTBDLHFCQUFLLEVBQUU7QUFBRUosMEJBQVEsRUFBRSxFQUFaO0FBQWdCQyw0QkFBVSxFQUFFLE1BQTVCO0FBQW9DQywrQkFBYSxFQUFFO0FBQW5ELGlCQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREYsZUFVRTtBQUFLLHVCQUFTLEVBQUMsbUNBQWY7QUFBbUQsbUJBQUssRUFBRTtBQUFFWCxzQkFBTSxFQUFFO0FBQVYsZUFBMUQ7QUFBQSxzQ0FDRTtBQUFLLHFCQUFLLEVBQUU7QUFBRVksNEJBQVUsRUFBRSxFQUFkO0FBQWtCUCx5QkFBTyxFQUFFLE1BQTNCO0FBQW1DUyxnQ0FBYyxFQUFFO0FBQW5ELGlCQUFaO0FBQUEsd0NBQ0U7QUFBTSwyQkFBUyxFQUFDLDhDQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFERixlQUdFO0FBQU0sMkJBQVMsRUFBQyw4Q0FBaEI7QUFBQSx5Q0FBK0Q7QUFBSSx5QkFBSyxFQUFFO0FBQUVmLDJCQUFLLEVBQUUsRUFBVDtBQUFhZ0IsK0JBQVMsRUFBRTtBQUF4QjtBQUFYO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBL0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFIRixlQUlFO0FBQU0sMkJBQVMsRUFBQyw4Q0FBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQURGLGVBT0UscUVBQUMsaURBQUQ7QUFBTyxtQkFBRyxFQUFFLGdCQUFaO0FBQThCLG1CQUFHLEVBQUUsS0FBbkM7QUFBMEMscUJBQUssRUFBRTtBQUFFRiw2QkFBVyxFQUFFO0FBQWY7QUFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFQRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBREYsZUFvQ0U7QUFBQSw2QkFDRTtBQUFLLGlCQUFTLFlBQUt2QixTQUFMLENBQWQ7QUFBZ0MsYUFBSztBQUFJUyxlQUFLLEVBQUUsTUFBWDtBQUFtQkMsZ0JBQU0sRUFBRSxNQUEzQjtBQUFtQ0Msa0JBQVEsRUFBRTtBQUE3QyxXQUE0RFYsS0FBNUQsQ0FBckM7QUFBQSxnQ0FDRTtBQUFLLG1CQUFTLEVBQUMsRUFBZjtBQUFrQixlQUFLLEVBQUU7QUFBRVEsaUJBQUssRUFBRSxHQUFUO0FBQWNDLGtCQUFNLEVBQUUsR0FBdEI7QUFBMkJDLG9CQUFRLEVBQUUsVUFBckM7QUFBaURDLHNCQUFVLEVBQUUsU0FBN0Q7QUFBd0VDLGtCQUFNLEVBQUUsRUFBaEY7QUFBb0ZDLGdCQUFJLEVBQUU7QUFBMUY7QUFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFERixlQUVFO0FBQ0UsbUJBQVMsRUFBQyxFQURaO0FBRUUsZUFBSyxFQUFFO0FBQUVMLGlCQUFLLEVBQUUsR0FBVDtBQUFjQyxrQkFBTSxFQUFFLEdBQXRCO0FBQTJCRyxrQkFBTSxFQUFFLEVBQW5DO0FBQXVDQyxnQkFBSSxFQUFFLEVBQTdDO0FBQWlESCxvQkFBUSxFQUFFLFVBQTNEO0FBQXVFSSxtQkFBTyxFQUFFLE1BQWhGO0FBQXdGQyx5QkFBYSxFQUFFO0FBQXZHLFdBRlQ7QUFBQSxrQ0FHRSxxRUFBQyxpREFBRDtBQUFPLGVBQUcsRUFBQywwQkFBWDtBQUFzQyxlQUFHLEVBQUMsZUFBMUM7QUFBMEQsaUJBQUssRUFBRTtBQUFFQyxzQkFBUSxFQUFFO0FBQVo7QUFBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFIRixlQUlFLHFFQUFDLGlEQUFEO0FBQU8sZUFBRyxFQUFDLHNCQUFYO0FBQWtDLGVBQUcsRUFBRSxZQUF2QztBQUFxRCxxQkFBUyxFQUFDLFVBQS9EO0FBQTBFLGlCQUFLLEVBQUU7QUFBRUgsa0JBQUksRUFBRSxFQUFSO0FBQVlELG9CQUFNLEVBQUU7QUFBcEI7QUFBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFKRixlQU1FO0FBQUssaUJBQUssRUFBRTtBQUFFSCxvQkFBTSxFQUFFLEdBQVY7QUFBZUUsd0JBQVUsRUFBRTtBQUEzQixhQUFaO0FBQUEsb0NBQ0U7QUFBSyx1QkFBUyxFQUFDLCtCQUFmO0FBQStDLG1CQUFLLEVBQUU7QUFBRUYsc0JBQU0sRUFBRSxHQUFWO0FBQWVRLDRCQUFZLEVBQUU7QUFBN0IsZUFBdEQ7QUFBQSxzQ0FDRTtBQUFJLHlCQUFTLEVBQUMsMEJBQWQ7QUFBeUMscUJBQUssRUFBRTtBQUFFQywwQkFBUSxFQUFFLEVBQVo7QUFBZ0JDLDRCQUFVLEVBQUUsTUFBNUI7QUFBb0NDLCtCQUFhLEVBQUUsUUFBbkQ7QUFBNkRDLDRCQUFVLEVBQUUsRUFBekU7QUFBNkVDLDZCQUFXLEVBQUU7QUFBMUYsaUJBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQURGLGVBSUU7QUFBSSx5QkFBUyxFQUFDLDJCQUFkO0FBQTBDLHFCQUFLLEVBQUU7QUFBRUosMEJBQVEsRUFBRSxFQUFaO0FBQWdCQyw0QkFBVSxFQUFFLE1BQTVCO0FBQW9DQywrQkFBYSxFQUFFO0FBQW5ELGlCQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREYsZUFVRTtBQUFLLHVCQUFTLEVBQUMsbUNBQWY7QUFBbUQsbUJBQUssRUFBRTtBQUFFWCxzQkFBTSxFQUFFO0FBQVYsZUFBMUQ7QUFBQSxzQ0FDRTtBQUFLLHFCQUFLLEVBQUU7QUFBRVksNEJBQVUsRUFBRTtBQUFkLGlCQUFaO0FBQUEsdUNBQ0U7QUFBTSwyQkFBUyxFQUFDLDhDQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBREYsZUFJRSxxRUFBQyxpREFBRDtBQUFPLG1CQUFHLEVBQUUsZ0JBQVo7QUFBOEIsbUJBQUcsRUFBRSxLQUFuQztBQUEwQyxxQkFBSyxFQUFFO0FBQUVDLDZCQUFXLEVBQUU7QUFBZjtBQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFwQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBREY7QUFxRUQsQ0EvRU07S0FBTXhCLE8iLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvaG9tZS4yZmFkNTUyODVjNDM5M2ZiNTE2MC5ob3QtdXBkYXRlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgSW1hZ2UgfSBmcm9tIFwiQGNvbXBvbmVudHNcIjtcbmltcG9ydCBTbGlkZXIgZnJvbSBcInJlYWN0LXNsaWNrXCI7XG5pbXBvcnQgXCJzbGljay1jYXJvdXNlbC9zbGljay9zbGljay5jc3NcIjtcbmltcG9ydCBcInNsaWNrLWNhcm91c2VsL3NsaWNrL3NsaWNrLXRoZW1lLmNzc1wiO1xuXG5leHBvcnQgdHlwZSBQcm9wcyA9IHtcbiAgbmFtZXM/OiBBcnJheTxzdHJpbmc+O1xuICBiYWNrZ3JvdW5kX3VybD86IHN0cmluZztcbiAgdGFncz86IEFycmF5PHN0cmluZz47XG4gIGxvZ28/OiBzdHJpbmc7XG4gIGNsYXNzTmFtZT86IHN0cmluZztcbiAgc3R5bGU/OiBhbnk7XG59O1xuXG5leHBvcnQgY29uc3QgRm91bmRlcjogUmVhY3QuRkM8UHJvcHM+ID0gKHsgY2xhc3NOYW1lLCBzdHlsZSA9IHt9IH0pID0+IHtcbiAgY29uc3Qgc2V0dGluZ3MgPSB7XG4gICAgZG90czogdHJ1ZSxcbiAgICBpbmZpbml0ZTogdHJ1ZSxcbiAgICBzcGVlZDogNTAwLFxuICAgIC8vIGF1dG9wbGF5U3BlZWQ6IDIwMDAsXG4gICAgc2xpZGVzVG9TaG93OiAxLFxuICAgIHNsaWRlc1RvU2Nyb2xsOiAxLFxuICAgIGF1dG9wbGF5OiB0cnVlXG4gIH07XG4gIHJldHVybiAoXG4gICAgPFNsaWRlciB7Li4uc2V0dGluZ3N9PlxuICAgICAgPGRpdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9e2Ake2NsYXNzTmFtZX1gfSBzdHlsZT17eyB3aWR0aDogNjE1Ljk0LCBoZWlnaHQ6IDg2My45MSwgcG9zaXRpb246IFwicmVsYXRpdmVcIiwgLi4uc3R5bGUsIH19PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiXCIgc3R5bGU9e3sgd2lkdGg6IDU3MSwgaGVpZ2h0OiA3NjIsIHBvc2l0aW9uOiBcImFic29sdXRlXCIsIGJhY2tncm91bmQ6IFwiIzA4M0E0QVwiLCBib3R0b206IDUwLCBsZWZ0OiAwLCB9fT48L2Rpdj5cbiAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJcIlxuICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IDU5NCwgaGVpZ2h0OiA3ODgsIGJvdHRvbTogNjUsIGxlZnQ6IDE1LCBwb3NpdGlvbjogXCJhYnNvbHV0ZVwiLCBkaXNwbGF5OiBcImZsZXhcIiwgZmxleERpcmVjdGlvbjogXCJjb2x1bW5cIiwgfX0+XG4gICAgICAgICAgICA8SW1hZ2Ugc3JjPVwiL2ljb25zL0JoYXZpc2hfaW1hZ2Uuc3ZnXCIgYWx0PVwiZm91bmRlciBpbWFnZVwiIHN0eWxlPXt7IGZsZXhHcm93OiAxIH19PjwvSW1hZ2U+XG4gICAgICAgICAgICA8SW1hZ2Ugc3JjPVwiL2ljb25zL3JlY3RhbmdsZS5zdmdcIiBhbHQ9e1wicmVhY3RhbmdsZVwifSBjbGFzc05hbWU9XCJhYnNvbHV0ZVwiIHN0eWxlPXt7IGxlZnQ6IDM4LCBib3R0b206IDI1NCB9fSAvPlxuXG4gICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGhlaWdodDogMjA5LCBiYWNrZ3JvdW5kOiBcIiMwMTU3NkVcIiB9fT5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBmbGV4IGl0ZW1zLWNlbnRlclwiIHN0eWxlPXt7IGhlaWdodDogMTE4LCBib3JkZXJCb3R0b206IFwiMXB4IHNvbGlkICNFQkVCRTlcIiB9fT5cbiAgICAgICAgICAgICAgICA8aDYgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtc2Vjb25kYXJ5XCIgc3R5bGU9e3sgZm9udFNpemU6IDMyLCBsaW5lSGVpZ2h0OiBcIjM2cHhcIiwgbGV0dGVyU3BhY2luZzogXCIwLjA1ZW1cIiwgbWFyZ2luTGVmdDogMzEsIG1hcmdpblJpZ2h0OiA4LCB9fT5cbiAgICAgICAgICAgICAgICAgIEJIQVZJU0hcbiAgICAgICAgICAgICAgPC9oNj5cbiAgICAgICAgICAgICAgICA8aDYgY2xhc3NOYW1lPVwiZm9udC1saWdodCB0ZXh0LXNlY29uZGFyeVwiIHN0eWxlPXt7IGZvbnRTaXplOiAzMiwgbGluZUhlaWdodDogXCIzNnB4XCIsIGxldHRlclNwYWNpbmc6IFwiMC4wNWVtXCIsIH19PlxuICAgICAgICAgICAgICAgICAgQUdHQVJXQUxcbiAgICAgICAgICAgICAgPC9oNj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXJcIiBzdHlsZT17eyBoZWlnaHQ6IDg4IH19PlxuICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgbWFyZ2luTGVmdDogMzEsIGRpc3BsYXk6ICdmbGV4JywganVzdGlmeUNvbnRlbnQ6ICdzcGFjZS1hcm91bmQnIH19PlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zZWNvbmRhcnkgZm9udC1tZWRpdW0gdGV4dC1sZyBsZWFkaW5nLTZcIj4gTW9iaWxpdHk8L3NwYW4+XG5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2Vjb25kYXJ5IGZvbnQtbWVkaXVtIHRleHQtbGcgbGVhZGluZy02XCI+PGhyIHN0eWxlPXt7IHdpZHRoOiAzMCwgdHJhbnNmb3JtOiAncm90YXRlKDkwZGVnKScgfX0gLz48L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNlY29uZGFyeSBmb250LW1lZGl1bSB0ZXh0LWxnIGxlYWRpbmctNlwiPiBFbGVjdHJpYyBDYXJzPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxJbWFnZSBzcmM9e1wiL2ljb25zL29sYS5zdmdcIn0gYWx0PXtcIm9sYVwifSBzdHlsZT17eyBtYXJnaW5SaWdodDogNTcgfX0gLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuXG5cbiAgICAgIDxkaXY+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgJHtjbGFzc05hbWV9YH0gc3R5bGU9e3sgd2lkdGg6IDYxNS45NCwgaGVpZ2h0OiA4NjMuOTEsIHBvc2l0aW9uOiBcInJlbGF0aXZlXCIsIC4uLnN0eWxlLCB9fT5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIlwiIHN0eWxlPXt7IHdpZHRoOiA1NzEsIGhlaWdodDogNzYyLCBwb3NpdGlvbjogXCJhYnNvbHV0ZVwiLCBiYWNrZ3JvdW5kOiBcIiMwODNBNEFcIiwgYm90dG9tOiA1MCwgbGVmdDogMCwgfX0+PC9kaXY+XG4gICAgICAgICAgPGRpdlxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiXCJcbiAgICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiA1OTQsIGhlaWdodDogNzg4LCBib3R0b206IDY1LCBsZWZ0OiAxNSwgcG9zaXRpb246IFwiYWJzb2x1dGVcIiwgZGlzcGxheTogXCJmbGV4XCIsIGZsZXhEaXJlY3Rpb246IFwiY29sdW1uXCIsIH19PlxuICAgICAgICAgICAgPEltYWdlIHNyYz1cIi9pY29ucy9CaGF2aXNoX2ltYWdlLnN2Z1wiIGFsdD1cImZvdW5kZXIgaW1hZ2VcIiBzdHlsZT17eyBmbGV4R3JvdzogMSB9fT48L0ltYWdlPlxuICAgICAgICAgICAgPEltYWdlIHNyYz1cIi9pY29ucy9yZWN0YW5nbGUuc3ZnXCIgYWx0PXtcInJlYWN0YW5nbGVcIn0gY2xhc3NOYW1lPVwiYWJzb2x1dGVcIiBzdHlsZT17eyBsZWZ0OiAzOCwgYm90dG9tOiAyNTQgfX0gLz5cblxuICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBoZWlnaHQ6IDIwOSwgYmFja2dyb3VuZDogXCIjMDE1NzZFXCIgfX0+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgZmxleCBpdGVtcy1jZW50ZXJcIiBzdHlsZT17eyBoZWlnaHQ6IDExOCwgYm9yZGVyQm90dG9tOiBcIjFweCBzb2xpZCAjRUJFQkU5XCIgfX0+XG4gICAgICAgICAgICAgICAgPGg2IGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNlY29uZGFyeVwiIHN0eWxlPXt7IGZvbnRTaXplOiAzMiwgbGluZUhlaWdodDogXCIzNnB4XCIsIGxldHRlclNwYWNpbmc6IFwiMC4wNWVtXCIsIG1hcmdpbkxlZnQ6IDMxLCBtYXJnaW5SaWdodDogOCwgfX0+XG4gICAgICAgICAgICAgICAgICBqaGdiamhiamhiamhcbiAgICAgICAgICAgIDwvaDY+XG4gICAgICAgICAgICAgICAgPGg2IGNsYXNzTmFtZT1cImZvbnQtbGlnaHQgdGV4dC1zZWNvbmRhcnlcIiBzdHlsZT17eyBmb250U2l6ZTogMzIsIGxpbmVIZWlnaHQ6IFwiMzZweFwiLCBsZXR0ZXJTcGFjaW5nOiBcIjAuMDVlbVwiLCB9fT5cbiAgICAgICAgICAgICAgICAgIEFHR0FSV0FMXG4gICAgICAgICAgICA8L2g2PlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlclwiIHN0eWxlPXt7IGhlaWdodDogODggfX0+XG4gICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBtYXJnaW5MZWZ0OiAzMSB9fT5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2Vjb25kYXJ5IGZvbnQtbWVkaXVtIHRleHQtbGcgbGVhZGluZy02XCI+IE1vYmlsaXR5PC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxJbWFnZSBzcmM9e1wiL2ljb25zL29sYS5zdmdcIn0gYWx0PXtcIm9sYVwifSBzdHlsZT17eyBtYXJnaW5SaWdodDogNTcgfX0gLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgIDwvU2xpZGVyPlxuICApO1xufTtcbiJdLCJzb3VyY2VSb290IjoiIn0=