webpackHotUpdate_N_E("pages/contact",{

/***/ "./src/modules/contact/form.tsx":
/*!**************************************!*\
  !*** ./src/modules/contact/form.tsx ***!
  \**************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


var _jsxFileName = "C:\\Users\\KARTHIK\\Documents\\workspace\\matrix-cms-ui-development\\src\\modules\\contact\\form.tsx",
    _this = undefined;



var ContactForm = function ContactForm() {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: "relative m-auto w-11/12\t",
    style: {
      marginTop: 100,
      marginBottom: 150
    },
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "row",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        style: {
          flex: '60%'
        },
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h1", {
          className: "main-txt text-4xl lg:text-3xl tablet:text-2xl md:text-2xl sm:text-xl font-bold",
          children: "Vist our India Advisory Team Offices"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 9,
          columnNumber: 11
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "row ",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            style: {
              flex: '66%'
            },
            className: "col-span-8 contact-address",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "map-info border-b-2 mr-5 pb-5",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                href: "#",
                className: "uppercase font-bold text-xl border-b-3 bbc",
                children: "Bangalore"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 13,
                columnNumber: 17
              }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("hr", {
                className: "under-line"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 14,
                columnNumber: 17
              }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
                children: ["197, 6th Main, 1st Cross ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 15,
                  columnNumber: 45
                }, _this), " HAL 2nd Stage, Indira Nagar ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 15,
                  columnNumber: 80
                }, _this), " Bengaluru 560038 ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 15,
                  columnNumber: 104
                }, _this), " ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 15,
                  columnNumber: 111
                }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                  href: "tel:+91-80-25196000",
                  children: "+91-80-25196000"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 15,
                  columnNumber: 117
                }, _this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 15,
                columnNumber: 17
              }, _this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 12,
              columnNumber: 15
            }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "direction-link",
              children: ["GET DIRECTION ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
                  src: "/icons/blackArrow.svg"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 17,
                  columnNumber: 68
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 17,
                columnNumber: 62
              }, _this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 17,
              columnNumber: 15
            }, _this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 11,
            columnNumber: 13
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            style: {
              flex: '44%'
            },
            className: "col-span-4 relative",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "city-overlay",
              children: "Banglore"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 20,
              columnNumber: 15
            }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
              className: "contact-img",
              src: "../../img/image 26.png",
              alt: ""
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 21,
              columnNumber: 15
            }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "contact-bg-overlay "
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 22,
              columnNumber: 15
            }, _this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 19,
            columnNumber: 13
          }, _this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 10,
          columnNumber: 11
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "row ",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            style: {
              flex: '66%'
            },
            className: "col-span-8 contact-address",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "map-info border-b-2 mr-5 pb-5",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                href: "#",
                className: "uppercase font-bold text-xl border-b-3 bbc",
                children: "Bangalore"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 28,
                columnNumber: 17
              }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("hr", {
                className: "under-line"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 29,
                columnNumber: 17
              }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
                children: ["197, 6th Main, 1st Cross ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 30,
                  columnNumber: 45
                }, _this), " HAL 2nd Stage, Indira Nagar ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 30,
                  columnNumber: 80
                }, _this), " Bengaluru 560038 ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 30,
                  columnNumber: 104
                }, _this), " ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 30,
                  columnNumber: 111
                }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                  href: "tel:+91-80-25196000",
                  children: "+91-80-25196000"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 30,
                  columnNumber: 117
                }, _this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 30,
                columnNumber: 17
              }, _this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 27,
              columnNumber: 15
            }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "direction-link",
              children: ["GET DIRECTION ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
                  src: "/icons/blackArrow.svg"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 32,
                  columnNumber: 68
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 32,
                columnNumber: 62
              }, _this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 32,
              columnNumber: 15
            }, _this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 26,
            columnNumber: 13
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            style: {
              flex: '44%'
            },
            className: "col-span-4 relative",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
              className: "contact-img",
              src: "../../img/image 26.png",
              alt: ""
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 35,
              columnNumber: 15
            }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "contact-bg-overlay "
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 36,
              columnNumber: 15
            }, _this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 34,
            columnNumber: 13
          }, _this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 25,
          columnNumber: 11
        }, _this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 8,
        columnNumber: 9
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        style: {
          flex: '40%'
        }
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 40,
        columnNumber: 9
      }, _this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 7,
      columnNumber: 7
    }, _this)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 6,
    columnNumber: 5
  }, _this);
};

_c = ContactForm;
/* harmony default export */ __webpack_exports__["default"] = (ContactForm);

var _c;

$RefreshReg$(_c, "ContactForm");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vc3JjL21vZHVsZXMvY29udGFjdC9mb3JtLnRzeCJdLCJuYW1lcyI6WyJDb250YWN0Rm9ybSIsIm1hcmdpblRvcCIsIm1hcmdpbkJvdHRvbSIsImZsZXgiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7O0FBR0EsSUFBTUEsV0FBcUIsR0FBRyxTQUF4QkEsV0FBd0IsR0FBTTtBQUNsQyxzQkFDRTtBQUFLLGFBQVMsRUFBQywyQkFBZjtBQUEwQyxTQUFLLEVBQUU7QUFBRUMsZUFBUyxFQUFFLEdBQWI7QUFBa0JDLGtCQUFZLEVBQUU7QUFBaEMsS0FBakQ7QUFBQSwyQkFDRTtBQUFLLGVBQVMsRUFBQyxLQUFmO0FBQUEsOEJBQ0U7QUFBSyxhQUFLLEVBQUU7QUFBRUMsY0FBSSxFQUFFO0FBQVIsU0FBWjtBQUFBLGdDQUNFO0FBQUksbUJBQVMsRUFBQyxnRkFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFERixlQUVFO0FBQUssbUJBQVMsRUFBQyxNQUFmO0FBQUEsa0NBQ0U7QUFBSyxpQkFBSyxFQUFFO0FBQUVBLGtCQUFJLEVBQUU7QUFBUixhQUFaO0FBQTZCLHFCQUFTLEVBQUMsNEJBQXZDO0FBQUEsb0NBQ0U7QUFBSyx1QkFBUyxFQUFDLCtCQUFmO0FBQUEsc0NBQ0U7QUFBRyxvQkFBSSxFQUFDLEdBQVI7QUFBWSx5QkFBUyxFQUFDLDRDQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFERixlQUVFO0FBQUkseUJBQVMsRUFBQztBQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRkYsZUFHRTtBQUFBLHFFQUE0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE1QixnREFBK0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBL0QscUNBQXVGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXZGLG9CQUE4RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE5RixlQUFvRztBQUFHLHNCQUFJLEVBQUMscUJBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXBHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFIRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREYsZUFNRTtBQUFLLHVCQUFTLEVBQUMsZ0JBQWY7QUFBQSx3REFBK0M7QUFBQSx1Q0FBTTtBQUFLLHFCQUFHLEVBQUM7QUFBVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFERixlQVNFO0FBQUssaUJBQUssRUFBRTtBQUFFQSxrQkFBSSxFQUFFO0FBQVIsYUFBWjtBQUE2QixxQkFBUyxFQUFDLHFCQUF2QztBQUFBLG9DQUNFO0FBQUssdUJBQVMsRUFBQyxjQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQURGLGVBRUU7QUFBSyx1QkFBUyxFQUFDLGFBQWY7QUFBNkIsaUJBQUcsRUFBQyx3QkFBakM7QUFBMEQsaUJBQUcsRUFBQztBQUE5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUZGLGVBR0U7QUFBSyx1QkFBUyxFQUFDO0FBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFIRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUZGLGVBaUJFO0FBQUssbUJBQVMsRUFBQyxNQUFmO0FBQUEsa0NBQ0U7QUFBSyxpQkFBSyxFQUFFO0FBQUVBLGtCQUFJLEVBQUU7QUFBUixhQUFaO0FBQTZCLHFCQUFTLEVBQUMsNEJBQXZDO0FBQUEsb0NBQ0U7QUFBSyx1QkFBUyxFQUFDLCtCQUFmO0FBQUEsc0NBQ0U7QUFBRyxvQkFBSSxFQUFDLEdBQVI7QUFBWSx5QkFBUyxFQUFDLDRDQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFERixlQUVFO0FBQUkseUJBQVMsRUFBQztBQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRkYsZUFHRTtBQUFBLHFFQUE0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE1QixnREFBK0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBL0QscUNBQXVGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXZGLG9CQUE4RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE5RixlQUFvRztBQUFHLHNCQUFJLEVBQUMscUJBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXBHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFIRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREYsZUFNRTtBQUFLLHVCQUFTLEVBQUMsZ0JBQWY7QUFBQSx3REFBK0M7QUFBQSx1Q0FBTTtBQUFLLHFCQUFHLEVBQUM7QUFBVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFERixlQVNFO0FBQUssaUJBQUssRUFBRTtBQUFFQSxrQkFBSSxFQUFFO0FBQVIsYUFBWjtBQUE2QixxQkFBUyxFQUFDLHFCQUF2QztBQUFBLG9DQUNFO0FBQUssdUJBQVMsRUFBQyxhQUFmO0FBQTZCLGlCQUFHLEVBQUMsd0JBQWpDO0FBQTBELGlCQUFHLEVBQUM7QUFBOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFERixlQUVFO0FBQUssdUJBQVMsRUFBQztBQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFqQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREYsZUFpQ0U7QUFBSyxhQUFLLEVBQUU7QUFBRUEsY0FBSSxFQUFFO0FBQVI7QUFBWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBakNGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FERjtBQWlIRCxDQWxIRDs7S0FBTUgsVztBQW1IU0EsMEVBQWYiLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvY29udGFjdC45ZTk0ODNjMzQ5N2EzZDA4YzEwMy5ob3QtdXBkYXRlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IEJ1dHRvbiBmcm9tIFwiQGNvbXBvbmVudHMvYnV0dG9uL1ByaW1hcnlCdXR0b25JY29uUmlnaHRcIjtcblxuY29uc3QgQ29udGFjdEZvcm06IFJlYWN0LkZDID0gKCkgPT4ge1xuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmUgbS1hdXRvIHctMTEvMTJcdFwiIHN0eWxlPXt7IG1hcmdpblRvcDogMTAwLCBtYXJnaW5Cb3R0b206IDE1MCB9fT5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm93XCI+XG4gICAgICAgIDxkaXYgc3R5bGU9e3sgZmxleDogJzYwJScgfX0+XG4gICAgICAgICAgPGgxIGNsYXNzTmFtZT1cIm1haW4tdHh0IHRleHQtNHhsIGxnOnRleHQtM3hsIHRhYmxldDp0ZXh0LTJ4bCBtZDp0ZXh0LTJ4bCBzbTp0ZXh0LXhsIGZvbnQtYm9sZFwiPlZpc3Qgb3VyIEluZGlhIEFkdmlzb3J5IFRlYW0gT2ZmaWNlczwvaDE+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3cgXCI+XG4gICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZsZXg6ICc2NiUnIH19IGNsYXNzTmFtZT1cImNvbC1zcGFuLTggY29udGFjdC1hZGRyZXNzXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWFwLWluZm8gYm9yZGVyLWItMiBtci01IHBiLTVcIj5cbiAgICAgICAgICAgICAgICA8YSBocmVmPVwiI1wiIGNsYXNzTmFtZT1cInVwcGVyY2FzZSBmb250LWJvbGQgdGV4dC14bCBib3JkZXItYi0zIGJiY1wiPkJhbmdhbG9yZTwvYT5cbiAgICAgICAgICAgICAgICA8aHIgY2xhc3NOYW1lPVwidW5kZXItbGluZVwiIC8+XG4gICAgICAgICAgICAgICAgPHA+MTk3LCA2dGggTWFpbiwgMXN0IENyb3NzIDxiciAvPiBIQUwgMm5kIFN0YWdlLCBJbmRpcmEgTmFnYXIgPGJyIC8+IEJlbmdhbHVydSA1NjAwMzggPGJyIC8+IDxiciAvPjxhIGhyZWY9XCJ0ZWw6KzkxLTgwLTI1MTk2MDAwXCI+KzkxLTgwLTI1MTk2MDAwPC9hPjwvcD5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZGlyZWN0aW9uLWxpbmtcIiA+R0VUIERJUkVDVElPTiA8c3Bhbj48aW1nIHNyYz0nL2ljb25zL2JsYWNrQXJyb3cuc3ZnJyAvPjwvc3Bhbj48L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBmbGV4OiAnNDQlJyB9fSBjbGFzc05hbWU9XCJjb2wtc3Bhbi00IHJlbGF0aXZlXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPSdjaXR5LW92ZXJsYXknPkJhbmdsb3JlPC9kaXY+XG4gICAgICAgICAgICAgIDxpbWcgY2xhc3NOYW1lPSdjb250YWN0LWltZycgc3JjPVwiLi4vLi4vaW1nL2ltYWdlIDI2LnBuZ1wiIGFsdD1cIlwiIC8+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGFjdC1iZy1vdmVybGF5IFwiPjwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3cgXCI+XG4gICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZsZXg6ICc2NiUnIH19IGNsYXNzTmFtZT1cImNvbC1zcGFuLTggY29udGFjdC1hZGRyZXNzXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWFwLWluZm8gYm9yZGVyLWItMiBtci01IHBiLTVcIj5cbiAgICAgICAgICAgICAgICA8YSBocmVmPVwiI1wiIGNsYXNzTmFtZT1cInVwcGVyY2FzZSBmb250LWJvbGQgdGV4dC14bCBib3JkZXItYi0zIGJiY1wiPkJhbmdhbG9yZTwvYT5cbiAgICAgICAgICAgICAgICA8aHIgY2xhc3NOYW1lPVwidW5kZXItbGluZVwiIC8+XG4gICAgICAgICAgICAgICAgPHA+MTk3LCA2dGggTWFpbiwgMXN0IENyb3NzIDxiciAvPiBIQUwgMm5kIFN0YWdlLCBJbmRpcmEgTmFnYXIgPGJyIC8+IEJlbmdhbHVydSA1NjAwMzggPGJyIC8+IDxiciAvPjxhIGhyZWY9XCJ0ZWw6KzkxLTgwLTI1MTk2MDAwXCI+KzkxLTgwLTI1MTk2MDAwPC9hPjwvcD5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZGlyZWN0aW9uLWxpbmtcIiA+R0VUIERJUkVDVElPTiA8c3Bhbj48aW1nIHNyYz0nL2ljb25zL2JsYWNrQXJyb3cuc3ZnJyAvPjwvc3Bhbj48L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBmbGV4OiAnNDQlJyB9fSBjbGFzc05hbWU9XCJjb2wtc3Bhbi00IHJlbGF0aXZlXCI+XG4gICAgICAgICAgICAgIDxpbWcgY2xhc3NOYW1lPSdjb250YWN0LWltZycgc3JjPVwiLi4vLi4vaW1nL2ltYWdlIDI2LnBuZ1wiIGFsdD1cIlwiIC8+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGFjdC1iZy1vdmVybGF5IFwiPjwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IHN0eWxlPXt7IGZsZXg6ICc0MCUnIH19PjwvZGl2PlxuICAgICAgPC9kaXY+XG5cblxuICAgICAgey8qIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMTJcIj4gKi99XG4gICAgICB7LyogPGRpdiBjbGFzc05hbWU9XCJjb2wtc3Bhbi04XCI+XG4gICAgICAgICAgPGgxIGNsYXNzTmFtZT1cIm1haW4tdHh0IHRleHQtNHhsIGxnOnRleHQtM3hsIHRhYmxldDp0ZXh0LTJ4bCBtZDp0ZXh0LTJ4bCBzbTp0ZXh0LXhsIGZvbnQtYm9sZFwiPlZpc3Qgb3VyIEluZGlhIEFkdmlzb3J5IFRlYW0gT2ZmaWNlczwvaDE+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xMiBcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLXNwYW4tOFwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1hcC1pbmZvIGJvcmRlci1iLTIgbXItNSBwYi01XCI+XG4gICAgICAgICAgICAgICAgPGEgaHJlZj1cIiNcIiBjbGFzc05hbWU9XCJ1cHBlcmNhc2UgZm9udC1ib2xkIHRleHQteGwgYm9yZGVyLWItMyBiYmNcIj5CYW5nYWxvcmU8L2E+XG4gICAgICAgICAgICAgICAgPGhyIGNsYXNzTmFtZT1cInVuZGVyLWxpbmVcIiAvPlxuICAgICAgICAgICAgICAgIDxwPjE5NywgNnRoIE1haW4sIDFzdCBDcm9zcyA8YnIgLz4gSEFMIDJuZCBTdGFnZSwgSW5kaXJhIE5hZ2FyIDxiciAvPiBCZW5nYWx1cnUgNTYwMDM4IDxiciAvPiA8YnIgLz48YSBocmVmPVwidGVsOis5MS04MC0yNTE5NjAwMFwiPis5MS04MC0yNTE5NjAwMDwvYT48L3A+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRpcmVjdGlvbi1saW5rXCIgPkdFVCBESVJFQ1RJT048L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtc3Bhbi00IHJlbGF0aXZlXCI+XG4gICAgICAgICAgICAgIDxpbWcgc3JjPVwiLi4vLi4vaW1nL2ltYWdlIDI2LnBuZ1wiIGFsdD1cIlwiIC8+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctb3ZlcmxheSBcIj48L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxociBjbGFzc05hbWU9XCJsaW5lXCIgLz5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEyXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC1zcGFuLThcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYXAtaW5mbyBib3JkZXItYi0yIG1yLTUgcGItNVwiPlxuICAgICAgICAgICAgICAgIDxhIGhyZWY9XCIjXCIgY2xhc3NOYW1lPVwidXBwZXJjYXNlIGZvbnQtYm9sZCB0ZXh0LXhsIGJvcmRlci1iLTMgYmJjXCI+REVMSEk8L2E+XG4gICAgICAgICAgICAgICAgPGhyIGNsYXNzTmFtZT1cInVuZGVyLWxpbmVcIiAvPlxuICAgICAgICAgICAgICAgIDxwPjR0aCBGbG9vciwgQXJpYSBUb3dlcnMsIDxiciAvPiBKVyBNYXJyaW90dCwgQXNzZXQgQXJlYSA0LCA8YnIgLz4gQWVyb2NpdHksIE5ldyBEZWxoaSwgMTEwMDM3IDxiciAvPiA8YnIgLz48YSBocmVmPVwidGVsOis5MS0xMS00OTQ5NTAwMFwiPis5MS0xMS00OTQ5NTAwMDwvYT48L3A+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRpcmVjdGlvbi1saW5rXCIgPkdFVCBESVJFQ1RJT048L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtc3Bhbi00IHJlbGF0aXZlXCI+XG4gICAgICAgICAgICAgIDxpbWcgc3JjPVwiLi4vLi4vaW1nL2ltYWdlIDI2LnBuZ1wiIGFsdD1cIlwiIC8+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctb3ZlcmxheSBcIj48L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxociBjbGFzc05hbWU9XCJsaW5lXCIgLz5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEyXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC1zcGFuLThcIj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJtYXAtaW5mbyBib3JkZXItYi0yIG1yLTUgcGItNVwiPlxuICAgICAgICAgICAgICAgIDxhIGhyZWY9XCIjXCIgY2xhc3NOYW1lPVwidXBwZXJjYXNlIGZvbnQtYm9sZCB0ZXh0LXhsIGJvcmRlci1iLTMgYmJjXCI+TVVNQkFJPC9hPlxuICAgICAgICAgICAgICAgIDxociBjbGFzc05hbWU9XCJ1bmRlci1saW5lXCIgLz5cbiAgICAgICAgICAgICAgICA8cD42MDEtNjAyLCBDZWVqYXkgSG91c2UsIDxiciAvPiBEciBBbm5pZSBCZXNhbnQgUm9hZCwgV29ybGksICA8YnIgLz4gTXVtYmFpIDQwMDAxOCA8YnIgLz4gPGJyIC8+PGEgaHJlZj1cInRlbDorOTEtMjItNjc2ODAwMDBcIj4rOTEtMjItNjc2ODAwMDA8L2E+PC9wPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJkaXJlY3Rpb24tbGlua1wiID5HRVQgRElSRUNUSU9OPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLXNwYW4tNCByZWxhdGl2ZVwiPlxuICAgICAgICAgICAgICA8aW1nIHNyYz1cIi4uLy4uL2ltZy9pbWFnZSAyNi5wbmdcIiBhbHQ9XCJcIiAvPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLW92ZXJsYXkgXCI+PC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+ICovfVxuICAgICAgey8qIDxkaXYgY2xhc3NOYW1lPVwiY29sLXNwYW4tNCBcIj5cbiAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwibWFpbi10eHQgdGV4dC00eGwgbGc6dGV4dC0zeGwgdGFibGV0OnRleHQtMnhsIG1kOnRleHQtMnhsIHNtOnRleHQteGwgZm9udC1ib2xkXCI+U2hhcmUgeW91ciBCdXNpbmVzcyBQbGFuczwvaDE+XG4gICAgICAgICAgPGZvcm0gY2xhc3NOYW1lPSdjb250YWN0LWZvcm0nPlxuICAgICAgICAgICAgPGxhYmVsID5OYW1lPC9sYWJlbD5cbiAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIHBsYWNlaG9sZGVyPVwiTmFtZVwiIC8+XG4gICAgICAgICAgICA8bGFiZWwgPkNvbXBhbnkgTmFtZTwvbGFiZWw+XG4gICAgICAgICAgICA8aW5wdXQgdHlwZT1cInRleHRcIiBwbGFjZWhvbGRlcj1cIkNvbXBhbnkgTmFtZVwiIC8+XG4gICAgICAgICAgICA8bGFiZWwgPldoYXQgYXJlIHlvdSBidWlsZGluZz88L2xhYmVsPlxuICAgICAgICAgICAgPHRleHRhcmVhIHBsYWNlaG9sZGVyPVwiQ29tcGFueSBCcmllZlwiIC8+XG4gICAgICAgICAgICA8bGFiZWwgPkZpbGUgQXR0YWNobWVudDwvbGFiZWw+XG4gICAgICAgICAgICA8aW5wdXQgdHlwZT1cImZpbGVcIiAvPlxuICAgICAgICAgICAgPGxhYmVsID5FbWFpbCBJZDwvbGFiZWw+XG4gICAgICAgICAgICA8aW5wdXQgdHlwZT1cImVtYWlsXCIgcGxhY2Vob2xkZXI9XCJDb250YWN0IEVtYWlsXCIgLz5cbiAgICAgICAgICAgIDxsYWJlbCA+TW9iaWxlIE51bWJlcjwvbGFiZWw+XG4gICAgICAgICAgICA8aW5wdXQgdHlwZT1cInRleHRcIiBwbGFjZWhvbGRlcj1cIkNvbnRhY3QgTnVtYmVyXCIgLz5cbiAgICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgICAgdGl0bGU9XCJBcHBseVwiXG4gICAgICAgICAgICAgIHVybD1cIi9pY29ucy9yaWdodEFycm93LnN2Z1wiXG4gICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGNvbnNvbGUubG9nKFwic3Vic2NyaWJlXCIpfVxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWxnIGxlYWRpbmctNlwiXG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvZm9ybT5cbiAgICAgICAgPC9kaXY+ICovfVxuICAgICAgey8qIDwvZGl2PiAqL31cbiAgICA8L2Rpdj5cbiAgKVxufVxuZXhwb3J0IGRlZmF1bHQgQ29udGFjdEZvcm07XG4iXSwic291cmNlUm9vdCI6IiJ9