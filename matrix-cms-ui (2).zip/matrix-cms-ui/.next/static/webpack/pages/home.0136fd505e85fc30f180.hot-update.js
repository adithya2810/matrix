webpackHotUpdate_N_E("pages/home",{

/***/ "./node_modules/classnames/index.js":
false,

/***/ "./node_modules/enquire.js/src/MediaQuery.js":
false,

/***/ "./node_modules/enquire.js/src/MediaQueryDispatch.js":
false,

/***/ "./node_modules/enquire.js/src/QueryHandler.js":
false,

/***/ "./node_modules/enquire.js/src/Util.js":
false,

/***/ "./node_modules/enquire.js/src/index.js":
false,

/***/ "./node_modules/json2mq/index.js":
false,

/***/ "./node_modules/lodash.debounce/index.js":
false,

/***/ "./node_modules/next/dist/compiled/webpack/global.js":
false,

/***/ "./node_modules/react-slick/lib/arrows.js":
false,

/***/ "./node_modules/react-slick/lib/default-props.js":
false,

/***/ "./node_modules/react-slick/lib/dots.js":
false,

/***/ "./node_modules/react-slick/lib/index.js":
false,

/***/ "./node_modules/react-slick/lib/initial-state.js":
false,

/***/ "./node_modules/react-slick/lib/inner-slider.js":
false,

/***/ "./node_modules/react-slick/lib/slider.js":
false,

/***/ "./node_modules/react-slick/lib/track.js":
false,

/***/ "./node_modules/react-slick/lib/utils/innerSliderUtils.js":
false,

/***/ "./node_modules/resize-observer-polyfill/dist/ResizeObserver.es.js":
false,

/***/ "./node_modules/string-convert/camel2hyphen.js":
false,

/***/ "./src/components/founder/Founder.tsx":
/*!********************************************!*\
  !*** ./src/components/founder/Founder.tsx ***!
  \********************************************/
/*! exports provided: Founder */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Founder", function() { return Founder; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var C_Users_KARTHIK_Documents_workspace_matrix_cms_ui_development_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @components */ "./src/components/index.ts");



var _jsxFileName = "C:\\Users\\KARTHIK\\Documents\\workspace\\matrix-cms-ui-development\\src\\components\\founder\\Founder.tsx",
    _this = undefined;

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { Object(C_Users_KARTHIK_Documents_workspace_matrix_cms_ui_development_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__["default"])(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }



var Founder = function Founder(_ref) {
  var className = _ref.className,
      _ref$style = _ref.style,
      style = _ref$style === void 0 ? {} : _ref$style;
  return (
    /*#__PURE__*/
    // <Carousel>
    Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "".concat(className),
        style: _objectSpread({
          width: 615.94,
          height: 863.91,
          position: "relative"
        }, style),
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "",
          style: {
            width: 571,
            height: 762,
            position: "absolute",
            background: "#083A4A",
            bottom: 50,
            left: 0
          }
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 19,
          columnNumber: 9
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "",
          style: {
            width: 594,
            height: 788,
            bottom: 65,
            left: 15,
            position: "absolute",
            display: "flex",
            flexDirection: "column"
          },
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_3__["Image"], {
            src: "/icons/Bhavish_image.svg",
            alt: "founder image",
            style: {
              flexGrow: 1
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 23,
            columnNumber: 11
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_3__["Image"], {
            src: "/icons/rectangle.svg",
            alt: "reactangle",
            className: "absolute",
            style: {
              left: 38,
              bottom: 254
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 24,
            columnNumber: 11
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            style: {
              height: 209,
              background: "#01576E"
            },
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "text-center flex items-center",
              style: {
                height: 118,
                borderBottom: "1px solid #EBEBE9"
              },
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h6", {
                className: "font-bold text-secondary",
                style: {
                  fontSize: 32,
                  lineHeight: "36px",
                  letterSpacing: "0.05em",
                  marginLeft: 31,
                  marginRight: 8
                },
                children: "BHAVISH"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 28,
                columnNumber: 15
              }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h6", {
                className: "font-light text-secondary",
                style: {
                  fontSize: 32,
                  lineHeight: "36px",
                  letterSpacing: "0.05em"
                },
                children: "AGGARWAL"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 31,
                columnNumber: 15
              }, _this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 27,
              columnNumber: 13
            }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "flex justify-between items-center",
              style: {
                height: 88
              },
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                style: {
                  marginLeft: 31
                },
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                  className: "text-secondary font-medium text-lg leading-6",
                  children: " Mobility"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 38,
                  columnNumber: 17
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 37,
                columnNumber: 15
              }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_3__["Image"], {
                src: "/icons/ola.svg",
                alt: "ola",
                style: {
                  marginRight: 57
                }
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 40,
                columnNumber: 15
              }, _this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 36,
              columnNumber: 13
            }, _this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 26,
            columnNumber: 11
          }, _this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 20,
          columnNumber: 9
        }, _this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 18,
        columnNumber: 7
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 17,
      columnNumber: 5
    }, _this) // </Carousel>

  );
};
_c = Founder;

var _c;

$RefreshReg$(_c, "Founder");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vc3JjL2NvbXBvbmVudHMvZm91bmRlci9Gb3VuZGVyLnRzeCJdLCJuYW1lcyI6WyJGb3VuZGVyIiwiY2xhc3NOYW1lIiwic3R5bGUiLCJ3aWR0aCIsImhlaWdodCIsInBvc2l0aW9uIiwiYmFja2dyb3VuZCIsImJvdHRvbSIsImxlZnQiLCJkaXNwbGF5IiwiZmxleERpcmVjdGlvbiIsImZsZXhHcm93IiwiYm9yZGVyQm90dG9tIiwiZm9udFNpemUiLCJsaW5lSGVpZ2h0IiwibGV0dGVyU3BhY2luZyIsIm1hcmdpbkxlZnQiLCJtYXJnaW5SaWdodCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFZTyxJQUFNQSxPQUF3QixHQUFHLFNBQTNCQSxPQUEyQixPQUErQjtBQUFBLE1BQTVCQyxTQUE0QixRQUE1QkEsU0FBNEI7QUFBQSx3QkFBakJDLEtBQWlCO0FBQUEsTUFBakJBLEtBQWlCLDJCQUFULEVBQVM7QUFDckU7QUFBQTtBQUNFO0FBQ0E7QUFBQSw2QkFDRTtBQUFLLGlCQUFTLFlBQUtELFNBQUwsQ0FBZDtBQUFnQyxhQUFLO0FBQUlFLGVBQUssRUFBRSxNQUFYO0FBQW1CQyxnQkFBTSxFQUFFLE1BQTNCO0FBQW1DQyxrQkFBUSxFQUFFO0FBQTdDLFdBQTRESCxLQUE1RCxDQUFyQztBQUFBLGdDQUNFO0FBQUssbUJBQVMsRUFBQyxFQUFmO0FBQWtCLGVBQUssRUFBRTtBQUFFQyxpQkFBSyxFQUFFLEdBQVQ7QUFBY0Msa0JBQU0sRUFBRSxHQUF0QjtBQUEyQkMsb0JBQVEsRUFBRSxVQUFyQztBQUFpREMsc0JBQVUsRUFBRSxTQUE3RDtBQUF3RUMsa0JBQU0sRUFBRSxFQUFoRjtBQUFvRkMsZ0JBQUksRUFBRTtBQUExRjtBQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURGLGVBRUU7QUFDRSxtQkFBUyxFQUFDLEVBRFo7QUFFRSxlQUFLLEVBQUU7QUFBRUwsaUJBQUssRUFBRSxHQUFUO0FBQWNDLGtCQUFNLEVBQUUsR0FBdEI7QUFBMkJHLGtCQUFNLEVBQUUsRUFBbkM7QUFBdUNDLGdCQUFJLEVBQUUsRUFBN0M7QUFBaURILG9CQUFRLEVBQUUsVUFBM0Q7QUFBdUVJLG1CQUFPLEVBQUUsTUFBaEY7QUFBd0ZDLHlCQUFhLEVBQUU7QUFBdkcsV0FGVDtBQUFBLGtDQUdFLHFFQUFDLGlEQUFEO0FBQU8sZUFBRyxFQUFDLDBCQUFYO0FBQXNDLGVBQUcsRUFBQyxlQUExQztBQUEwRCxpQkFBSyxFQUFFO0FBQUVDLHNCQUFRLEVBQUU7QUFBWjtBQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUhGLGVBSUUscUVBQUMsaURBQUQ7QUFBTyxlQUFHLEVBQUMsc0JBQVg7QUFBa0MsZUFBRyxFQUFFLFlBQXZDO0FBQXFELHFCQUFTLEVBQUMsVUFBL0Q7QUFBMEUsaUJBQUssRUFBRTtBQUFFSCxrQkFBSSxFQUFFLEVBQVI7QUFBWUQsb0JBQU0sRUFBRTtBQUFwQjtBQUFqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUpGLGVBTUU7QUFBSyxpQkFBSyxFQUFFO0FBQUVILG9CQUFNLEVBQUUsR0FBVjtBQUFlRSx3QkFBVSxFQUFFO0FBQTNCLGFBQVo7QUFBQSxvQ0FDRTtBQUFLLHVCQUFTLEVBQUMsK0JBQWY7QUFBK0MsbUJBQUssRUFBRTtBQUFFRixzQkFBTSxFQUFFLEdBQVY7QUFBZVEsNEJBQVksRUFBRTtBQUE3QixlQUF0RDtBQUFBLHNDQUNFO0FBQUkseUJBQVMsRUFBQywwQkFBZDtBQUF5QyxxQkFBSyxFQUFFO0FBQUVDLDBCQUFRLEVBQUUsRUFBWjtBQUFnQkMsNEJBQVUsRUFBRSxNQUE1QjtBQUFvQ0MsK0JBQWEsRUFBRSxRQUFuRDtBQUE2REMsNEJBQVUsRUFBRSxFQUF6RTtBQUE2RUMsNkJBQVcsRUFBRTtBQUExRixpQkFBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBREYsZUFJRTtBQUFJLHlCQUFTLEVBQUMsMkJBQWQ7QUFBMEMscUJBQUssRUFBRTtBQUFFSiwwQkFBUSxFQUFFLEVBQVo7QUFBZ0JDLDRCQUFVLEVBQUUsTUFBNUI7QUFBb0NDLCtCQUFhLEVBQUU7QUFBbkQsaUJBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFERixlQVVFO0FBQUssdUJBQVMsRUFBQyxtQ0FBZjtBQUFtRCxtQkFBSyxFQUFFO0FBQUVYLHNCQUFNLEVBQUU7QUFBVixlQUExRDtBQUFBLHNDQUNFO0FBQUsscUJBQUssRUFBRTtBQUFFWSw0QkFBVSxFQUFFO0FBQWQsaUJBQVo7QUFBQSx1Q0FDRTtBQUFNLDJCQUFTLEVBQUMsOENBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFERixlQUlFLHFFQUFDLGlEQUFEO0FBQU8sbUJBQUcsRUFBRSxnQkFBWjtBQUE4QixtQkFBRyxFQUFFLEtBQW5DO0FBQTBDLHFCQUFLLEVBQUU7QUFBRUMsNkJBQVcsRUFBRTtBQUFmO0FBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFORjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUZGLENBK0JFOztBQS9CRjtBQWlDRCxDQWxDTTtLQUFNakIsTyIsImZpbGUiOiJzdGF0aWMvd2VicGFjay9wYWdlcy9ob21lLjAxMzZmZDUwNWU4NWZjMzBmMTgwLmhvdC11cGRhdGUuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBJbWFnZSB9IGZyb20gXCJAY29tcG9uZW50c1wiO1xuaW1wb3J0IENhcm91c2VsIGZyb20gXCJyZWFjdC1zbGlja1wiO1xuXG5leHBvcnQgdHlwZSBQcm9wcyA9IHtcbiAgbmFtZXM/OiBBcnJheTxzdHJpbmc+O1xuICBiYWNrZ3JvdW5kX3VybD86IHN0cmluZztcbiAgdGFncz86IEFycmF5PHN0cmluZz47XG4gIGxvZ28/OiBzdHJpbmc7XG4gIGNsYXNzTmFtZT86IHN0cmluZztcbiAgc3R5bGU/OiBhbnk7XG59O1xuXG5leHBvcnQgY29uc3QgRm91bmRlcjogUmVhY3QuRkM8UHJvcHM+ID0gKHsgY2xhc3NOYW1lLCBzdHlsZSA9IHt9IH0pID0+IHtcbiAgcmV0dXJuIChcbiAgICAvLyA8Q2Fyb3VzZWw+XG4gICAgPGRpdj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPXtgJHtjbGFzc05hbWV9YH0gc3R5bGU9e3sgd2lkdGg6IDYxNS45NCwgaGVpZ2h0OiA4NjMuOTEsIHBvc2l0aW9uOiBcInJlbGF0aXZlXCIsIC4uLnN0eWxlLCB9fT5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJcIiBzdHlsZT17eyB3aWR0aDogNTcxLCBoZWlnaHQ6IDc2MiwgcG9zaXRpb246IFwiYWJzb2x1dGVcIiwgYmFja2dyb3VuZDogXCIjMDgzQTRBXCIsIGJvdHRvbTogNTAsIGxlZnQ6IDAsIH19PjwvZGl2PlxuICAgICAgICA8ZGl2XG4gICAgICAgICAgY2xhc3NOYW1lPVwiXCJcbiAgICAgICAgICBzdHlsZT17eyB3aWR0aDogNTk0LCBoZWlnaHQ6IDc4OCwgYm90dG9tOiA2NSwgbGVmdDogMTUsIHBvc2l0aW9uOiBcImFic29sdXRlXCIsIGRpc3BsYXk6IFwiZmxleFwiLCBmbGV4RGlyZWN0aW9uOiBcImNvbHVtblwiLCB9fT5cbiAgICAgICAgICA8SW1hZ2Ugc3JjPVwiL2ljb25zL0JoYXZpc2hfaW1hZ2Uuc3ZnXCIgYWx0PVwiZm91bmRlciBpbWFnZVwiIHN0eWxlPXt7IGZsZXhHcm93OiAxIH19PjwvSW1hZ2U+XG4gICAgICAgICAgPEltYWdlIHNyYz1cIi9pY29ucy9yZWN0YW5nbGUuc3ZnXCIgYWx0PXtcInJlYWN0YW5nbGVcIn0gY2xhc3NOYW1lPVwiYWJzb2x1dGVcIiBzdHlsZT17eyBsZWZ0OiAzOCwgYm90dG9tOiAyNTQgfX0gLz5cblxuICAgICAgICAgIDxkaXYgc3R5bGU9e3sgaGVpZ2h0OiAyMDksIGJhY2tncm91bmQ6IFwiIzAxNTc2RVwiIH19PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBmbGV4IGl0ZW1zLWNlbnRlclwiIHN0eWxlPXt7IGhlaWdodDogMTE4LCBib3JkZXJCb3R0b206IFwiMXB4IHNvbGlkICNFQkVCRTlcIiB9fT5cbiAgICAgICAgICAgICAgPGg2IGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNlY29uZGFyeVwiIHN0eWxlPXt7IGZvbnRTaXplOiAzMiwgbGluZUhlaWdodDogXCIzNnB4XCIsIGxldHRlclNwYWNpbmc6IFwiMC4wNWVtXCIsIG1hcmdpbkxlZnQ6IDMxLCBtYXJnaW5SaWdodDogOCwgfX0+XG4gICAgICAgICAgICAgICAgQkhBVklTSFxuICAgICAgICAgICAgICA8L2g2PlxuICAgICAgICAgICAgICA8aDYgY2xhc3NOYW1lPVwiZm9udC1saWdodCB0ZXh0LXNlY29uZGFyeVwiIHN0eWxlPXt7IGZvbnRTaXplOiAzMiwgbGluZUhlaWdodDogXCIzNnB4XCIsIGxldHRlclNwYWNpbmc6IFwiMC4wNWVtXCIsIH19PlxuICAgICAgICAgICAgICAgIEFHR0FSV0FMXG4gICAgICAgICAgICAgIDwvaDY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXJcIiBzdHlsZT17eyBoZWlnaHQ6IDg4IH19PlxuICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IG1hcmdpbkxlZnQ6IDMxIH19PlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2Vjb25kYXJ5IGZvbnQtbWVkaXVtIHRleHQtbGcgbGVhZGluZy02XCI+IE1vYmlsaXR5PC9zcGFuPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPEltYWdlIHNyYz17XCIvaWNvbnMvb2xhLnN2Z1wifSBhbHQ9e1wib2xhXCJ9IHN0eWxlPXt7IG1hcmdpblJpZ2h0OiA1NyB9fSAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICAgLy8gPC9DYXJvdXNlbD5cbiAgKTtcbn07XG4iXSwic291cmNlUm9vdCI6IiJ9