webpackHotUpdate_N_E("pages/contact",{

/***/ "./src/modules/contact/form.tsx":
/*!**************************************!*\
  !*** ./src/modules/contact/form.tsx ***!
  \**************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


var _jsxFileName = "C:\\Users\\KARTHIK\\Documents\\workspace\\matrix-cms-ui-development\\src\\modules\\contact\\form.tsx",
    _this = undefined;



var ContactForm = function ContactForm() {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: "relative m-auto w-11/12\t",
    style: {
      marginTop: 100,
      marginBottom: 150
    },
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "row",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        style: {
          flex: '60%'
        },
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h1", {
          className: "main-txt text-4xl lg:text-3xl tablet:text-2xl md:text-2xl sm:text-xl font-bold",
          children: "Vist our India Advisory Team Offices"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 9,
          columnNumber: 11
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "row ",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            style: {
              flex: '66%'
            },
            className: "col-span-8 contact-address",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "map-info border-b-2 mr-5 pb-5",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                href: "#",
                className: "uppercase font-bold text-xl border-b-3 bbc",
                children: "Bangalore"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 13,
                columnNumber: 17
              }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("hr", {
                className: "under-line"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 14,
                columnNumber: 17
              }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
                children: ["197, 6th Main, 1st Cross ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 15,
                  columnNumber: 45
                }, _this), " HAL 2nd Stage, Indira Nagar ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 15,
                  columnNumber: 80
                }, _this), " Bengaluru 560038 ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 15,
                  columnNumber: 104
                }, _this), " ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 15,
                  columnNumber: 111
                }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                  href: "tel:+91-80-25196000",
                  children: "+91-80-25196000"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 15,
                  columnNumber: 117
                }, _this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 15,
                columnNumber: 17
              }, _this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 12,
              columnNumber: 15
            }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "direction-link",
              children: "GET DIRECTION"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 17,
              columnNumber: 15
            }, _this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 11,
            columnNumber: 13
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            style: {
              flex: '44%'
            },
            className: "col-span-4 relative",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "city-overlay",
              children: "Banglore"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 20,
              columnNumber: 15
            }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
              className: "contact-img",
              src: "../../img/image 26.png",
              alt: ""
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 21,
              columnNumber: 15
            }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "contact-bg-overlay "
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 22,
              columnNumber: 15
            }, _this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 19,
            columnNumber: 13
          }, _this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 10,
          columnNumber: 11
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "row ",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            style: {
              flex: '66%'
            },
            className: "col-span-8 contact-address",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "map-info border-b-2 mr-5 pb-5",
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                href: "#",
                className: "uppercase font-bold text-xl border-b-3 bbc",
                children: "Bangalore"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 28,
                columnNumber: 17
              }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("hr", {
                className: "under-line"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 29,
                columnNumber: 17
              }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
                children: ["197, 6th Main, 1st Cross ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 30,
                  columnNumber: 45
                }, _this), " HAL 2nd Stage, Indira Nagar ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 30,
                  columnNumber: 80
                }, _this), " Bengaluru 560038 ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 30,
                  columnNumber: 104
                }, _this), " ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 30,
                  columnNumber: 111
                }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
                  href: "tel:+91-80-25196000",
                  children: "+91-80-25196000"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 30,
                  columnNumber: 117
                }, _this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 30,
                columnNumber: 17
              }, _this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 27,
              columnNumber: 15
            }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "direction-link",
              children: "GET DIRECTION"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 32,
              columnNumber: 15
            }, _this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 26,
            columnNumber: 13
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            style: {
              flex: '44%'
            },
            className: "col-span-4 relative",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
              className: "contact-img",
              src: "../../img/image 26.png",
              alt: ""
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 35,
              columnNumber: 15
            }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "contact-bg-overlay "
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 36,
              columnNumber: 15
            }, _this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 34,
            columnNumber: 13
          }, _this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 25,
          columnNumber: 11
        }, _this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 8,
        columnNumber: 9
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        style: {
          flex: '40%'
        }
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 40,
        columnNumber: 9
      }, _this)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 7,
      columnNumber: 7
    }, _this)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 6,
    columnNumber: 5
  }, _this);
};

_c = ContactForm;
/* harmony default export */ __webpack_exports__["default"] = (ContactForm);

var _c;

$RefreshReg$(_c, "ContactForm");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vc3JjL21vZHVsZXMvY29udGFjdC9mb3JtLnRzeCJdLCJuYW1lcyI6WyJDb250YWN0Rm9ybSIsIm1hcmdpblRvcCIsIm1hcmdpbkJvdHRvbSIsImZsZXgiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7O0FBR0EsSUFBTUEsV0FBcUIsR0FBRyxTQUF4QkEsV0FBd0IsR0FBTTtBQUNsQyxzQkFDRTtBQUFLLGFBQVMsRUFBQywyQkFBZjtBQUEwQyxTQUFLLEVBQUU7QUFBRUMsZUFBUyxFQUFFLEdBQWI7QUFBa0JDLGtCQUFZLEVBQUU7QUFBaEMsS0FBakQ7QUFBQSwyQkFDRTtBQUFLLGVBQVMsRUFBQyxLQUFmO0FBQUEsOEJBQ0U7QUFBSyxhQUFLLEVBQUU7QUFBRUMsY0FBSSxFQUFFO0FBQVIsU0FBWjtBQUFBLGdDQUNFO0FBQUksbUJBQVMsRUFBQyxnRkFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFERixlQUVFO0FBQUssbUJBQVMsRUFBQyxNQUFmO0FBQUEsa0NBQ0U7QUFBSyxpQkFBSyxFQUFFO0FBQUVBLGtCQUFJLEVBQUU7QUFBUixhQUFaO0FBQTZCLHFCQUFTLEVBQUMsNEJBQXZDO0FBQUEsb0NBQ0U7QUFBSyx1QkFBUyxFQUFDLCtCQUFmO0FBQUEsc0NBQ0U7QUFBRyxvQkFBSSxFQUFDLEdBQVI7QUFBWSx5QkFBUyxFQUFDLDRDQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFERixlQUVFO0FBQUkseUJBQVMsRUFBQztBQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRkYsZUFHRTtBQUFBLHFFQUE0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE1QixnREFBK0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBL0QscUNBQXVGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXZGLG9CQUE4RjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUE5RixlQUFvRztBQUFHLHNCQUFJLEVBQUMscUJBQVI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXBHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFIRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREYsZUFNRTtBQUFLLHVCQUFTLEVBQUMsZ0JBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURGLGVBU0U7QUFBSyxpQkFBSyxFQUFFO0FBQUVBLGtCQUFJLEVBQUU7QUFBUixhQUFaO0FBQTZCLHFCQUFTLEVBQUMscUJBQXZDO0FBQUEsb0NBQ0U7QUFBSyx1QkFBUyxFQUFDLGNBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREYsZUFFRTtBQUFLLHVCQUFTLEVBQUMsYUFBZjtBQUE2QixpQkFBRyxFQUFDLHdCQUFqQztBQUEwRCxpQkFBRyxFQUFDO0FBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRkYsZUFHRTtBQUFLLHVCQUFTLEVBQUM7QUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFURjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRkYsZUFpQkU7QUFBSyxtQkFBUyxFQUFDLE1BQWY7QUFBQSxrQ0FDRTtBQUFLLGlCQUFLLEVBQUU7QUFBRUEsa0JBQUksRUFBRTtBQUFSLGFBQVo7QUFBNkIscUJBQVMsRUFBQyw0QkFBdkM7QUFBQSxvQ0FDRTtBQUFLLHVCQUFTLEVBQUMsK0JBQWY7QUFBQSxzQ0FDRTtBQUFHLG9CQUFJLEVBQUMsR0FBUjtBQUFZLHlCQUFTLEVBQUMsNENBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQURGLGVBRUU7QUFBSSx5QkFBUyxFQUFDO0FBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFGRixlQUdFO0FBQUEscUVBQTRCO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTVCLGdEQUErRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUEvRCxxQ0FBdUY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBdkYsb0JBQThGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQTlGLGVBQW9HO0FBQUcsc0JBQUksRUFBQyxxQkFBUjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBcEc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFERixlQU1FO0FBQUssdUJBQVMsRUFBQyxnQkFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFORjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREYsZUFTRTtBQUFLLGlCQUFLLEVBQUU7QUFBRUEsa0JBQUksRUFBRTtBQUFSLGFBQVo7QUFBNkIscUJBQVMsRUFBQyxxQkFBdkM7QUFBQSxvQ0FDRTtBQUFLLHVCQUFTLEVBQUMsYUFBZjtBQUE2QixpQkFBRyxFQUFDLHdCQUFqQztBQUEwRCxpQkFBRyxFQUFDO0FBQTlEO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREYsZUFFRTtBQUFLLHVCQUFTLEVBQUM7QUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFURjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGLGVBaUNFO0FBQUssYUFBSyxFQUFFO0FBQUVBLGNBQUksRUFBRTtBQUFSO0FBQVo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQWpDRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBREY7QUFpSEQsQ0FsSEQ7O0tBQU1ILFc7QUFtSFNBLDBFQUFmIiwiZmlsZSI6InN0YXRpYy93ZWJwYWNrL3BhZ2VzL2NvbnRhY3QuMzdiYTI0OTRhYjgwMWMyMWIzNzIuaG90LXVwZGF0ZS5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCBCdXR0b24gZnJvbSBcIkBjb21wb25lbnRzL2J1dHRvbi9QcmltYXJ5QnV0dG9uSWNvblJpZ2h0XCI7XG5cbmNvbnN0IENvbnRhY3RGb3JtOiBSZWFjdC5GQyA9ICgpID0+IHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlIG0tYXV0byB3LTExLzEyXHRcIiBzdHlsZT17eyBtYXJnaW5Ub3A6IDEwMCwgbWFyZ2luQm90dG9tOiAxNTAgfX0+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInJvd1wiPlxuICAgICAgICA8ZGl2IHN0eWxlPXt7IGZsZXg6ICc2MCUnIH19PlxuICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJtYWluLXR4dCB0ZXh0LTR4bCBsZzp0ZXh0LTN4bCB0YWJsZXQ6dGV4dC0yeGwgbWQ6dGV4dC0yeGwgc206dGV4dC14bCBmb250LWJvbGRcIj5WaXN0IG91ciBJbmRpYSBBZHZpc29yeSBUZWFtIE9mZmljZXM8L2gxPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicm93IFwiPlxuICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBmbGV4OiAnNjYlJyB9fSBjbGFzc05hbWU9XCJjb2wtc3Bhbi04IGNvbnRhY3QtYWRkcmVzc1wiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1hcC1pbmZvIGJvcmRlci1iLTIgbXItNSBwYi01XCI+XG4gICAgICAgICAgICAgICAgPGEgaHJlZj1cIiNcIiBjbGFzc05hbWU9XCJ1cHBlcmNhc2UgZm9udC1ib2xkIHRleHQteGwgYm9yZGVyLWItMyBiYmNcIj5CYW5nYWxvcmU8L2E+XG4gICAgICAgICAgICAgICAgPGhyIGNsYXNzTmFtZT1cInVuZGVyLWxpbmVcIiAvPlxuICAgICAgICAgICAgICAgIDxwPjE5NywgNnRoIE1haW4sIDFzdCBDcm9zcyA8YnIgLz4gSEFMIDJuZCBTdGFnZSwgSW5kaXJhIE5hZ2FyIDxiciAvPiBCZW5nYWx1cnUgNTYwMDM4IDxiciAvPiA8YnIgLz48YSBocmVmPVwidGVsOis5MS04MC0yNTE5NjAwMFwiPis5MS04MC0yNTE5NjAwMDwvYT48L3A+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRpcmVjdGlvbi1saW5rXCIgPkdFVCBESVJFQ1RJT048L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBmbGV4OiAnNDQlJyB9fSBjbGFzc05hbWU9XCJjb2wtc3Bhbi00IHJlbGF0aXZlXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPSdjaXR5LW92ZXJsYXknPkJhbmdsb3JlPC9kaXY+XG4gICAgICAgICAgICAgIDxpbWcgY2xhc3NOYW1lPSdjb250YWN0LWltZycgc3JjPVwiLi4vLi4vaW1nL2ltYWdlIDI2LnBuZ1wiIGFsdD1cIlwiIC8+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29udGFjdC1iZy1vdmVybGF5IFwiPjwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJyb3cgXCI+XG4gICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZsZXg6ICc2NiUnIH19IGNsYXNzTmFtZT1cImNvbC1zcGFuLTggY29udGFjdC1hZGRyZXNzXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWFwLWluZm8gYm9yZGVyLWItMiBtci01IHBiLTVcIj5cbiAgICAgICAgICAgICAgICA8YSBocmVmPVwiI1wiIGNsYXNzTmFtZT1cInVwcGVyY2FzZSBmb250LWJvbGQgdGV4dC14bCBib3JkZXItYi0zIGJiY1wiPkJhbmdhbG9yZTwvYT5cbiAgICAgICAgICAgICAgICA8aHIgY2xhc3NOYW1lPVwidW5kZXItbGluZVwiIC8+XG4gICAgICAgICAgICAgICAgPHA+MTk3LCA2dGggTWFpbiwgMXN0IENyb3NzIDxiciAvPiBIQUwgMm5kIFN0YWdlLCBJbmRpcmEgTmFnYXIgPGJyIC8+IEJlbmdhbHVydSA1NjAwMzggPGJyIC8+IDxiciAvPjxhIGhyZWY9XCJ0ZWw6KzkxLTgwLTI1MTk2MDAwXCI+KzkxLTgwLTI1MTk2MDAwPC9hPjwvcD5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZGlyZWN0aW9uLWxpbmtcIiA+R0VUIERJUkVDVElPTjwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGZsZXg6ICc0NCUnIH19IGNsYXNzTmFtZT1cImNvbC1zcGFuLTQgcmVsYXRpdmVcIj5cbiAgICAgICAgICAgICAgPGltZyBjbGFzc05hbWU9J2NvbnRhY3QtaW1nJyBzcmM9XCIuLi8uLi9pbWcvaW1hZ2UgMjYucG5nXCIgYWx0PVwiXCIgLz5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb250YWN0LWJnLW92ZXJsYXkgXCI+PC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgc3R5bGU9e3sgZmxleDogJzQwJScgfX0+PC9kaXY+XG4gICAgICA8L2Rpdj5cblxuXG4gICAgICB7LyogPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xMlwiPiAqL31cbiAgICAgIHsvKiA8ZGl2IGNsYXNzTmFtZT1cImNvbC1zcGFuLThcIj5cbiAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwibWFpbi10eHQgdGV4dC00eGwgbGc6dGV4dC0zeGwgdGFibGV0OnRleHQtMnhsIG1kOnRleHQtMnhsIHNtOnRleHQteGwgZm9udC1ib2xkXCI+VmlzdCBvdXIgSW5kaWEgQWR2aXNvcnkgVGVhbSBPZmZpY2VzPC9oMT5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEyIFwiPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtc3Bhbi04XCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibWFwLWluZm8gYm9yZGVyLWItMiBtci01IHBiLTVcIj5cbiAgICAgICAgICAgICAgICA8YSBocmVmPVwiI1wiIGNsYXNzTmFtZT1cInVwcGVyY2FzZSBmb250LWJvbGQgdGV4dC14bCBib3JkZXItYi0zIGJiY1wiPkJhbmdhbG9yZTwvYT5cbiAgICAgICAgICAgICAgICA8aHIgY2xhc3NOYW1lPVwidW5kZXItbGluZVwiIC8+XG4gICAgICAgICAgICAgICAgPHA+MTk3LCA2dGggTWFpbiwgMXN0IENyb3NzIDxiciAvPiBIQUwgMm5kIFN0YWdlLCBJbmRpcmEgTmFnYXIgPGJyIC8+IEJlbmdhbHVydSA1NjAwMzggPGJyIC8+IDxiciAvPjxhIGhyZWY9XCJ0ZWw6KzkxLTgwLTI1MTk2MDAwXCI+KzkxLTgwLTI1MTk2MDAwPC9hPjwvcD5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZGlyZWN0aW9uLWxpbmtcIiA+R0VUIERJUkVDVElPTjwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC1zcGFuLTQgcmVsYXRpdmVcIj5cbiAgICAgICAgICAgICAgPGltZyBzcmM9XCIuLi8uLi9pbWcvaW1hZ2UgMjYucG5nXCIgYWx0PVwiXCIgLz5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1vdmVybGF5IFwiPjwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGhyIGNsYXNzTmFtZT1cImxpbmVcIiAvPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMTJcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLXNwYW4tOFwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1hcC1pbmZvIGJvcmRlci1iLTIgbXItNSBwYi01XCI+XG4gICAgICAgICAgICAgICAgPGEgaHJlZj1cIiNcIiBjbGFzc05hbWU9XCJ1cHBlcmNhc2UgZm9udC1ib2xkIHRleHQteGwgYm9yZGVyLWItMyBiYmNcIj5ERUxISTwvYT5cbiAgICAgICAgICAgICAgICA8aHIgY2xhc3NOYW1lPVwidW5kZXItbGluZVwiIC8+XG4gICAgICAgICAgICAgICAgPHA+NHRoIEZsb29yLCBBcmlhIFRvd2VycywgPGJyIC8+IEpXIE1hcnJpb3R0LCBBc3NldCBBcmVhIDQsIDxiciAvPiBBZXJvY2l0eSwgTmV3IERlbGhpLCAxMTAwMzcgPGJyIC8+IDxiciAvPjxhIGhyZWY9XCJ0ZWw6KzkxLTExLTQ5NDk1MDAwXCI+KzkxLTExLTQ5NDk1MDAwPC9hPjwvcD5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZGlyZWN0aW9uLWxpbmtcIiA+R0VUIERJUkVDVElPTjwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImNvbC1zcGFuLTQgcmVsYXRpdmVcIj5cbiAgICAgICAgICAgICAgPGltZyBzcmM9XCIuLi8uLi9pbWcvaW1hZ2UgMjYucG5nXCIgYWx0PVwiXCIgLz5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1vdmVybGF5IFwiPjwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGhyIGNsYXNzTmFtZT1cImxpbmVcIiAvPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZ3JpZCBncmlkLWNvbHMtMTJcIj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiY29sLXNwYW4tOFwiPlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1hcC1pbmZvIGJvcmRlci1iLTIgbXItNSBwYi01XCI+XG4gICAgICAgICAgICAgICAgPGEgaHJlZj1cIiNcIiBjbGFzc05hbWU9XCJ1cHBlcmNhc2UgZm9udC1ib2xkIHRleHQteGwgYm9yZGVyLWItMyBiYmNcIj5NVU1CQUk8L2E+XG4gICAgICAgICAgICAgICAgPGhyIGNsYXNzTmFtZT1cInVuZGVyLWxpbmVcIiAvPlxuICAgICAgICAgICAgICAgIDxwPjYwMS02MDIsIENlZWpheSBIb3VzZSwgPGJyIC8+IERyIEFubmllIEJlc2FudCBSb2FkLCBXb3JsaSwgIDxiciAvPiBNdW1iYWkgNDAwMDE4IDxiciAvPiA8YnIgLz48YSBocmVmPVwidGVsOis5MS0yMi02NzY4MDAwMFwiPis5MS0yMi02NzY4MDAwMDwvYT48L3A+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImRpcmVjdGlvbi1saW5rXCIgPkdFVCBESVJFQ1RJT048L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb2wtc3Bhbi00IHJlbGF0aXZlXCI+XG4gICAgICAgICAgICAgIDxpbWcgc3JjPVwiLi4vLi4vaW1nL2ltYWdlIDI2LnBuZ1wiIGFsdD1cIlwiIC8+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctb3ZlcmxheSBcIj48L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj4gKi99XG4gICAgICB7LyogPGRpdiBjbGFzc05hbWU9XCJjb2wtc3Bhbi00IFwiPlxuICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJtYWluLXR4dCB0ZXh0LTR4bCBsZzp0ZXh0LTN4bCB0YWJsZXQ6dGV4dC0yeGwgbWQ6dGV4dC0yeGwgc206dGV4dC14bCBmb250LWJvbGRcIj5TaGFyZSB5b3VyIEJ1c2luZXNzIFBsYW5zPC9oMT5cbiAgICAgICAgICA8Zm9ybSBjbGFzc05hbWU9J2NvbnRhY3QtZm9ybSc+XG4gICAgICAgICAgICA8bGFiZWwgPk5hbWU8L2xhYmVsPlxuICAgICAgICAgICAgPGlucHV0IHR5cGU9XCJ0ZXh0XCIgcGxhY2Vob2xkZXI9XCJOYW1lXCIgLz5cbiAgICAgICAgICAgIDxsYWJlbCA+Q29tcGFueSBOYW1lPC9sYWJlbD5cbiAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIHBsYWNlaG9sZGVyPVwiQ29tcGFueSBOYW1lXCIgLz5cbiAgICAgICAgICAgIDxsYWJlbCA+V2hhdCBhcmUgeW91IGJ1aWxkaW5nPzwvbGFiZWw+XG4gICAgICAgICAgICA8dGV4dGFyZWEgcGxhY2Vob2xkZXI9XCJDb21wYW55IEJyaWVmXCIgLz5cbiAgICAgICAgICAgIDxsYWJlbCA+RmlsZSBBdHRhY2htZW50PC9sYWJlbD5cbiAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwiZmlsZVwiIC8+XG4gICAgICAgICAgICA8bGFiZWwgPkVtYWlsIElkPC9sYWJlbD5cbiAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwiZW1haWxcIiBwbGFjZWhvbGRlcj1cIkNvbnRhY3QgRW1haWxcIiAvPlxuICAgICAgICAgICAgPGxhYmVsID5Nb2JpbGUgTnVtYmVyPC9sYWJlbD5cbiAgICAgICAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIHBsYWNlaG9sZGVyPVwiQ29udGFjdCBOdW1iZXJcIiAvPlxuICAgICAgICAgICAgPEJ1dHRvblxuICAgICAgICAgICAgICB0aXRsZT1cIkFwcGx5XCJcbiAgICAgICAgICAgICAgdXJsPVwiL2ljb25zL3JpZ2h0QXJyb3cuc3ZnXCJcbiAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gY29uc29sZS5sb2coXCJzdWJzY3JpYmVcIil9XG4gICAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtbGcgbGVhZGluZy02XCJcbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC9mb3JtPlxuICAgICAgICA8L2Rpdj4gKi99XG4gICAgICB7LyogPC9kaXY+ICovfVxuICAgIDwvZGl2PlxuICApXG59XG5leHBvcnQgZGVmYXVsdCBDb250YWN0Rm9ybTtcbiJdLCJzb3VyY2VSb290IjoiIn0=