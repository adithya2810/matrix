webpackHotUpdate_N_E("pages/home",{

/***/ "./src/components/founder/Founder.tsx":
/*!********************************************!*\
  !*** ./src/components/founder/Founder.tsx ***!
  \********************************************/
/*! exports provided: Founder */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Founder", function() { return Founder; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var C_Users_KARTHIK_Documents_workspace_matrix_cms_ui_development_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react-slick */ "./node_modules/react-slick/lib/index.js");
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react_slick__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! slick-carousel/slick/slick.css */ "./node_modules/slick-carousel/slick/slick.css");
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! slick-carousel/slick/slick-theme.css */ "./node_modules/slick-carousel/slick/slick-theme.css");
/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @components */ "./src/components/index.ts");



var _jsxFileName = "C:\\Users\\KARTHIK\\Documents\\workspace\\matrix-cms-ui-development\\src\\components\\founder\\Founder.tsx",
    _this = undefined;

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { Object(C_Users_KARTHIK_Documents_workspace_matrix_cms_ui_development_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__["default"])(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }






var Founder = function Founder(_ref) {
  var className = _ref.className,
      _ref$style = _ref.style,
      style = _ref$style === void 0 ? {} : _ref$style;
  var heros = [{
    firstName: 'Bhavish',
    lastName: 'AGGARWAL',
    firstName1: null,
    lastName1: null,
    caption: 'Mobility',
    caption1: 'Electric Cars',
    logo: '/icons/ola.svg',
    image: '/icons/Bhavish_image.svg',
    heading: ['We are', 'founders', 'first']
  }, {
    firstName: 'ROHIT',
    lastName: 'M.A.',
    firstName1: null,
    lastName1: null,
    caption: 'Healthcare',
    caption1: null,
    logo: '/icons/Cloudnine.svg',
    image: '/icons/Rohit_Treatment.svg',
    heading: ['We ', 'partner', 'closely']
  }, {
    firstName: 'ANINDYA',
    lastName: 'DUTTA',
    firstName1: 'SANDEEP',
    lastName1: 'DALMIA',
    caption: 'Student Housing Platform',
    caption1: null,
    logo: '/icons/Stanza.svg',
    image: '/icons/Anindya.svg',
    heading: ['We ', 'invest', 'early']
  }, {
    firstName: 'Asish',
    lastName: 'MOHAPATRA',
    firstName1: null,
    lastName1: null,
    caption: 'Fintech',
    caption1: 'SME Lending',
    logo: '/icons/OfBusiness.svg',
    image: '/icons/Asish.svg',
    heading: ['We', 'commit', 'personally']
  }, {
    firstName: 'Mr.',
    lastName: 'LAKSHIPATHY',
    firstName1: null,
    lastName1: null,
    caption: 'Fintech',
    caption1: 'NBFC',
    logo: '/icons/mx.svg',
    image: '/icons/Laxmipathy.svg',
    heading: ['We are', 'founders', 'first']
  }, {
    firstName: 'CHAKRADHAR',
    lastName: 'GADE',
    firstName1: 'NITIN',
    lastName1: 'KAUSHAL',
    caption: 'Fintech',
    caption1: 'NBFC',
    logo: '/icons/Country.svg',
    heading: ['We', 'commit', 'personally'],
    image: '/icons/Chakradhar.svg'
  }];
  var data = [{
    image_url: "/icons/content1.svg",
    title: "From both sides of the table : Kunal Bahl unplugged",
    author: "TARUN DAVDA",
    content_id: "abcdef",
    content_type: "blog",
    read_duration: "4 MIN"
  }, {
    image_url: "/icons/content1.svg",
    title: "From both sides of the table : Kunal Bahl unplugged",
    author: "TARUN DAVDA",
    content_id: "abcdefg",
    content_type: "blog",
    read_duration: "4 MIN"
  }];
  var settings = {
    dots: true,
    infinite: true,
    speed: 500,
    autoplaySpeed: 5000,
    slidesToShow: 1,
    slidesToScroll: 1 // autoplay: true

  };
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_slick__WEBPACK_IMPORTED_MODULE_3___default.a, _objectSpread(_objectSpread({}, settings), {}, {
    children: heros.map(function (hero) {
      return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "".concat(className),
          style: _objectSpread({
            width: 615.94,
            height: 863.91,
            position: "relative"
          }, style),
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "",
            style: {
              width: 571,
              height: 762,
              position: "absolute",
              background: "#083A4A",
              bottom: 50,
              left: 0
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 113,
            columnNumber: 13
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "",
            style: {
              width: 594,
              height: 788,
              bottom: 65,
              left: 15,
              position: "absolute",
              display: "flex",
              flexDirection: "column"
            },
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_6__["Image"], {
              src: hero.image,
              alt: "founder image",
              style: {
                flexGrow: 1
              }
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 115,
              columnNumber: 15
            }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_6__["Image"], {
              src: "/icons/rectangle.svg",
              alt: "reactangle",
              className: "absolute",
              style: {
                left: 38,
                bottom: 254
              }
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 116,
              columnNumber: 15
            }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              style: {
                height: 209,
                background: "#01576E"
              },
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "text-center flex items-center",
                style: {
                  height: 118,
                  borderBottom: "1px solid #EBEBE9"
                },
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h6", {
                  className: "font-bold text-secondary",
                  style: {
                    fontSize: 32,
                    lineHeight: "36px",
                    letterSpacing: "0.05em",
                    marginLeft: 31,
                    marginRight: 8
                  },
                  children: hero.firstName
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 120,
                  columnNumber: 19
                }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h6", {
                  className: "font-light text-secondary",
                  style: {
                    fontSize: 32,
                    lineHeight: "36px",
                    letterSpacing: "0.05em"
                  },
                  children: hero.lastName
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 123,
                  columnNumber: 19
                }, _this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 119,
                columnNumber: 17
              }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "flex justify-between items-center",
                style: {
                  height: 88
                },
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  style: {
                    marginLeft: 31,
                    display: 'flex',
                    justifyContent: 'space-around'
                  },
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                    className: "text-secondary font-medium text-lg leading-6",
                    children: [" ", hero.caption]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 130,
                    columnNumber: 21
                  }, _this), hero.caption1 && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                    className: "text-secondary font-medium text-lg leading-6",
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("hr", {
                      style: {
                        width: 30,
                        transform: 'rotate(90deg)'
                      }
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 131,
                      columnNumber: 102
                    }, _this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 131,
                    columnNumber: 39
                  }, _this), hero.caption1 && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                    className: "text-secondary font-medium text-lg leading-6",
                    children: [" ", hero.caption1]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 132,
                    columnNumber: 39
                  }, _this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 129,
                  columnNumber: 19
                }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_6__["Image"], {
                  src: hero.logo,
                  alt: "ola",
                  style: {
                    marginRight: 57
                  }
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 134,
                  columnNumber: 19
                }, _this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 128,
                columnNumber: 17
              }, _this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 118,
              columnNumber: 15
            }, _this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 114,
            columnNumber: 13
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "",
            style: {
              left: 760,
              position: "absolute"
            },
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
              className: "slide-header",
              children: [hero.heading[0], /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                style: {
                  color: '#01576E'
                },
                children: [" ", hero.heading[1], " "]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 140,
                columnNumber: 60
              }, _this), " ", hero.heading[2]]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 140,
              columnNumber: 15
            }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_6__["ContentSlider"], {
                style: {
                  left: 325,
                  background: "#EBEBE9",
                  border: "1px solid #EBEBE9",
                  boxSizing: "border-box",
                  fontSize: 28,
                  lineHeight: "34px",
                  paddingTop: 24,
                  paddingLeft: 34
                },
                contentList: data,
                className: "absolute bottom-0 right-0 text-primary-dark",
                header: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                  children: ["Dive into the ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                    className: "text-accent",
                    children: "Matrix Moments"
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 155,
                    columnNumber: 47
                  }, _this), " series"]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 155,
                  columnNumber: 27
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 142,
                columnNumber: 17
              }, _this)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 141,
              columnNumber: 15
            }, _this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 139,
            columnNumber: 13
          }, _this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 112,
          columnNumber: 11
        }, _this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 111,
        columnNumber: 17
      }, _this);
    })
  }), void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 109,
    columnNumber: 5
  }, _this);
};
_c = Founder;

var _c;

$RefreshReg$(_c, "Founder");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vc3JjL2NvbXBvbmVudHMvZm91bmRlci9Gb3VuZGVyLnRzeCJdLCJuYW1lcyI6WyJGb3VuZGVyIiwiY2xhc3NOYW1lIiwic3R5bGUiLCJoZXJvcyIsImZpcnN0TmFtZSIsImxhc3ROYW1lIiwiZmlyc3ROYW1lMSIsImxhc3ROYW1lMSIsImNhcHRpb24iLCJjYXB0aW9uMSIsImxvZ28iLCJpbWFnZSIsImhlYWRpbmciLCJkYXRhIiwiaW1hZ2VfdXJsIiwidGl0bGUiLCJhdXRob3IiLCJjb250ZW50X2lkIiwiY29udGVudF90eXBlIiwicmVhZF9kdXJhdGlvbiIsInNldHRpbmdzIiwiZG90cyIsImluZmluaXRlIiwic3BlZWQiLCJhdXRvcGxheVNwZWVkIiwic2xpZGVzVG9TaG93Iiwic2xpZGVzVG9TY3JvbGwiLCJtYXAiLCJoZXJvIiwid2lkdGgiLCJoZWlnaHQiLCJwb3NpdGlvbiIsImJhY2tncm91bmQiLCJib3R0b20iLCJsZWZ0IiwiZGlzcGxheSIsImZsZXhEaXJlY3Rpb24iLCJmbGV4R3JvdyIsImJvcmRlckJvdHRvbSIsImZvbnRTaXplIiwibGluZUhlaWdodCIsImxldHRlclNwYWNpbmciLCJtYXJnaW5MZWZ0IiwibWFyZ2luUmlnaHQiLCJqdXN0aWZ5Q29udGVudCIsInRyYW5zZm9ybSIsImNvbG9yIiwiYm9yZGVyIiwiYm94U2l6aW5nIiwicGFkZGluZ1RvcCIsInBhZGRpbmdMZWZ0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQVdPLElBQU1BLE9BQXdCLEdBQUcsU0FBM0JBLE9BQTJCLE9BQStCO0FBQUEsTUFBNUJDLFNBQTRCLFFBQTVCQSxTQUE0QjtBQUFBLHdCQUFqQkMsS0FBaUI7QUFBQSxNQUFqQkEsS0FBaUIsMkJBQVQsRUFBUztBQUNyRSxNQUFNQyxLQUFLLEdBQUcsQ0FBQztBQUNiQyxhQUFTLEVBQUUsU0FERTtBQUViQyxZQUFRLEVBQUUsVUFGRztBQUdiQyxjQUFVLEVBQUUsSUFIQztBQUliQyxhQUFTLEVBQUUsSUFKRTtBQUtiQyxXQUFPLEVBQUUsVUFMSTtBQU1iQyxZQUFRLEVBQUUsZUFORztBQU9iQyxRQUFJLEVBQUUsZ0JBUE87QUFRYkMsU0FBSyxFQUFFLDBCQVJNO0FBU2JDLFdBQU8sRUFBRSxDQUFDLFFBQUQsRUFBVyxVQUFYLEVBQXVCLE9BQXZCO0FBVEksR0FBRCxFQVVYO0FBQ0RSLGFBQVMsRUFBRSxPQURWO0FBRURDLFlBQVEsRUFBRSxNQUZUO0FBR0RDLGNBQVUsRUFBRSxJQUhYO0FBSURDLGFBQVMsRUFBRSxJQUpWO0FBS0RDLFdBQU8sRUFBRSxZQUxSO0FBTURDLFlBQVEsRUFBRSxJQU5UO0FBT0RDLFFBQUksRUFBRSxzQkFQTDtBQVFEQyxTQUFLLEVBQUUsNEJBUk47QUFTREMsV0FBTyxFQUFFLENBQUMsS0FBRCxFQUFRLFNBQVIsRUFBbUIsU0FBbkI7QUFUUixHQVZXLEVBb0JYO0FBQ0RSLGFBQVMsRUFBRSxTQURWO0FBRURDLFlBQVEsRUFBRSxPQUZUO0FBR0RDLGNBQVUsRUFBRSxTQUhYO0FBSURDLGFBQVMsRUFBRSxRQUpWO0FBS0RDLFdBQU8sRUFBRSwwQkFMUjtBQU1EQyxZQUFRLEVBQUUsSUFOVDtBQU9EQyxRQUFJLEVBQUUsbUJBUEw7QUFRREMsU0FBSyxFQUFFLG9CQVJOO0FBU0RDLFdBQU8sRUFBRSxDQUFDLEtBQUQsRUFBUSxRQUFSLEVBQWtCLE9BQWxCO0FBVFIsR0FwQlcsRUE4Qlg7QUFDRFIsYUFBUyxFQUFFLE9BRFY7QUFFREMsWUFBUSxFQUFFLFdBRlQ7QUFHREMsY0FBVSxFQUFFLElBSFg7QUFJREMsYUFBUyxFQUFFLElBSlY7QUFLREMsV0FBTyxFQUFFLFNBTFI7QUFNREMsWUFBUSxFQUFFLGFBTlQ7QUFPREMsUUFBSSxFQUFFLHVCQVBMO0FBUURDLFNBQUssRUFBRSxrQkFSTjtBQVNEQyxXQUFPLEVBQUUsQ0FBQyxJQUFELEVBQU8sUUFBUCxFQUFpQixZQUFqQjtBQVRSLEdBOUJXLEVBd0NYO0FBQ0RSLGFBQVMsRUFBRSxLQURWO0FBRURDLFlBQVEsRUFBRSxhQUZUO0FBR0RDLGNBQVUsRUFBRSxJQUhYO0FBSURDLGFBQVMsRUFBRSxJQUpWO0FBS0RDLFdBQU8sRUFBRSxTQUxSO0FBTURDLFlBQVEsRUFBRSxNQU5UO0FBT0RDLFFBQUksRUFBRSxlQVBMO0FBUURDLFNBQUssRUFBRSx1QkFSTjtBQVNEQyxXQUFPLEVBQUUsQ0FBQyxRQUFELEVBQVcsVUFBWCxFQUF1QixPQUF2QjtBQVRSLEdBeENXLEVBa0RYO0FBQ0RSLGFBQVMsRUFBRSxZQURWO0FBRURDLFlBQVEsRUFBRSxNQUZUO0FBR0RDLGNBQVUsRUFBRSxPQUhYO0FBSURDLGFBQVMsRUFBRSxTQUpWO0FBS0RDLFdBQU8sRUFBRSxTQUxSO0FBTURDLFlBQVEsRUFBRSxNQU5UO0FBT0RDLFFBQUksRUFBRSxvQkFQTDtBQVFERSxXQUFPLEVBQUUsQ0FBQyxJQUFELEVBQU8sUUFBUCxFQUFpQixZQUFqQixDQVJSO0FBU0RELFNBQUssRUFBRTtBQVROLEdBbERXLENBQWQ7QUE4REEsTUFBTUUsSUFBSSxHQUFHLENBQ1g7QUFDRUMsYUFBUyxFQUFFLHFCQURiO0FBRUVDLFNBQUssRUFBRSxxREFGVDtBQUdFQyxVQUFNLEVBQUUsYUFIVjtBQUlFQyxjQUFVLEVBQUUsUUFKZDtBQUtFQyxnQkFBWSxFQUFFLE1BTGhCO0FBTUVDLGlCQUFhLEVBQUU7QUFOakIsR0FEVyxFQVNYO0FBQ0VMLGFBQVMsRUFBRSxxQkFEYjtBQUVFQyxTQUFLLEVBQUUscURBRlQ7QUFHRUMsVUFBTSxFQUFFLGFBSFY7QUFJRUMsY0FBVSxFQUFFLFNBSmQ7QUFLRUMsZ0JBQVksRUFBRSxNQUxoQjtBQU1FQyxpQkFBYSxFQUFFO0FBTmpCLEdBVFcsQ0FBYjtBQW9CQSxNQUFNQyxRQUFRLEdBQUc7QUFDZkMsUUFBSSxFQUFFLElBRFM7QUFFZkMsWUFBUSxFQUFFLElBRks7QUFHZkMsU0FBSyxFQUFFLEdBSFE7QUFJZkMsaUJBQWEsRUFBRSxJQUpBO0FBS2ZDLGdCQUFZLEVBQUUsQ0FMQztBQU1mQyxrQkFBYyxFQUFFLENBTkQsQ0FPZjs7QUFQZSxHQUFqQjtBQVNBLHNCQUNFLHFFQUFDLGtEQUFELGtDQUFZTixRQUFaO0FBQUEsY0FDR2pCLEtBQUssQ0FBQ3dCLEdBQU4sQ0FBVSxVQUFBQyxJQUFJLEVBQUk7QUFDakIsMEJBQVE7QUFBQSwrQkFDTjtBQUFLLG1CQUFTLFlBQUszQixTQUFMLENBQWQ7QUFBZ0MsZUFBSztBQUFJNEIsaUJBQUssRUFBRSxNQUFYO0FBQW1CQyxrQkFBTSxFQUFFLE1BQTNCO0FBQW1DQyxvQkFBUSxFQUFFO0FBQTdDLGFBQTREN0IsS0FBNUQsQ0FBckM7QUFBQSxrQ0FDRTtBQUFLLHFCQUFTLEVBQUMsRUFBZjtBQUFrQixpQkFBSyxFQUFFO0FBQUUyQixtQkFBSyxFQUFFLEdBQVQ7QUFBY0Msb0JBQU0sRUFBRSxHQUF0QjtBQUEyQkMsc0JBQVEsRUFBRSxVQUFyQztBQUFpREMsd0JBQVUsRUFBRSxTQUE3RDtBQUF3RUMsb0JBQU0sRUFBRSxFQUFoRjtBQUFvRkMsa0JBQUksRUFBRTtBQUExRjtBQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURGLGVBRUU7QUFBSyxxQkFBUyxFQUFDLEVBQWY7QUFBa0IsaUJBQUssRUFBRTtBQUFFTCxtQkFBSyxFQUFFLEdBQVQ7QUFBY0Msb0JBQU0sRUFBRSxHQUF0QjtBQUEyQkcsb0JBQU0sRUFBRSxFQUFuQztBQUF1Q0Msa0JBQUksRUFBRSxFQUE3QztBQUFpREgsc0JBQVEsRUFBRSxVQUEzRDtBQUF1RUkscUJBQU8sRUFBRSxNQUFoRjtBQUF3RkMsMkJBQWEsRUFBRTtBQUF2RyxhQUF6QjtBQUFBLG9DQUNFLHFFQUFDLGlEQUFEO0FBQU8saUJBQUcsRUFBRVIsSUFBSSxDQUFDakIsS0FBakI7QUFBd0IsaUJBQUcsRUFBQyxlQUE1QjtBQUE0QyxtQkFBSyxFQUFFO0FBQUUwQix3QkFBUSxFQUFFO0FBQVo7QUFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFERixlQUVFLHFFQUFDLGlEQUFEO0FBQU8saUJBQUcsRUFBQyxzQkFBWDtBQUFrQyxpQkFBRyxFQUFFLFlBQXZDO0FBQXFELHVCQUFTLEVBQUMsVUFBL0Q7QUFBMEUsbUJBQUssRUFBRTtBQUFFSCxvQkFBSSxFQUFFLEVBQVI7QUFBWUQsc0JBQU0sRUFBRTtBQUFwQjtBQUFqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUZGLGVBSUU7QUFBSyxtQkFBSyxFQUFFO0FBQUVILHNCQUFNLEVBQUUsR0FBVjtBQUFlRSwwQkFBVSxFQUFFO0FBQTNCLGVBQVo7QUFBQSxzQ0FDRTtBQUFLLHlCQUFTLEVBQUMsK0JBQWY7QUFBK0MscUJBQUssRUFBRTtBQUFFRix3QkFBTSxFQUFFLEdBQVY7QUFBZVEsOEJBQVksRUFBRTtBQUE3QixpQkFBdEQ7QUFBQSx3Q0FDRTtBQUFJLDJCQUFTLEVBQUMsMEJBQWQ7QUFBeUMsdUJBQUssRUFBRTtBQUFFQyw0QkFBUSxFQUFFLEVBQVo7QUFBZ0JDLDhCQUFVLEVBQUUsTUFBNUI7QUFBb0NDLGlDQUFhLEVBQUUsUUFBbkQ7QUFBNkRDLDhCQUFVLEVBQUUsRUFBekU7QUFBNkVDLCtCQUFXLEVBQUU7QUFBMUYsbUJBQWhEO0FBQUEsNEJBQ0dmLElBQUksQ0FBQ3hCO0FBRFI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFERixlQUlFO0FBQUksMkJBQVMsRUFBQywyQkFBZDtBQUEwQyx1QkFBSyxFQUFFO0FBQUVtQyw0QkFBUSxFQUFFLEVBQVo7QUFBZ0JDLDhCQUFVLEVBQUUsTUFBNUI7QUFBb0NDLGlDQUFhLEVBQUU7QUFBbkQsbUJBQWpEO0FBQUEsNEJBQ0diLElBQUksQ0FBQ3ZCO0FBRFI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBREYsZUFVRTtBQUFLLHlCQUFTLEVBQUMsbUNBQWY7QUFBbUQscUJBQUssRUFBRTtBQUFFeUIsd0JBQU0sRUFBRTtBQUFWLGlCQUExRDtBQUFBLHdDQUNFO0FBQUssdUJBQUssRUFBRTtBQUFFWSw4QkFBVSxFQUFFLEVBQWQ7QUFBa0JQLDJCQUFPLEVBQUUsTUFBM0I7QUFBbUNTLGtDQUFjLEVBQUU7QUFBbkQsbUJBQVo7QUFBQSwwQ0FDRTtBQUFNLDZCQUFTLEVBQUMsOENBQWhCO0FBQUEsb0NBQWlFaEIsSUFBSSxDQUFDcEIsT0FBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQURGLEVBRUdvQixJQUFJLENBQUNuQixRQUFMLGlCQUFpQjtBQUFNLDZCQUFTLEVBQUMsOENBQWhCO0FBQUEsMkNBQStEO0FBQUksMkJBQUssRUFBRTtBQUFFb0IsNkJBQUssRUFBRSxFQUFUO0FBQWFnQixpQ0FBUyxFQUFFO0FBQXhCO0FBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUZwQixFQUdHakIsSUFBSSxDQUFDbkIsUUFBTCxpQkFBaUI7QUFBTSw2QkFBUyxFQUFDLDhDQUFoQjtBQUFBLG9DQUFpRW1CLElBQUksQ0FBQ25CLFFBQXRFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFIcEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQURGLGVBTUUscUVBQUMsaURBQUQ7QUFBTyxxQkFBRyxFQUFFbUIsSUFBSSxDQUFDbEIsSUFBakI7QUFBdUIscUJBQUcsRUFBRSxLQUE1QjtBQUFtQyx1QkFBSyxFQUFFO0FBQUVpQywrQkFBVyxFQUFFO0FBQWY7QUFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFORjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFGRixlQTJCRTtBQUFLLHFCQUFTLEVBQUMsRUFBZjtBQUFrQixpQkFBSyxFQUFFO0FBQUVULGtCQUFJLEVBQUUsR0FBUjtBQUFhSCxzQkFBUSxFQUFFO0FBQXZCLGFBQXpCO0FBQUEsb0NBQ0U7QUFBRyx1QkFBUyxFQUFDLGNBQWI7QUFBQSx5QkFBNkJILElBQUksQ0FBQ2hCLE9BQUwsQ0FBYSxDQUFiLENBQTdCLGVBQTZDO0FBQU0scUJBQUssRUFBRTtBQUFFa0MsdUJBQUssRUFBRTtBQUFULGlCQUFiO0FBQUEsZ0NBQXFDbEIsSUFBSSxDQUFDaEIsT0FBTCxDQUFhLENBQWIsQ0FBckM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUE3QyxPQUE0R2dCLElBQUksQ0FBQ2hCLE9BQUwsQ0FBYSxDQUFiLENBQTVHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFERixlQUVFO0FBQUEscUNBQ0UscUVBQUMseURBQUQ7QUFDRSxxQkFBSyxFQUFFO0FBQ0xzQixzQkFBSSxFQUFFLEdBREQ7QUFFTEYsNEJBQVUsRUFBRSxTQUZQO0FBR0xlLHdCQUFNLEVBQUUsbUJBSEg7QUFJTEMsMkJBQVMsRUFBRSxZQUpOO0FBS0xULDBCQUFRLEVBQUUsRUFMTDtBQU1MQyw0QkFBVSxFQUFFLE1BTlA7QUFPTFMsNEJBQVUsRUFBRSxFQVBQO0FBUUxDLDZCQUFXLEVBQUU7QUFSUixpQkFEVDtBQVdFLDJCQUFXLEVBQUVyQyxJQVhmO0FBWUUseUJBQVMsRUFBQyw2Q0FaWjtBQWFFLHNCQUFNLGVBQUU7QUFBQSw0REFBb0I7QUFBTSw2QkFBUyxFQUFDLGFBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUFwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFiVjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBM0JGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURNO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBUjtBQWtERCxLQW5EQTtBQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FERjtBQTRERCxDQXhKTTtLQUFNYixPIiwiZmlsZSI6InN0YXRpYy93ZWJwYWNrL3BhZ2VzL2hvbWUuNGI2YzBhMGY2NDFmMWUzNDQ4ZjAuaG90LXVwZGF0ZS5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCBTbGlkZXIgZnJvbSBcInJlYWN0LXNsaWNrXCI7XG5pbXBvcnQgXCJzbGljay1jYXJvdXNlbC9zbGljay9zbGljay5jc3NcIjtcbmltcG9ydCBcInNsaWNrLWNhcm91c2VsL3NsaWNrL3NsaWNrLXRoZW1lLmNzc1wiO1xuaW1wb3J0IHsgSW1hZ2UsIENvbnRlbnRTbGlkZXIgfSBmcm9tIFwiQGNvbXBvbmVudHNcIjtcblxuZXhwb3J0IHR5cGUgUHJvcHMgPSB7XG4gIG5hbWVzPzogQXJyYXk8c3RyaW5nPjtcbiAgYmFja2dyb3VuZF91cmw/OiBzdHJpbmc7XG4gIHRhZ3M/OiBBcnJheTxzdHJpbmc+O1xuICBsb2dvPzogc3RyaW5nO1xuICBjbGFzc05hbWU/OiBzdHJpbmc7XG4gIHN0eWxlPzogYW55O1xufTtcblxuZXhwb3J0IGNvbnN0IEZvdW5kZXI6IFJlYWN0LkZDPFByb3BzPiA9ICh7IGNsYXNzTmFtZSwgc3R5bGUgPSB7fSB9KSA9PiB7XG4gIGNvbnN0IGhlcm9zID0gW3tcbiAgICBmaXJzdE5hbWU6ICdCaGF2aXNoJyxcbiAgICBsYXN0TmFtZTogJ0FHR0FSV0FMJyxcbiAgICBmaXJzdE5hbWUxOiBudWxsLFxuICAgIGxhc3ROYW1lMTogbnVsbCxcbiAgICBjYXB0aW9uOiAnTW9iaWxpdHknLFxuICAgIGNhcHRpb24xOiAnRWxlY3RyaWMgQ2FycycsXG4gICAgbG9nbzogJy9pY29ucy9vbGEuc3ZnJyxcbiAgICBpbWFnZTogJy9pY29ucy9CaGF2aXNoX2ltYWdlLnN2ZycsXG4gICAgaGVhZGluZzogWydXZSBhcmUnLCAnZm91bmRlcnMnLCAnZmlyc3QnXVxuICB9LCB7XG4gICAgZmlyc3ROYW1lOiAnUk9ISVQnLFxuICAgIGxhc3ROYW1lOiAnTS5BLicsXG4gICAgZmlyc3ROYW1lMTogbnVsbCxcbiAgICBsYXN0TmFtZTE6IG51bGwsXG4gICAgY2FwdGlvbjogJ0hlYWx0aGNhcmUnLFxuICAgIGNhcHRpb24xOiBudWxsLFxuICAgIGxvZ286ICcvaWNvbnMvQ2xvdWRuaW5lLnN2ZycsXG4gICAgaW1hZ2U6ICcvaWNvbnMvUm9oaXRfVHJlYXRtZW50LnN2ZycsXG4gICAgaGVhZGluZzogWydXZSAnLCAncGFydG5lcicsICdjbG9zZWx5J11cbiAgfSwge1xuICAgIGZpcnN0TmFtZTogJ0FOSU5EWUEnLFxuICAgIGxhc3ROYW1lOiAnRFVUVEEnLFxuICAgIGZpcnN0TmFtZTE6ICdTQU5ERUVQJyxcbiAgICBsYXN0TmFtZTE6ICdEQUxNSUEnLFxuICAgIGNhcHRpb246ICdTdHVkZW50IEhvdXNpbmcgUGxhdGZvcm0nLFxuICAgIGNhcHRpb24xOiBudWxsLFxuICAgIGxvZ286ICcvaWNvbnMvU3RhbnphLnN2ZycsXG4gICAgaW1hZ2U6ICcvaWNvbnMvQW5pbmR5YS5zdmcnLFxuICAgIGhlYWRpbmc6IFsnV2UgJywgJ2ludmVzdCcsICdlYXJseSddXG4gIH0sIHtcbiAgICBmaXJzdE5hbWU6ICdBc2lzaCcsXG4gICAgbGFzdE5hbWU6ICdNT0hBUEFUUkEnLFxuICAgIGZpcnN0TmFtZTE6IG51bGwsXG4gICAgbGFzdE5hbWUxOiBudWxsLFxuICAgIGNhcHRpb246ICdGaW50ZWNoJyxcbiAgICBjYXB0aW9uMTogJ1NNRSBMZW5kaW5nJyxcbiAgICBsb2dvOiAnL2ljb25zL09mQnVzaW5lc3Muc3ZnJyxcbiAgICBpbWFnZTogJy9pY29ucy9Bc2lzaC5zdmcnLFxuICAgIGhlYWRpbmc6IFsnV2UnLCAnY29tbWl0JywgJ3BlcnNvbmFsbHknXVxuICB9LCB7XG4gICAgZmlyc3ROYW1lOiAnTXIuJyxcbiAgICBsYXN0TmFtZTogJ0xBS1NISVBBVEhZJyxcbiAgICBmaXJzdE5hbWUxOiBudWxsLFxuICAgIGxhc3ROYW1lMTogbnVsbCxcbiAgICBjYXB0aW9uOiAnRmludGVjaCcsXG4gICAgY2FwdGlvbjE6ICdOQkZDJyxcbiAgICBsb2dvOiAnL2ljb25zL214LnN2ZycsXG4gICAgaW1hZ2U6ICcvaWNvbnMvTGF4bWlwYXRoeS5zdmcnLFxuICAgIGhlYWRpbmc6IFsnV2UgYXJlJywgJ2ZvdW5kZXJzJywgJ2ZpcnN0J11cbiAgfSwge1xuICAgIGZpcnN0TmFtZTogJ0NIQUtSQURIQVInLFxuICAgIGxhc3ROYW1lOiAnR0FERScsXG4gICAgZmlyc3ROYW1lMTogJ05JVElOJyxcbiAgICBsYXN0TmFtZTE6ICdLQVVTSEFMJyxcbiAgICBjYXB0aW9uOiAnRmludGVjaCcsXG4gICAgY2FwdGlvbjE6ICdOQkZDJyxcbiAgICBsb2dvOiAnL2ljb25zL0NvdW50cnkuc3ZnJyxcbiAgICBoZWFkaW5nOiBbJ1dlJywgJ2NvbW1pdCcsICdwZXJzb25hbGx5J10sXG4gICAgaW1hZ2U6ICcvaWNvbnMvQ2hha3JhZGhhci5zdmcnXG4gIH1dXG5cbiAgY29uc3QgZGF0YSA9IFtcbiAgICB7XG4gICAgICBpbWFnZV91cmw6IFwiL2ljb25zL2NvbnRlbnQxLnN2Z1wiLFxuICAgICAgdGl0bGU6IFwiRnJvbSBib3RoIHNpZGVzIG9mIHRoZSB0YWJsZSA6IEt1bmFsIEJhaGwgdW5wbHVnZ2VkXCIsXG4gICAgICBhdXRob3I6IFwiVEFSVU4gREFWREFcIixcbiAgICAgIGNvbnRlbnRfaWQ6IFwiYWJjZGVmXCIsXG4gICAgICBjb250ZW50X3R5cGU6IFwiYmxvZ1wiLFxuICAgICAgcmVhZF9kdXJhdGlvbjogXCI0IE1JTlwiLFxuICAgIH0sXG4gICAge1xuICAgICAgaW1hZ2VfdXJsOiBcIi9pY29ucy9jb250ZW50MS5zdmdcIixcbiAgICAgIHRpdGxlOiBcIkZyb20gYm90aCBzaWRlcyBvZiB0aGUgdGFibGUgOiBLdW5hbCBCYWhsIHVucGx1Z2dlZFwiLFxuICAgICAgYXV0aG9yOiBcIlRBUlVOIERBVkRBXCIsXG4gICAgICBjb250ZW50X2lkOiBcImFiY2RlZmdcIixcbiAgICAgIGNvbnRlbnRfdHlwZTogXCJibG9nXCIsXG4gICAgICByZWFkX2R1cmF0aW9uOiBcIjQgTUlOXCIsXG4gICAgfSxcblxuICBdO1xuXG4gIGNvbnN0IHNldHRpbmdzID0ge1xuICAgIGRvdHM6IHRydWUsXG4gICAgaW5maW5pdGU6IHRydWUsXG4gICAgc3BlZWQ6IDUwMCxcbiAgICBhdXRvcGxheVNwZWVkOiA1MDAwLFxuICAgIHNsaWRlc1RvU2hvdzogMSxcbiAgICBzbGlkZXNUb1Njcm9sbDogMSxcbiAgICAvLyBhdXRvcGxheTogdHJ1ZVxuICB9O1xuICByZXR1cm4gKFxuICAgIDxTbGlkZXIgey4uLnNldHRpbmdzfT5cbiAgICAgIHtoZXJvcy5tYXAoaGVybyA9PiB7XG4gICAgICAgIHJldHVybiAoPGRpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YCR7Y2xhc3NOYW1lfWB9IHN0eWxlPXt7IHdpZHRoOiA2MTUuOTQsIGhlaWdodDogODYzLjkxLCBwb3NpdGlvbjogXCJyZWxhdGl2ZVwiLCAuLi5zdHlsZSwgfX0+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIlwiIHN0eWxlPXt7IHdpZHRoOiA1NzEsIGhlaWdodDogNzYyLCBwb3NpdGlvbjogXCJhYnNvbHV0ZVwiLCBiYWNrZ3JvdW5kOiBcIiMwODNBNEFcIiwgYm90dG9tOiA1MCwgbGVmdDogMCwgfX0+PC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIlwiIHN0eWxlPXt7IHdpZHRoOiA1OTQsIGhlaWdodDogNzg4LCBib3R0b206IDY1LCBsZWZ0OiAxNSwgcG9zaXRpb246IFwiYWJzb2x1dGVcIiwgZGlzcGxheTogXCJmbGV4XCIsIGZsZXhEaXJlY3Rpb246IFwiY29sdW1uXCIsIH19PlxuICAgICAgICAgICAgICA8SW1hZ2Ugc3JjPXtoZXJvLmltYWdlfSBhbHQ9XCJmb3VuZGVyIGltYWdlXCIgc3R5bGU9e3sgZmxleEdyb3c6IDEgfX0+PC9JbWFnZT5cbiAgICAgICAgICAgICAgPEltYWdlIHNyYz1cIi9pY29ucy9yZWN0YW5nbGUuc3ZnXCIgYWx0PXtcInJlYWN0YW5nbGVcIn0gY2xhc3NOYW1lPVwiYWJzb2x1dGVcIiBzdHlsZT17eyBsZWZ0OiAzOCwgYm90dG9tOiAyNTQgfX0gLz5cblxuICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGhlaWdodDogMjA5LCBiYWNrZ3JvdW5kOiBcIiMwMTU3NkVcIiB9fT5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIGZsZXggaXRlbXMtY2VudGVyXCIgc3R5bGU9e3sgaGVpZ2h0OiAxMTgsIGJvcmRlckJvdHRvbTogXCIxcHggc29saWQgI0VCRUJFOVwiIH19PlxuICAgICAgICAgICAgICAgICAgPGg2IGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNlY29uZGFyeVwiIHN0eWxlPXt7IGZvbnRTaXplOiAzMiwgbGluZUhlaWdodDogXCIzNnB4XCIsIGxldHRlclNwYWNpbmc6IFwiMC4wNWVtXCIsIG1hcmdpbkxlZnQ6IDMxLCBtYXJnaW5SaWdodDogOCwgfX0+XG4gICAgICAgICAgICAgICAgICAgIHtoZXJvLmZpcnN0TmFtZX1cbiAgICAgICAgICAgICAgICAgIDwvaDY+XG4gICAgICAgICAgICAgICAgICA8aDYgY2xhc3NOYW1lPVwiZm9udC1saWdodCB0ZXh0LXNlY29uZGFyeVwiIHN0eWxlPXt7IGZvbnRTaXplOiAzMiwgbGluZUhlaWdodDogXCIzNnB4XCIsIGxldHRlclNwYWNpbmc6IFwiMC4wNWVtXCIsIH19PlxuICAgICAgICAgICAgICAgICAgICB7aGVyby5sYXN0TmFtZX1cbiAgICAgICAgICAgICAgICAgIDwvaDY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlclwiIHN0eWxlPXt7IGhlaWdodDogODggfX0+XG4gICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IG1hcmdpbkxlZnQ6IDMxLCBkaXNwbGF5OiAnZmxleCcsIGp1c3RpZnlDb250ZW50OiAnc3BhY2UtYXJvdW5kJyB9fT5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zZWNvbmRhcnkgZm9udC1tZWRpdW0gdGV4dC1sZyBsZWFkaW5nLTZcIj4ge2hlcm8uY2FwdGlvbn08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIHtoZXJvLmNhcHRpb24xICYmIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2Vjb25kYXJ5IGZvbnQtbWVkaXVtIHRleHQtbGcgbGVhZGluZy02XCI+PGhyIHN0eWxlPXt7IHdpZHRoOiAzMCwgdHJhbnNmb3JtOiAncm90YXRlKDkwZGVnKScgfX0gLz48L3NwYW4+fVxuICAgICAgICAgICAgICAgICAgICB7aGVyby5jYXB0aW9uMSAmJiA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNlY29uZGFyeSBmb250LW1lZGl1bSB0ZXh0LWxnIGxlYWRpbmctNlwiPiB7aGVyby5jYXB0aW9uMX08L3NwYW4+fVxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8SW1hZ2Ugc3JjPXtoZXJvLmxvZ299IGFsdD17XCJvbGFcIn0gc3R5bGU9e3sgbWFyZ2luUmlnaHQ6IDU3IH19IC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiXCIgc3R5bGU9e3sgbGVmdDogNzYwLCBwb3NpdGlvbjogXCJhYnNvbHV0ZVwiIH19PlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9J3NsaWRlLWhlYWRlcic+e2hlcm8uaGVhZGluZ1swXX08c3BhbiBzdHlsZT17eyBjb2xvcjogJyMwMTU3NkUnIH19PiB7aGVyby5oZWFkaW5nWzFdfSA8L3NwYW4+IHtoZXJvLmhlYWRpbmdbMl19PC9wPlxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIDxDb250ZW50U2xpZGVyXG4gICAgICAgICAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgICAgICAgICBsZWZ0OiAzMjUsXG4gICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6IFwiI0VCRUJFOVwiLFxuICAgICAgICAgICAgICAgICAgICBib3JkZXI6IFwiMXB4IHNvbGlkICNFQkVCRTlcIixcbiAgICAgICAgICAgICAgICAgICAgYm94U2l6aW5nOiBcImJvcmRlci1ib3hcIixcbiAgICAgICAgICAgICAgICAgICAgZm9udFNpemU6IDI4LFxuICAgICAgICAgICAgICAgICAgICBsaW5lSGVpZ2h0OiBcIjM0cHhcIixcbiAgICAgICAgICAgICAgICAgICAgcGFkZGluZ1RvcDogMjQsXG4gICAgICAgICAgICAgICAgICAgIHBhZGRpbmdMZWZ0OiAzNCxcbiAgICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgICBjb250ZW50TGlzdD17ZGF0YX1cbiAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImFic29sdXRlIGJvdHRvbS0wIHJpZ2h0LTAgdGV4dC1wcmltYXJ5LWRhcmtcIlxuICAgICAgICAgICAgICAgICAgaGVhZGVyPXs8c3Bhbj5EaXZlIGludG8gdGhlIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtYWNjZW50XCI+TWF0cml4IE1vbWVudHM8L3NwYW4+IHNlcmllczwvc3Bhbj59XG4gICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+KVxuICAgICAgfSl9XG5cblxuXG5cbiAgICA8L1NsaWRlcj5cbiAgKTtcbn07XG4iXSwic291cmNlUm9vdCI6IiJ9