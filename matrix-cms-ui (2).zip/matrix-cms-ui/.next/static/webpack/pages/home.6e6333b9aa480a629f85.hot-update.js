webpackHotUpdate_N_E("pages/home",{

/***/ "./node_modules/next/dist/compiled/css-loader/cjs.js?!./node_modules/next/dist/compiled/postcss-loader/cjs.js?!./node_modules/slick-carousel/slick/slick-theme.css":
/*!***********************************************************************************************************************************************************!*\
  !*** (webpack)/css-loader/cjs.js??ref--5-oneOf-5-1!(webpack)/postcss-loader/cjs.js??ref--5-oneOf-5-2!./node_modules/slick-carousel/slick/slick-theme.css ***!
  \***********************************************************************************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _next_dist_compiled_css_loader_api_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../next/dist/compiled/css-loader/api.js */ "./node_modules/next/dist/compiled/css-loader/api.js");
/* harmony import */ var _next_dist_compiled_css_loader_api_js__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_next_dist_compiled_css_loader_api_js__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _next_dist_compiled_css_loader_getUrl_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../../next/dist/compiled/css-loader/getUrl.js */ "./node_modules/next/dist/compiled/css-loader/getUrl.js");
/* harmony import */ var _next_dist_compiled_css_loader_getUrl_js__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_next_dist_compiled_css_loader_getUrl_js__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _ajax_loader_gif__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./ajax-loader.gif */ "./node_modules/slick-carousel/slick/ajax-loader.gif");
/* harmony import */ var _fonts_slick_eot__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./fonts/slick.eot */ "./node_modules/slick-carousel/slick/fonts/slick.eot");
/* harmony import */ var _fonts_slick_woff__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./fonts/slick.woff */ "./node_modules/slick-carousel/slick/fonts/slick.woff");
/* harmony import */ var _fonts_slick_ttf__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./fonts/slick.ttf */ "./node_modules/slick-carousel/slick/fonts/slick.ttf");
/* harmony import */ var _fonts_slick_svg__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./fonts/slick.svg */ "./node_modules/slick-carousel/slick/fonts/slick.svg");
// Imports







var ___CSS_LOADER_EXPORT___ = _next_dist_compiled_css_loader_api_js__WEBPACK_IMPORTED_MODULE_0___default()(true);
var ___CSS_LOADER_URL_REPLACEMENT_0___ = _next_dist_compiled_css_loader_getUrl_js__WEBPACK_IMPORTED_MODULE_1___default()(_ajax_loader_gif__WEBPACK_IMPORTED_MODULE_2__["default"]);
var ___CSS_LOADER_URL_REPLACEMENT_1___ = _next_dist_compiled_css_loader_getUrl_js__WEBPACK_IMPORTED_MODULE_1___default()(_fonts_slick_eot__WEBPACK_IMPORTED_MODULE_3__["default"]);
var ___CSS_LOADER_URL_REPLACEMENT_2___ = _next_dist_compiled_css_loader_getUrl_js__WEBPACK_IMPORTED_MODULE_1___default()(_fonts_slick_eot__WEBPACK_IMPORTED_MODULE_3__["default"], { hash: "?#iefix" });
var ___CSS_LOADER_URL_REPLACEMENT_3___ = _next_dist_compiled_css_loader_getUrl_js__WEBPACK_IMPORTED_MODULE_1___default()(_fonts_slick_woff__WEBPACK_IMPORTED_MODULE_4__["default"]);
var ___CSS_LOADER_URL_REPLACEMENT_4___ = _next_dist_compiled_css_loader_getUrl_js__WEBPACK_IMPORTED_MODULE_1___default()(_fonts_slick_ttf__WEBPACK_IMPORTED_MODULE_5__["default"]);
var ___CSS_LOADER_URL_REPLACEMENT_5___ = _next_dist_compiled_css_loader_getUrl_js__WEBPACK_IMPORTED_MODULE_1___default()(_fonts_slick_svg__WEBPACK_IMPORTED_MODULE_6__["default"], { hash: "#slick" });
// Module
___CSS_LOADER_EXPORT___.push([module.i, "@charset 'UTF-8';\n\n/* Slider */\n\n.slick-loading .slick-list\n{\n  background: #fff url(" + ___CSS_LOADER_URL_REPLACEMENT_0___ + ") center center no-repeat;\n}\n\n/* Icons */\n\n@font-face\n{\n  font-family: 'slick';\n\n  font-weight: normal;\n\n  font-style: normal;\n\n  src: url(" + ___CSS_LOADER_URL_REPLACEMENT_1___ + ");\n\n  src: url(" + ___CSS_LOADER_URL_REPLACEMENT_2___ + ") format('embedded-opentype'), url(" + ___CSS_LOADER_URL_REPLACEMENT_3___ + ") format('woff'), url(" + ___CSS_LOADER_URL_REPLACEMENT_4___ + ") format('truetype'), url(" + ___CSS_LOADER_URL_REPLACEMENT_5___ + ") format('svg');\n}\n\n/* Arrows */\n\n.slick-prev,\n.slick-next\n{\n  font-size: 0;\n  line-height: 0;\n  position: absolute;\n  top: 50%;\n  display: block;\n  width: 20px;\n  height: 20px;\n  padding: 0;\n  transform: translate(0, -50%);\n  cursor: pointer;\n  color: transparent;\n  border: none;\n  outline: none;\n  background: transparent;\n}\n\n.slick-prev:hover,\n.slick-prev:focus,\n.slick-next:hover,\n.slick-next:focus\n{\n  color: transparent;\n  outline: none;\n  background: transparent;\n}\n\n.slick-prev:hover:before,\n.slick-prev:focus:before,\n.slick-next:hover:before,\n.slick-next:focus:before\n{\n  opacity: 1;\n}\n\n.slick-prev.slick-disabled:before,\n.slick-next.slick-disabled:before\n{\n  opacity: .25;\n}\n\n.slick-prev:before,\n.slick-next:before\n{\n  font-family: 'slick';\n  font-size: 20px;\n  line-height: 1;\n  opacity: .75;\n  color: white;\n  -webkit-font-smoothing: antialiased;\n  -moz-osx-font-smoothing: grayscale;\n}\n\n.slick-prev\n{\n  left: -25px;\n}\n\n[dir='rtl'] .slick-prev\n{\n  right: -25px;\n  left: auto;\n}\n\n.slick-prev:before\n{\n  content: '←';\n}\n\n[dir='rtl'] .slick-prev:before\n{\n  content: '→';\n}\n\n.slick-next\n{\n  right: -25px;\n}\n\n[dir='rtl'] .slick-next\n{\n  right: auto;\n  left: -25px;\n}\n\n.slick-next:before\n{\n  content: '→';\n}\n\n[dir='rtl'] .slick-next:before\n{\n  content: '←';\n}\n\n/* Dots */\n\n.slick-dotted.slick-slider\n{\n  margin-bottom: 30px;\n}\n\n.slick-dots\n{\n  position: absolute;\n  bottom: -25px;\n  display: block;\n  width: 100%;\n  padding: 0;\n  margin: 0;\n  list-style: none;\n  text-align: center;\n}\n\n.slick-dots li\n{\n  position: relative;\n  display: inline-block;\n  width: 20px;\n  height: 20px;\n  margin: 0 5px;\n  padding: 0;\n  cursor: pointer;\n}\n\n.slick-dots li button\n{\n  font-size: 0;\n  line-height: 0;\n  display: block;\n  width: 20px;\n  height: 20px;\n  padding: 5px;\n  cursor: pointer;\n  color: transparent;\n  border: 0;\n  outline: none;\n  background: transparent;\n}\n\n.slick-dots li button:hover,\n.slick-dots li button:focus\n{\n  outline: none;\n}\n\n.slick-dots li button:hover:before,\n.slick-dots li button:focus:before\n{\n  opacity: 1;\n}\n\n.slick-dots li button:before\n{\n  font-family: 'slick';\n  font-size: 6px;\n  line-height: 20px;\n  position: absolute;\n  top: 0;\n  left: 0;\n  width: 20px;\n  height: 20px;\n  content: '•';\n  text-align: center;\n  opacity: .25;\n  color: black;\n  -webkit-font-smoothing: antialiased;\n  -moz-osx-font-smoothing: grayscale;\n}\n\n.slick-dots li.slick-active button:before\n{\n  opacity: .75;\n  color: black;\n}\n", "",{"version":3,"sources":["webpack://node_modules/slick-carousel/slick/slick-theme.css"],"names":[],"mappings":"AAAA,gBAAgB;;AAChB,WAAW;;AACX;;EAEI,gFAAiE;AACrE;;AAEA,UAAU;;AACV;;EAEI,oBAAoB;;EACpB,mBAAmB;;EACnB,kBAAkB;;EAElB,4CAA6B;;EAC7B,mPAAqM;AACzM;;AACA,WAAW;;AACX;;;EAGI,YAAY;EACZ,cAAc;EAEd,kBAAkB;EAClB,QAAQ;EAER,cAAc;EAEd,WAAW;EACX,YAAY;EACZ,UAAU;EAGV,6BAA6B;EAE7B,eAAe;EAEf,kBAAkB;EAClB,YAAY;EACZ,aAAa;EACb,uBAAuB;AAC3B;;AACA;;;;;EAKI,kBAAkB;EAClB,aAAa;EACb,uBAAuB;AAC3B;;AACA;;;;;EAKI,UAAU;AACd;;AACA;;;EAGI,YAAY;AAChB;;AAEA;;;EAGI,oBAAoB;EACpB,eAAe;EACf,cAAc;EAEd,YAAY;EACZ,YAAY;EAEZ,mCAAmC;EACnC,kCAAkC;AACtC;;AAEA;;EAEI,WAAW;AACf;;AACA;;EAEI,YAAY;EACZ,UAAU;AACd;;AACA;;EAEI,YAAY;AAChB;;AACA;;EAEI,YAAY;AAChB;;AAEA;;EAEI,YAAY;AAChB;;AACA;;EAEI,WAAW;EACX,WAAW;AACf;;AACA;;EAEI,YAAY;AAChB;;AACA;;EAEI,YAAY;AAChB;;AAEA,SAAS;;AACT;;EAEI,mBAAmB;AACvB;;AAEA;;EAEI,kBAAkB;EAClB,aAAa;EAEb,cAAc;EAEd,WAAW;EACX,UAAU;EACV,SAAS;EAET,gBAAgB;EAEhB,kBAAkB;AACtB;;AACA;;EAEI,kBAAkB;EAElB,qBAAqB;EAErB,WAAW;EACX,YAAY;EACZ,aAAa;EACb,UAAU;EAEV,eAAe;AACnB;;AACA;;EAEI,YAAY;EACZ,cAAc;EAEd,cAAc;EAEd,WAAW;EACX,YAAY;EACZ,YAAY;EAEZ,eAAe;EAEf,kBAAkB;EAClB,SAAS;EACT,aAAa;EACb,uBAAuB;AAC3B;;AACA;;;EAGI,aAAa;AACjB;;AACA;;;EAGI,UAAU;AACd;;AACA;;EAEI,oBAAoB;EACpB,cAAc;EACd,iBAAiB;EAEjB,kBAAkB;EAClB,MAAM;EACN,OAAO;EAEP,WAAW;EACX,YAAY;EAEZ,YAAY;EACZ,kBAAkB;EAElB,YAAY;EACZ,YAAY;EAEZ,mCAAmC;EACnC,kCAAkC;AACtC;;AACA;;EAEI,YAAY;EACZ,YAAY;AAChB","sourcesContent":["@charset 'UTF-8';\n/* Slider */\n.slick-loading .slick-list\n{\n    background: #fff url('./ajax-loader.gif') center center no-repeat;\n}\n\n/* Icons */\n@font-face\n{\n    font-family: 'slick';\n    font-weight: normal;\n    font-style: normal;\n\n    src: url('./fonts/slick.eot');\n    src: url('./fonts/slick.eot?#iefix') format('embedded-opentype'), url('./fonts/slick.woff') format('woff'), url('./fonts/slick.ttf') format('truetype'), url('./fonts/slick.svg#slick') format('svg');\n}\n/* Arrows */\n.slick-prev,\n.slick-next\n{\n    font-size: 0;\n    line-height: 0;\n\n    position: absolute;\n    top: 50%;\n\n    display: block;\n\n    width: 20px;\n    height: 20px;\n    padding: 0;\n    -webkit-transform: translate(0, -50%);\n    -ms-transform: translate(0, -50%);\n    transform: translate(0, -50%);\n\n    cursor: pointer;\n\n    color: transparent;\n    border: none;\n    outline: none;\n    background: transparent;\n}\n.slick-prev:hover,\n.slick-prev:focus,\n.slick-next:hover,\n.slick-next:focus\n{\n    color: transparent;\n    outline: none;\n    background: transparent;\n}\n.slick-prev:hover:before,\n.slick-prev:focus:before,\n.slick-next:hover:before,\n.slick-next:focus:before\n{\n    opacity: 1;\n}\n.slick-prev.slick-disabled:before,\n.slick-next.slick-disabled:before\n{\n    opacity: .25;\n}\n\n.slick-prev:before,\n.slick-next:before\n{\n    font-family: 'slick';\n    font-size: 20px;\n    line-height: 1;\n\n    opacity: .75;\n    color: white;\n\n    -webkit-font-smoothing: antialiased;\n    -moz-osx-font-smoothing: grayscale;\n}\n\n.slick-prev\n{\n    left: -25px;\n}\n[dir='rtl'] .slick-prev\n{\n    right: -25px;\n    left: auto;\n}\n.slick-prev:before\n{\n    content: '←';\n}\n[dir='rtl'] .slick-prev:before\n{\n    content: '→';\n}\n\n.slick-next\n{\n    right: -25px;\n}\n[dir='rtl'] .slick-next\n{\n    right: auto;\n    left: -25px;\n}\n.slick-next:before\n{\n    content: '→';\n}\n[dir='rtl'] .slick-next:before\n{\n    content: '←';\n}\n\n/* Dots */\n.slick-dotted.slick-slider\n{\n    margin-bottom: 30px;\n}\n\n.slick-dots\n{\n    position: absolute;\n    bottom: -25px;\n\n    display: block;\n\n    width: 100%;\n    padding: 0;\n    margin: 0;\n\n    list-style: none;\n\n    text-align: center;\n}\n.slick-dots li\n{\n    position: relative;\n\n    display: inline-block;\n\n    width: 20px;\n    height: 20px;\n    margin: 0 5px;\n    padding: 0;\n\n    cursor: pointer;\n}\n.slick-dots li button\n{\n    font-size: 0;\n    line-height: 0;\n\n    display: block;\n\n    width: 20px;\n    height: 20px;\n    padding: 5px;\n\n    cursor: pointer;\n\n    color: transparent;\n    border: 0;\n    outline: none;\n    background: transparent;\n}\n.slick-dots li button:hover,\n.slick-dots li button:focus\n{\n    outline: none;\n}\n.slick-dots li button:hover:before,\n.slick-dots li button:focus:before\n{\n    opacity: 1;\n}\n.slick-dots li button:before\n{\n    font-family: 'slick';\n    font-size: 6px;\n    line-height: 20px;\n\n    position: absolute;\n    top: 0;\n    left: 0;\n\n    width: 20px;\n    height: 20px;\n\n    content: '•';\n    text-align: center;\n\n    opacity: .25;\n    color: black;\n\n    -webkit-font-smoothing: antialiased;\n    -moz-osx-font-smoothing: grayscale;\n}\n.slick-dots li.slick-active button:before\n{\n    opacity: .75;\n    color: black;\n}\n"],"sourceRoot":""}]);
// Exports
/* harmony default export */ __webpack_exports__["default"] = (___CSS_LOADER_EXPORT___);


/***/ }),

/***/ "./node_modules/next/dist/compiled/css-loader/getUrl.js":
/*!**************************************!*\
  !*** (webpack)/css-loader/getUrl.js ***!
  \**************************************/
/*! no static exports found */
/***/ (function(module, exports) {

/* WEBPACK VAR INJECTION */(function(__dirname) {module.exports=function(){"use strict";var e={91:function(e){e.exports=function(e,r){if(!r){r={}}e=e&&e.__esModule?e.default:e;if(typeof e!=="string"){return e}if(/^['"].*['"]$/.test(e)){e=e.slice(1,-1)}if(r.hash){e+=r.hash}if(/["'() \t\n]/.test(e)||r.needQuotes){return'"'.concat(e.replace(/"/g,'\\"').replace(/\n/g,"\\n"),'"')}return e}}};var r={};function __nccwpck_require__(t){if(r[t]){return r[t].exports}var _=r[t]={exports:{}};var n=true;try{e[t](_,_.exports,__nccwpck_require__);n=false}finally{if(n)delete r[t]}return _.exports}__nccwpck_require__.ab=__dirname+"/";return __nccwpck_require__(91)}();
/* WEBPACK VAR INJECTION */}.call(this, "/"))

/***/ }),

/***/ "./node_modules/slick-carousel/slick/ajax-loader.gif":
/*!***********************************************************!*\
  !*** ./node_modules/slick-carousel/slick/ajax-loader.gif ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/media/ajax-loader.fb6f3c230cb846e25247dfaa1da94d8f.gif");

/***/ }),

/***/ "./node_modules/slick-carousel/slick/fonts/slick.eot":
/*!***********************************************************!*\
  !*** ./node_modules/slick-carousel/slick/fonts/slick.eot ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/media/slick.a4e97f5a2a64f0ab132323fbeb33ae29.eot");

/***/ }),

/***/ "./node_modules/slick-carousel/slick/fonts/slick.svg":
/*!***********************************************************!*\
  !*** ./node_modules/slick-carousel/slick/fonts/slick.svg ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/media/slick.2630a3e3eab21c607e21576571b95b9d.svg");

/***/ }),

/***/ "./node_modules/slick-carousel/slick/fonts/slick.ttf":
/*!***********************************************************!*\
  !*** ./node_modules/slick-carousel/slick/fonts/slick.ttf ***!
  \***********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/media/slick.c94f7671dcc99dce43e22a89f486f7c2.ttf");

/***/ }),

/***/ "./node_modules/slick-carousel/slick/fonts/slick.woff":
/*!************************************************************!*\
  !*** ./node_modules/slick-carousel/slick/fonts/slick.woff ***!
  \************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (__webpack_require__.p + "static/media/slick.295183786cd8a138986521d9f388a286.woff");

/***/ }),

/***/ "./node_modules/slick-carousel/slick/slick-theme.css":
/*!***********************************************************!*\
  !*** ./node_modules/slick-carousel/slick/slick-theme.css ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

var api = __webpack_require__(/*! ../../next/dist/build/webpack/loaders/next-style-loader/runtime/injectStylesIntoStyleTag.js */ "./node_modules/next/dist/build/webpack/loaders/next-style-loader/runtime/injectStylesIntoStyleTag.js");
            var content = __webpack_require__(/*! !../../next/dist/compiled/css-loader/cjs.js??ref--5-oneOf-5-1!../../next/dist/compiled/postcss-loader/cjs.js??ref--5-oneOf-5-2!./slick-theme.css */ "./node_modules/next/dist/compiled/css-loader/cjs.js?!./node_modules/next/dist/compiled/postcss-loader/cjs.js?!./node_modules/slick-carousel/slick/slick-theme.css");

            content = content.__esModule ? content.default : content;

            if (typeof content === 'string') {
              content = [[module.i, content, '']];
            }

var options = {};

options.insert = function(element){// These elements should always exist. If they do not,
// this code should fail.
var anchorElement=document.querySelector('#__next_css__DO_NOT_USE__');var parentNode=anchorElement.parentNode;// Normally <head>
// Each style tag should be placed right before our
// anchor. By inserting before and not after, we do not
// need to track the last inserted element.
parentNode.insertBefore(element,anchorElement);};
options.singleton = false;

var update = api(content, options);


if (true) {
  if (!content.locals || module.hot.invalidate) {
    var isEqualLocals = function isEqualLocals(a,b,isNamedExport){if(!a&&b||a&&!b){return false;}let p;for(p in a){if(isNamedExport&&p==='default'){// eslint-disable-next-line no-continue
continue;}if(a[p]!==b[p]){return false;}}for(p in b){if(isNamedExport&&p==='default'){// eslint-disable-next-line no-continue
continue;}if(!a[p]){return false;}}return true;};
    var oldLocals = content.locals;

    module.hot.accept(
      /*! !../../next/dist/compiled/css-loader/cjs.js??ref--5-oneOf-5-1!../../next/dist/compiled/postcss-loader/cjs.js??ref--5-oneOf-5-2!./slick-theme.css */ "./node_modules/next/dist/compiled/css-loader/cjs.js?!./node_modules/next/dist/compiled/postcss-loader/cjs.js?!./node_modules/slick-carousel/slick/slick-theme.css",
      function () {
        content = __webpack_require__(/*! !../../next/dist/compiled/css-loader/cjs.js??ref--5-oneOf-5-1!../../next/dist/compiled/postcss-loader/cjs.js??ref--5-oneOf-5-2!./slick-theme.css */ "./node_modules/next/dist/compiled/css-loader/cjs.js?!./node_modules/next/dist/compiled/postcss-loader/cjs.js?!./node_modules/slick-carousel/slick/slick-theme.css");

              content = content.__esModule ? content.default : content;

              if (typeof content === 'string') {
                content = [[module.i, content, '']];
              }

              if (!isEqualLocals(oldLocals, content.locals)) {
                module.hot.invalidate();

                return;
              }

              oldLocals = content.locals;

              update(content);
      }
    )
  }

  module.hot.dispose(function() {
    update();
  });
}

module.exports = content.locals || {};

/***/ }),

/***/ "./src/components/founder/Founder.tsx":
/*!********************************************!*\
  !*** ./src/components/founder/Founder.tsx ***!
  \********************************************/
/*! exports provided: Founder */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Founder", function() { return Founder; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var C_Users_KARTHIK_Documents_workspace_matrix_cms_ui_development_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @components */ "./src/components/index.ts");
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-slick */ "./node_modules/react-slick/lib/index.js");
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_slick__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! slick-carousel/slick/slick.css */ "./node_modules/slick-carousel/slick/slick.css");
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! slick-carousel/slick/slick-theme.css */ "./node_modules/slick-carousel/slick/slick-theme.css");
/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_6__);



var _jsxFileName = "C:\\Users\\KARTHIK\\Documents\\workspace\\matrix-cms-ui-development\\src\\components\\founder\\Founder.tsx",
    _this = undefined;

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { Object(C_Users_KARTHIK_Documents_workspace_matrix_cms_ui_development_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__["default"])(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }






var Founder = function Founder(_ref) {
  var className = _ref.className,
      _ref$style = _ref.style,
      style = _ref$style === void 0 ? {} : _ref$style;
  var settings = {
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1
  };
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "".concat(className),
        style: _objectSpread({
          width: 615.94,
          height: 863.91,
          position: "relative"
        }, style),
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "",
          style: {
            width: 571,
            height: 762,
            position: "absolute",
            background: "#083A4A",
            bottom: 50,
            left: 0
          }
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 28,
          columnNumber: 11
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "",
          style: {
            width: 594,
            height: 788,
            bottom: 65,
            left: 15,
            position: "absolute",
            display: "flex",
            flexDirection: "column"
          },
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_3__["Image"], {
            src: "/icons/Bhavish_image.svg",
            alt: "founder image",
            style: {
              flexGrow: 1
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 32,
            columnNumber: 13
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_3__["Image"], {
            src: "/icons/rectangle.svg",
            alt: "reactangle",
            className: "absolute",
            style: {
              left: 38,
              bottom: 254
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 33,
            columnNumber: 13
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            style: {
              height: 209,
              background: "#01576E"
            },
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "text-center flex items-center",
              style: {
                height: 118,
                borderBottom: "1px solid #EBEBE9"
              },
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h6", {
                className: "font-bold text-secondary",
                style: {
                  fontSize: 32,
                  lineHeight: "36px",
                  letterSpacing: "0.05em",
                  marginLeft: 31,
                  marginRight: 8
                },
                children: "BHAVISH"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 37,
                columnNumber: 17
              }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h6", {
                className: "font-light text-secondary",
                style: {
                  fontSize: 32,
                  lineHeight: "36px",
                  letterSpacing: "0.05em"
                },
                children: "AGGARWAL"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 40,
                columnNumber: 17
              }, _this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 36,
              columnNumber: 15
            }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "flex justify-between items-center",
              style: {
                height: 88
              },
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                style: {
                  marginLeft: 31
                },
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                  className: "text-secondary font-medium text-lg leading-6",
                  children: " Mobility"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 47,
                  columnNumber: 19
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 46,
                columnNumber: 17
              }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_3__["Image"], {
                src: "/icons/ola.svg",
                alt: "ola",
                style: {
                  marginRight: 57
                }
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 49,
                columnNumber: 17
              }, _this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 45,
              columnNumber: 15
            }, _this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 35,
            columnNumber: 13
          }, _this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 29,
          columnNumber: 11
        }, _this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 27,
        columnNumber: 9
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 26,
      columnNumber: 7
    }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "".concat(className),
        style: _objectSpread({
          width: 615.94,
          height: 863.91,
          position: "relative"
        }, style),
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "",
          style: {
            width: 571,
            height: 762,
            position: "absolute",
            background: "#083A4A",
            bottom: 50,
            left: 0
          }
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 57,
          columnNumber: 11
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "",
          style: {
            width: 594,
            height: 788,
            bottom: 65,
            left: 15,
            position: "absolute",
            display: "flex",
            flexDirection: "column"
          },
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_3__["Image"], {
            src: "/icons/Bhavish_image.svg",
            alt: "founder image",
            style: {
              flexGrow: 1
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 61,
            columnNumber: 13
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_3__["Image"], {
            src: "/icons/rectangle.svg",
            alt: "reactangle",
            className: "absolute",
            style: {
              left: 38,
              bottom: 254
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 62,
            columnNumber: 13
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            style: {
              height: 209,
              background: "#01576E"
            },
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "text-center flex items-center",
              style: {
                height: 118,
                borderBottom: "1px solid #EBEBE9"
              },
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h6", {
                className: "font-bold text-secondary",
                style: {
                  fontSize: 32,
                  lineHeight: "36px",
                  letterSpacing: "0.05em",
                  marginLeft: 31,
                  marginRight: 8
                },
                children: "BHAVISH"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 66,
                columnNumber: 17
              }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h6", {
                className: "font-light text-secondary",
                style: {
                  fontSize: 32,
                  lineHeight: "36px",
                  letterSpacing: "0.05em"
                },
                children: "AGGARWAL"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 69,
                columnNumber: 17
              }, _this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 65,
              columnNumber: 15
            }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "flex justify-between items-center",
              style: {
                height: 88
              },
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                style: {
                  marginLeft: 31
                },
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                  className: "text-secondary font-medium text-lg leading-6",
                  children: " Mobility"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 76,
                  columnNumber: 19
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 75,
                columnNumber: 17
              }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_3__["Image"], {
                src: "/icons/ola.svg",
                alt: "ola",
                style: {
                  marginRight: 57
                }
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 78,
                columnNumber: 17
              }, _this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 74,
              columnNumber: 15
            }, _this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 64,
            columnNumber: 13
          }, _this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 58,
          columnNumber: 11
        }, _this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 56,
        columnNumber: 9
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 55,
      columnNumber: 7
    }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_slick__WEBPACK_IMPORTED_MODULE_4___default.a, _objectSpread(_objectSpread({}, settings), {}, {
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        children: "lkdfvd"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 85,
        columnNumber: 9
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        children: "lkdfvd"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 86,
        columnNumber: 9
      }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        children: "lkdfvd"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 87,
        columnNumber: 9
      }, _this)]
    }), void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 84,
      columnNumber: 7
    }, _this)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 25,
    columnNumber: 5
  }, _this);
};
_c = Founder;

var _c;

$RefreshReg$(_c, "Founder");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vbm9kZV9tb2R1bGVzL3NsaWNrLWNhcm91c2VsL3NsaWNrL3NsaWNrLXRoZW1lLmNzcyIsIndlYnBhY2s6Ly9fTl9FLyh3ZWJwYWNrKS9jc3MtbG9hZGVyL2dldFVybC5qcyIsIndlYnBhY2s6Ly9fTl9FLy4vbm9kZV9tb2R1bGVzL3NsaWNrLWNhcm91c2VsL3NsaWNrL2FqYXgtbG9hZGVyLmdpZiIsIndlYnBhY2s6Ly9fTl9FLy4vbm9kZV9tb2R1bGVzL3NsaWNrLWNhcm91c2VsL3NsaWNrL2ZvbnRzL3NsaWNrLmVvdCIsIndlYnBhY2s6Ly9fTl9FLy4vbm9kZV9tb2R1bGVzL3NsaWNrLWNhcm91c2VsL3NsaWNrL2ZvbnRzL3NsaWNrLnN2ZyIsIndlYnBhY2s6Ly9fTl9FLy4vbm9kZV9tb2R1bGVzL3NsaWNrLWNhcm91c2VsL3NsaWNrL2ZvbnRzL3NsaWNrLnR0ZiIsIndlYnBhY2s6Ly9fTl9FLy4vbm9kZV9tb2R1bGVzL3NsaWNrLWNhcm91c2VsL3NsaWNrL2ZvbnRzL3NsaWNrLndvZmYiLCJ3ZWJwYWNrOi8vX05fRS8uL25vZGVfbW9kdWxlcy9zbGljay1jYXJvdXNlbC9zbGljay9zbGljay10aGVtZS5jc3M/ZWU5YSIsIndlYnBhY2s6Ly9fTl9FLy4vc3JjL2NvbXBvbmVudHMvZm91bmRlci9Gb3VuZGVyLnRzeCJdLCJuYW1lcyI6WyJGb3VuZGVyIiwiY2xhc3NOYW1lIiwic3R5bGUiLCJzZXR0aW5ncyIsImRvdHMiLCJpbmZpbml0ZSIsInNwZWVkIiwic2xpZGVzVG9TaG93Iiwic2xpZGVzVG9TY3JvbGwiLCJ3aWR0aCIsImhlaWdodCIsInBvc2l0aW9uIiwiYmFja2dyb3VuZCIsImJvdHRvbSIsImxlZnQiLCJkaXNwbGF5IiwiZmxleERpcmVjdGlvbiIsImZsZXhHcm93IiwiYm9yZGVyQm90dG9tIiwiZm9udFNpemUiLCJsaW5lSGVpZ2h0IiwibGV0dGVyU3BhY2luZyIsIm1hcmdpbkxlZnQiLCJtYXJnaW5SaWdodCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7OztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDcUY7QUFDTztBQUM5QjtBQUNBO0FBQ0M7QUFDRDtBQUNBO0FBQzlELDhCQUE4Qiw0RUFBMkI7QUFDekQseUNBQXlDLCtFQUErQixDQUFDLHdEQUE2QjtBQUN0Ryx5Q0FBeUMsK0VBQStCLENBQUMsd0RBQTZCO0FBQ3RHLHlDQUF5QywrRUFBK0IsQ0FBQyx3REFBNkIsR0FBRyxrQkFBa0I7QUFDM0gseUNBQXlDLCtFQUErQixDQUFDLHlEQUE2QjtBQUN0Ryx5Q0FBeUMsK0VBQStCLENBQUMsd0RBQTZCO0FBQ3RHLHlDQUF5QywrRUFBK0IsQ0FBQyx3REFBNkIsR0FBRyxpQkFBaUI7QUFDMUg7QUFDQSw4QkFBOEIsUUFBUyxvQkFBb0IsaURBQWlELDZGQUE2RixHQUFHLGdDQUFnQyx5QkFBeUIsMEJBQTBCLHlCQUF5QiwyREFBMkQsMFJBQTBSLEdBQUcsZ0RBQWdELGlCQUFpQixtQkFBbUIsdUJBQXVCLGFBQWEsbUJBQW1CLGdCQUFnQixpQkFBaUIsZUFBZSxrQ0FBa0Msb0JBQW9CLHVCQUF1QixpQkFBaUIsa0JBQWtCLDRCQUE0QixHQUFHLG9GQUFvRix1QkFBdUIsa0JBQWtCLDRCQUE0QixHQUFHLGdIQUFnSCxlQUFlLEdBQUcsNEVBQTRFLGlCQUFpQixHQUFHLDhDQUE4Qyx5QkFBeUIsb0JBQW9CLG1CQUFtQixpQkFBaUIsaUJBQWlCLHdDQUF3Qyx1Q0FBdUMsR0FBRyxrQkFBa0IsZ0JBQWdCLEdBQUcsOEJBQThCLGlCQUFpQixlQUFlLEdBQUcseUJBQXlCLGlCQUFpQixHQUFHLHFDQUFxQyxpQkFBaUIsR0FBRyxrQkFBa0IsaUJBQWlCLEdBQUcsOEJBQThCLGdCQUFnQixnQkFBZ0IsR0FBRyx5QkFBeUIsaUJBQWlCLEdBQUcscUNBQXFDLGlCQUFpQixHQUFHLCtDQUErQyx3QkFBd0IsR0FBRyxrQkFBa0IsdUJBQXVCLGtCQUFrQixtQkFBbUIsZ0JBQWdCLGVBQWUsY0FBYyxxQkFBcUIsdUJBQXVCLEdBQUcscUJBQXFCLHVCQUF1QiwwQkFBMEIsZ0JBQWdCLGlCQUFpQixrQkFBa0IsZUFBZSxvQkFBb0IsR0FBRyw0QkFBNEIsaUJBQWlCLG1CQUFtQixtQkFBbUIsZ0JBQWdCLGlCQUFpQixpQkFBaUIsb0JBQW9CLHVCQUF1QixjQUFjLGtCQUFrQiw0QkFBNEIsR0FBRyxnRUFBZ0Usa0JBQWtCLEdBQUcsOEVBQThFLGVBQWUsR0FBRyxtQ0FBbUMseUJBQXlCLG1CQUFtQixzQkFBc0IsdUJBQXVCLFdBQVcsWUFBWSxnQkFBZ0IsaUJBQWlCLGlCQUFpQix1QkFBdUIsaUJBQWlCLGlCQUFpQix3Q0FBd0MsdUNBQXVDLEdBQUcsZ0RBQWdELGlCQUFpQixpQkFBaUIsR0FBRyxTQUFTLDBIQUEwSCxZQUFZLE1BQU0sWUFBWSxPQUFPLFdBQVcsTUFBTSxhQUFhLGNBQWMsY0FBYyxjQUFjLGFBQWEsT0FBTyxXQUFXLE9BQU8sVUFBVSxVQUFVLFlBQVksV0FBVyxVQUFVLFVBQVUsVUFBVSxVQUFVLFlBQVksV0FBVyxZQUFZLFdBQVcsVUFBVSxZQUFZLE9BQU8sU0FBUyxZQUFZLFdBQVcsWUFBWSxPQUFPLFNBQVMsVUFBVSxNQUFNLE9BQU8sVUFBVSxPQUFPLE9BQU8sWUFBWSxXQUFXLFVBQVUsVUFBVSxVQUFVLFlBQVksYUFBYSxPQUFPLE1BQU0sVUFBVSxNQUFNLE1BQU0sVUFBVSxVQUFVLE1BQU0sTUFBTSxVQUFVLE9BQU8sTUFBTSxVQUFVLE9BQU8sTUFBTSxVQUFVLE9BQU8sTUFBTSxVQUFVLFVBQVUsTUFBTSxNQUFNLFVBQVUsT0FBTyxNQUFNLFVBQVUsT0FBTyxXQUFXLE1BQU0sWUFBWSxPQUFPLE1BQU0sWUFBWSxXQUFXLFVBQVUsVUFBVSxVQUFVLFVBQVUsWUFBWSxhQUFhLE9BQU8sTUFBTSxZQUFZLGFBQWEsV0FBVyxVQUFVLFVBQVUsVUFBVSxVQUFVLE9BQU8sTUFBTSxVQUFVLFVBQVUsVUFBVSxVQUFVLFVBQVUsVUFBVSxVQUFVLFlBQVksV0FBVyxVQUFVLFlBQVksT0FBTyxPQUFPLFVBQVUsT0FBTyxPQUFPLFVBQVUsTUFBTSxNQUFNLFlBQVksV0FBVyxZQUFZLGFBQWEsV0FBVyxVQUFVLFVBQVUsVUFBVSxVQUFVLFlBQVksV0FBVyxVQUFVLFlBQVksYUFBYSxPQUFPLE1BQU0sVUFBVSxVQUFVLDJDQUEyQyw2Q0FBNkMsd0VBQXdFLEdBQUcsOEJBQThCLDJCQUEyQiwwQkFBMEIseUJBQXlCLHNDQUFzQyw0TUFBNE0sR0FBRyw0Q0FBNEMsbUJBQW1CLHFCQUFxQiwyQkFBMkIsZUFBZSx1QkFBdUIsb0JBQW9CLG1CQUFtQixpQkFBaUIsNENBQTRDLHdDQUF3QyxvQ0FBb0Msd0JBQXdCLDJCQUEyQixtQkFBbUIsb0JBQW9CLDhCQUE4QixHQUFHLGtGQUFrRix5QkFBeUIsb0JBQW9CLDhCQUE4QixHQUFHLDhHQUE4RyxpQkFBaUIsR0FBRywwRUFBMEUsbUJBQW1CLEdBQUcsOENBQThDLDJCQUEyQixzQkFBc0IscUJBQXFCLHFCQUFxQixtQkFBbUIsNENBQTRDLHlDQUF5QyxHQUFHLGtCQUFrQixrQkFBa0IsR0FBRyw0QkFBNEIsbUJBQW1CLGlCQUFpQixHQUFHLHVCQUF1QixtQkFBbUIsR0FBRyxtQ0FBbUMsbUJBQW1CLEdBQUcsa0JBQWtCLG1CQUFtQixHQUFHLDRCQUE0QixrQkFBa0Isa0JBQWtCLEdBQUcsdUJBQXVCLG1CQUFtQixHQUFHLG1DQUFtQyxtQkFBbUIsR0FBRyw2Q0FBNkMsMEJBQTBCLEdBQUcsa0JBQWtCLHlCQUF5QixvQkFBb0IsdUJBQXVCLG9CQUFvQixpQkFBaUIsZ0JBQWdCLHlCQUF5QiwyQkFBMkIsR0FBRyxtQkFBbUIseUJBQXlCLDhCQUE4QixvQkFBb0IsbUJBQW1CLG9CQUFvQixpQkFBaUIsd0JBQXdCLEdBQUcsMEJBQTBCLG1CQUFtQixxQkFBcUIsdUJBQXVCLG9CQUFvQixtQkFBbUIsbUJBQW1CLHdCQUF3QiwyQkFBMkIsZ0JBQWdCLG9CQUFvQiw4QkFBOEIsR0FBRyw4REFBOEQsb0JBQW9CLEdBQUcsNEVBQTRFLGlCQUFpQixHQUFHLGlDQUFpQywyQkFBMkIscUJBQXFCLHdCQUF3QiwyQkFBMkIsYUFBYSxjQUFjLG9CQUFvQixtQkFBbUIscUJBQXFCLHlCQUF5QixxQkFBcUIsbUJBQW1CLDRDQUE0Qyx5Q0FBeUMsR0FBRyw4Q0FBOEMsbUJBQW1CLG1CQUFtQixHQUFHLHFCQUFxQjtBQUN6M1A7QUFDZSxzRkFBdUIsRUFBQzs7Ozs7Ozs7Ozs7O0FDbEJ2QywyRUFBMEIsYUFBYSxPQUFPLGVBQWUsd0JBQXdCLE9BQU8sS0FBSyw4QkFBOEIsd0JBQXdCLFNBQVMsMkJBQTJCLGdCQUFnQixXQUFXLFVBQVUsd0NBQXdDLGlFQUFpRSxZQUFZLFNBQVMsZ0NBQWdDLFNBQVMsb0JBQW9CLFlBQVksWUFBWSxXQUFXLElBQUksc0NBQXNDLFFBQVEsUUFBUSxpQkFBaUIsaUJBQWlCLHFDQUFxQywrQkFBK0IsRzs7Ozs7Ozs7Ozs7OztBQ0E5bEI7QUFBZSxvRkFBdUIsa0VBQWtFLEU7Ozs7Ozs7Ozs7OztBQ0F4RztBQUFlLG9GQUF1Qiw0REFBNEQsRTs7Ozs7Ozs7Ozs7O0FDQWxHO0FBQWUsb0ZBQXVCLDREQUE0RCxFOzs7Ozs7Ozs7Ozs7QUNBbEc7QUFBZSxvRkFBdUIsNERBQTRELEU7Ozs7Ozs7Ozs7OztBQ0FsRztBQUFlLG9GQUF1Qiw2REFBNkQsRTs7Ozs7Ozs7Ozs7QUNBbkcsVUFBVSxtQkFBTyxDQUFDLHlNQUE4RjtBQUNoSCwwQkFBMEIsbUJBQU8sQ0FBQywyVEFBbUo7O0FBRXJMOztBQUVBO0FBQ0EsMEJBQTBCLFFBQVM7QUFDbkM7O0FBRUE7O0FBRUEsbUNBQW1DO0FBQ25DO0FBQ0Esc0VBQXNFLHdDQUF3QztBQUM5RztBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBOzs7QUFHQSxJQUFJLElBQVU7QUFDZDtBQUNBLGtFQUFrRSxpQkFBaUIsY0FBYyxNQUFNLFlBQVksaUNBQWlDO0FBQ3BKLFVBQVUsZ0JBQWdCLGVBQWUsWUFBWSxpQ0FBaUM7QUFDdEYsVUFBVSxVQUFVLGVBQWU7QUFDbkM7O0FBRUE7QUFDQSxNQUFNLDJUQUFtSjtBQUN6SjtBQUNBLGtCQUFrQixtQkFBTyxDQUFDLDJUQUFtSjs7QUFFN0s7O0FBRUE7QUFDQSw0QkFBNEIsUUFBUztBQUNyQzs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUE7O0FBRUE7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTtBQUNBLEdBQUc7QUFDSDs7QUFFQSxzQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDM0RBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFXTyxJQUFNQSxPQUF3QixHQUFHLFNBQTNCQSxPQUEyQixPQUErQjtBQUFBLE1BQTVCQyxTQUE0QixRQUE1QkEsU0FBNEI7QUFBQSx3QkFBakJDLEtBQWlCO0FBQUEsTUFBakJBLEtBQWlCLDJCQUFULEVBQVM7QUFDckUsTUFBTUMsUUFBUSxHQUFHO0FBQ2ZDLFFBQUksRUFBRSxJQURTO0FBRWZDLFlBQVEsRUFBRSxJQUZLO0FBR2ZDLFNBQUssRUFBRSxHQUhRO0FBSWZDLGdCQUFZLEVBQUUsQ0FKQztBQUtmQyxrQkFBYyxFQUFFO0FBTEQsR0FBakI7QUFPQSxzQkFDRTtBQUFBLDRCQUNFO0FBQUEsNkJBQ0U7QUFBSyxpQkFBUyxZQUFLUCxTQUFMLENBQWQ7QUFBZ0MsYUFBSztBQUFJUSxlQUFLLEVBQUUsTUFBWDtBQUFtQkMsZ0JBQU0sRUFBRSxNQUEzQjtBQUFtQ0Msa0JBQVEsRUFBRTtBQUE3QyxXQUE0RFQsS0FBNUQsQ0FBckM7QUFBQSxnQ0FDRTtBQUFLLG1CQUFTLEVBQUMsRUFBZjtBQUFrQixlQUFLLEVBQUU7QUFBRU8saUJBQUssRUFBRSxHQUFUO0FBQWNDLGtCQUFNLEVBQUUsR0FBdEI7QUFBMkJDLG9CQUFRLEVBQUUsVUFBckM7QUFBaURDLHNCQUFVLEVBQUUsU0FBN0Q7QUFBd0VDLGtCQUFNLEVBQUUsRUFBaEY7QUFBb0ZDLGdCQUFJLEVBQUU7QUFBMUY7QUFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFERixlQUVFO0FBQ0UsbUJBQVMsRUFBQyxFQURaO0FBRUUsZUFBSyxFQUFFO0FBQUVMLGlCQUFLLEVBQUUsR0FBVDtBQUFjQyxrQkFBTSxFQUFFLEdBQXRCO0FBQTJCRyxrQkFBTSxFQUFFLEVBQW5DO0FBQXVDQyxnQkFBSSxFQUFFLEVBQTdDO0FBQWlESCxvQkFBUSxFQUFFLFVBQTNEO0FBQXVFSSxtQkFBTyxFQUFFLE1BQWhGO0FBQXdGQyx5QkFBYSxFQUFFO0FBQXZHLFdBRlQ7QUFBQSxrQ0FHRSxxRUFBQyxpREFBRDtBQUFPLGVBQUcsRUFBQywwQkFBWDtBQUFzQyxlQUFHLEVBQUMsZUFBMUM7QUFBMEQsaUJBQUssRUFBRTtBQUFFQyxzQkFBUSxFQUFFO0FBQVo7QUFBakU7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFIRixlQUlFLHFFQUFDLGlEQUFEO0FBQU8sZUFBRyxFQUFDLHNCQUFYO0FBQWtDLGVBQUcsRUFBRSxZQUF2QztBQUFxRCxxQkFBUyxFQUFDLFVBQS9EO0FBQTBFLGlCQUFLLEVBQUU7QUFBRUgsa0JBQUksRUFBRSxFQUFSO0FBQVlELG9CQUFNLEVBQUU7QUFBcEI7QUFBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFKRixlQU1FO0FBQUssaUJBQUssRUFBRTtBQUFFSCxvQkFBTSxFQUFFLEdBQVY7QUFBZUUsd0JBQVUsRUFBRTtBQUEzQixhQUFaO0FBQUEsb0NBQ0U7QUFBSyx1QkFBUyxFQUFDLCtCQUFmO0FBQStDLG1CQUFLLEVBQUU7QUFBRUYsc0JBQU0sRUFBRSxHQUFWO0FBQWVRLDRCQUFZLEVBQUU7QUFBN0IsZUFBdEQ7QUFBQSxzQ0FDRTtBQUFJLHlCQUFTLEVBQUMsMEJBQWQ7QUFBeUMscUJBQUssRUFBRTtBQUFFQywwQkFBUSxFQUFFLEVBQVo7QUFBZ0JDLDRCQUFVLEVBQUUsTUFBNUI7QUFBb0NDLCtCQUFhLEVBQUUsUUFBbkQ7QUFBNkRDLDRCQUFVLEVBQUUsRUFBekU7QUFBNkVDLDZCQUFXLEVBQUU7QUFBMUYsaUJBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQURGLGVBSUU7QUFBSSx5QkFBUyxFQUFDLDJCQUFkO0FBQTBDLHFCQUFLLEVBQUU7QUFBRUosMEJBQVEsRUFBRSxFQUFaO0FBQWdCQyw0QkFBVSxFQUFFLE1BQTVCO0FBQW9DQywrQkFBYSxFQUFFO0FBQW5ELGlCQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREYsZUFVRTtBQUFLLHVCQUFTLEVBQUMsbUNBQWY7QUFBbUQsbUJBQUssRUFBRTtBQUFFWCxzQkFBTSxFQUFFO0FBQVYsZUFBMUQ7QUFBQSxzQ0FDRTtBQUFLLHFCQUFLLEVBQUU7QUFBRVksNEJBQVUsRUFBRTtBQUFkLGlCQUFaO0FBQUEsdUNBQ0U7QUFBTSwyQkFBUyxFQUFDLDhDQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBREYsZUFJRSxxRUFBQyxpREFBRDtBQUFPLG1CQUFHLEVBQUUsZ0JBQVo7QUFBOEIsbUJBQUcsRUFBRSxLQUFuQztBQUEwQyxxQkFBSyxFQUFFO0FBQUVDLDZCQUFXLEVBQUU7QUFBZjtBQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFERixlQThCRTtBQUFBLDZCQUNFO0FBQUssaUJBQVMsWUFBS3RCLFNBQUwsQ0FBZDtBQUFnQyxhQUFLO0FBQUlRLGVBQUssRUFBRSxNQUFYO0FBQW1CQyxnQkFBTSxFQUFFLE1BQTNCO0FBQW1DQyxrQkFBUSxFQUFFO0FBQTdDLFdBQTREVCxLQUE1RCxDQUFyQztBQUFBLGdDQUNFO0FBQUssbUJBQVMsRUFBQyxFQUFmO0FBQWtCLGVBQUssRUFBRTtBQUFFTyxpQkFBSyxFQUFFLEdBQVQ7QUFBY0Msa0JBQU0sRUFBRSxHQUF0QjtBQUEyQkMsb0JBQVEsRUFBRSxVQUFyQztBQUFpREMsc0JBQVUsRUFBRSxTQUE3RDtBQUF3RUMsa0JBQU0sRUFBRSxFQUFoRjtBQUFvRkMsZ0JBQUksRUFBRTtBQUExRjtBQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURGLGVBRUU7QUFDRSxtQkFBUyxFQUFDLEVBRFo7QUFFRSxlQUFLLEVBQUU7QUFBRUwsaUJBQUssRUFBRSxHQUFUO0FBQWNDLGtCQUFNLEVBQUUsR0FBdEI7QUFBMkJHLGtCQUFNLEVBQUUsRUFBbkM7QUFBdUNDLGdCQUFJLEVBQUUsRUFBN0M7QUFBaURILG9CQUFRLEVBQUUsVUFBM0Q7QUFBdUVJLG1CQUFPLEVBQUUsTUFBaEY7QUFBd0ZDLHlCQUFhLEVBQUU7QUFBdkcsV0FGVDtBQUFBLGtDQUdFLHFFQUFDLGlEQUFEO0FBQU8sZUFBRyxFQUFDLDBCQUFYO0FBQXNDLGVBQUcsRUFBQyxlQUExQztBQUEwRCxpQkFBSyxFQUFFO0FBQUVDLHNCQUFRLEVBQUU7QUFBWjtBQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUhGLGVBSUUscUVBQUMsaURBQUQ7QUFBTyxlQUFHLEVBQUMsc0JBQVg7QUFBa0MsZUFBRyxFQUFFLFlBQXZDO0FBQXFELHFCQUFTLEVBQUMsVUFBL0Q7QUFBMEUsaUJBQUssRUFBRTtBQUFFSCxrQkFBSSxFQUFFLEVBQVI7QUFBWUQsb0JBQU0sRUFBRTtBQUFwQjtBQUFqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUpGLGVBTUU7QUFBSyxpQkFBSyxFQUFFO0FBQUVILG9CQUFNLEVBQUUsR0FBVjtBQUFlRSx3QkFBVSxFQUFFO0FBQTNCLGFBQVo7QUFBQSxvQ0FDRTtBQUFLLHVCQUFTLEVBQUMsK0JBQWY7QUFBK0MsbUJBQUssRUFBRTtBQUFFRixzQkFBTSxFQUFFLEdBQVY7QUFBZVEsNEJBQVksRUFBRTtBQUE3QixlQUF0RDtBQUFBLHNDQUNFO0FBQUkseUJBQVMsRUFBQywwQkFBZDtBQUF5QyxxQkFBSyxFQUFFO0FBQUVDLDBCQUFRLEVBQUUsRUFBWjtBQUFnQkMsNEJBQVUsRUFBRSxNQUE1QjtBQUFvQ0MsK0JBQWEsRUFBRSxRQUFuRDtBQUE2REMsNEJBQVUsRUFBRSxFQUF6RTtBQUE2RUMsNkJBQVcsRUFBRTtBQUExRixpQkFBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBREYsZUFJRTtBQUFJLHlCQUFTLEVBQUMsMkJBQWQ7QUFBMEMscUJBQUssRUFBRTtBQUFFSiwwQkFBUSxFQUFFLEVBQVo7QUFBZ0JDLDRCQUFVLEVBQUUsTUFBNUI7QUFBb0NDLCtCQUFhLEVBQUU7QUFBbkQsaUJBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFERixlQVVFO0FBQUssdUJBQVMsRUFBQyxtQ0FBZjtBQUFtRCxtQkFBSyxFQUFFO0FBQUVYLHNCQUFNLEVBQUU7QUFBVixlQUExRDtBQUFBLHNDQUNFO0FBQUsscUJBQUssRUFBRTtBQUFFWSw0QkFBVSxFQUFFO0FBQWQsaUJBQVo7QUFBQSx1Q0FDRTtBQUFNLDJCQUFTLEVBQUMsOENBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFERixlQUlFLHFFQUFDLGlEQUFEO0FBQU8sbUJBQUcsRUFBRSxnQkFBWjtBQUE4QixtQkFBRyxFQUFFLEtBQW5DO0FBQTBDLHFCQUFLLEVBQUU7QUFBRUMsNkJBQVcsRUFBRTtBQUFmO0FBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFORjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTlCRixlQTJERSxxRUFBQyxrREFBRCxrQ0FBWXBCLFFBQVo7QUFBQSw4QkFDRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGLGVBRUU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFGRixlQUdFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBM0RGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQURGO0FBbUVELENBM0VNO0tBQU1ILE8iLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvaG9tZS42ZTYzMzNiOWFhNDgwYTYyOWY4NS5ob3QtdXBkYXRlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiLy8gSW1wb3J0c1xuaW1wb3J0IF9fX0NTU19MT0FERVJfQVBJX0lNUE9SVF9fXyBmcm9tIFwiLi4vLi4vbmV4dC9kaXN0L2NvbXBpbGVkL2Nzcy1sb2FkZXIvYXBpLmpzXCI7XG5pbXBvcnQgX19fQ1NTX0xPQURFUl9HRVRfVVJMX0lNUE9SVF9fXyBmcm9tIFwiLi4vLi4vbmV4dC9kaXN0L2NvbXBpbGVkL2Nzcy1sb2FkZXIvZ2V0VXJsLmpzXCI7XG5pbXBvcnQgX19fQ1NTX0xPQURFUl9VUkxfSU1QT1JUXzBfX18gZnJvbSBcIi4vYWpheC1sb2FkZXIuZ2lmXCI7XG5pbXBvcnQgX19fQ1NTX0xPQURFUl9VUkxfSU1QT1JUXzFfX18gZnJvbSBcIi4vZm9udHMvc2xpY2suZW90XCI7XG5pbXBvcnQgX19fQ1NTX0xPQURFUl9VUkxfSU1QT1JUXzJfX18gZnJvbSBcIi4vZm9udHMvc2xpY2sud29mZlwiO1xuaW1wb3J0IF9fX0NTU19MT0FERVJfVVJMX0lNUE9SVF8zX19fIGZyb20gXCIuL2ZvbnRzL3NsaWNrLnR0ZlwiO1xuaW1wb3J0IF9fX0NTU19MT0FERVJfVVJMX0lNUE9SVF80X19fIGZyb20gXCIuL2ZvbnRzL3NsaWNrLnN2Z1wiO1xudmFyIF9fX0NTU19MT0FERVJfRVhQT1JUX19fID0gX19fQ1NTX0xPQURFUl9BUElfSU1QT1JUX19fKHRydWUpO1xudmFyIF9fX0NTU19MT0FERVJfVVJMX1JFUExBQ0VNRU5UXzBfX18gPSBfX19DU1NfTE9BREVSX0dFVF9VUkxfSU1QT1JUX19fKF9fX0NTU19MT0FERVJfVVJMX0lNUE9SVF8wX19fKTtcbnZhciBfX19DU1NfTE9BREVSX1VSTF9SRVBMQUNFTUVOVF8xX19fID0gX19fQ1NTX0xPQURFUl9HRVRfVVJMX0lNUE9SVF9fXyhfX19DU1NfTE9BREVSX1VSTF9JTVBPUlRfMV9fXyk7XG52YXIgX19fQ1NTX0xPQURFUl9VUkxfUkVQTEFDRU1FTlRfMl9fXyA9IF9fX0NTU19MT0FERVJfR0VUX1VSTF9JTVBPUlRfX18oX19fQ1NTX0xPQURFUl9VUkxfSU1QT1JUXzFfX18sIHsgaGFzaDogXCI/I2llZml4XCIgfSk7XG52YXIgX19fQ1NTX0xPQURFUl9VUkxfUkVQTEFDRU1FTlRfM19fXyA9IF9fX0NTU19MT0FERVJfR0VUX1VSTF9JTVBPUlRfX18oX19fQ1NTX0xPQURFUl9VUkxfSU1QT1JUXzJfX18pO1xudmFyIF9fX0NTU19MT0FERVJfVVJMX1JFUExBQ0VNRU5UXzRfX18gPSBfX19DU1NfTE9BREVSX0dFVF9VUkxfSU1QT1JUX19fKF9fX0NTU19MT0FERVJfVVJMX0lNUE9SVF8zX19fKTtcbnZhciBfX19DU1NfTE9BREVSX1VSTF9SRVBMQUNFTUVOVF81X19fID0gX19fQ1NTX0xPQURFUl9HRVRfVVJMX0lNUE9SVF9fXyhfX19DU1NfTE9BREVSX1VSTF9JTVBPUlRfNF9fXywgeyBoYXNoOiBcIiNzbGlja1wiIH0pO1xuLy8gTW9kdWxlXG5fX19DU1NfTE9BREVSX0VYUE9SVF9fXy5wdXNoKFttb2R1bGUuaWQsIFwiQGNoYXJzZXQgJ1VURi04JztcXG5cXG4vKiBTbGlkZXIgKi9cXG5cXG4uc2xpY2stbG9hZGluZyAuc2xpY2stbGlzdFxcbntcXG4gIGJhY2tncm91bmQ6ICNmZmYgdXJsKFwiICsgX19fQ1NTX0xPQURFUl9VUkxfUkVQTEFDRU1FTlRfMF9fXyArIFwiKSBjZW50ZXIgY2VudGVyIG5vLXJlcGVhdDtcXG59XFxuXFxuLyogSWNvbnMgKi9cXG5cXG5AZm9udC1mYWNlXFxue1xcbiAgZm9udC1mYW1pbHk6ICdzbGljayc7XFxuXFxuICBmb250LXdlaWdodDogbm9ybWFsO1xcblxcbiAgZm9udC1zdHlsZTogbm9ybWFsO1xcblxcbiAgc3JjOiB1cmwoXCIgKyBfX19DU1NfTE9BREVSX1VSTF9SRVBMQUNFTUVOVF8xX19fICsgXCIpO1xcblxcbiAgc3JjOiB1cmwoXCIgKyBfX19DU1NfTE9BREVSX1VSTF9SRVBMQUNFTUVOVF8yX19fICsgXCIpIGZvcm1hdCgnZW1iZWRkZWQtb3BlbnR5cGUnKSwgdXJsKFwiICsgX19fQ1NTX0xPQURFUl9VUkxfUkVQTEFDRU1FTlRfM19fXyArIFwiKSBmb3JtYXQoJ3dvZmYnKSwgdXJsKFwiICsgX19fQ1NTX0xPQURFUl9VUkxfUkVQTEFDRU1FTlRfNF9fXyArIFwiKSBmb3JtYXQoJ3RydWV0eXBlJyksIHVybChcIiArIF9fX0NTU19MT0FERVJfVVJMX1JFUExBQ0VNRU5UXzVfX18gKyBcIikgZm9ybWF0KCdzdmcnKTtcXG59XFxuXFxuLyogQXJyb3dzICovXFxuXFxuLnNsaWNrLXByZXYsXFxuLnNsaWNrLW5leHRcXG57XFxuICBmb250LXNpemU6IDA7XFxuICBsaW5lLWhlaWdodDogMDtcXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcXG4gIHRvcDogNTAlO1xcbiAgZGlzcGxheTogYmxvY2s7XFxuICB3aWR0aDogMjBweDtcXG4gIGhlaWdodDogMjBweDtcXG4gIHBhZGRpbmc6IDA7XFxuICB0cmFuc2Zvcm06IHRyYW5zbGF0ZSgwLCAtNTAlKTtcXG4gIGN1cnNvcjogcG9pbnRlcjtcXG4gIGNvbG9yOiB0cmFuc3BhcmVudDtcXG4gIGJvcmRlcjogbm9uZTtcXG4gIG91dGxpbmU6IG5vbmU7XFxuICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcXG59XFxuXFxuLnNsaWNrLXByZXY6aG92ZXIsXFxuLnNsaWNrLXByZXY6Zm9jdXMsXFxuLnNsaWNrLW5leHQ6aG92ZXIsXFxuLnNsaWNrLW5leHQ6Zm9jdXNcXG57XFxuICBjb2xvcjogdHJhbnNwYXJlbnQ7XFxuICBvdXRsaW5lOiBub25lO1xcbiAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XFxufVxcblxcbi5zbGljay1wcmV2OmhvdmVyOmJlZm9yZSxcXG4uc2xpY2stcHJldjpmb2N1czpiZWZvcmUsXFxuLnNsaWNrLW5leHQ6aG92ZXI6YmVmb3JlLFxcbi5zbGljay1uZXh0OmZvY3VzOmJlZm9yZVxcbntcXG4gIG9wYWNpdHk6IDE7XFxufVxcblxcbi5zbGljay1wcmV2LnNsaWNrLWRpc2FibGVkOmJlZm9yZSxcXG4uc2xpY2stbmV4dC5zbGljay1kaXNhYmxlZDpiZWZvcmVcXG57XFxuICBvcGFjaXR5OiAuMjU7XFxufVxcblxcbi5zbGljay1wcmV2OmJlZm9yZSxcXG4uc2xpY2stbmV4dDpiZWZvcmVcXG57XFxuICBmb250LWZhbWlseTogJ3NsaWNrJztcXG4gIGZvbnQtc2l6ZTogMjBweDtcXG4gIGxpbmUtaGVpZ2h0OiAxO1xcbiAgb3BhY2l0eTogLjc1O1xcbiAgY29sb3I6IHdoaXRlO1xcbiAgLXdlYmtpdC1mb250LXNtb290aGluZzogYW50aWFsaWFzZWQ7XFxuICAtbW96LW9zeC1mb250LXNtb290aGluZzogZ3JheXNjYWxlO1xcbn1cXG5cXG4uc2xpY2stcHJldlxcbntcXG4gIGxlZnQ6IC0yNXB4O1xcbn1cXG5cXG5bZGlyPSdydGwnXSAuc2xpY2stcHJldlxcbntcXG4gIHJpZ2h0OiAtMjVweDtcXG4gIGxlZnQ6IGF1dG87XFxufVxcblxcbi5zbGljay1wcmV2OmJlZm9yZVxcbntcXG4gIGNvbnRlbnQ6ICfihpAnO1xcbn1cXG5cXG5bZGlyPSdydGwnXSAuc2xpY2stcHJldjpiZWZvcmVcXG57XFxuICBjb250ZW50OiAn4oaSJztcXG59XFxuXFxuLnNsaWNrLW5leHRcXG57XFxuICByaWdodDogLTI1cHg7XFxufVxcblxcbltkaXI9J3J0bCddIC5zbGljay1uZXh0XFxue1xcbiAgcmlnaHQ6IGF1dG87XFxuICBsZWZ0OiAtMjVweDtcXG59XFxuXFxuLnNsaWNrLW5leHQ6YmVmb3JlXFxue1xcbiAgY29udGVudDogJ+KGkic7XFxufVxcblxcbltkaXI9J3J0bCddIC5zbGljay1uZXh0OmJlZm9yZVxcbntcXG4gIGNvbnRlbnQ6ICfihpAnO1xcbn1cXG5cXG4vKiBEb3RzICovXFxuXFxuLnNsaWNrLWRvdHRlZC5zbGljay1zbGlkZXJcXG57XFxuICBtYXJnaW4tYm90dG9tOiAzMHB4O1xcbn1cXG5cXG4uc2xpY2stZG90c1xcbntcXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcXG4gIGJvdHRvbTogLTI1cHg7XFxuICBkaXNwbGF5OiBibG9jaztcXG4gIHdpZHRoOiAxMDAlO1xcbiAgcGFkZGluZzogMDtcXG4gIG1hcmdpbjogMDtcXG4gIGxpc3Qtc3R5bGU6IG5vbmU7XFxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XFxufVxcblxcbi5zbGljay1kb3RzIGxpXFxue1xcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xcbiAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xcbiAgd2lkdGg6IDIwcHg7XFxuICBoZWlnaHQ6IDIwcHg7XFxuICBtYXJnaW46IDAgNXB4O1xcbiAgcGFkZGluZzogMDtcXG4gIGN1cnNvcjogcG9pbnRlcjtcXG59XFxuXFxuLnNsaWNrLWRvdHMgbGkgYnV0dG9uXFxue1xcbiAgZm9udC1zaXplOiAwO1xcbiAgbGluZS1oZWlnaHQ6IDA7XFxuICBkaXNwbGF5OiBibG9jaztcXG4gIHdpZHRoOiAyMHB4O1xcbiAgaGVpZ2h0OiAyMHB4O1xcbiAgcGFkZGluZzogNXB4O1xcbiAgY3Vyc29yOiBwb2ludGVyO1xcbiAgY29sb3I6IHRyYW5zcGFyZW50O1xcbiAgYm9yZGVyOiAwO1xcbiAgb3V0bGluZTogbm9uZTtcXG4gIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xcbn1cXG5cXG4uc2xpY2stZG90cyBsaSBidXR0b246aG92ZXIsXFxuLnNsaWNrLWRvdHMgbGkgYnV0dG9uOmZvY3VzXFxue1xcbiAgb3V0bGluZTogbm9uZTtcXG59XFxuXFxuLnNsaWNrLWRvdHMgbGkgYnV0dG9uOmhvdmVyOmJlZm9yZSxcXG4uc2xpY2stZG90cyBsaSBidXR0b246Zm9jdXM6YmVmb3JlXFxue1xcbiAgb3BhY2l0eTogMTtcXG59XFxuXFxuLnNsaWNrLWRvdHMgbGkgYnV0dG9uOmJlZm9yZVxcbntcXG4gIGZvbnQtZmFtaWx5OiAnc2xpY2snO1xcbiAgZm9udC1zaXplOiA2cHg7XFxuICBsaW5lLWhlaWdodDogMjBweDtcXG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcXG4gIHRvcDogMDtcXG4gIGxlZnQ6IDA7XFxuICB3aWR0aDogMjBweDtcXG4gIGhlaWdodDogMjBweDtcXG4gIGNvbnRlbnQ6ICfigKInO1xcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xcbiAgb3BhY2l0eTogLjI1O1xcbiAgY29sb3I6IGJsYWNrO1xcbiAgLXdlYmtpdC1mb250LXNtb290aGluZzogYW50aWFsaWFzZWQ7XFxuICAtbW96LW9zeC1mb250LXNtb290aGluZzogZ3JheXNjYWxlO1xcbn1cXG5cXG4uc2xpY2stZG90cyBsaS5zbGljay1hY3RpdmUgYnV0dG9uOmJlZm9yZVxcbntcXG4gIG9wYWNpdHk6IC43NTtcXG4gIGNvbG9yOiBibGFjaztcXG59XFxuXCIsIFwiXCIse1widmVyc2lvblwiOjMsXCJzb3VyY2VzXCI6W1wid2VicGFjazovL25vZGVfbW9kdWxlcy9zbGljay1jYXJvdXNlbC9zbGljay9zbGljay10aGVtZS5jc3NcIl0sXCJuYW1lc1wiOltdLFwibWFwcGluZ3NcIjpcIkFBQUEsZ0JBQWdCOztBQUNoQixXQUFXOztBQUNYOztFQUVJLGdGQUFpRTtBQUNyRTs7QUFFQSxVQUFVOztBQUNWOztFQUVJLG9CQUFvQjs7RUFDcEIsbUJBQW1COztFQUNuQixrQkFBa0I7O0VBRWxCLDRDQUE2Qjs7RUFDN0IsbVBBQXFNO0FBQ3pNOztBQUNBLFdBQVc7O0FBQ1g7OztFQUdJLFlBQVk7RUFDWixjQUFjO0VBRWQsa0JBQWtCO0VBQ2xCLFFBQVE7RUFFUixjQUFjO0VBRWQsV0FBVztFQUNYLFlBQVk7RUFDWixVQUFVO0VBR1YsNkJBQTZCO0VBRTdCLGVBQWU7RUFFZixrQkFBa0I7RUFDbEIsWUFBWTtFQUNaLGFBQWE7RUFDYix1QkFBdUI7QUFDM0I7O0FBQ0E7Ozs7O0VBS0ksa0JBQWtCO0VBQ2xCLGFBQWE7RUFDYix1QkFBdUI7QUFDM0I7O0FBQ0E7Ozs7O0VBS0ksVUFBVTtBQUNkOztBQUNBOzs7RUFHSSxZQUFZO0FBQ2hCOztBQUVBOzs7RUFHSSxvQkFBb0I7RUFDcEIsZUFBZTtFQUNmLGNBQWM7RUFFZCxZQUFZO0VBQ1osWUFBWTtFQUVaLG1DQUFtQztFQUNuQyxrQ0FBa0M7QUFDdEM7O0FBRUE7O0VBRUksV0FBVztBQUNmOztBQUNBOztFQUVJLFlBQVk7RUFDWixVQUFVO0FBQ2Q7O0FBQ0E7O0VBRUksWUFBWTtBQUNoQjs7QUFDQTs7RUFFSSxZQUFZO0FBQ2hCOztBQUVBOztFQUVJLFlBQVk7QUFDaEI7O0FBQ0E7O0VBRUksV0FBVztFQUNYLFdBQVc7QUFDZjs7QUFDQTs7RUFFSSxZQUFZO0FBQ2hCOztBQUNBOztFQUVJLFlBQVk7QUFDaEI7O0FBRUEsU0FBUzs7QUFDVDs7RUFFSSxtQkFBbUI7QUFDdkI7O0FBRUE7O0VBRUksa0JBQWtCO0VBQ2xCLGFBQWE7RUFFYixjQUFjO0VBRWQsV0FBVztFQUNYLFVBQVU7RUFDVixTQUFTO0VBRVQsZ0JBQWdCO0VBRWhCLGtCQUFrQjtBQUN0Qjs7QUFDQTs7RUFFSSxrQkFBa0I7RUFFbEIscUJBQXFCO0VBRXJCLFdBQVc7RUFDWCxZQUFZO0VBQ1osYUFBYTtFQUNiLFVBQVU7RUFFVixlQUFlO0FBQ25COztBQUNBOztFQUVJLFlBQVk7RUFDWixjQUFjO0VBRWQsY0FBYztFQUVkLFdBQVc7RUFDWCxZQUFZO0VBQ1osWUFBWTtFQUVaLGVBQWU7RUFFZixrQkFBa0I7RUFDbEIsU0FBUztFQUNULGFBQWE7RUFDYix1QkFBdUI7QUFDM0I7O0FBQ0E7OztFQUdJLGFBQWE7QUFDakI7O0FBQ0E7OztFQUdJLFVBQVU7QUFDZDs7QUFDQTs7RUFFSSxvQkFBb0I7RUFDcEIsY0FBYztFQUNkLGlCQUFpQjtFQUVqQixrQkFBa0I7RUFDbEIsTUFBTTtFQUNOLE9BQU87RUFFUCxXQUFXO0VBQ1gsWUFBWTtFQUVaLFlBQVk7RUFDWixrQkFBa0I7RUFFbEIsWUFBWTtFQUNaLFlBQVk7RUFFWixtQ0FBbUM7RUFDbkMsa0NBQWtDO0FBQ3RDOztBQUNBOztFQUVJLFlBQVk7RUFDWixZQUFZO0FBQ2hCXCIsXCJzb3VyY2VzQ29udGVudFwiOltcIkBjaGFyc2V0ICdVVEYtOCc7XFxuLyogU2xpZGVyICovXFxuLnNsaWNrLWxvYWRpbmcgLnNsaWNrLWxpc3RcXG57XFxuICAgIGJhY2tncm91bmQ6ICNmZmYgdXJsKCcuL2FqYXgtbG9hZGVyLmdpZicpIGNlbnRlciBjZW50ZXIgbm8tcmVwZWF0O1xcbn1cXG5cXG4vKiBJY29ucyAqL1xcbkBmb250LWZhY2VcXG57XFxuICAgIGZvbnQtZmFtaWx5OiAnc2xpY2snO1xcbiAgICBmb250LXdlaWdodDogbm9ybWFsO1xcbiAgICBmb250LXN0eWxlOiBub3JtYWw7XFxuXFxuICAgIHNyYzogdXJsKCcuL2ZvbnRzL3NsaWNrLmVvdCcpO1xcbiAgICBzcmM6IHVybCgnLi9mb250cy9zbGljay5lb3Q/I2llZml4JykgZm9ybWF0KCdlbWJlZGRlZC1vcGVudHlwZScpLCB1cmwoJy4vZm9udHMvc2xpY2sud29mZicpIGZvcm1hdCgnd29mZicpLCB1cmwoJy4vZm9udHMvc2xpY2sudHRmJykgZm9ybWF0KCd0cnVldHlwZScpLCB1cmwoJy4vZm9udHMvc2xpY2suc3ZnI3NsaWNrJykgZm9ybWF0KCdzdmcnKTtcXG59XFxuLyogQXJyb3dzICovXFxuLnNsaWNrLXByZXYsXFxuLnNsaWNrLW5leHRcXG57XFxuICAgIGZvbnQtc2l6ZTogMDtcXG4gICAgbGluZS1oZWlnaHQ6IDA7XFxuXFxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcXG4gICAgdG9wOiA1MCU7XFxuXFxuICAgIGRpc3BsYXk6IGJsb2NrO1xcblxcbiAgICB3aWR0aDogMjBweDtcXG4gICAgaGVpZ2h0OiAyMHB4O1xcbiAgICBwYWRkaW5nOiAwO1xcbiAgICAtd2Via2l0LXRyYW5zZm9ybTogdHJhbnNsYXRlKDAsIC01MCUpO1xcbiAgICAtbXMtdHJhbnNmb3JtOiB0cmFuc2xhdGUoMCwgLTUwJSk7XFxuICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlKDAsIC01MCUpO1xcblxcbiAgICBjdXJzb3I6IHBvaW50ZXI7XFxuXFxuICAgIGNvbG9yOiB0cmFuc3BhcmVudDtcXG4gICAgYm9yZGVyOiBub25lO1xcbiAgICBvdXRsaW5lOiBub25lO1xcbiAgICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcXG59XFxuLnNsaWNrLXByZXY6aG92ZXIsXFxuLnNsaWNrLXByZXY6Zm9jdXMsXFxuLnNsaWNrLW5leHQ6aG92ZXIsXFxuLnNsaWNrLW5leHQ6Zm9jdXNcXG57XFxuICAgIGNvbG9yOiB0cmFuc3BhcmVudDtcXG4gICAgb3V0bGluZTogbm9uZTtcXG4gICAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XFxufVxcbi5zbGljay1wcmV2OmhvdmVyOmJlZm9yZSxcXG4uc2xpY2stcHJldjpmb2N1czpiZWZvcmUsXFxuLnNsaWNrLW5leHQ6aG92ZXI6YmVmb3JlLFxcbi5zbGljay1uZXh0OmZvY3VzOmJlZm9yZVxcbntcXG4gICAgb3BhY2l0eTogMTtcXG59XFxuLnNsaWNrLXByZXYuc2xpY2stZGlzYWJsZWQ6YmVmb3JlLFxcbi5zbGljay1uZXh0LnNsaWNrLWRpc2FibGVkOmJlZm9yZVxcbntcXG4gICAgb3BhY2l0eTogLjI1O1xcbn1cXG5cXG4uc2xpY2stcHJldjpiZWZvcmUsXFxuLnNsaWNrLW5leHQ6YmVmb3JlXFxue1xcbiAgICBmb250LWZhbWlseTogJ3NsaWNrJztcXG4gICAgZm9udC1zaXplOiAyMHB4O1xcbiAgICBsaW5lLWhlaWdodDogMTtcXG5cXG4gICAgb3BhY2l0eTogLjc1O1xcbiAgICBjb2xvcjogd2hpdGU7XFxuXFxuICAgIC13ZWJraXQtZm9udC1zbW9vdGhpbmc6IGFudGlhbGlhc2VkO1xcbiAgICAtbW96LW9zeC1mb250LXNtb290aGluZzogZ3JheXNjYWxlO1xcbn1cXG5cXG4uc2xpY2stcHJldlxcbntcXG4gICAgbGVmdDogLTI1cHg7XFxufVxcbltkaXI9J3J0bCddIC5zbGljay1wcmV2XFxue1xcbiAgICByaWdodDogLTI1cHg7XFxuICAgIGxlZnQ6IGF1dG87XFxufVxcbi5zbGljay1wcmV2OmJlZm9yZVxcbntcXG4gICAgY29udGVudDogJ+KGkCc7XFxufVxcbltkaXI9J3J0bCddIC5zbGljay1wcmV2OmJlZm9yZVxcbntcXG4gICAgY29udGVudDogJ+KGkic7XFxufVxcblxcbi5zbGljay1uZXh0XFxue1xcbiAgICByaWdodDogLTI1cHg7XFxufVxcbltkaXI9J3J0bCddIC5zbGljay1uZXh0XFxue1xcbiAgICByaWdodDogYXV0bztcXG4gICAgbGVmdDogLTI1cHg7XFxufVxcbi5zbGljay1uZXh0OmJlZm9yZVxcbntcXG4gICAgY29udGVudDogJ+KGkic7XFxufVxcbltkaXI9J3J0bCddIC5zbGljay1uZXh0OmJlZm9yZVxcbntcXG4gICAgY29udGVudDogJ+KGkCc7XFxufVxcblxcbi8qIERvdHMgKi9cXG4uc2xpY2stZG90dGVkLnNsaWNrLXNsaWRlclxcbntcXG4gICAgbWFyZ2luLWJvdHRvbTogMzBweDtcXG59XFxuXFxuLnNsaWNrLWRvdHNcXG57XFxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcXG4gICAgYm90dG9tOiAtMjVweDtcXG5cXG4gICAgZGlzcGxheTogYmxvY2s7XFxuXFxuICAgIHdpZHRoOiAxMDAlO1xcbiAgICBwYWRkaW5nOiAwO1xcbiAgICBtYXJnaW46IDA7XFxuXFxuICAgIGxpc3Qtc3R5bGU6IG5vbmU7XFxuXFxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcXG59XFxuLnNsaWNrLWRvdHMgbGlcXG57XFxuICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcXG5cXG4gICAgZGlzcGxheTogaW5saW5lLWJsb2NrO1xcblxcbiAgICB3aWR0aDogMjBweDtcXG4gICAgaGVpZ2h0OiAyMHB4O1xcbiAgICBtYXJnaW46IDAgNXB4O1xcbiAgICBwYWRkaW5nOiAwO1xcblxcbiAgICBjdXJzb3I6IHBvaW50ZXI7XFxufVxcbi5zbGljay1kb3RzIGxpIGJ1dHRvblxcbntcXG4gICAgZm9udC1zaXplOiAwO1xcbiAgICBsaW5lLWhlaWdodDogMDtcXG5cXG4gICAgZGlzcGxheTogYmxvY2s7XFxuXFxuICAgIHdpZHRoOiAyMHB4O1xcbiAgICBoZWlnaHQ6IDIwcHg7XFxuICAgIHBhZGRpbmc6IDVweDtcXG5cXG4gICAgY3Vyc29yOiBwb2ludGVyO1xcblxcbiAgICBjb2xvcjogdHJhbnNwYXJlbnQ7XFxuICAgIGJvcmRlcjogMDtcXG4gICAgb3V0bGluZTogbm9uZTtcXG4gICAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XFxufVxcbi5zbGljay1kb3RzIGxpIGJ1dHRvbjpob3ZlcixcXG4uc2xpY2stZG90cyBsaSBidXR0b246Zm9jdXNcXG57XFxuICAgIG91dGxpbmU6IG5vbmU7XFxufVxcbi5zbGljay1kb3RzIGxpIGJ1dHRvbjpob3ZlcjpiZWZvcmUsXFxuLnNsaWNrLWRvdHMgbGkgYnV0dG9uOmZvY3VzOmJlZm9yZVxcbntcXG4gICAgb3BhY2l0eTogMTtcXG59XFxuLnNsaWNrLWRvdHMgbGkgYnV0dG9uOmJlZm9yZVxcbntcXG4gICAgZm9udC1mYW1pbHk6ICdzbGljayc7XFxuICAgIGZvbnQtc2l6ZTogNnB4O1xcbiAgICBsaW5lLWhlaWdodDogMjBweDtcXG5cXG4gICAgcG9zaXRpb246IGFic29sdXRlO1xcbiAgICB0b3A6IDA7XFxuICAgIGxlZnQ6IDA7XFxuXFxuICAgIHdpZHRoOiAyMHB4O1xcbiAgICBoZWlnaHQ6IDIwcHg7XFxuXFxuICAgIGNvbnRlbnQ6ICfigKInO1xcbiAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XFxuXFxuICAgIG9wYWNpdHk6IC4yNTtcXG4gICAgY29sb3I6IGJsYWNrO1xcblxcbiAgICAtd2Via2l0LWZvbnQtc21vb3RoaW5nOiBhbnRpYWxpYXNlZDtcXG4gICAgLW1vei1vc3gtZm9udC1zbW9vdGhpbmc6IGdyYXlzY2FsZTtcXG59XFxuLnNsaWNrLWRvdHMgbGkuc2xpY2stYWN0aXZlIGJ1dHRvbjpiZWZvcmVcXG57XFxuICAgIG9wYWNpdHk6IC43NTtcXG4gICAgY29sb3I6IGJsYWNrO1xcbn1cXG5cIl0sXCJzb3VyY2VSb290XCI6XCJcIn1dKTtcbi8vIEV4cG9ydHNcbmV4cG9ydCBkZWZhdWx0IF9fX0NTU19MT0FERVJfRVhQT1JUX19fO1xuIiwibW9kdWxlLmV4cG9ydHM9ZnVuY3Rpb24oKXtcInVzZSBzdHJpY3RcIjt2YXIgZT17OTE6ZnVuY3Rpb24oZSl7ZS5leHBvcnRzPWZ1bmN0aW9uKGUscil7aWYoIXIpe3I9e319ZT1lJiZlLl9fZXNNb2R1bGU/ZS5kZWZhdWx0OmU7aWYodHlwZW9mIGUhPT1cInN0cmluZ1wiKXtyZXR1cm4gZX1pZigvXlsnXCJdLipbJ1wiXSQvLnRlc3QoZSkpe2U9ZS5zbGljZSgxLC0xKX1pZihyLmhhc2gpe2UrPXIuaGFzaH1pZigvW1wiJygpIFxcdFxcbl0vLnRlc3QoZSl8fHIubmVlZFF1b3Rlcyl7cmV0dXJuJ1wiJy5jb25jYXQoZS5yZXBsYWNlKC9cIi9nLCdcXFxcXCInKS5yZXBsYWNlKC9cXG4vZyxcIlxcXFxuXCIpLCdcIicpfXJldHVybiBlfX19O3ZhciByPXt9O2Z1bmN0aW9uIF9fbmNjd3Bja19yZXF1aXJlX18odCl7aWYoclt0XSl7cmV0dXJuIHJbdF0uZXhwb3J0c312YXIgXz1yW3RdPXtleHBvcnRzOnt9fTt2YXIgbj10cnVlO3RyeXtlW3RdKF8sXy5leHBvcnRzLF9fbmNjd3Bja19yZXF1aXJlX18pO249ZmFsc2V9ZmluYWxseXtpZihuKWRlbGV0ZSByW3RdfXJldHVybiBfLmV4cG9ydHN9X19uY2N3cGNrX3JlcXVpcmVfXy5hYj1fX2Rpcm5hbWUrXCIvXCI7cmV0dXJuIF9fbmNjd3Bja19yZXF1aXJlX18oOTEpfSgpOyIsImV4cG9ydCBkZWZhdWx0IF9fd2VicGFja19wdWJsaWNfcGF0aF9fICsgXCJzdGF0aWMvbWVkaWEvYWpheC1sb2FkZXIuZmI2ZjNjMjMwY2I4NDZlMjUyNDdkZmFhMWRhOTRkOGYuZ2lmXCI7IiwiZXhwb3J0IGRlZmF1bHQgX193ZWJwYWNrX3B1YmxpY19wYXRoX18gKyBcInN0YXRpYy9tZWRpYS9zbGljay5hNGU5N2Y1YTJhNjRmMGFiMTMyMzIzZmJlYjMzYWUyOS5lb3RcIjsiLCJleHBvcnQgZGVmYXVsdCBfX3dlYnBhY2tfcHVibGljX3BhdGhfXyArIFwic3RhdGljL21lZGlhL3NsaWNrLjI2MzBhM2UzZWFiMjFjNjA3ZTIxNTc2NTcxYjk1YjlkLnN2Z1wiOyIsImV4cG9ydCBkZWZhdWx0IF9fd2VicGFja19wdWJsaWNfcGF0aF9fICsgXCJzdGF0aWMvbWVkaWEvc2xpY2suYzk0Zjc2NzFkY2M5OWRjZTQzZTIyYTg5ZjQ4NmY3YzIudHRmXCI7IiwiZXhwb3J0IGRlZmF1bHQgX193ZWJwYWNrX3B1YmxpY19wYXRoX18gKyBcInN0YXRpYy9tZWRpYS9zbGljay4yOTUxODM3ODZjZDhhMTM4OTg2NTIxZDlmMzg4YTI4Ni53b2ZmXCI7IiwidmFyIGFwaSA9IHJlcXVpcmUoXCIhLi4vLi4vbmV4dC9kaXN0L2J1aWxkL3dlYnBhY2svbG9hZGVycy9uZXh0LXN0eWxlLWxvYWRlci9ydW50aW1lL2luamVjdFN0eWxlc0ludG9TdHlsZVRhZy5qc1wiKTtcbiAgICAgICAgICAgIHZhciBjb250ZW50ID0gcmVxdWlyZShcIiEhLi4vLi4vbmV4dC9kaXN0L2NvbXBpbGVkL2Nzcy1sb2FkZXIvY2pzLmpzPz9yZWYtLTUtb25lT2YtNS0xIS4uLy4uL25leHQvZGlzdC9jb21waWxlZC9wb3N0Y3NzLWxvYWRlci9janMuanM/P3JlZi0tNS1vbmVPZi01LTIhLi9zbGljay10aGVtZS5jc3NcIik7XG5cbiAgICAgICAgICAgIGNvbnRlbnQgPSBjb250ZW50Ll9fZXNNb2R1bGUgPyBjb250ZW50LmRlZmF1bHQgOiBjb250ZW50O1xuXG4gICAgICAgICAgICBpZiAodHlwZW9mIGNvbnRlbnQgPT09ICdzdHJpbmcnKSB7XG4gICAgICAgICAgICAgIGNvbnRlbnQgPSBbW21vZHVsZS5pZCwgY29udGVudCwgJyddXTtcbiAgICAgICAgICAgIH1cblxudmFyIG9wdGlvbnMgPSB7fTtcblxub3B0aW9ucy5pbnNlcnQgPSBmdW5jdGlvbihlbGVtZW50KXsvLyBUaGVzZSBlbGVtZW50cyBzaG91bGQgYWx3YXlzIGV4aXN0LiBJZiB0aGV5IGRvIG5vdCxcbi8vIHRoaXMgY29kZSBzaG91bGQgZmFpbC5cbnZhciBhbmNob3JFbGVtZW50PWRvY3VtZW50LnF1ZXJ5U2VsZWN0b3IoJyNfX25leHRfY3NzX19ET19OT1RfVVNFX18nKTt2YXIgcGFyZW50Tm9kZT1hbmNob3JFbGVtZW50LnBhcmVudE5vZGU7Ly8gTm9ybWFsbHkgPGhlYWQ+XG4vLyBFYWNoIHN0eWxlIHRhZyBzaG91bGQgYmUgcGxhY2VkIHJpZ2h0IGJlZm9yZSBvdXJcbi8vIGFuY2hvci4gQnkgaW5zZXJ0aW5nIGJlZm9yZSBhbmQgbm90IGFmdGVyLCB3ZSBkbyBub3Rcbi8vIG5lZWQgdG8gdHJhY2sgdGhlIGxhc3QgaW5zZXJ0ZWQgZWxlbWVudC5cbnBhcmVudE5vZGUuaW5zZXJ0QmVmb3JlKGVsZW1lbnQsYW5jaG9yRWxlbWVudCk7fTtcbm9wdGlvbnMuc2luZ2xldG9uID0gZmFsc2U7XG5cbnZhciB1cGRhdGUgPSBhcGkoY29udGVudCwgb3B0aW9ucyk7XG5cblxuaWYgKG1vZHVsZS5ob3QpIHtcbiAgaWYgKCFjb250ZW50LmxvY2FscyB8fCBtb2R1bGUuaG90LmludmFsaWRhdGUpIHtcbiAgICB2YXIgaXNFcXVhbExvY2FscyA9IGZ1bmN0aW9uIGlzRXF1YWxMb2NhbHMoYSxiLGlzTmFtZWRFeHBvcnQpe2lmKCFhJiZifHxhJiYhYil7cmV0dXJuIGZhbHNlO31sZXQgcDtmb3IocCBpbiBhKXtpZihpc05hbWVkRXhwb3J0JiZwPT09J2RlZmF1bHQnKXsvLyBlc2xpbnQtZGlzYWJsZS1uZXh0LWxpbmUgbm8tY29udGludWVcbmNvbnRpbnVlO31pZihhW3BdIT09YltwXSl7cmV0dXJuIGZhbHNlO319Zm9yKHAgaW4gYil7aWYoaXNOYW1lZEV4cG9ydCYmcD09PSdkZWZhdWx0Jyl7Ly8gZXNsaW50LWRpc2FibGUtbmV4dC1saW5lIG5vLWNvbnRpbnVlXG5jb250aW51ZTt9aWYoIWFbcF0pe3JldHVybiBmYWxzZTt9fXJldHVybiB0cnVlO307XG4gICAgdmFyIG9sZExvY2FscyA9IGNvbnRlbnQubG9jYWxzO1xuXG4gICAgbW9kdWxlLmhvdC5hY2NlcHQoXG4gICAgICBcIiEhLi4vLi4vbmV4dC9kaXN0L2NvbXBpbGVkL2Nzcy1sb2FkZXIvY2pzLmpzPz9yZWYtLTUtb25lT2YtNS0xIS4uLy4uL25leHQvZGlzdC9jb21waWxlZC9wb3N0Y3NzLWxvYWRlci9janMuanM/P3JlZi0tNS1vbmVPZi01LTIhLi9zbGljay10aGVtZS5jc3NcIixcbiAgICAgIGZ1bmN0aW9uICgpIHtcbiAgICAgICAgY29udGVudCA9IHJlcXVpcmUoXCIhIS4uLy4uL25leHQvZGlzdC9jb21waWxlZC9jc3MtbG9hZGVyL2Nqcy5qcz8/cmVmLS01LW9uZU9mLTUtMSEuLi8uLi9uZXh0L2Rpc3QvY29tcGlsZWQvcG9zdGNzcy1sb2FkZXIvY2pzLmpzPz9yZWYtLTUtb25lT2YtNS0yIS4vc2xpY2stdGhlbWUuY3NzXCIpO1xuXG4gICAgICAgICAgICAgIGNvbnRlbnQgPSBjb250ZW50Ll9fZXNNb2R1bGUgPyBjb250ZW50LmRlZmF1bHQgOiBjb250ZW50O1xuXG4gICAgICAgICAgICAgIGlmICh0eXBlb2YgY29udGVudCA9PT0gJ3N0cmluZycpIHtcbiAgICAgICAgICAgICAgICBjb250ZW50ID0gW1ttb2R1bGUuaWQsIGNvbnRlbnQsICcnXV07XG4gICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgICBpZiAoIWlzRXF1YWxMb2NhbHMob2xkTG9jYWxzLCBjb250ZW50LmxvY2FscykpIHtcbiAgICAgICAgICAgICAgICBtb2R1bGUuaG90LmludmFsaWRhdGUoKTtcblxuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgIG9sZExvY2FscyA9IGNvbnRlbnQubG9jYWxzO1xuXG4gICAgICAgICAgICAgIHVwZGF0ZShjb250ZW50KTtcbiAgICAgIH1cbiAgICApXG4gIH1cblxuICBtb2R1bGUuaG90LmRpc3Bvc2UoZnVuY3Rpb24oKSB7XG4gICAgdXBkYXRlKCk7XG4gIH0pO1xufVxuXG5tb2R1bGUuZXhwb3J0cyA9IGNvbnRlbnQubG9jYWxzIHx8IHt9OyIsImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IEltYWdlIH0gZnJvbSBcIkBjb21wb25lbnRzXCI7XG5pbXBvcnQgU2xpZGVyIGZyb20gXCJyZWFjdC1zbGlja1wiO1xuaW1wb3J0IFwic2xpY2stY2Fyb3VzZWwvc2xpY2svc2xpY2suY3NzXCI7XG5pbXBvcnQgXCJzbGljay1jYXJvdXNlbC9zbGljay9zbGljay10aGVtZS5jc3NcIjtcblxuZXhwb3J0IHR5cGUgUHJvcHMgPSB7XG4gIG5hbWVzPzogQXJyYXk8c3RyaW5nPjtcbiAgYmFja2dyb3VuZF91cmw/OiBzdHJpbmc7XG4gIHRhZ3M/OiBBcnJheTxzdHJpbmc+O1xuICBsb2dvPzogc3RyaW5nO1xuICBjbGFzc05hbWU/OiBzdHJpbmc7XG4gIHN0eWxlPzogYW55O1xufTtcblxuZXhwb3J0IGNvbnN0IEZvdW5kZXI6IFJlYWN0LkZDPFByb3BzPiA9ICh7IGNsYXNzTmFtZSwgc3R5bGUgPSB7fSB9KSA9PiB7XG4gIGNvbnN0IHNldHRpbmdzID0ge1xuICAgIGRvdHM6IHRydWUsXG4gICAgaW5maW5pdGU6IHRydWUsXG4gICAgc3BlZWQ6IDUwMCxcbiAgICBzbGlkZXNUb1Nob3c6IDEsXG4gICAgc2xpZGVzVG9TY3JvbGw6IDFcbiAgfTtcbiAgcmV0dXJuIChcbiAgICA8ZGl2PlxuICAgICAgPGRpdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9e2Ake2NsYXNzTmFtZX1gfSBzdHlsZT17eyB3aWR0aDogNjE1Ljk0LCBoZWlnaHQ6IDg2My45MSwgcG9zaXRpb246IFwicmVsYXRpdmVcIiwgLi4uc3R5bGUsIH19PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiXCIgc3R5bGU9e3sgd2lkdGg6IDU3MSwgaGVpZ2h0OiA3NjIsIHBvc2l0aW9uOiBcImFic29sdXRlXCIsIGJhY2tncm91bmQ6IFwiIzA4M0E0QVwiLCBib3R0b206IDUwLCBsZWZ0OiAwLCB9fT48L2Rpdj5cbiAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJcIlxuICAgICAgICAgICAgc3R5bGU9e3sgd2lkdGg6IDU5NCwgaGVpZ2h0OiA3ODgsIGJvdHRvbTogNjUsIGxlZnQ6IDE1LCBwb3NpdGlvbjogXCJhYnNvbHV0ZVwiLCBkaXNwbGF5OiBcImZsZXhcIiwgZmxleERpcmVjdGlvbjogXCJjb2x1bW5cIiwgfX0+XG4gICAgICAgICAgICA8SW1hZ2Ugc3JjPVwiL2ljb25zL0JoYXZpc2hfaW1hZ2Uuc3ZnXCIgYWx0PVwiZm91bmRlciBpbWFnZVwiIHN0eWxlPXt7IGZsZXhHcm93OiAxIH19PjwvSW1hZ2U+XG4gICAgICAgICAgICA8SW1hZ2Ugc3JjPVwiL2ljb25zL3JlY3RhbmdsZS5zdmdcIiBhbHQ9e1wicmVhY3RhbmdsZVwifSBjbGFzc05hbWU9XCJhYnNvbHV0ZVwiIHN0eWxlPXt7IGxlZnQ6IDM4LCBib3R0b206IDI1NCB9fSAvPlxuXG4gICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGhlaWdodDogMjA5LCBiYWNrZ3JvdW5kOiBcIiMwMTU3NkVcIiB9fT5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBmbGV4IGl0ZW1zLWNlbnRlclwiIHN0eWxlPXt7IGhlaWdodDogMTE4LCBib3JkZXJCb3R0b206IFwiMXB4IHNvbGlkICNFQkVCRTlcIiB9fT5cbiAgICAgICAgICAgICAgICA8aDYgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtc2Vjb25kYXJ5XCIgc3R5bGU9e3sgZm9udFNpemU6IDMyLCBsaW5lSGVpZ2h0OiBcIjM2cHhcIiwgbGV0dGVyU3BhY2luZzogXCIwLjA1ZW1cIiwgbWFyZ2luTGVmdDogMzEsIG1hcmdpblJpZ2h0OiA4LCB9fT5cbiAgICAgICAgICAgICAgICAgIEJIQVZJU0hcbiAgICAgICAgICAgICAgPC9oNj5cbiAgICAgICAgICAgICAgICA8aDYgY2xhc3NOYW1lPVwiZm9udC1saWdodCB0ZXh0LXNlY29uZGFyeVwiIHN0eWxlPXt7IGZvbnRTaXplOiAzMiwgbGluZUhlaWdodDogXCIzNnB4XCIsIGxldHRlclNwYWNpbmc6IFwiMC4wNWVtXCIsIH19PlxuICAgICAgICAgICAgICAgICAgQUdHQVJXQUxcbiAgICAgICAgICAgICAgPC9oNj5cbiAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXJcIiBzdHlsZT17eyBoZWlnaHQ6IDg4IH19PlxuICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgbWFyZ2luTGVmdDogMzEgfX0+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNlY29uZGFyeSBmb250LW1lZGl1bSB0ZXh0LWxnIGxlYWRpbmctNlwiPiBNb2JpbGl0eTwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICA8SW1hZ2Ugc3JjPXtcIi9pY29ucy9vbGEuc3ZnXCJ9IGFsdD17XCJvbGFcIn0gc3R5bGU9e3sgbWFyZ2luUmlnaHQ6IDU3IH19IC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgICA8ZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YCR7Y2xhc3NOYW1lfWB9IHN0eWxlPXt7IHdpZHRoOiA2MTUuOTQsIGhlaWdodDogODYzLjkxLCBwb3NpdGlvbjogXCJyZWxhdGl2ZVwiLCAuLi5zdHlsZSwgfX0+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJcIiBzdHlsZT17eyB3aWR0aDogNTcxLCBoZWlnaHQ6IDc2MiwgcG9zaXRpb246IFwiYWJzb2x1dGVcIiwgYmFja2dyb3VuZDogXCIjMDgzQTRBXCIsIGJvdHRvbTogNTAsIGxlZnQ6IDAsIH19PjwvZGl2PlxuICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cIlwiXG4gICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogNTk0LCBoZWlnaHQ6IDc4OCwgYm90dG9tOiA2NSwgbGVmdDogMTUsIHBvc2l0aW9uOiBcImFic29sdXRlXCIsIGRpc3BsYXk6IFwiZmxleFwiLCBmbGV4RGlyZWN0aW9uOiBcImNvbHVtblwiLCB9fT5cbiAgICAgICAgICAgIDxJbWFnZSBzcmM9XCIvaWNvbnMvQmhhdmlzaF9pbWFnZS5zdmdcIiBhbHQ9XCJmb3VuZGVyIGltYWdlXCIgc3R5bGU9e3sgZmxleEdyb3c6IDEgfX0+PC9JbWFnZT5cbiAgICAgICAgICAgIDxJbWFnZSBzcmM9XCIvaWNvbnMvcmVjdGFuZ2xlLnN2Z1wiIGFsdD17XCJyZWFjdGFuZ2xlXCJ9IGNsYXNzTmFtZT1cImFic29sdXRlXCIgc3R5bGU9e3sgbGVmdDogMzgsIGJvdHRvbTogMjU0IH19IC8+XG5cbiAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgaGVpZ2h0OiAyMDksIGJhY2tncm91bmQ6IFwiIzAxNTc2RVwiIH19PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIGZsZXggaXRlbXMtY2VudGVyXCIgc3R5bGU9e3sgaGVpZ2h0OiAxMTgsIGJvcmRlckJvdHRvbTogXCIxcHggc29saWQgI0VCRUJFOVwiIH19PlxuICAgICAgICAgICAgICAgIDxoNiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zZWNvbmRhcnlcIiBzdHlsZT17eyBmb250U2l6ZTogMzIsIGxpbmVIZWlnaHQ6IFwiMzZweFwiLCBsZXR0ZXJTcGFjaW5nOiBcIjAuMDVlbVwiLCBtYXJnaW5MZWZ0OiAzMSwgbWFyZ2luUmlnaHQ6IDgsIH19PlxuICAgICAgICAgICAgICAgICAgQkhBVklTSFxuICAgICAgICAgICAgPC9oNj5cbiAgICAgICAgICAgICAgICA8aDYgY2xhc3NOYW1lPVwiZm9udC1saWdodCB0ZXh0LXNlY29uZGFyeVwiIHN0eWxlPXt7IGZvbnRTaXplOiAzMiwgbGluZUhlaWdodDogXCIzNnB4XCIsIGxldHRlclNwYWNpbmc6IFwiMC4wNWVtXCIsIH19PlxuICAgICAgICAgICAgICAgICAgQUdHQVJXQUxcbiAgICAgICAgICAgIDwvaDY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyXCIgc3R5bGU9e3sgaGVpZ2h0OiA4OCB9fT5cbiAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IG1hcmdpbkxlZnQ6IDMxIH19PlxuICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zZWNvbmRhcnkgZm9udC1tZWRpdW0gdGV4dC1sZyBsZWFkaW5nLTZcIj4gTW9iaWxpdHk8L3NwYW4+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPEltYWdlIHNyYz17XCIvaWNvbnMvb2xhLnN2Z1wifSBhbHQ9e1wib2xhXCJ9IHN0eWxlPXt7IG1hcmdpblJpZ2h0OiA1NyB9fSAvPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgICAgPFNsaWRlciB7Li4uc2V0dGluZ3N9PlxuICAgICAgICA8ZGl2PmxrZGZ2ZDwvZGl2PlxuICAgICAgICA8ZGl2PmxrZGZ2ZDwvZGl2PlxuICAgICAgICA8ZGl2PmxrZGZ2ZDwvZGl2PlxuICAgICAgPC9TbGlkZXI+XG4gICAgPC9kaXY+XG4gICk7XG59O1xuIl0sInNvdXJjZVJvb3QiOiIifQ==