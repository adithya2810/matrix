webpackHotUpdate_N_E("pages/home",{

/***/ "./src/components/founder/Founder.tsx":
/*!********************************************!*\
  !*** ./src/components/founder/Founder.tsx ***!
  \********************************************/
/*! exports provided: Founder */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Founder", function() { return Founder; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var C_Users_KARTHIK_Documents_workspace_matrix_cms_ui_development_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @components */ "./src/components/index.ts");
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-slick */ "./node_modules/react-slick/lib/index.js");
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_slick__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! slick-carousel/slick/slick.css */ "./node_modules/slick-carousel/slick/slick.css");
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! slick-carousel/slick/slick-theme.css */ "./node_modules/slick-carousel/slick/slick-theme.css");
/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_6__);



var _jsxFileName = "C:\\Users\\KARTHIK\\Documents\\workspace\\matrix-cms-ui-development\\src\\components\\founder\\Founder.tsx",
    _this = undefined;

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { Object(C_Users_KARTHIK_Documents_workspace_matrix_cms_ui_development_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__["default"])(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }






var Founder = function Founder(_ref) {
  var className = _ref.className,
      _ref$style = _ref.style,
      style = _ref$style === void 0 ? {} : _ref$style;
  var settings = {
    dots: true,
    infinite: true,
    speed: 500,
    // autoplaySpeed: 2000,
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true
  };
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_slick__WEBPACK_IMPORTED_MODULE_4___default.a, _objectSpread(_objectSpread({}, settings), {}, {
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "".concat(className),
        style: _objectSpread({
          width: 615.94,
          height: 863.91,
          position: "relative"
        }, style),
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "",
          style: {
            width: 571,
            height: 762,
            position: "absolute",
            background: "#083A4A",
            bottom: 50,
            left: 0
          }
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 30,
          columnNumber: 11
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "",
          style: {
            width: 594,
            height: 788,
            bottom: 65,
            left: 15,
            position: "absolute",
            display: "flex",
            flexDirection: "column"
          },
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_3__["Image"], {
            src: "/icons/Bhavish_image.svg",
            alt: "founder image",
            style: {
              flexGrow: 1
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 34,
            columnNumber: 13
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_3__["Image"], {
            src: "/icons/rectangle.svg",
            alt: "reactangle",
            className: "absolute",
            style: {
              left: 38,
              bottom: 254
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 35,
            columnNumber: 13
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            style: {
              height: 209,
              background: "#01576E"
            },
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "text-center flex items-center",
              style: {
                height: 118,
                borderBottom: "1px solid #EBEBE9"
              },
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h6", {
                className: "font-bold text-secondary",
                style: {
                  fontSize: 32,
                  lineHeight: "36px",
                  letterSpacing: "0.05em",
                  marginLeft: 31,
                  marginRight: 8
                },
                children: "BHAVISH"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 39,
                columnNumber: 17
              }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h6", {
                className: "font-light text-secondary",
                style: {
                  fontSize: 32,
                  lineHeight: "36px",
                  letterSpacing: "0.05em"
                },
                children: "AGGARWAL"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 42,
                columnNumber: 17
              }, _this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 38,
              columnNumber: 15
            }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "flex justify-between items-center",
              style: {
                height: 88
              },
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                style: {
                  marginLeft: 31
                },
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                  className: "text-secondary font-medium text-lg leading-6",
                  children: " Mobility"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 49,
                  columnNumber: 19
                }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                  style: {
                    marginLeft: 20,
                    marginRight: 20
                  },
                  className: "text-secondary font-medium text-lg leading-6",
                  children: "|"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 50,
                  columnNumber: 19
                }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                  className: "text-secondary font-medium text-lg leading-6",
                  children: " Electric Cars"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 51,
                  columnNumber: 19
                }, _this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 48,
                columnNumber: 17
              }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_3__["Image"], {
                src: "/icons/ola.svg",
                alt: "ola",
                style: {
                  marginRight: 57
                }
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 53,
                columnNumber: 17
              }, _this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 47,
              columnNumber: 15
            }, _this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 37,
            columnNumber: 13
          }, _this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 31,
          columnNumber: 11
        }, _this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 29,
        columnNumber: 9
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 28,
      columnNumber: 7
    }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "".concat(className),
        style: _objectSpread({
          width: 615.94,
          height: 863.91,
          position: "relative"
        }, style),
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "",
          style: {
            width: 571,
            height: 762,
            position: "absolute",
            background: "#083A4A",
            bottom: 50,
            left: 0
          }
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 64,
          columnNumber: 11
        }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "",
          style: {
            width: 594,
            height: 788,
            bottom: 65,
            left: 15,
            position: "absolute",
            display: "flex",
            flexDirection: "column"
          },
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_3__["Image"], {
            src: "/icons/Bhavish_image.svg",
            alt: "founder image",
            style: {
              flexGrow: 1
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 68,
            columnNumber: 13
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_3__["Image"], {
            src: "/icons/rectangle.svg",
            alt: "reactangle",
            className: "absolute",
            style: {
              left: 38,
              bottom: 254
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 69,
            columnNumber: 13
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            style: {
              height: 209,
              background: "#01576E"
            },
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "text-center flex items-center",
              style: {
                height: 118,
                borderBottom: "1px solid #EBEBE9"
              },
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h6", {
                className: "font-bold text-secondary",
                style: {
                  fontSize: 32,
                  lineHeight: "36px",
                  letterSpacing: "0.05em",
                  marginLeft: 31,
                  marginRight: 8
                },
                children: "jhgbjhbjhbjh"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 73,
                columnNumber: 17
              }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h6", {
                className: "font-light text-secondary",
                style: {
                  fontSize: 32,
                  lineHeight: "36px",
                  letterSpacing: "0.05em"
                },
                children: "AGGARWAL"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 76,
                columnNumber: 17
              }, _this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 72,
              columnNumber: 15
            }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "flex justify-between items-center",
              style: {
                height: 88
              },
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                style: {
                  marginLeft: 31
                },
                children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                  className: "text-secondary font-medium text-lg leading-6",
                  children: " Mobility"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 83,
                  columnNumber: 19
                }, _this)
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 82,
                columnNumber: 17
              }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_3__["Image"], {
                src: "/icons/ola.svg",
                alt: "ola",
                style: {
                  marginRight: 57
                }
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 85,
                columnNumber: 17
              }, _this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 81,
              columnNumber: 15
            }, _this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 71,
            columnNumber: 13
          }, _this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 65,
          columnNumber: 11
        }, _this)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 63,
        columnNumber: 9
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 62,
      columnNumber: 7
    }, _this)]
  }), void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 27,
    columnNumber: 5
  }, _this);
};
_c = Founder;

var _c;

$RefreshReg$(_c, "Founder");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vc3JjL2NvbXBvbmVudHMvZm91bmRlci9Gb3VuZGVyLnRzeCJdLCJuYW1lcyI6WyJGb3VuZGVyIiwiY2xhc3NOYW1lIiwic3R5bGUiLCJzZXR0aW5ncyIsImRvdHMiLCJpbmZpbml0ZSIsInNwZWVkIiwic2xpZGVzVG9TaG93Iiwic2xpZGVzVG9TY3JvbGwiLCJhdXRvcGxheSIsIndpZHRoIiwiaGVpZ2h0IiwicG9zaXRpb24iLCJiYWNrZ3JvdW5kIiwiYm90dG9tIiwibGVmdCIsImRpc3BsYXkiLCJmbGV4RGlyZWN0aW9uIiwiZmxleEdyb3ciLCJib3JkZXJCb3R0b20iLCJmb250U2l6ZSIsImxpbmVIZWlnaHQiLCJsZXR0ZXJTcGFjaW5nIiwibWFyZ2luTGVmdCIsIm1hcmdpblJpZ2h0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQVdPLElBQU1BLE9BQXdCLEdBQUcsU0FBM0JBLE9BQTJCLE9BQStCO0FBQUEsTUFBNUJDLFNBQTRCLFFBQTVCQSxTQUE0QjtBQUFBLHdCQUFqQkMsS0FBaUI7QUFBQSxNQUFqQkEsS0FBaUIsMkJBQVQsRUFBUztBQUNyRSxNQUFNQyxRQUFRLEdBQUc7QUFDZkMsUUFBSSxFQUFFLElBRFM7QUFFZkMsWUFBUSxFQUFFLElBRks7QUFHZkMsU0FBSyxFQUFFLEdBSFE7QUFJZjtBQUNBQyxnQkFBWSxFQUFFLENBTEM7QUFNZkMsa0JBQWMsRUFBRSxDQU5EO0FBT2ZDLFlBQVEsRUFBRTtBQVBLLEdBQWpCO0FBU0Esc0JBQ0UscUVBQUMsa0RBQUQsa0NBQVlOLFFBQVo7QUFBQSw0QkFDRTtBQUFBLDZCQUNFO0FBQUssaUJBQVMsWUFBS0YsU0FBTCxDQUFkO0FBQWdDLGFBQUs7QUFBSVMsZUFBSyxFQUFFLE1BQVg7QUFBbUJDLGdCQUFNLEVBQUUsTUFBM0I7QUFBbUNDLGtCQUFRLEVBQUU7QUFBN0MsV0FBNERWLEtBQTVELENBQXJDO0FBQUEsZ0NBQ0U7QUFBSyxtQkFBUyxFQUFDLEVBQWY7QUFBa0IsZUFBSyxFQUFFO0FBQUVRLGlCQUFLLEVBQUUsR0FBVDtBQUFjQyxrQkFBTSxFQUFFLEdBQXRCO0FBQTJCQyxvQkFBUSxFQUFFLFVBQXJDO0FBQWlEQyxzQkFBVSxFQUFFLFNBQTdEO0FBQXdFQyxrQkFBTSxFQUFFLEVBQWhGO0FBQW9GQyxnQkFBSSxFQUFFO0FBQTFGO0FBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBREYsZUFFRTtBQUNFLG1CQUFTLEVBQUMsRUFEWjtBQUVFLGVBQUssRUFBRTtBQUFFTCxpQkFBSyxFQUFFLEdBQVQ7QUFBY0Msa0JBQU0sRUFBRSxHQUF0QjtBQUEyQkcsa0JBQU0sRUFBRSxFQUFuQztBQUF1Q0MsZ0JBQUksRUFBRSxFQUE3QztBQUFpREgsb0JBQVEsRUFBRSxVQUEzRDtBQUF1RUksbUJBQU8sRUFBRSxNQUFoRjtBQUF3RkMseUJBQWEsRUFBRTtBQUF2RyxXQUZUO0FBQUEsa0NBR0UscUVBQUMsaURBQUQ7QUFBTyxlQUFHLEVBQUMsMEJBQVg7QUFBc0MsZUFBRyxFQUFDLGVBQTFDO0FBQTBELGlCQUFLLEVBQUU7QUFBRUMsc0JBQVEsRUFBRTtBQUFaO0FBQWpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSEYsZUFJRSxxRUFBQyxpREFBRDtBQUFPLGVBQUcsRUFBQyxzQkFBWDtBQUFrQyxlQUFHLEVBQUUsWUFBdkM7QUFBcUQscUJBQVMsRUFBQyxVQUEvRDtBQUEwRSxpQkFBSyxFQUFFO0FBQUVILGtCQUFJLEVBQUUsRUFBUjtBQUFZRCxvQkFBTSxFQUFFO0FBQXBCO0FBQWpGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSkYsZUFNRTtBQUFLLGlCQUFLLEVBQUU7QUFBRUgsb0JBQU0sRUFBRSxHQUFWO0FBQWVFLHdCQUFVLEVBQUU7QUFBM0IsYUFBWjtBQUFBLG9DQUNFO0FBQUssdUJBQVMsRUFBQywrQkFBZjtBQUErQyxtQkFBSyxFQUFFO0FBQUVGLHNCQUFNLEVBQUUsR0FBVjtBQUFlUSw0QkFBWSxFQUFFO0FBQTdCLGVBQXREO0FBQUEsc0NBQ0U7QUFBSSx5QkFBUyxFQUFDLDBCQUFkO0FBQXlDLHFCQUFLLEVBQUU7QUFBRUMsMEJBQVEsRUFBRSxFQUFaO0FBQWdCQyw0QkFBVSxFQUFFLE1BQTVCO0FBQW9DQywrQkFBYSxFQUFFLFFBQW5EO0FBQTZEQyw0QkFBVSxFQUFFLEVBQXpFO0FBQTZFQyw2QkFBVyxFQUFFO0FBQTFGLGlCQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFERixlQUlFO0FBQUkseUJBQVMsRUFBQywyQkFBZDtBQUEwQyxxQkFBSyxFQUFFO0FBQUVKLDBCQUFRLEVBQUUsRUFBWjtBQUFnQkMsNEJBQVUsRUFBRSxNQUE1QjtBQUFvQ0MsK0JBQWEsRUFBRTtBQUFuRCxpQkFBakQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQURGLGVBVUU7QUFBSyx1QkFBUyxFQUFDLG1DQUFmO0FBQW1ELG1CQUFLLEVBQUU7QUFBRVgsc0JBQU0sRUFBRTtBQUFWLGVBQTFEO0FBQUEsc0NBQ0U7QUFBSyxxQkFBSyxFQUFFO0FBQUVZLDRCQUFVLEVBQUU7QUFBZCxpQkFBWjtBQUFBLHdDQUNFO0FBQU0sMkJBQVMsRUFBQyw4Q0FBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBREYsZUFFRTtBQUFNLHVCQUFLLEVBQUU7QUFBRUEsOEJBQVUsRUFBRSxFQUFkO0FBQWtCQywrQkFBVyxFQUFFO0FBQS9CLG1CQUFiO0FBQWtELDJCQUFTLEVBQUMsOENBQTVEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUZGLGVBR0U7QUFBTSwyQkFBUyxFQUFDLDhDQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFIRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBREYsZUFNRSxxRUFBQyxpREFBRDtBQUFPLG1CQUFHLEVBQUUsZ0JBQVo7QUFBOEIsbUJBQUcsRUFBRSxLQUFuQztBQUEwQyxxQkFBSyxFQUFFO0FBQUVBLDZCQUFXLEVBQUU7QUFBZjtBQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFERixlQW1DRTtBQUFBLDZCQUNFO0FBQUssaUJBQVMsWUFBS3ZCLFNBQUwsQ0FBZDtBQUFnQyxhQUFLO0FBQUlTLGVBQUssRUFBRSxNQUFYO0FBQW1CQyxnQkFBTSxFQUFFLE1BQTNCO0FBQW1DQyxrQkFBUSxFQUFFO0FBQTdDLFdBQTREVixLQUE1RCxDQUFyQztBQUFBLGdDQUNFO0FBQUssbUJBQVMsRUFBQyxFQUFmO0FBQWtCLGVBQUssRUFBRTtBQUFFUSxpQkFBSyxFQUFFLEdBQVQ7QUFBY0Msa0JBQU0sRUFBRSxHQUF0QjtBQUEyQkMsb0JBQVEsRUFBRSxVQUFyQztBQUFpREMsc0JBQVUsRUFBRSxTQUE3RDtBQUF3RUMsa0JBQU0sRUFBRSxFQUFoRjtBQUFvRkMsZ0JBQUksRUFBRTtBQUExRjtBQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURGLGVBRUU7QUFDRSxtQkFBUyxFQUFDLEVBRFo7QUFFRSxlQUFLLEVBQUU7QUFBRUwsaUJBQUssRUFBRSxHQUFUO0FBQWNDLGtCQUFNLEVBQUUsR0FBdEI7QUFBMkJHLGtCQUFNLEVBQUUsRUFBbkM7QUFBdUNDLGdCQUFJLEVBQUUsRUFBN0M7QUFBaURILG9CQUFRLEVBQUUsVUFBM0Q7QUFBdUVJLG1CQUFPLEVBQUUsTUFBaEY7QUFBd0ZDLHlCQUFhLEVBQUU7QUFBdkcsV0FGVDtBQUFBLGtDQUdFLHFFQUFDLGlEQUFEO0FBQU8sZUFBRyxFQUFDLDBCQUFYO0FBQXNDLGVBQUcsRUFBQyxlQUExQztBQUEwRCxpQkFBSyxFQUFFO0FBQUVDLHNCQUFRLEVBQUU7QUFBWjtBQUFqRTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUhGLGVBSUUscUVBQUMsaURBQUQ7QUFBTyxlQUFHLEVBQUMsc0JBQVg7QUFBa0MsZUFBRyxFQUFFLFlBQXZDO0FBQXFELHFCQUFTLEVBQUMsVUFBL0Q7QUFBMEUsaUJBQUssRUFBRTtBQUFFSCxrQkFBSSxFQUFFLEVBQVI7QUFBWUQsb0JBQU0sRUFBRTtBQUFwQjtBQUFqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUpGLGVBTUU7QUFBSyxpQkFBSyxFQUFFO0FBQUVILG9CQUFNLEVBQUUsR0FBVjtBQUFlRSx3QkFBVSxFQUFFO0FBQTNCLGFBQVo7QUFBQSxvQ0FDRTtBQUFLLHVCQUFTLEVBQUMsK0JBQWY7QUFBK0MsbUJBQUssRUFBRTtBQUFFRixzQkFBTSxFQUFFLEdBQVY7QUFBZVEsNEJBQVksRUFBRTtBQUE3QixlQUF0RDtBQUFBLHNDQUNFO0FBQUkseUJBQVMsRUFBQywwQkFBZDtBQUF5QyxxQkFBSyxFQUFFO0FBQUVDLDBCQUFRLEVBQUUsRUFBWjtBQUFnQkMsNEJBQVUsRUFBRSxNQUE1QjtBQUFvQ0MsK0JBQWEsRUFBRSxRQUFuRDtBQUE2REMsNEJBQVUsRUFBRSxFQUF6RTtBQUE2RUMsNkJBQVcsRUFBRTtBQUExRixpQkFBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBREYsZUFJRTtBQUFJLHlCQUFTLEVBQUMsMkJBQWQ7QUFBMEMscUJBQUssRUFBRTtBQUFFSiwwQkFBUSxFQUFFLEVBQVo7QUFBZ0JDLDRCQUFVLEVBQUUsTUFBNUI7QUFBb0NDLCtCQUFhLEVBQUU7QUFBbkQsaUJBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFERixlQVVFO0FBQUssdUJBQVMsRUFBQyxtQ0FBZjtBQUFtRCxtQkFBSyxFQUFFO0FBQUVYLHNCQUFNLEVBQUU7QUFBVixlQUExRDtBQUFBLHNDQUNFO0FBQUsscUJBQUssRUFBRTtBQUFFWSw0QkFBVSxFQUFFO0FBQWQsaUJBQVo7QUFBQSx1Q0FDRTtBQUFNLDJCQUFTLEVBQUMsOENBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFERixlQUlFLHFFQUFDLGlEQUFEO0FBQU8sbUJBQUcsRUFBRSxnQkFBWjtBQUE4QixtQkFBRyxFQUFFLEtBQW5DO0FBQTBDLHFCQUFLLEVBQUU7QUFBRUMsNkJBQVcsRUFBRTtBQUFmO0FBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFORjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQW5DRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FERjtBQW9FRCxDQTlFTTtLQUFNeEIsTyIsImZpbGUiOiJzdGF0aWMvd2VicGFjay9wYWdlcy9ob21lLjI1ZDdlNTAwMDRlNDVhMzhjYWYxLmhvdC11cGRhdGUuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBJbWFnZSB9IGZyb20gXCJAY29tcG9uZW50c1wiO1xuaW1wb3J0IFNsaWRlciBmcm9tIFwicmVhY3Qtc2xpY2tcIjtcbmltcG9ydCBcInNsaWNrLWNhcm91c2VsL3NsaWNrL3NsaWNrLmNzc1wiO1xuaW1wb3J0IFwic2xpY2stY2Fyb3VzZWwvc2xpY2svc2xpY2stdGhlbWUuY3NzXCI7XG5cbmV4cG9ydCB0eXBlIFByb3BzID0ge1xuICBuYW1lcz86IEFycmF5PHN0cmluZz47XG4gIGJhY2tncm91bmRfdXJsPzogc3RyaW5nO1xuICB0YWdzPzogQXJyYXk8c3RyaW5nPjtcbiAgbG9nbz86IHN0cmluZztcbiAgY2xhc3NOYW1lPzogc3RyaW5nO1xuICBzdHlsZT86IGFueTtcbn07XG5cbmV4cG9ydCBjb25zdCBGb3VuZGVyOiBSZWFjdC5GQzxQcm9wcz4gPSAoeyBjbGFzc05hbWUsIHN0eWxlID0ge30gfSkgPT4ge1xuICBjb25zdCBzZXR0aW5ncyA9IHtcbiAgICBkb3RzOiB0cnVlLFxuICAgIGluZmluaXRlOiB0cnVlLFxuICAgIHNwZWVkOiA1MDAsXG4gICAgLy8gYXV0b3BsYXlTcGVlZDogMjAwMCxcbiAgICBzbGlkZXNUb1Nob3c6IDEsXG4gICAgc2xpZGVzVG9TY3JvbGw6IDEsXG4gICAgYXV0b3BsYXk6IHRydWVcbiAgfTtcbiAgcmV0dXJuIChcbiAgICA8U2xpZGVyIHsuLi5zZXR0aW5nc30+XG4gICAgICA8ZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YCR7Y2xhc3NOYW1lfWB9IHN0eWxlPXt7IHdpZHRoOiA2MTUuOTQsIGhlaWdodDogODYzLjkxLCBwb3NpdGlvbjogXCJyZWxhdGl2ZVwiLCAuLi5zdHlsZSwgfX0+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJcIiBzdHlsZT17eyB3aWR0aDogNTcxLCBoZWlnaHQ6IDc2MiwgcG9zaXRpb246IFwiYWJzb2x1dGVcIiwgYmFja2dyb3VuZDogXCIjMDgzQTRBXCIsIGJvdHRvbTogNTAsIGxlZnQ6IDAsIH19PjwvZGl2PlxuICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cIlwiXG4gICAgICAgICAgICBzdHlsZT17eyB3aWR0aDogNTk0LCBoZWlnaHQ6IDc4OCwgYm90dG9tOiA2NSwgbGVmdDogMTUsIHBvc2l0aW9uOiBcImFic29sdXRlXCIsIGRpc3BsYXk6IFwiZmxleFwiLCBmbGV4RGlyZWN0aW9uOiBcImNvbHVtblwiLCB9fT5cbiAgICAgICAgICAgIDxJbWFnZSBzcmM9XCIvaWNvbnMvQmhhdmlzaF9pbWFnZS5zdmdcIiBhbHQ9XCJmb3VuZGVyIGltYWdlXCIgc3R5bGU9e3sgZmxleEdyb3c6IDEgfX0+PC9JbWFnZT5cbiAgICAgICAgICAgIDxJbWFnZSBzcmM9XCIvaWNvbnMvcmVjdGFuZ2xlLnN2Z1wiIGFsdD17XCJyZWFjdGFuZ2xlXCJ9IGNsYXNzTmFtZT1cImFic29sdXRlXCIgc3R5bGU9e3sgbGVmdDogMzgsIGJvdHRvbTogMjU0IH19IC8+XG5cbiAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgaGVpZ2h0OiAyMDksIGJhY2tncm91bmQ6IFwiIzAxNTc2RVwiIH19PlxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIGZsZXggaXRlbXMtY2VudGVyXCIgc3R5bGU9e3sgaGVpZ2h0OiAxMTgsIGJvcmRlckJvdHRvbTogXCIxcHggc29saWQgI0VCRUJFOVwiIH19PlxuICAgICAgICAgICAgICAgIDxoNiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zZWNvbmRhcnlcIiBzdHlsZT17eyBmb250U2l6ZTogMzIsIGxpbmVIZWlnaHQ6IFwiMzZweFwiLCBsZXR0ZXJTcGFjaW5nOiBcIjAuMDVlbVwiLCBtYXJnaW5MZWZ0OiAzMSwgbWFyZ2luUmlnaHQ6IDgsIH19PlxuICAgICAgICAgICAgICAgICAgQkhBVklTSFxuICAgICAgICAgICAgICA8L2g2PlxuICAgICAgICAgICAgICAgIDxoNiBjbGFzc05hbWU9XCJmb250LWxpZ2h0IHRleHQtc2Vjb25kYXJ5XCIgc3R5bGU9e3sgZm9udFNpemU6IDMyLCBsaW5lSGVpZ2h0OiBcIjM2cHhcIiwgbGV0dGVyU3BhY2luZzogXCIwLjA1ZW1cIiwgfX0+XG4gICAgICAgICAgICAgICAgICBBR0dBUldBTFxuICAgICAgICAgICAgICA8L2g2PlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlclwiIHN0eWxlPXt7IGhlaWdodDogODggfX0+XG4gICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBtYXJnaW5MZWZ0OiAzMSB9fT5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2Vjb25kYXJ5IGZvbnQtbWVkaXVtIHRleHQtbGcgbGVhZGluZy02XCI+IE1vYmlsaXR5PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgPHNwYW4gc3R5bGU9e3sgbWFyZ2luTGVmdDogMjAsIG1hcmdpblJpZ2h0OiAyMCB9fSBjbGFzc05hbWU9XCJ0ZXh0LXNlY29uZGFyeSBmb250LW1lZGl1bSB0ZXh0LWxnIGxlYWRpbmctNlwiPnw8L3NwYW4+XG4gICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNlY29uZGFyeSBmb250LW1lZGl1bSB0ZXh0LWxnIGxlYWRpbmctNlwiPiBFbGVjdHJpYyBDYXJzPC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxJbWFnZSBzcmM9e1wiL2ljb25zL29sYS5zdmdcIn0gYWx0PXtcIm9sYVwifSBzdHlsZT17eyBtYXJnaW5SaWdodDogNTcgfX0gLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuXG5cbiAgICAgIDxkaXY+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgJHtjbGFzc05hbWV9YH0gc3R5bGU9e3sgd2lkdGg6IDYxNS45NCwgaGVpZ2h0OiA4NjMuOTEsIHBvc2l0aW9uOiBcInJlbGF0aXZlXCIsIC4uLnN0eWxlLCB9fT5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIlwiIHN0eWxlPXt7IHdpZHRoOiA1NzEsIGhlaWdodDogNzYyLCBwb3NpdGlvbjogXCJhYnNvbHV0ZVwiLCBiYWNrZ3JvdW5kOiBcIiMwODNBNEFcIiwgYm90dG9tOiA1MCwgbGVmdDogMCwgfX0+PC9kaXY+XG4gICAgICAgICAgPGRpdlxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiXCJcbiAgICAgICAgICAgIHN0eWxlPXt7IHdpZHRoOiA1OTQsIGhlaWdodDogNzg4LCBib3R0b206IDY1LCBsZWZ0OiAxNSwgcG9zaXRpb246IFwiYWJzb2x1dGVcIiwgZGlzcGxheTogXCJmbGV4XCIsIGZsZXhEaXJlY3Rpb246IFwiY29sdW1uXCIsIH19PlxuICAgICAgICAgICAgPEltYWdlIHNyYz1cIi9pY29ucy9CaGF2aXNoX2ltYWdlLnN2Z1wiIGFsdD1cImZvdW5kZXIgaW1hZ2VcIiBzdHlsZT17eyBmbGV4R3JvdzogMSB9fT48L0ltYWdlPlxuICAgICAgICAgICAgPEltYWdlIHNyYz1cIi9pY29ucy9yZWN0YW5nbGUuc3ZnXCIgYWx0PXtcInJlYWN0YW5nbGVcIn0gY2xhc3NOYW1lPVwiYWJzb2x1dGVcIiBzdHlsZT17eyBsZWZ0OiAzOCwgYm90dG9tOiAyNTQgfX0gLz5cblxuICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBoZWlnaHQ6IDIwOSwgYmFja2dyb3VuZDogXCIjMDE1NzZFXCIgfX0+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgZmxleCBpdGVtcy1jZW50ZXJcIiBzdHlsZT17eyBoZWlnaHQ6IDExOCwgYm9yZGVyQm90dG9tOiBcIjFweCBzb2xpZCAjRUJFQkU5XCIgfX0+XG4gICAgICAgICAgICAgICAgPGg2IGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNlY29uZGFyeVwiIHN0eWxlPXt7IGZvbnRTaXplOiAzMiwgbGluZUhlaWdodDogXCIzNnB4XCIsIGxldHRlclNwYWNpbmc6IFwiMC4wNWVtXCIsIG1hcmdpbkxlZnQ6IDMxLCBtYXJnaW5SaWdodDogOCwgfX0+XG4gICAgICAgICAgICAgICAgICBqaGdiamhiamhiamhcbiAgICAgICAgICAgIDwvaDY+XG4gICAgICAgICAgICAgICAgPGg2IGNsYXNzTmFtZT1cImZvbnQtbGlnaHQgdGV4dC1zZWNvbmRhcnlcIiBzdHlsZT17eyBmb250U2l6ZTogMzIsIGxpbmVIZWlnaHQ6IFwiMzZweFwiLCBsZXR0ZXJTcGFjaW5nOiBcIjAuMDVlbVwiLCB9fT5cbiAgICAgICAgICAgICAgICAgIEFHR0FSV0FMXG4gICAgICAgICAgICA8L2g2PlxuICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlclwiIHN0eWxlPXt7IGhlaWdodDogODggfX0+XG4gICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBtYXJnaW5MZWZ0OiAzMSB9fT5cbiAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2Vjb25kYXJ5IGZvbnQtbWVkaXVtIHRleHQtbGcgbGVhZGluZy02XCI+IE1vYmlsaXR5PC9zcGFuPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgIDxJbWFnZSBzcmM9e1wiL2ljb25zL29sYS5zdmdcIn0gYWx0PXtcIm9sYVwifSBzdHlsZT17eyBtYXJnaW5SaWdodDogNTcgfX0gLz5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgIDwvU2xpZGVyPlxuICApO1xufTtcbiJdLCJzb3VyY2VSb290IjoiIn0=