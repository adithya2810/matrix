webpackHotUpdate_N_E("pages/home",{

/***/ "./src/components/founder/Founder.tsx":
/*!********************************************!*\
  !*** ./src/components/founder/Founder.tsx ***!
  \********************************************/
/*! exports provided: Founder */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Founder", function() { return Founder; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var C_Users_KARTHIK_Documents_workspace_matrix_cms_ui_development_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @components */ "./src/components/index.ts");
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-slick */ "./node_modules/react-slick/lib/index.js");
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_slick__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! slick-carousel/slick/slick.css */ "./node_modules/slick-carousel/slick/slick.css");
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! slick-carousel/slick/slick-theme.css */ "./node_modules/slick-carousel/slick/slick-theme.css");
/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_6__);



var _jsxFileName = "C:\\Users\\KARTHIK\\Documents\\workspace\\matrix-cms-ui-development\\src\\components\\founder\\Founder.tsx",
    _this = undefined;

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { Object(C_Users_KARTHIK_Documents_workspace_matrix_cms_ui_development_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__["default"])(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }






var Founder = function Founder(_ref) {
  var className = _ref.className,
      _ref$style = _ref.style,
      style = _ref$style === void 0 ? {} : _ref$style;
  var heros = [{
    firstName: 'Bhavish',
    lastName: 'AGGARWAL',
    firstName1: null,
    lastName1: null,
    caption: 'Mobility',
    caption1: 'Electric Cars',
    logo: '/icons/ola.svg',
    image: '/icons/Bhavish_image.svg'
  }, {
    firstName: 'ROHIT',
    lastName: 'M.A.',
    firstName1: null,
    lastName1: null,
    caption: 'Healthcare',
    caption1: null,
    logo: '/icons/Cloudnine.svg',
    image: '/icons/Rohit_Treatment.svg'
  }, {
    firstName: 'ANINDYA',
    lastName: 'DUTTA',
    firstName1: 'SANDEEP',
    lastName1: 'DALMIA',
    caption: 'Student Housing Platform',
    caption1: null,
    logo: '/icons/Stanza.svg',
    image: '/icons/Anindya.svg'
  }, {
    firstName: 'Asish',
    lastName: 'MOHAPATRA',
    firstName1: null,
    lastName1: null,
    caption: 'Fintech',
    caption1: 'SME Lending',
    logo: '/icons/OfBusiness.svg',
    image: '/icons/Asish.svg'
  }, {
    firstName: 'Mr.',
    lastName: 'LAKSHIPATHY',
    firstName1: null,
    lastName1: null,
    caption: 'Fintech',
    caption1: 'NBFC',
    logo: '/icons/mx.svg',
    image: '/icons/Laxmipathy.svg'
  }, {
    firstName: 'CHAKRADHAR',
    lastName: 'GADE',
    firstName1: 'NITIN',
    lastName1: 'KAUSHAL',
    caption: 'Fintech',
    caption1: 'NBFC',
    logo: '/icons/Country.svg',
    image: '/icons/Chakradhar.svg'
  }];
  var settings = {
    dots: true,
    infinite: true,
    speed: 500,
    autoplaySpeed: 5000,
    slidesToShow: 1,
    slidesToScroll: 1 // autoplay: true

  };
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_slick__WEBPACK_IMPORTED_MODULE_4___default.a, _objectSpread(_objectSpread({}, settings), {}, {
    children: heros.map(function (hero) {
      return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "".concat(className),
          style: _objectSpread({
            width: 615.94,
            height: 863.91,
            position: "relative"
          }, style),
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "",
            style: {
              width: 571,
              height: 762,
              position: "absolute",
              background: "#083A4A",
              bottom: 50,
              left: 0
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 87,
            columnNumber: 13
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "",
            style: {
              width: 594,
              height: 788,
              bottom: 65,
              left: 15,
              position: "absolute",
              display: "flex",
              flexDirection: "column"
            },
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_3__["Image"], {
              src: hero.image,
              alt: "founder image",
              style: {
                flexGrow: 1
              }
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 89,
              columnNumber: 15
            }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_3__["Image"], {
              src: "/icons/rectangle.svg",
              alt: "reactangle",
              className: "absolute",
              style: {
                left: 38,
                bottom: 254
              }
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 90,
              columnNumber: 15
            }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              style: {
                height: 209,
                background: "#01576E"
              },
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "text-center flex items-center",
                style: {
                  height: 118,
                  borderBottom: "1px solid #EBEBE9"
                },
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h6", {
                  className: "font-bold text-secondary",
                  style: {
                    fontSize: 32,
                    lineHeight: "36px",
                    letterSpacing: "0.05em",
                    marginLeft: 31,
                    marginRight: 8
                  },
                  children: hero.firstName
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 94,
                  columnNumber: 19
                }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h6", {
                  className: "font-light text-secondary",
                  style: {
                    fontSize: 32,
                    lineHeight: "36px",
                    letterSpacing: "0.05em"
                  },
                  children: hero.lastName
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 97,
                  columnNumber: 19
                }, _this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 93,
                columnNumber: 17
              }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "flex justify-between items-center",
                style: {
                  height: 88
                },
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  style: {
                    marginLeft: 31,
                    display: 'flex',
                    justifyContent: 'space-around'
                  },
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                    className: "text-secondary font-medium text-lg leading-6",
                    children: [" ", hero.caption]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 104,
                    columnNumber: 21
                  }, _this), hero.caption1 && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                    className: "text-secondary font-medium text-lg leading-6",
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("hr", {
                      style: {
                        width: 30,
                        transform: 'rotate(90deg)'
                      }
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 105,
                      columnNumber: 102
                    }, _this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 105,
                    columnNumber: 39
                  }, _this), hero.caption1 && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                    className: "text-secondary font-medium text-lg leading-6",
                    children: [" ", hero.caption1]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 106,
                    columnNumber: 39
                  }, _this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 103,
                  columnNumber: 19
                }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_3__["Image"], {
                  src: hero.logo,
                  alt: "ola",
                  style: {
                    marginRight: 57
                  }
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 108,
                  columnNumber: 19
                }, _this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 102,
                columnNumber: 17
              }, _this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 92,
              columnNumber: 15
            }, _this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 88,
            columnNumber: 13
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "",
            style: {
              left: 760,
              position: "absolute"
            },
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h1", {
              className: "slide-header",
              children: "We are founders first"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 114,
              columnNumber: 15
            }, _this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 113,
            columnNumber: 13
          }, _this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 86,
          columnNumber: 11
        }, _this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 85,
        columnNumber: 17
      }, _this);
    })
  }), void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 83,
    columnNumber: 5
  }, _this);
};
_c = Founder;

var _c;

$RefreshReg$(_c, "Founder");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vc3JjL2NvbXBvbmVudHMvZm91bmRlci9Gb3VuZGVyLnRzeCJdLCJuYW1lcyI6WyJGb3VuZGVyIiwiY2xhc3NOYW1lIiwic3R5bGUiLCJoZXJvcyIsImZpcnN0TmFtZSIsImxhc3ROYW1lIiwiZmlyc3ROYW1lMSIsImxhc3ROYW1lMSIsImNhcHRpb24iLCJjYXB0aW9uMSIsImxvZ28iLCJpbWFnZSIsInNldHRpbmdzIiwiZG90cyIsImluZmluaXRlIiwic3BlZWQiLCJhdXRvcGxheVNwZWVkIiwic2xpZGVzVG9TaG93Iiwic2xpZGVzVG9TY3JvbGwiLCJtYXAiLCJoZXJvIiwid2lkdGgiLCJoZWlnaHQiLCJwb3NpdGlvbiIsImJhY2tncm91bmQiLCJib3R0b20iLCJsZWZ0IiwiZGlzcGxheSIsImZsZXhEaXJlY3Rpb24iLCJmbGV4R3JvdyIsImJvcmRlckJvdHRvbSIsImZvbnRTaXplIiwibGluZUhlaWdodCIsImxldHRlclNwYWNpbmciLCJtYXJnaW5MZWZ0IiwibWFyZ2luUmlnaHQiLCJqdXN0aWZ5Q29udGVudCIsInRyYW5zZm9ybSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFXTyxJQUFNQSxPQUF3QixHQUFHLFNBQTNCQSxPQUEyQixPQUErQjtBQUFBLE1BQTVCQyxTQUE0QixRQUE1QkEsU0FBNEI7QUFBQSx3QkFBakJDLEtBQWlCO0FBQUEsTUFBakJBLEtBQWlCLDJCQUFULEVBQVM7QUFDckUsTUFBTUMsS0FBSyxHQUFHLENBQUM7QUFDYkMsYUFBUyxFQUFFLFNBREU7QUFFYkMsWUFBUSxFQUFFLFVBRkc7QUFHYkMsY0FBVSxFQUFFLElBSEM7QUFJYkMsYUFBUyxFQUFFLElBSkU7QUFLYkMsV0FBTyxFQUFFLFVBTEk7QUFNYkMsWUFBUSxFQUFFLGVBTkc7QUFPYkMsUUFBSSxFQUFFLGdCQVBPO0FBUWJDLFNBQUssRUFBRTtBQVJNLEdBQUQsRUFTWDtBQUNEUCxhQUFTLEVBQUUsT0FEVjtBQUVEQyxZQUFRLEVBQUUsTUFGVDtBQUdEQyxjQUFVLEVBQUUsSUFIWDtBQUlEQyxhQUFTLEVBQUUsSUFKVjtBQUtEQyxXQUFPLEVBQUUsWUFMUjtBQU1EQyxZQUFRLEVBQUUsSUFOVDtBQU9EQyxRQUFJLEVBQUUsc0JBUEw7QUFRREMsU0FBSyxFQUFFO0FBUk4sR0FUVyxFQWtCWDtBQUNEUCxhQUFTLEVBQUUsU0FEVjtBQUVEQyxZQUFRLEVBQUUsT0FGVDtBQUdEQyxjQUFVLEVBQUUsU0FIWDtBQUlEQyxhQUFTLEVBQUUsUUFKVjtBQUtEQyxXQUFPLEVBQUUsMEJBTFI7QUFNREMsWUFBUSxFQUFFLElBTlQ7QUFPREMsUUFBSSxFQUFFLG1CQVBMO0FBUURDLFNBQUssRUFBRTtBQVJOLEdBbEJXLEVBMkJYO0FBQ0RQLGFBQVMsRUFBRSxPQURWO0FBRURDLFlBQVEsRUFBRSxXQUZUO0FBR0RDLGNBQVUsRUFBRSxJQUhYO0FBSURDLGFBQVMsRUFBRSxJQUpWO0FBS0RDLFdBQU8sRUFBRSxTQUxSO0FBTURDLFlBQVEsRUFBRSxhQU5UO0FBT0RDLFFBQUksRUFBRSx1QkFQTDtBQVFEQyxTQUFLLEVBQUU7QUFSTixHQTNCVyxFQW9DWDtBQUNEUCxhQUFTLEVBQUUsS0FEVjtBQUVEQyxZQUFRLEVBQUUsYUFGVDtBQUdEQyxjQUFVLEVBQUUsSUFIWDtBQUlEQyxhQUFTLEVBQUUsSUFKVjtBQUtEQyxXQUFPLEVBQUUsU0FMUjtBQU1EQyxZQUFRLEVBQUUsTUFOVDtBQU9EQyxRQUFJLEVBQUUsZUFQTDtBQVFEQyxTQUFLLEVBQUU7QUFSTixHQXBDVyxFQTZDWDtBQUNEUCxhQUFTLEVBQUUsWUFEVjtBQUVEQyxZQUFRLEVBQUUsTUFGVDtBQUdEQyxjQUFVLEVBQUUsT0FIWDtBQUlEQyxhQUFTLEVBQUUsU0FKVjtBQUtEQyxXQUFPLEVBQUUsU0FMUjtBQU1EQyxZQUFRLEVBQUUsTUFOVDtBQU9EQyxRQUFJLEVBQUUsb0JBUEw7QUFRREMsU0FBSyxFQUFFO0FBUk4sR0E3Q1csQ0FBZDtBQXdEQSxNQUFNQyxRQUFRLEdBQUc7QUFDZkMsUUFBSSxFQUFFLElBRFM7QUFFZkMsWUFBUSxFQUFFLElBRks7QUFHZkMsU0FBSyxFQUFFLEdBSFE7QUFJZkMsaUJBQWEsRUFBRSxJQUpBO0FBS2ZDLGdCQUFZLEVBQUUsQ0FMQztBQU1mQyxrQkFBYyxFQUFFLENBTkQsQ0FPZjs7QUFQZSxHQUFqQjtBQVNBLHNCQUNFLHFFQUFDLGtEQUFELGtDQUFZTixRQUFaO0FBQUEsY0FDR1QsS0FBSyxDQUFDZ0IsR0FBTixDQUFVLFVBQUFDLElBQUksRUFBSTtBQUNqQiwwQkFBUTtBQUFBLCtCQUNOO0FBQUssbUJBQVMsWUFBS25CLFNBQUwsQ0FBZDtBQUFnQyxlQUFLO0FBQUlvQixpQkFBSyxFQUFFLE1BQVg7QUFBbUJDLGtCQUFNLEVBQUUsTUFBM0I7QUFBbUNDLG9CQUFRLEVBQUU7QUFBN0MsYUFBNERyQixLQUE1RCxDQUFyQztBQUFBLGtDQUNFO0FBQUsscUJBQVMsRUFBQyxFQUFmO0FBQWtCLGlCQUFLLEVBQUU7QUFBRW1CLG1CQUFLLEVBQUUsR0FBVDtBQUFjQyxvQkFBTSxFQUFFLEdBQXRCO0FBQTJCQyxzQkFBUSxFQUFFLFVBQXJDO0FBQWlEQyx3QkFBVSxFQUFFLFNBQTdEO0FBQXdFQyxvQkFBTSxFQUFFLEVBQWhGO0FBQW9GQyxrQkFBSSxFQUFFO0FBQTFGO0FBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREYsZUFFRTtBQUFLLHFCQUFTLEVBQUMsRUFBZjtBQUFrQixpQkFBSyxFQUFFO0FBQUVMLG1CQUFLLEVBQUUsR0FBVDtBQUFjQyxvQkFBTSxFQUFFLEdBQXRCO0FBQTJCRyxvQkFBTSxFQUFFLEVBQW5DO0FBQXVDQyxrQkFBSSxFQUFFLEVBQTdDO0FBQWlESCxzQkFBUSxFQUFFLFVBQTNEO0FBQXVFSSxxQkFBTyxFQUFFLE1BQWhGO0FBQXdGQywyQkFBYSxFQUFFO0FBQXZHLGFBQXpCO0FBQUEsb0NBQ0UscUVBQUMsaURBQUQ7QUFBTyxpQkFBRyxFQUFFUixJQUFJLENBQUNULEtBQWpCO0FBQXdCLGlCQUFHLEVBQUMsZUFBNUI7QUFBNEMsbUJBQUssRUFBRTtBQUFFa0Isd0JBQVEsRUFBRTtBQUFaO0FBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREYsZUFFRSxxRUFBQyxpREFBRDtBQUFPLGlCQUFHLEVBQUMsc0JBQVg7QUFBa0MsaUJBQUcsRUFBRSxZQUF2QztBQUFxRCx1QkFBUyxFQUFDLFVBQS9EO0FBQTBFLG1CQUFLLEVBQUU7QUFBRUgsb0JBQUksRUFBRSxFQUFSO0FBQVlELHNCQUFNLEVBQUU7QUFBcEI7QUFBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFGRixlQUlFO0FBQUssbUJBQUssRUFBRTtBQUFFSCxzQkFBTSxFQUFFLEdBQVY7QUFBZUUsMEJBQVUsRUFBRTtBQUEzQixlQUFaO0FBQUEsc0NBQ0U7QUFBSyx5QkFBUyxFQUFDLCtCQUFmO0FBQStDLHFCQUFLLEVBQUU7QUFBRUYsd0JBQU0sRUFBRSxHQUFWO0FBQWVRLDhCQUFZLEVBQUU7QUFBN0IsaUJBQXREO0FBQUEsd0NBQ0U7QUFBSSwyQkFBUyxFQUFDLDBCQUFkO0FBQXlDLHVCQUFLLEVBQUU7QUFBRUMsNEJBQVEsRUFBRSxFQUFaO0FBQWdCQyw4QkFBVSxFQUFFLE1BQTVCO0FBQW9DQyxpQ0FBYSxFQUFFLFFBQW5EO0FBQTZEQyw4QkFBVSxFQUFFLEVBQXpFO0FBQTZFQywrQkFBVyxFQUFFO0FBQTFGLG1CQUFoRDtBQUFBLDRCQUNHZixJQUFJLENBQUNoQjtBQURSO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBREYsZUFJRTtBQUFJLDJCQUFTLEVBQUMsMkJBQWQ7QUFBMEMsdUJBQUssRUFBRTtBQUFFMkIsNEJBQVEsRUFBRSxFQUFaO0FBQWdCQyw4QkFBVSxFQUFFLE1BQTVCO0FBQW9DQyxpQ0FBYSxFQUFFO0FBQW5ELG1CQUFqRDtBQUFBLDRCQUNHYixJQUFJLENBQUNmO0FBRFI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBREYsZUFVRTtBQUFLLHlCQUFTLEVBQUMsbUNBQWY7QUFBbUQscUJBQUssRUFBRTtBQUFFaUIsd0JBQU0sRUFBRTtBQUFWLGlCQUExRDtBQUFBLHdDQUNFO0FBQUssdUJBQUssRUFBRTtBQUFFWSw4QkFBVSxFQUFFLEVBQWQ7QUFBa0JQLDJCQUFPLEVBQUUsTUFBM0I7QUFBbUNTLGtDQUFjLEVBQUU7QUFBbkQsbUJBQVo7QUFBQSwwQ0FDRTtBQUFNLDZCQUFTLEVBQUMsOENBQWhCO0FBQUEsb0NBQWlFaEIsSUFBSSxDQUFDWixPQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBREYsRUFFR1ksSUFBSSxDQUFDWCxRQUFMLGlCQUFpQjtBQUFNLDZCQUFTLEVBQUMsOENBQWhCO0FBQUEsMkNBQStEO0FBQUksMkJBQUssRUFBRTtBQUFFWSw2QkFBSyxFQUFFLEVBQVQ7QUFBYWdCLGlDQUFTLEVBQUU7QUFBeEI7QUFBWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQS9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRnBCLEVBR0dqQixJQUFJLENBQUNYLFFBQUwsaUJBQWlCO0FBQU0sNkJBQVMsRUFBQyw4Q0FBaEI7QUFBQSxvQ0FBaUVXLElBQUksQ0FBQ1gsUUFBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUhwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBREYsZUFNRSxxRUFBQyxpREFBRDtBQUFPLHFCQUFHLEVBQUVXLElBQUksQ0FBQ1YsSUFBakI7QUFBdUIscUJBQUcsRUFBRSxLQUE1QjtBQUFtQyx1QkFBSyxFQUFFO0FBQUV5QiwrQkFBVyxFQUFFO0FBQWY7QUFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFORjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFGRixlQTJCRTtBQUFLLHFCQUFTLEVBQUMsRUFBZjtBQUFrQixpQkFBSyxFQUFFO0FBQUVULGtCQUFJLEVBQUUsR0FBUjtBQUFhSCxzQkFBUSxFQUFFO0FBQXZCLGFBQXpCO0FBQUEsbUNBQ0U7QUFBSSx1QkFBUyxFQUFDLGNBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTNCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFETTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQVI7QUFrQ0QsS0FuQ0E7QUFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBREY7QUE0Q0QsQ0E5R007S0FBTXZCLE8iLCJmaWxlIjoic3RhdGljL3dlYnBhY2svcGFnZXMvaG9tZS4zN2EwZDg0YzE2ZmU2YjE0YWExNy5ob3QtdXBkYXRlLmpzIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgSW1hZ2UgfSBmcm9tIFwiQGNvbXBvbmVudHNcIjtcbmltcG9ydCBTbGlkZXIgZnJvbSBcInJlYWN0LXNsaWNrXCI7XG5pbXBvcnQgXCJzbGljay1jYXJvdXNlbC9zbGljay9zbGljay5jc3NcIjtcbmltcG9ydCBcInNsaWNrLWNhcm91c2VsL3NsaWNrL3NsaWNrLXRoZW1lLmNzc1wiO1xuXG5leHBvcnQgdHlwZSBQcm9wcyA9IHtcbiAgbmFtZXM/OiBBcnJheTxzdHJpbmc+O1xuICBiYWNrZ3JvdW5kX3VybD86IHN0cmluZztcbiAgdGFncz86IEFycmF5PHN0cmluZz47XG4gIGxvZ28/OiBzdHJpbmc7XG4gIGNsYXNzTmFtZT86IHN0cmluZztcbiAgc3R5bGU/OiBhbnk7XG59O1xuXG5leHBvcnQgY29uc3QgRm91bmRlcjogUmVhY3QuRkM8UHJvcHM+ID0gKHsgY2xhc3NOYW1lLCBzdHlsZSA9IHt9IH0pID0+IHtcbiAgY29uc3QgaGVyb3MgPSBbe1xuICAgIGZpcnN0TmFtZTogJ0JoYXZpc2gnLFxuICAgIGxhc3ROYW1lOiAnQUdHQVJXQUwnLFxuICAgIGZpcnN0TmFtZTE6IG51bGwsXG4gICAgbGFzdE5hbWUxOiBudWxsLFxuICAgIGNhcHRpb246ICdNb2JpbGl0eScsXG4gICAgY2FwdGlvbjE6ICdFbGVjdHJpYyBDYXJzJyxcbiAgICBsb2dvOiAnL2ljb25zL29sYS5zdmcnLFxuICAgIGltYWdlOiAnL2ljb25zL0JoYXZpc2hfaW1hZ2Uuc3ZnJ1xuICB9LCB7XG4gICAgZmlyc3ROYW1lOiAnUk9ISVQnLFxuICAgIGxhc3ROYW1lOiAnTS5BLicsXG4gICAgZmlyc3ROYW1lMTogbnVsbCxcbiAgICBsYXN0TmFtZTE6IG51bGwsXG4gICAgY2FwdGlvbjogJ0hlYWx0aGNhcmUnLFxuICAgIGNhcHRpb24xOiBudWxsLFxuICAgIGxvZ286ICcvaWNvbnMvQ2xvdWRuaW5lLnN2ZycsXG4gICAgaW1hZ2U6ICcvaWNvbnMvUm9oaXRfVHJlYXRtZW50LnN2ZydcbiAgfSwge1xuICAgIGZpcnN0TmFtZTogJ0FOSU5EWUEnLFxuICAgIGxhc3ROYW1lOiAnRFVUVEEnLFxuICAgIGZpcnN0TmFtZTE6ICdTQU5ERUVQJyxcbiAgICBsYXN0TmFtZTE6ICdEQUxNSUEnLFxuICAgIGNhcHRpb246ICdTdHVkZW50IEhvdXNpbmcgUGxhdGZvcm0nLFxuICAgIGNhcHRpb24xOiBudWxsLFxuICAgIGxvZ286ICcvaWNvbnMvU3RhbnphLnN2ZycsXG4gICAgaW1hZ2U6ICcvaWNvbnMvQW5pbmR5YS5zdmcnXG4gIH0sIHtcbiAgICBmaXJzdE5hbWU6ICdBc2lzaCcsXG4gICAgbGFzdE5hbWU6ICdNT0hBUEFUUkEnLFxuICAgIGZpcnN0TmFtZTE6IG51bGwsXG4gICAgbGFzdE5hbWUxOiBudWxsLFxuICAgIGNhcHRpb246ICdGaW50ZWNoJyxcbiAgICBjYXB0aW9uMTogJ1NNRSBMZW5kaW5nJyxcbiAgICBsb2dvOiAnL2ljb25zL09mQnVzaW5lc3Muc3ZnJyxcbiAgICBpbWFnZTogJy9pY29ucy9Bc2lzaC5zdmcnXG4gIH0sIHtcbiAgICBmaXJzdE5hbWU6ICdNci4nLFxuICAgIGxhc3ROYW1lOiAnTEFLU0hJUEFUSFknLFxuICAgIGZpcnN0TmFtZTE6IG51bGwsXG4gICAgbGFzdE5hbWUxOiBudWxsLFxuICAgIGNhcHRpb246ICdGaW50ZWNoJyxcbiAgICBjYXB0aW9uMTogJ05CRkMnLFxuICAgIGxvZ286ICcvaWNvbnMvbXguc3ZnJyxcbiAgICBpbWFnZTogJy9pY29ucy9MYXhtaXBhdGh5LnN2ZydcbiAgfSwge1xuICAgIGZpcnN0TmFtZTogJ0NIQUtSQURIQVInLFxuICAgIGxhc3ROYW1lOiAnR0FERScsXG4gICAgZmlyc3ROYW1lMTogJ05JVElOJyxcbiAgICBsYXN0TmFtZTE6ICdLQVVTSEFMJyxcbiAgICBjYXB0aW9uOiAnRmludGVjaCcsXG4gICAgY2FwdGlvbjE6ICdOQkZDJyxcbiAgICBsb2dvOiAnL2ljb25zL0NvdW50cnkuc3ZnJyxcbiAgICBpbWFnZTogJy9pY29ucy9DaGFrcmFkaGFyLnN2ZydcbiAgfV1cblxuICBjb25zdCBzZXR0aW5ncyA9IHtcbiAgICBkb3RzOiB0cnVlLFxuICAgIGluZmluaXRlOiB0cnVlLFxuICAgIHNwZWVkOiA1MDAsXG4gICAgYXV0b3BsYXlTcGVlZDogNTAwMCxcbiAgICBzbGlkZXNUb1Nob3c6IDEsXG4gICAgc2xpZGVzVG9TY3JvbGw6IDEsXG4gICAgLy8gYXV0b3BsYXk6IHRydWVcbiAgfTtcbiAgcmV0dXJuIChcbiAgICA8U2xpZGVyIHsuLi5zZXR0aW5nc30+XG4gICAgICB7aGVyb3MubWFwKGhlcm8gPT4ge1xuICAgICAgICByZXR1cm4gKDxkaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9e2Ake2NsYXNzTmFtZX1gfSBzdHlsZT17eyB3aWR0aDogNjE1Ljk0LCBoZWlnaHQ6IDg2My45MSwgcG9zaXRpb246IFwicmVsYXRpdmVcIiwgLi4uc3R5bGUsIH19PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJcIiBzdHlsZT17eyB3aWR0aDogNTcxLCBoZWlnaHQ6IDc2MiwgcG9zaXRpb246IFwiYWJzb2x1dGVcIiwgYmFja2dyb3VuZDogXCIjMDgzQTRBXCIsIGJvdHRvbTogNTAsIGxlZnQ6IDAsIH19PjwvZGl2PlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJcIiBzdHlsZT17eyB3aWR0aDogNTk0LCBoZWlnaHQ6IDc4OCwgYm90dG9tOiA2NSwgbGVmdDogMTUsIHBvc2l0aW9uOiBcImFic29sdXRlXCIsIGRpc3BsYXk6IFwiZmxleFwiLCBmbGV4RGlyZWN0aW9uOiBcImNvbHVtblwiLCB9fT5cbiAgICAgICAgICAgICAgPEltYWdlIHNyYz17aGVyby5pbWFnZX0gYWx0PVwiZm91bmRlciBpbWFnZVwiIHN0eWxlPXt7IGZsZXhHcm93OiAxIH19PjwvSW1hZ2U+XG4gICAgICAgICAgICAgIDxJbWFnZSBzcmM9XCIvaWNvbnMvcmVjdGFuZ2xlLnN2Z1wiIGFsdD17XCJyZWFjdGFuZ2xlXCJ9IGNsYXNzTmFtZT1cImFic29sdXRlXCIgc3R5bGU9e3sgbGVmdDogMzgsIGJvdHRvbTogMjU0IH19IC8+XG5cbiAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBoZWlnaHQ6IDIwOSwgYmFja2dyb3VuZDogXCIjMDE1NzZFXCIgfX0+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBmbGV4IGl0ZW1zLWNlbnRlclwiIHN0eWxlPXt7IGhlaWdodDogMTE4LCBib3JkZXJCb3R0b206IFwiMXB4IHNvbGlkICNFQkVCRTlcIiB9fT5cbiAgICAgICAgICAgICAgICAgIDxoNiBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zZWNvbmRhcnlcIiBzdHlsZT17eyBmb250U2l6ZTogMzIsIGxpbmVIZWlnaHQ6IFwiMzZweFwiLCBsZXR0ZXJTcGFjaW5nOiBcIjAuMDVlbVwiLCBtYXJnaW5MZWZ0OiAzMSwgbWFyZ2luUmlnaHQ6IDgsIH19PlxuICAgICAgICAgICAgICAgICAgICB7aGVyby5maXJzdE5hbWV9XG4gICAgICAgICAgICAgICAgICA8L2g2PlxuICAgICAgICAgICAgICAgICAgPGg2IGNsYXNzTmFtZT1cImZvbnQtbGlnaHQgdGV4dC1zZWNvbmRhcnlcIiBzdHlsZT17eyBmb250U2l6ZTogMzIsIGxpbmVIZWlnaHQ6IFwiMzZweFwiLCBsZXR0ZXJTcGFjaW5nOiBcIjAuMDVlbVwiLCB9fT5cbiAgICAgICAgICAgICAgICAgICAge2hlcm8ubGFzdE5hbWV9XG4gICAgICAgICAgICAgICAgICA8L2g2PlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBpdGVtcy1jZW50ZXJcIiBzdHlsZT17eyBoZWlnaHQ6IDg4IH19PlxuICAgICAgICAgICAgICAgICAgPGRpdiBzdHlsZT17eyBtYXJnaW5MZWZ0OiAzMSwgZGlzcGxheTogJ2ZsZXgnLCBqdXN0aWZ5Q29udGVudDogJ3NwYWNlLWFyb3VuZCcgfX0+XG4gICAgICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2Vjb25kYXJ5IGZvbnQtbWVkaXVtIHRleHQtbGcgbGVhZGluZy02XCI+IHtoZXJvLmNhcHRpb259PC9zcGFuPlxuICAgICAgICAgICAgICAgICAgICB7aGVyby5jYXB0aW9uMSAmJiA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNlY29uZGFyeSBmb250LW1lZGl1bSB0ZXh0LWxnIGxlYWRpbmctNlwiPjxociBzdHlsZT17eyB3aWR0aDogMzAsIHRyYW5zZm9ybTogJ3JvdGF0ZSg5MGRlZyknIH19IC8+PC9zcGFuPn1cbiAgICAgICAgICAgICAgICAgICAge2hlcm8uY2FwdGlvbjEgJiYgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zZWNvbmRhcnkgZm9udC1tZWRpdW0gdGV4dC1sZyBsZWFkaW5nLTZcIj4ge2hlcm8uY2FwdGlvbjF9PC9zcGFuPn1cbiAgICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICAgICAgPEltYWdlIHNyYz17aGVyby5sb2dvfSBhbHQ9e1wib2xhXCJ9IHN0eWxlPXt7IG1hcmdpblJpZ2h0OiA1NyB9fSAvPlxuICAgICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDwvZGl2PlxuXG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIlwiIHN0eWxlPXt7IGxlZnQ6IDc2MCwgcG9zaXRpb246IFwiYWJzb2x1dGVcIiB9fT5cbiAgICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT0nc2xpZGUtaGVhZGVyJz5XZSBhcmUgZm91bmRlcnMgZmlyc3Q8L2gxPlxuXG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+KVxuICAgICAgfSl9XG5cblxuXG5cbiAgICA8L1NsaWRlcj5cbiAgKTtcbn07XG4iXSwic291cmNlUm9vdCI6IiJ9