webpackHotUpdate_N_E("pages/home",{

/***/ "./src/modules/home/homeCarousal/HomeCarousal.tsx":
/*!********************************************************!*\
  !*** ./src/modules/home/homeCarousal/HomeCarousal.tsx ***!
  \********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var C_Users_KARTHIK_Documents_workspace_matrix_cms_ui_development_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/slicedToArray */ "./node_modules/@babel/runtime/helpers/esm/slicedToArray.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @components */ "./src/components/index.ts");
/* harmony import */ var _components_founder_FounderDetail__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @components/founder/FounderDetail */ "./src/components/founder/FounderDetail.tsx");
/* harmony import */ var react_responsive_carousel_lib_styles_carousel_min_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react-responsive-carousel/lib/styles/carousel.min.css */ "./node_modules/react-responsive-carousel/lib/styles/carousel.min.css");
/* harmony import */ var react_responsive_carousel_lib_styles_carousel_min_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_responsive_carousel_lib_styles_carousel_min_css__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var react_responsive_carousel__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! react-responsive-carousel */ "./node_modules/react-responsive-carousel/lib/js/index.js");
/* harmony import */ var react_responsive_carousel__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(react_responsive_carousel__WEBPACK_IMPORTED_MODULE_6__);



var _jsxFileName = "C:\\Users\\KARTHIK\\Documents\\workspace\\matrix-cms-ui-development\\src\\modules\\home\\homeCarousal\\HomeCarousal.tsx",
    _this = undefined,
    _s = $RefreshSig$();




 // requires a loader


var data = [{
  image_url: "/icons/content1.svg",
  title: "From both sides of the table : Kunal Bahl unplugged",
  author: "TARUN DAVDA",
  content_id: "abcdef",
  content_type: "blog",
  read_duration: "4 MIN"
}, {
  image_url: "/icons/content1.svg",
  title: "From both sides of the table : Kunal Bahl unplugged",
  author: "TARUN DAVDA",
  content_id: "abcdefg",
  content_type: "blog",
  read_duration: "4 MIN"
}];

var HomeCarousal = function HomeCarousal() {
  _s();

  var _React$useState = react__WEBPACK_IMPORTED_MODULE_2___default.a.useState("/icons/backgroundCarousalImage.png"),
      _React$useState2 = Object(C_Users_KARTHIK_Documents_workspace_matrix_cms_ui_development_node_modules_babel_runtime_helpers_esm_slicedToArray__WEBPACK_IMPORTED_MODULE_1__["default"])(_React$useState, 2),
      backgroundUrl = _React$useState2[0],
      setBackgroundUrl = _React$useState2[1];

  return (
    /*#__PURE__*/
    // <Carousel>
    Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "relative",
      style: {
        height: 1080
      },
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_responsive_carousel__WEBPACK_IMPORTED_MODULE_6__["Carousel"], {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "absolute h-full w-full flex flex-col",
          style: {
            backgroundImage: "url(".concat(backgroundUrl, ")"),
            backgroundSize: "cover"
          },
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "flex",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_3__["Image"], {
              src: "/icons/leftArrow.svg",
              alt: "right Icon",
              height: 73,
              width: 37,
              style: {
                marginLeft: 179
              }
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 43,
              columnNumber: 13
            }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              style: {
                width: 533,
                marginLeft: 100
              },
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                style: {
                  fontWeight: 300,
                  fontSize: "100px",
                  lineHeight: "120px",
                  letterSpacing: "-0.01em",
                  opacity: 0.35,
                  marginTop: 117
                },
                children: [" ", "01/05"]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 51,
                columnNumber: 15
              }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "text-secondary-light",
                style: {
                  fontWeight: 200,
                  fontSize: "85px",
                  lineHeight: "95px",
                  opacity: 1,
                  marginTop: 151,
                  minWidth: 545
                },
                children: ["Tech-enabled", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 76,
                  columnNumber: 15
                }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                  className: "font-bold",
                  children: " Student housing"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 77,
                  columnNumber: 17
                }, _this), " ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 77,
                  columnNumber: 69
                }, _this), "Platform"]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 64,
                columnNumber: 15
              }, _this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 50,
              columnNumber: 13
            }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_founder_FounderDetail__WEBPACK_IMPORTED_MODULE_4__["FounderDetail"], {
              style: {
                marginTop: 36,
                marginLeft: 103
              }
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 81,
              columnNumber: 13
            }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_3__["Image"], {
              src: "/icons/rightArrow.large.svg",
              alt: "right Icon",
              height: 73,
              width: 37,
              style: {
                marginLeft: 103
              }
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 82,
              columnNumber: 13
            }, _this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 42,
            columnNumber: 11
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "absolute bg-accent",
            style: {
              bottom: 33,
              left: 269,
              height: 246,
              width: 564
            },
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
              className: "text-secondary font-medium text-lg leading-6 text-center h-full flex justify-center items-center",
              style: {
                writingMode: "vertical-lr",
                width: 56
              },
              children: [" ", "Hospitality Sector", " "]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 94,
              columnNumber: 13
            }, _this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 90,
            columnNumber: 11
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_3__["ContentSlider"], {
            style: {
              left: 325,
              background: "#EBEBE9",
              border: "1px solid #EBEBE9",
              boxSizing: "border-box",
              fontSize: 28,
              lineHeight: "34px",
              paddingTop: 24,
              paddingLeft: 34
            },
            contentList: data,
            className: "absolute bottom-0 right-0 text-primary-dark",
            header: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
              children: ["Dive into the ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                className: "text-accent",
                children: "Matrix Moments"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 115,
                columnNumber: 41
              }, _this), " series"]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 115,
              columnNumber: 21
            }, _this)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 102,
            columnNumber: 11
          }, _this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 35,
          columnNumber: 9
        }, _this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 34,
        columnNumber: 7
      }, _this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 33,
      columnNumber: 5
    }, _this) // </Carousel>

  );
};

_s(HomeCarousal, "zzogb7U4cw9IdhqzvwsqoFa+QS0=");

_c = HomeCarousal;
/* harmony default export */ __webpack_exports__["default"] = (HomeCarousal);

var _c;

$RefreshReg$(_c, "HomeCarousal");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vc3JjL21vZHVsZXMvaG9tZS9ob21lQ2Fyb3VzYWwvSG9tZUNhcm91c2FsLnRzeCJdLCJuYW1lcyI6WyJkYXRhIiwiaW1hZ2VfdXJsIiwidGl0bGUiLCJhdXRob3IiLCJjb250ZW50X2lkIiwiY29udGVudF90eXBlIiwicmVhZF9kdXJhdGlvbiIsIkhvbWVDYXJvdXNhbCIsIlJlYWN0IiwidXNlU3RhdGUiLCJiYWNrZ3JvdW5kVXJsIiwic2V0QmFja2dyb3VuZFVybCIsImhlaWdodCIsImJhY2tncm91bmRJbWFnZSIsImJhY2tncm91bmRTaXplIiwibWFyZ2luTGVmdCIsIndpZHRoIiwiZm9udFdlaWdodCIsImZvbnRTaXplIiwibGluZUhlaWdodCIsImxldHRlclNwYWNpbmciLCJvcGFjaXR5IiwibWFyZ2luVG9wIiwibWluV2lkdGgiLCJib3R0b20iLCJsZWZ0Iiwid3JpdGluZ01vZGUiLCJiYWNrZ3JvdW5kIiwiYm9yZGVyIiwiYm94U2l6aW5nIiwicGFkZGluZ1RvcCIsInBhZGRpbmdMZWZ0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtDQUNnRTs7QUFDaEU7QUFFQSxJQUFNQSxJQUFJLEdBQUcsQ0FDWDtBQUNFQyxXQUFTLEVBQUUscUJBRGI7QUFFRUMsT0FBSyxFQUFFLHFEQUZUO0FBR0VDLFFBQU0sRUFBRSxhQUhWO0FBSUVDLFlBQVUsRUFBRSxRQUpkO0FBS0VDLGNBQVksRUFBRSxNQUxoQjtBQU1FQyxlQUFhLEVBQUU7QUFOakIsQ0FEVyxFQVNYO0FBQ0VMLFdBQVMsRUFBRSxxQkFEYjtBQUVFQyxPQUFLLEVBQUUscURBRlQ7QUFHRUMsUUFBTSxFQUFFLGFBSFY7QUFJRUMsWUFBVSxFQUFFLFNBSmQ7QUFLRUMsY0FBWSxFQUFFLE1BTGhCO0FBTUVDLGVBQWEsRUFBRTtBQU5qQixDQVRXLENBQWI7O0FBb0JBLElBQU1DLFlBQVksR0FBRyxTQUFmQSxZQUFlLEdBQU07QUFBQTs7QUFBQSx3QkFDaUJDLDRDQUFLLENBQUNDLFFBQU4sQ0FDeEMsb0NBRHdDLENBRGpCO0FBQUE7QUFBQSxNQUNsQkMsYUFEa0I7QUFBQSxNQUNIQyxnQkFERzs7QUFJekI7QUFBQTtBQUNFO0FBQ0E7QUFBSyxlQUFTLEVBQUMsVUFBZjtBQUEwQixXQUFLLEVBQUU7QUFBRUMsY0FBTSxFQUFFO0FBQVYsT0FBakM7QUFBQSw2QkFDRSxxRUFBQyxrRUFBRDtBQUFBLCtCQUNFO0FBQ0UsbUJBQVMsRUFBQyxzQ0FEWjtBQUVFLGVBQUssRUFBRTtBQUNMQywyQkFBZSxnQkFBU0gsYUFBVCxNQURWO0FBRUxJLDBCQUFjLEVBQUU7QUFGWCxXQUZUO0FBQUEsa0NBT0U7QUFBSyxxQkFBUyxFQUFDLE1BQWY7QUFBQSxvQ0FDRSxxRUFBQyxpREFBRDtBQUNFLGlCQUFHLEVBQUMsc0JBRE47QUFFRSxpQkFBRyxFQUFFLFlBRlA7QUFHRSxvQkFBTSxFQUFFLEVBSFY7QUFJRSxtQkFBSyxFQUFFLEVBSlQ7QUFLRSxtQkFBSyxFQUFFO0FBQUVDLDBCQUFVLEVBQUU7QUFBZDtBQUxUO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREYsZUFRRTtBQUFLLG1CQUFLLEVBQUU7QUFBRUMscUJBQUssRUFBRSxHQUFUO0FBQWNELDBCQUFVLEVBQUU7QUFBMUIsZUFBWjtBQUFBLHNDQUNFO0FBQ0UscUJBQUssRUFBRTtBQUNMRSw0QkFBVSxFQUFFLEdBRFA7QUFFTEMsMEJBQVEsRUFBRSxPQUZMO0FBR0xDLDRCQUFVLEVBQUUsT0FIUDtBQUlMQywrQkFBYSxFQUFFLFNBSlY7QUFLTEMseUJBQU8sRUFBRSxJQUxKO0FBTUxDLDJCQUFTLEVBQUU7QUFOTixpQkFEVDtBQUFBLDJCQVVHLEdBVkg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQURGLGVBY0U7QUFDRSx5QkFBUyxFQUFDLHNCQURaO0FBRUUscUJBQUssRUFBRTtBQUNMTCw0QkFBVSxFQUFFLEdBRFA7QUFFTEMsMEJBQVEsRUFBRSxNQUZMO0FBR0xDLDRCQUFVLEVBQUUsTUFIUDtBQUlMRSx5QkFBTyxFQUFFLENBSko7QUFLTEMsMkJBQVMsRUFBRSxHQUxOO0FBTUxDLDBCQUFRLEVBQUU7QUFOTCxpQkFGVDtBQUFBLHdEQVlBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBWkEsZUFhRTtBQUFNLDJCQUFTLEVBQUMsV0FBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBYkYsb0JBYXNEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBYnREO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFkRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBUkYsZUF1Q0UscUVBQUMsK0VBQUQ7QUFBZSxtQkFBSyxFQUFFO0FBQUVELHlCQUFTLEVBQUUsRUFBYjtBQUFpQlAsMEJBQVUsRUFBRTtBQUE3QjtBQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQXZDRixlQXdDRSxxRUFBQyxpREFBRDtBQUNFLGlCQUFHLEVBQUMsNkJBRE47QUFFRSxpQkFBRyxFQUFFLFlBRlA7QUFHRSxvQkFBTSxFQUFFLEVBSFY7QUFJRSxtQkFBSyxFQUFFLEVBSlQ7QUFLRSxtQkFBSyxFQUFFO0FBQUVBLDBCQUFVLEVBQUU7QUFBZDtBQUxUO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBeENGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFQRixlQXVERTtBQUNFLHFCQUFTLEVBQUMsb0JBRFo7QUFFRSxpQkFBSyxFQUFFO0FBQUVTLG9CQUFNLEVBQUUsRUFBVjtBQUFjQyxrQkFBSSxFQUFFLEdBQXBCO0FBQXlCYixvQkFBTSxFQUFFLEdBQWpDO0FBQXNDSSxtQkFBSyxFQUFFO0FBQTdDLGFBRlQ7QUFBQSxtQ0FJRTtBQUNFLHVCQUFTLEVBQUMsa0dBRFo7QUFFRSxtQkFBSyxFQUFFO0FBQUVVLDJCQUFXLEVBQUUsYUFBZjtBQUE4QlYscUJBQUssRUFBRTtBQUFyQyxlQUZUO0FBQUEseUJBSUcsR0FKSCx3QkFLbUIsR0FMbkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkF2REYsZUFtRUUscUVBQUMseURBQUQ7QUFDRSxpQkFBSyxFQUFFO0FBQ0xTLGtCQUFJLEVBQUUsR0FERDtBQUVMRSx3QkFBVSxFQUFFLFNBRlA7QUFHTEMsb0JBQU0sRUFBRSxtQkFISDtBQUlMQyx1QkFBUyxFQUFFLFlBSk47QUFLTFgsc0JBQVEsRUFBRSxFQUxMO0FBTUxDLHdCQUFVLEVBQUUsTUFOUDtBQU9MVyx3QkFBVSxFQUFFLEVBUFA7QUFRTEMseUJBQVcsRUFBRTtBQVJSLGFBRFQ7QUFXRSx1QkFBVyxFQUFFL0IsSUFYZjtBQVlFLHFCQUFTLEVBQUMsNkNBWlo7QUFhRSxrQkFBTSxlQUFFO0FBQUEsd0RBQW9CO0FBQU0seUJBQVMsRUFBQyxhQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBYlY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFuRUY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFGRixDQXlGRTs7QUF6RkY7QUEyRkQsQ0EvRkQ7O0dBQU1PLFk7O0tBQUFBLFk7QUFpR1NBLDJFQUFmIiwiZmlsZSI6InN0YXRpYy93ZWJwYWNrL3BhZ2VzL2hvbWUuNWMwZDQzM2E0N2M0ZDAzZjhhM2QuaG90LXVwZGF0ZS5qcyIsInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IEltYWdlLCBDb250ZW50U2xpZGVyIH0gZnJvbSBcIkBjb21wb25lbnRzXCI7XG5pbXBvcnQgeyBGb3VuZGVyRGV0YWlsIH0gZnJvbSBcIkBjb21wb25lbnRzL2ZvdW5kZXIvRm91bmRlckRldGFpbFwiO1xuaW1wb3J0IFwicmVhY3QtcmVzcG9uc2l2ZS1jYXJvdXNlbC9saWIvc3R5bGVzL2Nhcm91c2VsLm1pbi5jc3NcIjsgLy8gcmVxdWlyZXMgYSBsb2FkZXJcbmltcG9ydCB7IENhcm91c2VsIH0gZnJvbSAncmVhY3QtcmVzcG9uc2l2ZS1jYXJvdXNlbCc7XG5cbmNvbnN0IGRhdGEgPSBbXG4gIHtcbiAgICBpbWFnZV91cmw6IFwiL2ljb25zL2NvbnRlbnQxLnN2Z1wiLFxuICAgIHRpdGxlOiBcIkZyb20gYm90aCBzaWRlcyBvZiB0aGUgdGFibGUgOiBLdW5hbCBCYWhsIHVucGx1Z2dlZFwiLFxuICAgIGF1dGhvcjogXCJUQVJVTiBEQVZEQVwiLFxuICAgIGNvbnRlbnRfaWQ6IFwiYWJjZGVmXCIsXG4gICAgY29udGVudF90eXBlOiBcImJsb2dcIixcbiAgICByZWFkX2R1cmF0aW9uOiBcIjQgTUlOXCIsXG4gIH0sXG4gIHtcbiAgICBpbWFnZV91cmw6IFwiL2ljb25zL2NvbnRlbnQxLnN2Z1wiLFxuICAgIHRpdGxlOiBcIkZyb20gYm90aCBzaWRlcyBvZiB0aGUgdGFibGUgOiBLdW5hbCBCYWhsIHVucGx1Z2dlZFwiLFxuICAgIGF1dGhvcjogXCJUQVJVTiBEQVZEQVwiLFxuICAgIGNvbnRlbnRfaWQ6IFwiYWJjZGVmZ1wiLFxuICAgIGNvbnRlbnRfdHlwZTogXCJibG9nXCIsXG4gICAgcmVhZF9kdXJhdGlvbjogXCI0IE1JTlwiLFxuICB9LFxuXG5dO1xuXG5jb25zdCBIb21lQ2Fyb3VzYWwgPSAoKSA9PiB7XG4gIGNvbnN0IFtiYWNrZ3JvdW5kVXJsLCBzZXRCYWNrZ3JvdW5kVXJsXSA9IFJlYWN0LnVzZVN0YXRlKFxuICAgIFwiL2ljb25zL2JhY2tncm91bmRDYXJvdXNhbEltYWdlLnBuZ1wiXG4gICk7XG4gIHJldHVybiAoXG4gICAgLy8gPENhcm91c2VsPlxuICAgIDxkaXYgY2xhc3NOYW1lPVwicmVsYXRpdmVcIiBzdHlsZT17eyBoZWlnaHQ6IDEwODAgfX0+XG4gICAgICA8Q2Fyb3VzZWw+XG4gICAgICAgIDxkaXZcbiAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSBoLWZ1bGwgdy1mdWxsIGZsZXggZmxleC1jb2xcIlxuICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICBiYWNrZ3JvdW5kSW1hZ2U6IGB1cmwoJHtiYWNrZ3JvdW5kVXJsfSlgLFxuICAgICAgICAgICAgYmFja2dyb3VuZFNpemU6IFwiY292ZXJcIixcbiAgICAgICAgICB9fVxuICAgICAgICA+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4XCI+XG4gICAgICAgICAgICA8SW1hZ2VcbiAgICAgICAgICAgICAgc3JjPVwiL2ljb25zL2xlZnRBcnJvdy5zdmdcIlxuICAgICAgICAgICAgICBhbHQ9e1wicmlnaHQgSWNvblwifVxuICAgICAgICAgICAgICBoZWlnaHQ9ezczfVxuICAgICAgICAgICAgICB3aWR0aD17Mzd9XG4gICAgICAgICAgICAgIHN0eWxlPXt7IG1hcmdpbkxlZnQ6IDE3OSB9fVxuICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgd2lkdGg6IDUzMywgbWFyZ2luTGVmdDogMTAwIH19PlxuICAgICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICAgICAgICAgIGZvbnRXZWlnaHQ6IDMwMCxcbiAgICAgICAgICAgICAgICAgIGZvbnRTaXplOiBcIjEwMHB4XCIsXG4gICAgICAgICAgICAgICAgICBsaW5lSGVpZ2h0OiBcIjEyMHB4XCIsXG4gICAgICAgICAgICAgICAgICBsZXR0ZXJTcGFjaW5nOiBcIi0wLjAxZW1cIixcbiAgICAgICAgICAgICAgICAgIG9wYWNpdHk6IDAuMzUsXG4gICAgICAgICAgICAgICAgICBtYXJnaW5Ub3A6IDExNyxcbiAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAge1wiIFwifVxuICAgICAgICAgICAgICAwMS8wNVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXNlY29uZGFyeS1saWdodFwiXG4gICAgICAgICAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICAgICAgICAgIGZvbnRXZWlnaHQ6IDIwMCxcbiAgICAgICAgICAgICAgICAgIGZvbnRTaXplOiBcIjg1cHhcIixcbiAgICAgICAgICAgICAgICAgIGxpbmVIZWlnaHQ6IFwiOTVweFwiLFxuICAgICAgICAgICAgICAgICAgb3BhY2l0eTogMSxcbiAgICAgICAgICAgICAgICAgIG1hcmdpblRvcDogMTUxLFxuICAgICAgICAgICAgICAgICAgbWluV2lkdGg6IDU0NSxcbiAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgVGVjaC1lbmFibGVkXG4gICAgICAgICAgICAgIDxiciAvPlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtYm9sZFwiPiBTdHVkZW50IGhvdXNpbmc8L3NwYW4+IDxiciAvPlxuICAgICAgICAgICAgICBQbGF0Zm9ybVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxGb3VuZGVyRGV0YWlsIHN0eWxlPXt7IG1hcmdpblRvcDogMzYsIG1hcmdpbkxlZnQ6IDEwMyB9fSAvPlxuICAgICAgICAgICAgPEltYWdlXG4gICAgICAgICAgICAgIHNyYz1cIi9pY29ucy9yaWdodEFycm93LmxhcmdlLnN2Z1wiXG4gICAgICAgICAgICAgIGFsdD17XCJyaWdodCBJY29uXCJ9XG4gICAgICAgICAgICAgIGhlaWdodD17NzN9XG4gICAgICAgICAgICAgIHdpZHRoPXszN31cbiAgICAgICAgICAgICAgc3R5bGU9e3sgbWFyZ2luTGVmdDogMTAzIH19XG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImFic29sdXRlIGJnLWFjY2VudFwiXG4gICAgICAgICAgICBzdHlsZT17eyBib3R0b206IDMzLCBsZWZ0OiAyNjksIGhlaWdodDogMjQ2LCB3aWR0aDogNTY0IH19XG4gICAgICAgICAgPlxuICAgICAgICAgICAgPHNwYW5cbiAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1zZWNvbmRhcnkgZm9udC1tZWRpdW0gdGV4dC1sZyBsZWFkaW5nLTYgdGV4dC1jZW50ZXIgaC1mdWxsIGZsZXgganVzdGlmeS1jZW50ZXIgaXRlbXMtY2VudGVyXCJcbiAgICAgICAgICAgICAgc3R5bGU9e3sgd3JpdGluZ01vZGU6IFwidmVydGljYWwtbHJcIiwgd2lkdGg6IDU2IH19XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIHtcIiBcIn1cbiAgICAgICAgICAgIEhvc3BpdGFsaXR5IFNlY3RvcntcIiBcIn1cbiAgICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8Q29udGVudFNsaWRlclxuICAgICAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICAgICAgbGVmdDogMzI1LFxuICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiBcIiNFQkVCRTlcIixcbiAgICAgICAgICAgICAgYm9yZGVyOiBcIjFweCBzb2xpZCAjRUJFQkU5XCIsXG4gICAgICAgICAgICAgIGJveFNpemluZzogXCJib3JkZXItYm94XCIsXG4gICAgICAgICAgICAgIGZvbnRTaXplOiAyOCxcbiAgICAgICAgICAgICAgbGluZUhlaWdodDogXCIzNHB4XCIsXG4gICAgICAgICAgICAgIHBhZGRpbmdUb3A6IDI0LFxuICAgICAgICAgICAgICBwYWRkaW5nTGVmdDogMzQsXG4gICAgICAgICAgICB9fVxuICAgICAgICAgICAgY29udGVudExpc3Q9e2RhdGF9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSBib3R0b20tMCByaWdodC0wIHRleHQtcHJpbWFyeS1kYXJrXCJcbiAgICAgICAgICAgIGhlYWRlcj17PHNwYW4+RGl2ZSBpbnRvIHRoZSA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWFjY2VudFwiPk1hdHJpeCBNb21lbnRzPC9zcGFuPiBzZXJpZXM8L3NwYW4+fVxuICAgICAgICAgIC8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9DYXJvdXNlbD5cbiAgICA8L2Rpdj5cbiAgICAvLyA8L0Nhcm91c2VsPlxuICApO1xufTtcblxuZXhwb3J0IGRlZmF1bHQgSG9tZUNhcm91c2FsO1xuIl0sInNvdXJjZVJvb3QiOiIifQ==