webpackHotUpdate_N_E("pages/home",{

/***/ "./src/components/founder/Founder.tsx":
/*!********************************************!*\
  !*** ./src/components/founder/Founder.tsx ***!
  \********************************************/
/*! exports provided: Founder */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* WEBPACK VAR INJECTION */(function(module) {/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Founder", function() { return Founder; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "./node_modules/react/jsx-dev-runtime.js");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var C_Users_KARTHIK_Documents_workspace_matrix_cms_ui_development_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node_modules/@babel/runtime/helpers/esm/defineProperty */ "./node_modules/@babel/runtime/helpers/esm/defineProperty.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ "./node_modules/react/index.js");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @components */ "./src/components/index.ts");
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react-slick */ "./node_modules/react-slick/lib/index.js");
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_slick__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! slick-carousel/slick/slick.css */ "./node_modules/slick-carousel/slick/slick.css");
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! slick-carousel/slick/slick-theme.css */ "./node_modules/slick-carousel/slick/slick-theme.css");
/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_6__);



var _jsxFileName = "C:\\Users\\KARTHIK\\Documents\\workspace\\matrix-cms-ui-development\\src\\components\\founder\\Founder.tsx",
    _this = undefined;

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { Object(C_Users_KARTHIK_Documents_workspace_matrix_cms_ui_development_node_modules_babel_runtime_helpers_esm_defineProperty__WEBPACK_IMPORTED_MODULE_1__["default"])(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }






var Founder = function Founder(_ref) {
  var className = _ref.className,
      _ref$style = _ref.style,
      style = _ref$style === void 0 ? {} : _ref$style;
  var heros = [{
    firstName: 'Bhavish',
    lastName: 'AGGARWAL',
    firstName1: null,
    lastName1: null,
    caption: 'Mobility',
    caption1: 'Electric Cars',
    logo: '/icons/ola.svg',
    image: '/icons/Bhavish_image.svg',
    heading: ['We are', 'founders', 'first']
  }, {
    firstName: 'ROHIT',
    lastName: 'M.A.',
    firstName1: null,
    lastName1: null,
    caption: 'Healthcare',
    caption1: null,
    logo: '/icons/Cloudnine.svg',
    image: '/icons/Rohit_Treatment.svg',
    heading: ['We ', 'partner', 'closely']
  }, {
    firstName: 'ANINDYA',
    lastName: 'DUTTA',
    firstName1: 'SANDEEP',
    lastName1: 'DALMIA',
    caption: 'Student Housing Platform',
    caption1: null,
    logo: '/icons/Stanza.svg',
    image: '/icons/Anindya.svg',
    heading: ['We ', 'invest', 'early']
  }, {
    firstName: 'Asish',
    lastName: 'MOHAPATRA',
    firstName1: null,
    lastName1: null,
    caption: 'Fintech',
    caption1: 'SME Lending',
    logo: '/icons/OfBusiness.svg',
    image: '/icons/Asish.svg',
    heading: ['We', 'commit', 'personally']
  }, {
    firstName: 'Mr.',
    lastName: 'LAKSHIPATHY',
    firstName1: null,
    lastName1: null,
    caption: 'Fintech',
    caption1: 'NBFC',
    logo: '/icons/mx.svg',
    image: '/icons/Laxmipathy.svg',
    heading: ['We are', 'founders', 'first']
  }, {
    firstName: 'CHAKRADHAR',
    lastName: 'GADE',
    firstName1: 'NITIN',
    lastName1: 'KAUSHAL',
    caption: 'Fintech',
    caption1: 'NBFC',
    logo: '/icons/Country.svg',
    heading: ['We', 'commit', 'personally'],
    image: '/icons/Chakradhar.svg'
  }];
  var settings = {
    dots: true,
    infinite: true,
    speed: 500,
    autoplaySpeed: 5000,
    slidesToShow: 1,
    slidesToScroll: 1 // autoplay: true

  };
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_slick__WEBPACK_IMPORTED_MODULE_4___default.a, _objectSpread(_objectSpread({}, settings), {}, {
    children: heros.map(function (hero) {
      return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "".concat(className),
          style: _objectSpread({
            width: 615.94,
            height: 863.91,
            position: "relative"
          }, style),
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "",
            style: {
              width: 571,
              height: 762,
              position: "absolute",
              background: "#083A4A",
              bottom: 50,
              left: 0
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 93,
            columnNumber: 13
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "",
            style: {
              width: 594,
              height: 788,
              bottom: 65,
              left: 15,
              position: "absolute",
              display: "flex",
              flexDirection: "column"
            },
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_3__["Image"], {
              src: hero.image,
              alt: "founder image",
              style: {
                flexGrow: 1
              }
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 95,
              columnNumber: 15
            }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_3__["Image"], {
              src: "/icons/rectangle.svg",
              alt: "reactangle",
              className: "absolute",
              style: {
                left: 38,
                bottom: 254
              }
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 96,
              columnNumber: 15
            }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              style: {
                height: 209,
                background: "#01576E"
              },
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "text-center flex items-center",
                style: {
                  height: 118,
                  borderBottom: "1px solid #EBEBE9"
                },
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h6", {
                  className: "font-bold text-secondary",
                  style: {
                    fontSize: 32,
                    lineHeight: "36px",
                    letterSpacing: "0.05em",
                    marginLeft: 31,
                    marginRight: 8
                  },
                  children: hero.firstName
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 100,
                  columnNumber: 19
                }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h6", {
                  className: "font-light text-secondary",
                  style: {
                    fontSize: 32,
                    lineHeight: "36px",
                    letterSpacing: "0.05em"
                  },
                  children: hero.lastName
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 103,
                  columnNumber: 19
                }, _this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 99,
                columnNumber: 17
              }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "flex justify-between items-center",
                style: {
                  height: 88
                },
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  style: {
                    marginLeft: 31,
                    display: 'flex',
                    justifyContent: 'space-around'
                  },
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                    className: "text-secondary font-medium text-lg leading-6",
                    children: [" ", hero.caption]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 110,
                    columnNumber: 21
                  }, _this), hero.caption1 && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                    className: "text-secondary font-medium text-lg leading-6",
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("hr", {
                      style: {
                        width: 30,
                        transform: 'rotate(90deg)'
                      }
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 111,
                      columnNumber: 102
                    }, _this)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 111,
                    columnNumber: 39
                  }, _this), hero.caption1 && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                    className: "text-secondary font-medium text-lg leading-6",
                    children: [" ", hero.caption1]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 112,
                    columnNumber: 39
                  }, _this)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 109,
                  columnNumber: 19
                }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_3__["Image"], {
                  src: hero.logo,
                  alt: "ola",
                  style: {
                    marginRight: 57
                  }
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 114,
                  columnNumber: 19
                }, _this)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 108,
                columnNumber: 17
              }, _this)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 98,
              columnNumber: 15
            }, _this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 94,
            columnNumber: 13
          }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "",
            style: {
              left: 760,
              position: "absolute"
            },
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
              className: "slide-header",
              children: [hero.heading[0], /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                style: {
                  color: '#01576E'
                },
                children: [" ", hero.heading[1], " "]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 120,
                columnNumber: 60
              }, _this), " ", hero.heading[2]]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 120,
              columnNumber: 15
            }, _this), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              children: "hchgcvhg"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 121,
              columnNumber: 15
            }, _this)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 119,
            columnNumber: 13
          }, _this)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 92,
          columnNumber: 11
        }, _this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 91,
        columnNumber: 17
      }, _this);
    })
  }), void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 89,
    columnNumber: 5
  }, _this);
};
_c = Founder;

var _c;

$RefreshReg$(_c, "Founder");

;
    var _a, _b;
    // Legacy CSS implementations will `eval` browser code in a Node.js context
    // to extract CSS. For backwards compatibility, we need to check we're in a
    // browser context before continuing.
    if (typeof self !== 'undefined' &&
        // AMP / No-JS mode does not inject these helpers:
        '$RefreshHelpers$' in self) {
        var currentExports = module.__proto__.exports;
        var prevExports = (_b = (_a = module.hot.data) === null || _a === void 0 ? void 0 : _a.prevExports) !== null && _b !== void 0 ? _b : null;
        // This cannot happen in MainTemplate because the exports mismatch between
        // templating and execution.
        self.$RefreshHelpers$.registerExportsForReactRefresh(currentExports, module.i);
        // A module can be accepted automatically based on its exports, e.g. when
        // it is a Refresh Boundary.
        if (self.$RefreshHelpers$.isReactRefreshBoundary(currentExports)) {
            // Save the previous exports on update so we can compare the boundary
            // signatures.
            module.hot.dispose(function (data) {
                data.prevExports = currentExports;
            });
            // Unconditionally accept an update to this module, we'll check if it's
            // still a Refresh Boundary later.
            module.hot.accept();
            // This field is set when the previous version of this module was a
            // Refresh Boundary, letting us know we need to check for invalidation or
            // enqueue an update.
            if (prevExports !== null) {
                // A boundary can become ineligible if its exports are incompatible
                // with the previous exports.
                //
                // For example, if you add/remove/change exports, we'll want to
                // re-execute the importing modules, and force those components to
                // re-render. Similarly, if you convert a class component to a
                // function, we want to invalidate the boundary.
                if (self.$RefreshHelpers$.shouldInvalidateReactRefreshBoundary(prevExports, currentExports)) {
                    module.hot.invalidate();
                }
                else {
                    self.$RefreshHelpers$.scheduleUpdate();
                }
            }
        }
        else {
            // Since we just executed the code for the module, it's possible that the
            // new exports made it ineligible for being a boundary.
            // We only care about the case when we were _previously_ a boundary,
            // because we already accepted this update (accidental side effect).
            var isNoLongerABoundary = prevExports !== null;
            if (isNoLongerABoundary) {
                module.hot.invalidate();
            }
        }
    }

/* WEBPACK VAR INJECTION */}.call(this, __webpack_require__(/*! ./../../../node_modules/next/dist/compiled/webpack/harmony-module.js */ "./node_modules/next/dist/compiled/webpack/harmony-module.js")(module)))

/***/ })

})
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9fTl9FLy4vc3JjL2NvbXBvbmVudHMvZm91bmRlci9Gb3VuZGVyLnRzeCJdLCJuYW1lcyI6WyJGb3VuZGVyIiwiY2xhc3NOYW1lIiwic3R5bGUiLCJoZXJvcyIsImZpcnN0TmFtZSIsImxhc3ROYW1lIiwiZmlyc3ROYW1lMSIsImxhc3ROYW1lMSIsImNhcHRpb24iLCJjYXB0aW9uMSIsImxvZ28iLCJpbWFnZSIsImhlYWRpbmciLCJzZXR0aW5ncyIsImRvdHMiLCJpbmZpbml0ZSIsInNwZWVkIiwiYXV0b3BsYXlTcGVlZCIsInNsaWRlc1RvU2hvdyIsInNsaWRlc1RvU2Nyb2xsIiwibWFwIiwiaGVybyIsIndpZHRoIiwiaGVpZ2h0IiwicG9zaXRpb24iLCJiYWNrZ3JvdW5kIiwiYm90dG9tIiwibGVmdCIsImRpc3BsYXkiLCJmbGV4RGlyZWN0aW9uIiwiZmxleEdyb3ciLCJib3JkZXJCb3R0b20iLCJmb250U2l6ZSIsImxpbmVIZWlnaHQiLCJsZXR0ZXJTcGFjaW5nIiwibWFyZ2luTGVmdCIsIm1hcmdpblJpZ2h0IiwianVzdGlmeUNvbnRlbnQiLCJ0cmFuc2Zvcm0iLCJjb2xvciJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFXTyxJQUFNQSxPQUF3QixHQUFHLFNBQTNCQSxPQUEyQixPQUErQjtBQUFBLE1BQTVCQyxTQUE0QixRQUE1QkEsU0FBNEI7QUFBQSx3QkFBakJDLEtBQWlCO0FBQUEsTUFBakJBLEtBQWlCLDJCQUFULEVBQVM7QUFDckUsTUFBTUMsS0FBSyxHQUFHLENBQUM7QUFDYkMsYUFBUyxFQUFFLFNBREU7QUFFYkMsWUFBUSxFQUFFLFVBRkc7QUFHYkMsY0FBVSxFQUFFLElBSEM7QUFJYkMsYUFBUyxFQUFFLElBSkU7QUFLYkMsV0FBTyxFQUFFLFVBTEk7QUFNYkMsWUFBUSxFQUFFLGVBTkc7QUFPYkMsUUFBSSxFQUFFLGdCQVBPO0FBUWJDLFNBQUssRUFBRSwwQkFSTTtBQVNiQyxXQUFPLEVBQUUsQ0FBQyxRQUFELEVBQVcsVUFBWCxFQUF1QixPQUF2QjtBQVRJLEdBQUQsRUFVWDtBQUNEUixhQUFTLEVBQUUsT0FEVjtBQUVEQyxZQUFRLEVBQUUsTUFGVDtBQUdEQyxjQUFVLEVBQUUsSUFIWDtBQUlEQyxhQUFTLEVBQUUsSUFKVjtBQUtEQyxXQUFPLEVBQUUsWUFMUjtBQU1EQyxZQUFRLEVBQUUsSUFOVDtBQU9EQyxRQUFJLEVBQUUsc0JBUEw7QUFRREMsU0FBSyxFQUFFLDRCQVJOO0FBU0RDLFdBQU8sRUFBRSxDQUFDLEtBQUQsRUFBUSxTQUFSLEVBQW1CLFNBQW5CO0FBVFIsR0FWVyxFQW9CWDtBQUNEUixhQUFTLEVBQUUsU0FEVjtBQUVEQyxZQUFRLEVBQUUsT0FGVDtBQUdEQyxjQUFVLEVBQUUsU0FIWDtBQUlEQyxhQUFTLEVBQUUsUUFKVjtBQUtEQyxXQUFPLEVBQUUsMEJBTFI7QUFNREMsWUFBUSxFQUFFLElBTlQ7QUFPREMsUUFBSSxFQUFFLG1CQVBMO0FBUURDLFNBQUssRUFBRSxvQkFSTjtBQVNEQyxXQUFPLEVBQUUsQ0FBQyxLQUFELEVBQVEsUUFBUixFQUFrQixPQUFsQjtBQVRSLEdBcEJXLEVBOEJYO0FBQ0RSLGFBQVMsRUFBRSxPQURWO0FBRURDLFlBQVEsRUFBRSxXQUZUO0FBR0RDLGNBQVUsRUFBRSxJQUhYO0FBSURDLGFBQVMsRUFBRSxJQUpWO0FBS0RDLFdBQU8sRUFBRSxTQUxSO0FBTURDLFlBQVEsRUFBRSxhQU5UO0FBT0RDLFFBQUksRUFBRSx1QkFQTDtBQVFEQyxTQUFLLEVBQUUsa0JBUk47QUFTREMsV0FBTyxFQUFFLENBQUMsSUFBRCxFQUFPLFFBQVAsRUFBaUIsWUFBakI7QUFUUixHQTlCVyxFQXdDWDtBQUNEUixhQUFTLEVBQUUsS0FEVjtBQUVEQyxZQUFRLEVBQUUsYUFGVDtBQUdEQyxjQUFVLEVBQUUsSUFIWDtBQUlEQyxhQUFTLEVBQUUsSUFKVjtBQUtEQyxXQUFPLEVBQUUsU0FMUjtBQU1EQyxZQUFRLEVBQUUsTUFOVDtBQU9EQyxRQUFJLEVBQUUsZUFQTDtBQVFEQyxTQUFLLEVBQUUsdUJBUk47QUFTREMsV0FBTyxFQUFFLENBQUMsUUFBRCxFQUFXLFVBQVgsRUFBdUIsT0FBdkI7QUFUUixHQXhDVyxFQWtEWDtBQUNEUixhQUFTLEVBQUUsWUFEVjtBQUVEQyxZQUFRLEVBQUUsTUFGVDtBQUdEQyxjQUFVLEVBQUUsT0FIWDtBQUlEQyxhQUFTLEVBQUUsU0FKVjtBQUtEQyxXQUFPLEVBQUUsU0FMUjtBQU1EQyxZQUFRLEVBQUUsTUFOVDtBQU9EQyxRQUFJLEVBQUUsb0JBUEw7QUFRREUsV0FBTyxFQUFFLENBQUMsSUFBRCxFQUFPLFFBQVAsRUFBaUIsWUFBakIsQ0FSUjtBQVNERCxTQUFLLEVBQUU7QUFUTixHQWxEVyxDQUFkO0FBOERBLE1BQU1FLFFBQVEsR0FBRztBQUNmQyxRQUFJLEVBQUUsSUFEUztBQUVmQyxZQUFRLEVBQUUsSUFGSztBQUdmQyxTQUFLLEVBQUUsR0FIUTtBQUlmQyxpQkFBYSxFQUFFLElBSkE7QUFLZkMsZ0JBQVksRUFBRSxDQUxDO0FBTWZDLGtCQUFjLEVBQUUsQ0FORCxDQU9mOztBQVBlLEdBQWpCO0FBU0Esc0JBQ0UscUVBQUMsa0RBQUQsa0NBQVlOLFFBQVo7QUFBQSxjQUNHVixLQUFLLENBQUNpQixHQUFOLENBQVUsVUFBQUMsSUFBSSxFQUFJO0FBQ2pCLDBCQUFRO0FBQUEsK0JBQ047QUFBSyxtQkFBUyxZQUFLcEIsU0FBTCxDQUFkO0FBQWdDLGVBQUs7QUFBSXFCLGlCQUFLLEVBQUUsTUFBWDtBQUFtQkMsa0JBQU0sRUFBRSxNQUEzQjtBQUFtQ0Msb0JBQVEsRUFBRTtBQUE3QyxhQUE0RHRCLEtBQTVELENBQXJDO0FBQUEsa0NBQ0U7QUFBSyxxQkFBUyxFQUFDLEVBQWY7QUFBa0IsaUJBQUssRUFBRTtBQUFFb0IsbUJBQUssRUFBRSxHQUFUO0FBQWNDLG9CQUFNLEVBQUUsR0FBdEI7QUFBMkJDLHNCQUFRLEVBQUUsVUFBckM7QUFBaURDLHdCQUFVLEVBQUUsU0FBN0Q7QUFBd0VDLG9CQUFNLEVBQUUsRUFBaEY7QUFBb0ZDLGtCQUFJLEVBQUU7QUFBMUY7QUFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFERixlQUVFO0FBQUsscUJBQVMsRUFBQyxFQUFmO0FBQWtCLGlCQUFLLEVBQUU7QUFBRUwsbUJBQUssRUFBRSxHQUFUO0FBQWNDLG9CQUFNLEVBQUUsR0FBdEI7QUFBMkJHLG9CQUFNLEVBQUUsRUFBbkM7QUFBdUNDLGtCQUFJLEVBQUUsRUFBN0M7QUFBaURILHNCQUFRLEVBQUUsVUFBM0Q7QUFBdUVJLHFCQUFPLEVBQUUsTUFBaEY7QUFBd0ZDLDJCQUFhLEVBQUU7QUFBdkcsYUFBekI7QUFBQSxvQ0FDRSxxRUFBQyxpREFBRDtBQUFPLGlCQUFHLEVBQUVSLElBQUksQ0FBQ1YsS0FBakI7QUFBd0IsaUJBQUcsRUFBQyxlQUE1QjtBQUE0QyxtQkFBSyxFQUFFO0FBQUVtQix3QkFBUSxFQUFFO0FBQVo7QUFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFERixlQUVFLHFFQUFDLGlEQUFEO0FBQU8saUJBQUcsRUFBQyxzQkFBWDtBQUFrQyxpQkFBRyxFQUFFLFlBQXZDO0FBQXFELHVCQUFTLEVBQUMsVUFBL0Q7QUFBMEUsbUJBQUssRUFBRTtBQUFFSCxvQkFBSSxFQUFFLEVBQVI7QUFBWUQsc0JBQU0sRUFBRTtBQUFwQjtBQUFqRjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUZGLGVBSUU7QUFBSyxtQkFBSyxFQUFFO0FBQUVILHNCQUFNLEVBQUUsR0FBVjtBQUFlRSwwQkFBVSxFQUFFO0FBQTNCLGVBQVo7QUFBQSxzQ0FDRTtBQUFLLHlCQUFTLEVBQUMsK0JBQWY7QUFBK0MscUJBQUssRUFBRTtBQUFFRix3QkFBTSxFQUFFLEdBQVY7QUFBZVEsOEJBQVksRUFBRTtBQUE3QixpQkFBdEQ7QUFBQSx3Q0FDRTtBQUFJLDJCQUFTLEVBQUMsMEJBQWQ7QUFBeUMsdUJBQUssRUFBRTtBQUFFQyw0QkFBUSxFQUFFLEVBQVo7QUFBZ0JDLDhCQUFVLEVBQUUsTUFBNUI7QUFBb0NDLGlDQUFhLEVBQUUsUUFBbkQ7QUFBNkRDLDhCQUFVLEVBQUUsRUFBekU7QUFBNkVDLCtCQUFXLEVBQUU7QUFBMUYsbUJBQWhEO0FBQUEsNEJBQ0dmLElBQUksQ0FBQ2pCO0FBRFI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFERixlQUlFO0FBQUksMkJBQVMsRUFBQywyQkFBZDtBQUEwQyx1QkFBSyxFQUFFO0FBQUU0Qiw0QkFBUSxFQUFFLEVBQVo7QUFBZ0JDLDhCQUFVLEVBQUUsTUFBNUI7QUFBb0NDLGlDQUFhLEVBQUU7QUFBbkQsbUJBQWpEO0FBQUEsNEJBQ0diLElBQUksQ0FBQ2hCO0FBRFI7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBREYsZUFVRTtBQUFLLHlCQUFTLEVBQUMsbUNBQWY7QUFBbUQscUJBQUssRUFBRTtBQUFFa0Isd0JBQU0sRUFBRTtBQUFWLGlCQUExRDtBQUFBLHdDQUNFO0FBQUssdUJBQUssRUFBRTtBQUFFWSw4QkFBVSxFQUFFLEVBQWQ7QUFBa0JQLDJCQUFPLEVBQUUsTUFBM0I7QUFBbUNTLGtDQUFjLEVBQUU7QUFBbkQsbUJBQVo7QUFBQSwwQ0FDRTtBQUFNLDZCQUFTLEVBQUMsOENBQWhCO0FBQUEsb0NBQWlFaEIsSUFBSSxDQUFDYixPQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBREYsRUFFR2EsSUFBSSxDQUFDWixRQUFMLGlCQUFpQjtBQUFNLDZCQUFTLEVBQUMsOENBQWhCO0FBQUEsMkNBQStEO0FBQUksMkJBQUssRUFBRTtBQUFFYSw2QkFBSyxFQUFFLEVBQVQ7QUFBYWdCLGlDQUFTLEVBQUU7QUFBeEI7QUFBWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQS9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBRnBCLEVBR0dqQixJQUFJLENBQUNaLFFBQUwsaUJBQWlCO0FBQU0sNkJBQVMsRUFBQyw4Q0FBaEI7QUFBQSxvQ0FBaUVZLElBQUksQ0FBQ1osUUFBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUhwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBREYsZUFNRSxxRUFBQyxpREFBRDtBQUFPLHFCQUFHLEVBQUVZLElBQUksQ0FBQ1gsSUFBakI7QUFBdUIscUJBQUcsRUFBRSxLQUE1QjtBQUFtQyx1QkFBSyxFQUFFO0FBQUUwQiwrQkFBVyxFQUFFO0FBQWY7QUFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFORjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFGRixlQTJCRTtBQUFLLHFCQUFTLEVBQUMsRUFBZjtBQUFrQixpQkFBSyxFQUFFO0FBQUVULGtCQUFJLEVBQUUsR0FBUjtBQUFhSCxzQkFBUSxFQUFFO0FBQXZCLGFBQXpCO0FBQUEsb0NBQ0U7QUFBRyx1QkFBUyxFQUFDLGNBQWI7QUFBQSx5QkFBNkJILElBQUksQ0FBQ1QsT0FBTCxDQUFhLENBQWIsQ0FBN0IsZUFBNkM7QUFBTSxxQkFBSyxFQUFFO0FBQUUyQix1QkFBSyxFQUFFO0FBQVQsaUJBQWI7QUFBQSxnQ0FBcUNsQixJQUFJLENBQUNULE9BQUwsQ0FBYSxDQUFiLENBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFBN0MsT0FBNEdTLElBQUksQ0FBQ1QsT0FBTCxDQUFhLENBQWIsQ0FBNUc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQURGLGVBRUU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQTNCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFETTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQVI7QUFvQ0QsS0FyQ0E7QUFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBREY7QUE4Q0QsQ0F0SE07S0FBTVosTyIsImZpbGUiOiJzdGF0aWMvd2VicGFjay9wYWdlcy9ob21lLjVmYTZjNzRiN2FlZGM2N2U3MzQ0LmhvdC11cGRhdGUuanMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBJbWFnZSB9IGZyb20gXCJAY29tcG9uZW50c1wiO1xuaW1wb3J0IFNsaWRlciBmcm9tIFwicmVhY3Qtc2xpY2tcIjtcbmltcG9ydCBcInNsaWNrLWNhcm91c2VsL3NsaWNrL3NsaWNrLmNzc1wiO1xuaW1wb3J0IFwic2xpY2stY2Fyb3VzZWwvc2xpY2svc2xpY2stdGhlbWUuY3NzXCI7XG5cbmV4cG9ydCB0eXBlIFByb3BzID0ge1xuICBuYW1lcz86IEFycmF5PHN0cmluZz47XG4gIGJhY2tncm91bmRfdXJsPzogc3RyaW5nO1xuICB0YWdzPzogQXJyYXk8c3RyaW5nPjtcbiAgbG9nbz86IHN0cmluZztcbiAgY2xhc3NOYW1lPzogc3RyaW5nO1xuICBzdHlsZT86IGFueTtcbn07XG5cbmV4cG9ydCBjb25zdCBGb3VuZGVyOiBSZWFjdC5GQzxQcm9wcz4gPSAoeyBjbGFzc05hbWUsIHN0eWxlID0ge30gfSkgPT4ge1xuICBjb25zdCBoZXJvcyA9IFt7XG4gICAgZmlyc3ROYW1lOiAnQmhhdmlzaCcsXG4gICAgbGFzdE5hbWU6ICdBR0dBUldBTCcsXG4gICAgZmlyc3ROYW1lMTogbnVsbCxcbiAgICBsYXN0TmFtZTE6IG51bGwsXG4gICAgY2FwdGlvbjogJ01vYmlsaXR5JyxcbiAgICBjYXB0aW9uMTogJ0VsZWN0cmljIENhcnMnLFxuICAgIGxvZ286ICcvaWNvbnMvb2xhLnN2ZycsXG4gICAgaW1hZ2U6ICcvaWNvbnMvQmhhdmlzaF9pbWFnZS5zdmcnLFxuICAgIGhlYWRpbmc6IFsnV2UgYXJlJywgJ2ZvdW5kZXJzJywgJ2ZpcnN0J11cbiAgfSwge1xuICAgIGZpcnN0TmFtZTogJ1JPSElUJyxcbiAgICBsYXN0TmFtZTogJ00uQS4nLFxuICAgIGZpcnN0TmFtZTE6IG51bGwsXG4gICAgbGFzdE5hbWUxOiBudWxsLFxuICAgIGNhcHRpb246ICdIZWFsdGhjYXJlJyxcbiAgICBjYXB0aW9uMTogbnVsbCxcbiAgICBsb2dvOiAnL2ljb25zL0Nsb3VkbmluZS5zdmcnLFxuICAgIGltYWdlOiAnL2ljb25zL1JvaGl0X1RyZWF0bWVudC5zdmcnLFxuICAgIGhlYWRpbmc6IFsnV2UgJywgJ3BhcnRuZXInLCAnY2xvc2VseSddXG4gIH0sIHtcbiAgICBmaXJzdE5hbWU6ICdBTklORFlBJyxcbiAgICBsYXN0TmFtZTogJ0RVVFRBJyxcbiAgICBmaXJzdE5hbWUxOiAnU0FOREVFUCcsXG4gICAgbGFzdE5hbWUxOiAnREFMTUlBJyxcbiAgICBjYXB0aW9uOiAnU3R1ZGVudCBIb3VzaW5nIFBsYXRmb3JtJyxcbiAgICBjYXB0aW9uMTogbnVsbCxcbiAgICBsb2dvOiAnL2ljb25zL1N0YW56YS5zdmcnLFxuICAgIGltYWdlOiAnL2ljb25zL0FuaW5keWEuc3ZnJyxcbiAgICBoZWFkaW5nOiBbJ1dlICcsICdpbnZlc3QnLCAnZWFybHknXVxuICB9LCB7XG4gICAgZmlyc3ROYW1lOiAnQXNpc2gnLFxuICAgIGxhc3ROYW1lOiAnTU9IQVBBVFJBJyxcbiAgICBmaXJzdE5hbWUxOiBudWxsLFxuICAgIGxhc3ROYW1lMTogbnVsbCxcbiAgICBjYXB0aW9uOiAnRmludGVjaCcsXG4gICAgY2FwdGlvbjE6ICdTTUUgTGVuZGluZycsXG4gICAgbG9nbzogJy9pY29ucy9PZkJ1c2luZXNzLnN2ZycsXG4gICAgaW1hZ2U6ICcvaWNvbnMvQXNpc2guc3ZnJyxcbiAgICBoZWFkaW5nOiBbJ1dlJywgJ2NvbW1pdCcsICdwZXJzb25hbGx5J11cbiAgfSwge1xuICAgIGZpcnN0TmFtZTogJ01yLicsXG4gICAgbGFzdE5hbWU6ICdMQUtTSElQQVRIWScsXG4gICAgZmlyc3ROYW1lMTogbnVsbCxcbiAgICBsYXN0TmFtZTE6IG51bGwsXG4gICAgY2FwdGlvbjogJ0ZpbnRlY2gnLFxuICAgIGNhcHRpb24xOiAnTkJGQycsXG4gICAgbG9nbzogJy9pY29ucy9teC5zdmcnLFxuICAgIGltYWdlOiAnL2ljb25zL0xheG1pcGF0aHkuc3ZnJyxcbiAgICBoZWFkaW5nOiBbJ1dlIGFyZScsICdmb3VuZGVycycsICdmaXJzdCddXG4gIH0sIHtcbiAgICBmaXJzdE5hbWU6ICdDSEFLUkFESEFSJyxcbiAgICBsYXN0TmFtZTogJ0dBREUnLFxuICAgIGZpcnN0TmFtZTE6ICdOSVRJTicsXG4gICAgbGFzdE5hbWUxOiAnS0FVU0hBTCcsXG4gICAgY2FwdGlvbjogJ0ZpbnRlY2gnLFxuICAgIGNhcHRpb24xOiAnTkJGQycsXG4gICAgbG9nbzogJy9pY29ucy9Db3VudHJ5LnN2ZycsXG4gICAgaGVhZGluZzogWydXZScsICdjb21taXQnLCAncGVyc29uYWxseSddLFxuICAgIGltYWdlOiAnL2ljb25zL0NoYWtyYWRoYXIuc3ZnJ1xuICB9XVxuXG4gIGNvbnN0IHNldHRpbmdzID0ge1xuICAgIGRvdHM6IHRydWUsXG4gICAgaW5maW5pdGU6IHRydWUsXG4gICAgc3BlZWQ6IDUwMCxcbiAgICBhdXRvcGxheVNwZWVkOiA1MDAwLFxuICAgIHNsaWRlc1RvU2hvdzogMSxcbiAgICBzbGlkZXNUb1Njcm9sbDogMSxcbiAgICAvLyBhdXRvcGxheTogdHJ1ZVxuICB9O1xuICByZXR1cm4gKFxuICAgIDxTbGlkZXIgey4uLnNldHRpbmdzfT5cbiAgICAgIHtoZXJvcy5tYXAoaGVybyA9PiB7XG4gICAgICAgIHJldHVybiAoPGRpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YCR7Y2xhc3NOYW1lfWB9IHN0eWxlPXt7IHdpZHRoOiA2MTUuOTQsIGhlaWdodDogODYzLjkxLCBwb3NpdGlvbjogXCJyZWxhdGl2ZVwiLCAuLi5zdHlsZSwgfX0+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIlwiIHN0eWxlPXt7IHdpZHRoOiA1NzEsIGhlaWdodDogNzYyLCBwb3NpdGlvbjogXCJhYnNvbHV0ZVwiLCBiYWNrZ3JvdW5kOiBcIiMwODNBNEFcIiwgYm90dG9tOiA1MCwgbGVmdDogMCwgfX0+PC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIlwiIHN0eWxlPXt7IHdpZHRoOiA1OTQsIGhlaWdodDogNzg4LCBib3R0b206IDY1LCBsZWZ0OiAxNSwgcG9zaXRpb246IFwiYWJzb2x1dGVcIiwgZGlzcGxheTogXCJmbGV4XCIsIGZsZXhEaXJlY3Rpb246IFwiY29sdW1uXCIsIH19PlxuICAgICAgICAgICAgICA8SW1hZ2Ugc3JjPXtoZXJvLmltYWdlfSBhbHQ9XCJmb3VuZGVyIGltYWdlXCIgc3R5bGU9e3sgZmxleEdyb3c6IDEgfX0+PC9JbWFnZT5cbiAgICAgICAgICAgICAgPEltYWdlIHNyYz1cIi9pY29ucy9yZWN0YW5nbGUuc3ZnXCIgYWx0PXtcInJlYWN0YW5nbGVcIn0gY2xhc3NOYW1lPVwiYWJzb2x1dGVcIiBzdHlsZT17eyBsZWZ0OiAzOCwgYm90dG9tOiAyNTQgfX0gLz5cblxuICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGhlaWdodDogMjA5LCBiYWNrZ3JvdW5kOiBcIiMwMTU3NkVcIiB9fT5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIGZsZXggaXRlbXMtY2VudGVyXCIgc3R5bGU9e3sgaGVpZ2h0OiAxMTgsIGJvcmRlckJvdHRvbTogXCIxcHggc29saWQgI0VCRUJFOVwiIH19PlxuICAgICAgICAgICAgICAgICAgPGg2IGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNlY29uZGFyeVwiIHN0eWxlPXt7IGZvbnRTaXplOiAzMiwgbGluZUhlaWdodDogXCIzNnB4XCIsIGxldHRlclNwYWNpbmc6IFwiMC4wNWVtXCIsIG1hcmdpbkxlZnQ6IDMxLCBtYXJnaW5SaWdodDogOCwgfX0+XG4gICAgICAgICAgICAgICAgICAgIHtoZXJvLmZpcnN0TmFtZX1cbiAgICAgICAgICAgICAgICAgIDwvaDY+XG4gICAgICAgICAgICAgICAgICA8aDYgY2xhc3NOYW1lPVwiZm9udC1saWdodCB0ZXh0LXNlY29uZGFyeVwiIHN0eWxlPXt7IGZvbnRTaXplOiAzMiwgbGluZUhlaWdodDogXCIzNnB4XCIsIGxldHRlclNwYWNpbmc6IFwiMC4wNWVtXCIsIH19PlxuICAgICAgICAgICAgICAgICAgICB7aGVyby5sYXN0TmFtZX1cbiAgICAgICAgICAgICAgICAgIDwvaDY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlclwiIHN0eWxlPXt7IGhlaWdodDogODggfX0+XG4gICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IG1hcmdpbkxlZnQ6IDMxLCBkaXNwbGF5OiAnZmxleCcsIGp1c3RpZnlDb250ZW50OiAnc3BhY2UtYXJvdW5kJyB9fT5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zZWNvbmRhcnkgZm9udC1tZWRpdW0gdGV4dC1sZyBsZWFkaW5nLTZcIj4ge2hlcm8uY2FwdGlvbn08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIHtoZXJvLmNhcHRpb24xICYmIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2Vjb25kYXJ5IGZvbnQtbWVkaXVtIHRleHQtbGcgbGVhZGluZy02XCI+PGhyIHN0eWxlPXt7IHdpZHRoOiAzMCwgdHJhbnNmb3JtOiAncm90YXRlKDkwZGVnKScgfX0gLz48L3NwYW4+fVxuICAgICAgICAgICAgICAgICAgICB7aGVyby5jYXB0aW9uMSAmJiA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNlY29uZGFyeSBmb250LW1lZGl1bSB0ZXh0LWxnIGxlYWRpbmctNlwiPiB7aGVyby5jYXB0aW9uMX08L3NwYW4+fVxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8SW1hZ2Ugc3JjPXtoZXJvLmxvZ299IGFsdD17XCJvbGFcIn0gc3R5bGU9e3sgbWFyZ2luUmlnaHQ6IDU3IH19IC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiXCIgc3R5bGU9e3sgbGVmdDogNzYwLCBwb3NpdGlvbjogXCJhYnNvbHV0ZVwiIH19PlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9J3NsaWRlLWhlYWRlcic+e2hlcm8uaGVhZGluZ1swXX08c3BhbiBzdHlsZT17eyBjb2xvcjogJyMwMTU3NkUnIH19PiB7aGVyby5oZWFkaW5nWzFdfSA8L3NwYW4+IHtoZXJvLmhlYWRpbmdbMl19PC9wPlxuICAgICAgICAgICAgICA8ZGl2PlxuICAgICAgICAgICAgICAgIGhjaGdjdmhnXG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PilcbiAgICAgIH0pfVxuXG5cblxuXG4gICAgPC9TbGlkZXI+XG4gICk7XG59O1xuIl0sInNvdXJjZVJvb3QiOiIifQ==