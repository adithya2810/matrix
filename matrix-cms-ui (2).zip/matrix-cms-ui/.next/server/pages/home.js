module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./pages/home/index.tsx");
/******/ })
/************************************************************************/
/******/ ({

/***/ "../next-server/lib/head":
/*!****************************************************!*\
  !*** external "next/dist/next-server/lib/head.js" ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("next/dist/next-server/lib/head.js");

/***/ }),

/***/ "../next-server/lib/to-base-64":
/*!**********************************************************!*\
  !*** external "next/dist/next-server/lib/to-base-64.js" ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("next/dist/next-server/lib/to-base-64.js");

/***/ }),

/***/ "../next-server/server/image-config":
/*!***************************************************************!*\
  !*** external "next/dist/next-server/server/image-config.js" ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("next/dist/next-server/server/image-config.js");

/***/ }),

/***/ "./constants/footerMenu.ts":
/*!*********************************!*\
  !*** ./constants/footerMenu.ts ***!
  \*********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
const footermenu = [{
  key: "footer_about",
  name: "About",
  link: ""
}, {
  key: "footer_portfolio",
  name: "Portfolio",
  link: "/portfolio"
}, {
  key: "footer_blog",
  name: "Blog",
  link: ""
}, {
  key: "footer_advisory_team",
  name: "Advisory Team",
  link: "/advisoryTeam"
}, {
  key: "footer_contact",
  name: "Contact",
  link: ""
}, {
  key: "footer_careers",
  name: "Careers",
  link: ""
}];
/* harmony default export */ __webpack_exports__["default"] = (footermenu);

/***/ }),

/***/ "./constants/index.ts":
/*!****************************!*\
  !*** ./constants/index.ts ***!
  \****************************/
/*! exports provided: navMenu, PRIVACY_POLICY */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PRIVACY_POLICY", function() { return PRIVACY_POLICY; });
/* harmony import */ var _footerMenu__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./footerMenu */ "./constants/footerMenu.ts");
/* empty/unused harmony star reexport *//* harmony import */ var _navMenu__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./navMenu */ "./constants/navMenu.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "navMenu", function() { return _navMenu__WEBPACK_IMPORTED_MODULE_1__["navMenu"]; });



const PRIVACY_POLICY = "MADE WITH LOVE BY PLEASE SEE ";

/***/ }),

/***/ "./constants/navMenu.ts":
/*!******************************!*\
  !*** ./constants/navMenu.ts ***!
  \******************************/
/*! exports provided: navMenu, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "navMenu", function() { return navMenu; });
const navMenu = {
  primary: [{
    key: "footer_about",
    name: "About",
    link: ""
  }, {
    key: "footer_portfolio",
    name: "Portfolio",
    link: ""
  }, {
    key: "footer_blog",
    name: "Blog",
    link: ""
  }],
  secondary: [{
    key: "footer_advisory_team",
    name: "Advisory Team",
    link: ""
  }, {
    key: "footer_contact",
    name: "Contact",
    link: ""
  }, {
    key: "footer_careers",
    name: "Careers",
    link: ""
  }]
};
/* harmony default export */ __webpack_exports__["default"] = (navMenu);

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/extends.js":
/*!********************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/extends.js ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _extends() {
  module.exports = _extends = Object.assign || function (target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];

      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }

    return target;
  };

  return _extends.apply(this, arguments);
}

module.exports = _extends;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js":
/*!**********************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/interopRequireDefault.js ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    "default": obj
  };
}

module.exports = _interopRequireDefault;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/objectWithoutPropertiesLoose.js":
/*!*****************************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/objectWithoutPropertiesLoose.js ***!
  \*****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _objectWithoutPropertiesLoose(source, excluded) {
  if (source == null) return {};
  var target = {};
  var sourceKeys = Object.keys(source);
  var key, i;

  for (i = 0; i < sourceKeys.length; i++) {
    key = sourceKeys[i];
    if (excluded.indexOf(key) >= 0) continue;
    target[key] = source[key];
  }

  return target;
}

module.exports = _objectWithoutPropertiesLoose;

/***/ }),

/***/ "./node_modules/next/dist/client/image.js":
/*!************************************************!*\
  !*** ./node_modules/next/dist/client/image.js ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js");

exports.__esModule = true;
exports.default = Image;

var _objectWithoutPropertiesLoose2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/objectWithoutPropertiesLoose */ "./node_modules/@babel/runtime/helpers/objectWithoutPropertiesLoose.js"));

var _extends2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/extends */ "./node_modules/@babel/runtime/helpers/extends.js"));

var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));

var _head = _interopRequireDefault(__webpack_require__(/*! ../next-server/lib/head */ "../next-server/lib/head"));

var _toBase = __webpack_require__(/*! ../next-server/lib/to-base-64 */ "../next-server/lib/to-base-64");

var _imageConfig = __webpack_require__(/*! ../next-server/server/image-config */ "../next-server/server/image-config");

var _useIntersection = __webpack_require__(/*! ./use-intersection */ "./node_modules/next/dist/client/use-intersection.js");

if (true) {
  ;
  global.__NEXT_IMAGE_IMPORTED = true;
}

const VALID_LOADING_VALUES = ['lazy', 'eager', undefined];
const loaders = new Map([['imgix', imgixLoader], ['cloudinary', cloudinaryLoader], ['akamai', akamaiLoader], ['default', defaultLoader]]);
const VALID_LAYOUT_VALUES = ['fill', 'fixed', 'intrinsic', 'responsive', undefined];
const {
  deviceSizes: configDeviceSizes,
  imageSizes: configImageSizes,
  loader: configLoader,
  path: configPath,
  domains: configDomains
} = {"deviceSizes":[640,750,828,1080,1200,1920,2048,3840],"imageSizes":[16,32,48,64,96,128,256,384],"path":"/_next/image","loader":"default","domains":[]} || _imageConfig.imageConfigDefault; // sort smallest to largest

const allSizes = [...configDeviceSizes, ...configImageSizes];
configDeviceSizes.sort((a, b) => a - b);
allSizes.sort((a, b) => a - b);

function getWidths(width, layout, sizes) {
  if (sizes && (layout === 'fill' || layout === 'responsive')) {
    // Find all the "vw" percent sizes used in the sizes prop
    const percentSizes = [...sizes.matchAll(/(^|\s)(1?\d?\d)vw/g)].map(m => parseInt(m[2]));

    if (percentSizes.length) {
      const smallestRatio = Math.min(...percentSizes) * 0.01;
      return {
        widths: allSizes.filter(s => s >= configDeviceSizes[0] * smallestRatio),
        kind: 'w'
      };
    }

    return {
      widths: allSizes,
      kind: 'w'
    };
  }

  if (typeof width !== 'number' || layout === 'fill' || layout === 'responsive') {
    return {
      widths: configDeviceSizes,
      kind: 'w'
    };
  }

  const widths = [...new Set( // > This means that most OLED screens that say they are 3x resolution,
  // > are actually 3x in the green color, but only 1.5x in the red and
  // > blue colors. Showing a 3x resolution image in the app vs a 2x
  // > resolution image will be visually the same, though the 3x image
  // > takes significantly more data. Even true 3x resolution screens are
  // > wasteful as the human eye cannot see that level of detail without
  // > something like a magnifying glass.
  // https://blog.twitter.com/engineering/en_us/topics/infrastructure/2019/capping-image-fidelity-on-ultra-high-resolution-devices.html
  [width, width * 2
  /*, width * 3*/
  ].map(w => allSizes.find(p => p >= w) || allSizes[allSizes.length - 1]))];
  return {
    widths,
    kind: 'x'
  };
}

function generateImgAttrs({
  src,
  unoptimized,
  layout,
  width,
  quality,
  sizes,
  loader
}) {
  if (unoptimized) {
    return {
      src,
      srcSet: undefined,
      sizes: undefined
    };
  }

  const {
    widths,
    kind
  } = getWidths(width, layout, sizes);
  const last = widths.length - 1;
  return {
    sizes: !sizes && kind === 'w' ? '100vw' : sizes,
    srcSet: widths.map((w, i) => `${loader({
      src,
      quality,
      width: w
    })} ${kind === 'w' ? w : i + 1}${kind}`).join(', '),
    // It's intended to keep `src` the last attribute because React updates
    // attributes in order. If we keep `src` the first one, Safari will
    // immediately start to fetch `src`, before `sizes` and `srcSet` are even
    // updated by React. That causes multiple unnecessary requests if `srcSet`
    // and `sizes` are defined.
    // This bug cannot be reproduced in Chrome or Firefox.
    src: loader({
      src,
      quality,
      width: widths[last]
    })
  };
}

function getInt(x) {
  if (typeof x === 'number') {
    return x;
  }

  if (typeof x === 'string') {
    return parseInt(x, 10);
  }

  return undefined;
}

function defaultImageLoader(loaderProps) {
  const load = loaders.get(configLoader);

  if (load) {
    return load((0, _extends2.default)({
      root: configPath
    }, loaderProps));
  }

  throw new Error(`Unknown "loader" found in "next.config.js". Expected: ${_imageConfig.VALID_LOADERS.join(', ')}. Received: ${configLoader}`);
}

function Image(_ref) {
  let {
    src,
    sizes,
    unoptimized = false,
    priority = false,
    loading,
    className,
    quality,
    width,
    height,
    objectFit,
    objectPosition,
    loader = defaultImageLoader
  } = _ref,
      all = (0, _objectWithoutPropertiesLoose2.default)(_ref, ["src", "sizes", "unoptimized", "priority", "loading", "className", "quality", "width", "height", "objectFit", "objectPosition", "loader"]);
  let rest = all;
  let layout = sizes ? 'responsive' : 'intrinsic';
  let unsized = false;

  if ('unsized' in rest) {
    unsized = Boolean(rest.unsized); // Remove property so it's not spread into image:

    delete rest['unsized'];
  } else if ('layout' in rest) {
    // Override default layout if the user specified one:
    if (rest.layout) layout = rest.layout; // Remove property so it's not spread into image:

    delete rest['layout'];
  }

  if (true) {
    if (!src) {
      throw new Error(`Image is missing required "src" property. Make sure you pass "src" in props to the \`next/image\` component. Received: ${JSON.stringify({
        width,
        height,
        quality
      })}`);
    }

    if (!VALID_LAYOUT_VALUES.includes(layout)) {
      throw new Error(`Image with src "${src}" has invalid "layout" property. Provided "${layout}" should be one of ${VALID_LAYOUT_VALUES.map(String).join(',')}.`);
    }

    if (!VALID_LOADING_VALUES.includes(loading)) {
      throw new Error(`Image with src "${src}" has invalid "loading" property. Provided "${loading}" should be one of ${VALID_LOADING_VALUES.map(String).join(',')}.`);
    }

    if (priority && loading === 'lazy') {
      throw new Error(`Image with src "${src}" has both "priority" and "loading='lazy'" properties. Only one should be used.`);
    }

    if (unsized) {
      throw new Error(`Image with src "${src}" has deprecated "unsized" property, which was removed in favor of the "layout='fill'" property`);
    }
  }

  let isLazy = !priority && (loading === 'lazy' || typeof loading === 'undefined');

  if (src && src.startsWith('data:')) {
    // https://developer.mozilla.org/en-US/docs/Web/HTTP/Basics_of_HTTP/Data_URIs
    unoptimized = true;
    isLazy = false;
  }

  const [setRef, isIntersected] = (0, _useIntersection.useIntersection)({
    rootMargin: '200px',
    disabled: !isLazy
  });
  const isVisible = !isLazy || isIntersected;
  const widthInt = getInt(width);
  const heightInt = getInt(height);
  const qualityInt = getInt(quality);
  let wrapperStyle;
  let sizerStyle;
  let sizerSvg;
  let imgStyle = {
    position: 'absolute',
    top: 0,
    left: 0,
    bottom: 0,
    right: 0,
    boxSizing: 'border-box',
    padding: 0,
    border: 'none',
    margin: 'auto',
    display: 'block',
    width: 0,
    height: 0,
    minWidth: '100%',
    maxWidth: '100%',
    minHeight: '100%',
    maxHeight: '100%',
    objectFit,
    objectPosition
  };

  if (typeof widthInt !== 'undefined' && typeof heightInt !== 'undefined' && layout !== 'fill') {
    // <Image src="i.png" width="100" height="100" />
    const quotient = heightInt / widthInt;
    const paddingTop = isNaN(quotient) ? '100%' : `${quotient * 100}%`;

    if (layout === 'responsive') {
      // <Image src="i.png" width="100" height="100" layout="responsive" />
      wrapperStyle = {
        display: 'block',
        overflow: 'hidden',
        position: 'relative',
        boxSizing: 'border-box',
        margin: 0
      };
      sizerStyle = {
        display: 'block',
        boxSizing: 'border-box',
        paddingTop
      };
    } else if (layout === 'intrinsic') {
      // <Image src="i.png" width="100" height="100" layout="intrinsic" />
      wrapperStyle = {
        display: 'inline-block',
        maxWidth: '100%',
        overflow: 'hidden',
        position: 'relative',
        boxSizing: 'border-box',
        margin: 0
      };
      sizerStyle = {
        boxSizing: 'border-box',
        display: 'block',
        maxWidth: '100%'
      };
      sizerSvg = `<svg width="${widthInt}" height="${heightInt}" xmlns="http://www.w3.org/2000/svg" version="1.1"/>`;
    } else if (layout === 'fixed') {
      // <Image src="i.png" width="100" height="100" layout="fixed" />
      wrapperStyle = {
        overflow: 'hidden',
        boxSizing: 'border-box',
        display: 'inline-block',
        position: 'relative',
        width: widthInt,
        height: heightInt
      };
    }
  } else if (typeof widthInt === 'undefined' && typeof heightInt === 'undefined' && layout === 'fill') {
    // <Image src="i.png" layout="fill" />
    wrapperStyle = {
      display: 'block',
      overflow: 'hidden',
      position: 'absolute',
      top: 0,
      left: 0,
      bottom: 0,
      right: 0,
      boxSizing: 'border-box',
      margin: 0
    };
  } else {
    // <Image src="i.png" />
    if (true) {
      throw new Error(`Image with src "${src}" must use "width" and "height" properties or "layout='fill'" property.`);
    }
  }

  let imgAttributes = {
    src: 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7',
    srcSet: undefined,
    sizes: undefined
  };

  if (isVisible) {
    imgAttributes = generateImgAttrs({
      src,
      unoptimized,
      layout,
      width: widthInt,
      quality: qualityInt,
      sizes,
      loader
    });
  }

  if (unsized) {
    wrapperStyle = undefined;
    sizerStyle = undefined;
    imgStyle = undefined;
  }

  return /*#__PURE__*/_react.default.createElement("div", {
    style: wrapperStyle
  }, sizerStyle ? /*#__PURE__*/_react.default.createElement("div", {
    style: sizerStyle
  }, sizerSvg ? /*#__PURE__*/_react.default.createElement("img", {
    style: {
      maxWidth: '100%',
      display: 'block',
      margin: 0,
      border: 'none',
      padding: 0
    },
    alt: "",
    "aria-hidden": true,
    role: "presentation",
    src: `data:image/svg+xml;base64,${(0, _toBase.toBase64)(sizerSvg)}`
  }) : null) : null, !isVisible && /*#__PURE__*/_react.default.createElement("noscript", null, /*#__PURE__*/_react.default.createElement("img", Object.assign({}, rest, generateImgAttrs({
    src,
    unoptimized,
    layout,
    width: widthInt,
    quality: qualityInt,
    sizes,
    loader
  }), {
    src: src,
    decoding: "async",
    sizes: sizes,
    style: imgStyle,
    className: className
  }))), /*#__PURE__*/_react.default.createElement("img", Object.assign({}, rest, imgAttributes, {
    decoding: "async",
    className: className,
    ref: setRef,
    style: imgStyle
  })), priority ?
  /*#__PURE__*/
  // Note how we omit the `href` attribute, as it would only be relevant
  // for browsers that do not support `imagesrcset`, and in those cases
  // it would likely cause the incorrect image to be preloaded.
  //
  // https://html.spec.whatwg.org/multipage/semantics.html#attr-link-imagesrcset
  _react.default.createElement(_head.default, null, /*#__PURE__*/_react.default.createElement("link", {
    key: '__nimg-' + imgAttributes.src + imgAttributes.srcSet + imgAttributes.sizes,
    rel: "preload",
    as: "image",
    href: imgAttributes.srcSet ? undefined : imgAttributes.src // @ts-ignore: imagesrcset is not yet in the link element type
    ,
    imagesrcset: imgAttributes.srcSet // @ts-ignore: imagesizes is not yet in the link element type
    ,
    imagesizes: imgAttributes.sizes
  })) : null);
} //BUILT IN LOADERS


function normalizeSrc(src) {
  return src[0] === '/' ? src.slice(1) : src;
}

function imgixLoader({
  root,
  src,
  width,
  quality
}) {
  // Demo: https://static.imgix.net/daisy.png?format=auto&fit=max&w=300
  const params = ['auto=format', 'fit=max', 'w=' + width];
  let paramsString = '';

  if (quality) {
    params.push('q=' + quality);
  }

  if (params.length) {
    paramsString = '?' + params.join('&');
  }

  return `${root}${normalizeSrc(src)}${paramsString}`;
}

function akamaiLoader({
  root,
  src,
  width
}) {
  return `${root}${normalizeSrc(src)}?imwidth=${width}`;
}

function cloudinaryLoader({
  root,
  src,
  width,
  quality
}) {
  // Demo: https://res.cloudinary.com/demo/image/upload/w_300,c_limit,q_auto/turtles.jpg
  const params = ['f_auto', 'c_limit', 'w_' + width, 'q_' + (quality || 'auto')];
  let paramsString = params.join(',') + '/';
  return `${root}${paramsString}${normalizeSrc(src)}`;
}

function defaultLoader({
  root,
  src,
  width,
  quality
}) {
  if (true) {
    const missingValues = []; // these should always be provided but make sure they are

    if (!src) missingValues.push('src');
    if (!width) missingValues.push('width');

    if (missingValues.length > 0) {
      throw new Error(`Next Image Optimization requires ${missingValues.join(', ')} to be provided. Make sure you pass them as props to the \`next/image\` component. Received: ${JSON.stringify({
        src,
        width,
        quality
      })}`);
    }

    if (src.startsWith('//')) {
      throw new Error(`Failed to parse src "${src}" on \`next/image\`, protocol-relative URL (//) must be changed to an absolute URL (http:// or https://)`);
    }

    if (!src.startsWith('/') && configDomains) {
      let parsedSrc;

      try {
        parsedSrc = new URL(src);
      } catch (err) {
        console.error(err);
        throw new Error(`Failed to parse src "${src}" on \`next/image\`, if using relative image it must start with a leading slash "/" or be an absolute URL (http:// or https://)`);
      }

      if (!configDomains.includes(parsedSrc.hostname)) {
        throw new Error(`Invalid src prop (${src}) on \`next/image\`, hostname "${parsedSrc.hostname}" is not configured under images in your \`next.config.js\`\n` + `See more info: https://nextjs.org/docs/messages/next-image-unconfigured-host`);
      }
    }
  }

  return `${root}?url=${encodeURIComponent(src)}&w=${width}&q=${quality || 75}`;
}

/***/ }),

/***/ "./node_modules/next/dist/client/request-idle-callback.js":
/*!****************************************************************!*\
  !*** ./node_modules/next/dist/client/request-idle-callback.js ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.cancelIdleCallback = exports.requestIdleCallback = void 0;

const requestIdleCallback = typeof self !== 'undefined' && self.requestIdleCallback || function (cb) {
  let start = Date.now();
  return setTimeout(function () {
    cb({
      didTimeout: false,
      timeRemaining: function () {
        return Math.max(0, 50 - (Date.now() - start));
      }
    });
  }, 1);
};

exports.requestIdleCallback = requestIdleCallback;

const cancelIdleCallback = typeof self !== 'undefined' && self.cancelIdleCallback || function (id) {
  return clearTimeout(id);
};

exports.cancelIdleCallback = cancelIdleCallback;

/***/ }),

/***/ "./node_modules/next/dist/client/use-intersection.js":
/*!***********************************************************!*\
  !*** ./node_modules/next/dist/client/use-intersection.js ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.useIntersection = useIntersection;

var _react = __webpack_require__(/*! react */ "react");

var _requestIdleCallback = __webpack_require__(/*! ./request-idle-callback */ "./node_modules/next/dist/client/request-idle-callback.js");

const hasIntersectionObserver = typeof IntersectionObserver !== 'undefined';

function useIntersection({
  rootMargin,
  disabled
}) {
  const isDisabled = disabled || !hasIntersectionObserver;
  const unobserve = (0, _react.useRef)();
  const [visible, setVisible] = (0, _react.useState)(false);
  const setRef = (0, _react.useCallback)(el => {
    if (unobserve.current) {
      unobserve.current();
      unobserve.current = undefined;
    }

    if (isDisabled || visible) return;

    if (el && el.tagName) {
      unobserve.current = observe(el, isVisible => isVisible && setVisible(isVisible), {
        rootMargin
      });
    }
  }, [isDisabled, rootMargin, visible]);
  (0, _react.useEffect)(() => {
    if (!hasIntersectionObserver) {
      if (!visible) {
        const idleCallback = (0, _requestIdleCallback.requestIdleCallback)(() => setVisible(true));
        return () => (0, _requestIdleCallback.cancelIdleCallback)(idleCallback);
      }
    }
  }, [visible]);
  return [setRef, visible];
}

function observe(element, callback, options) {
  const {
    id,
    observer,
    elements
  } = createObserver(options);
  elements.set(element, callback);
  observer.observe(element);
  return function unobserve() {
    elements.delete(element);
    observer.unobserve(element); // Destroy observer when there's nothing left to watch:

    if (elements.size === 0) {
      observer.disconnect();
      observers.delete(id);
    }
  };
}

const observers = new Map();

function createObserver(options) {
  const id = options.rootMargin || '';
  let instance = observers.get(id);

  if (instance) {
    return instance;
  }

  const elements = new Map();
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      const callback = elements.get(entry.target);
      const isVisible = entry.isIntersecting || entry.intersectionRatio > 0;

      if (callback && isVisible) {
        callback(isVisible);
      }
    });
  }, options);
  observers.set(id, instance = {
    id,
    observer,
    elements
  });
  return instance;
}

/***/ }),

/***/ "./node_modules/next/image.js":
/*!************************************!*\
  !*** ./node_modules/next/image.js ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! ./dist/client/image */ "./node_modules/next/dist/client/image.js")


/***/ }),

/***/ "./node_modules/slick-carousel/slick/slick-theme.css":
/*!***********************************************************!*\
  !*** ./node_modules/slick-carousel/slick/slick-theme.css ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {



/***/ }),

/***/ "./node_modules/slick-carousel/slick/slick.css":
/*!*****************************************************!*\
  !*** ./node_modules/slick-carousel/slick/slick.css ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {



/***/ }),

/***/ "./pages/home/index.tsx":
/*!******************************!*\
  !*** ./pages/home/index.tsx ***!
  \******************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _src_modules_home__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../src/modules/home */ "./src/modules/home/index.ts");

var _jsxFileName = "C:\\Users\\KARTHIK\\Documents\\workspace\\matrix-cms-ui-development\\pages\\home\\index.tsx";



function HomePage() {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_src_modules_home__WEBPACK_IMPORTED_MODULE_2__["default"], {}, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 5,
    columnNumber: 10
  }, this);
}

/* harmony default export */ __webpack_exports__["default"] = (HomePage);

/***/ }),

/***/ "./public/meta.json":
/*!**************************!*\
  !*** ./public/meta.json ***!
  \**************************/
/*! exports provided: name, plugins, default */
/***/ (function(module) {

module.exports = JSON.parse("{\"name\":\"matrix-cms-ui\",\"plugins\":[{\"name\":\"TailwindCSS\",\"description\":\"A utility-first CSS framework packed with classes like flex, pt-4, text-center and rotate-90 that can be composed to build any design, directly in your markup.\",\"url\":\"https://tailwindcss.com/docs\"},{\"name\":\"SASS/SCSS\",\"description\":\"Sass is a stylesheet language that’s compiled to CSS. It allows you to use variables, nested rules, mixins, functions, and more, all with a fully CSS-compatible syntax.\",\"url\":\"https://sass-lang.com/documentation\"},{\"name\":\"next-i18next\",\"description\":\"next-i18next is a plugin for Next.js projects that allows you to get translations up and running quickly and easily, while fully supporting SSR, multiple namespaces with codesplitting, etc.\",\"url\":\"https://github.com/isaachinman/next-i18next\"},{\"name\":\"Docker\",\"description\":\"Docker simplifies and accelerates your workflow, while giving developers the freedom to innovate with their choice of tools, application stacks, and deployment environments for each project.\",\"url\":\"https://www.docker.com/get-started\"},{\"name\":\"Github Actions\",\"description\":\"GitHub Actions makes it easy to automate all your software workflows, now with world-class CI/CD. Build, test, and deploy your code right from GitHub.\",\"url\":\"https://docs.github.com/en/actions\"}]}");

/***/ }),

/***/ "./src/components/banner/index.tsx":
/*!*****************************************!*\
  !*** ./src/components/banner/index.tsx ***!
  \*****************************************/
/*! exports provided: Banner */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Banner", function() { return Banner; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


var _jsxFileName = "C:\\Users\\KARTHIK\\Documents\\workspace\\matrix-cms-ui-development\\src\\components\\banner\\index.tsx";

const Banner = ({
  title,
  subTitle,
  bannerImg,
  mobileBannerImg
}) => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "sm:hidden w-full bg-cover bg-center c-bg relative",
      style: {
        backgroundImage: `url(${bannerImg})`
      },
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "flex items-center justify-center h-full w-full bg-gray-900 bg-opacity-50",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "text-center",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h1", {
            className: "text-white text-7lg md:leading-10 font-bold xl:text-4xl sm:text-2xl",
            children: title
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 17,
            columnNumber: 13
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
            className: "text-white text-3md md:text-xl",
            children: subTitle
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 18,
            columnNumber: 13
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "flex w-full relative position-bottom"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 19,
            columnNumber: 13
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 16,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 15,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 14,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "sm:block hidden w-full bg-cover bg-center c-bg relative",
      style: {
        backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)),url(${mobileBannerImg})`
      },
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "flex items-center justify-center h-full w-full bg-gray-900 bg-opacity-50",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "p-8",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h1", {
            className: "text-white leading-tight text-5sm font-medium sm:text-left",
            children: title
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 37,
            columnNumber: 13
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
            className: "text-white text-xl sm:text-left",
            children: subTitle
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 38,
            columnNumber: 13
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "flex w-full relative position-bottom"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 39,
            columnNumber: 13
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 36,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 35,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 34,
      columnNumber: 7
    }, undefined)]
  }, void 0, true);
};

/***/ }),

/***/ "./src/components/button/PrimaryButtonIconRight.tsx":
/*!**********************************************************!*\
  !*** ./src/components/button/PrimaryButtonIconRight.tsx ***!
  \**********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);

var _jsxFileName = "C:\\Users\\KARTHIK\\Documents\\workspace\\matrix-cms-ui-development\\src\\components\\button\\PrimaryButtonIconRight.tsx";


const Button = ({
  title,
  url,
  onClick,
  className = "",
  style = {}
}) => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("button", {
    onClick: onClick,
    style: style,
    className: `flex p-0.5 pl-0 items-center mt-2 ${className}`,
    children: [" ", title, " ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
      className: "pl-2",
      src: url
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 25,
      columnNumber: 15
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 19,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ __webpack_exports__["default"] = (Button);

/***/ }),

/***/ "./src/components/button/index.tsx":
/*!*****************************************!*\
  !*** ./src/components/button/index.tsx ***!
  \*****************************************/
/*! exports provided: Button */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Button", function() { return Button; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);

var _jsxFileName = "C:\\Users\\KARTHIK\\Documents\\workspace\\matrix-cms-ui-development\\src\\components\\button\\index.tsx";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }


const Button = (_ref) => {
  let {
    className = "",
    children
  } = _ref,
      rest = _objectWithoutProperties(_ref, ["className", "children"]);

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("button", _objectSpread(_objectSpread({
    className: `py-2 px-4 rounded bg-green-500 hover:bg-green-600 focus:outline-none ring-opacity-75 ring-green-400 focus:ring text-white text-lg ${className}`
  }, rest), {}, {
    children: children
  }), void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 14,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/components/cards/index.tsx":
/*!****************************************!*\
  !*** ./src/components/cards/index.tsx ***!
  \****************************************/
/*! exports provided: Cards */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Cards", function() { return Cards; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _public_meta_json__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @public/meta.json */ "./public/meta.json");
var _public_meta_json__WEBPACK_IMPORTED_MODULE_2___namespace = /*#__PURE__*/__webpack_require__.t(/*! @public/meta.json */ "./public/meta.json", 1);

var _jsxFileName = "C:\\Users\\KARTHIK\\Documents\\workspace\\matrix-cms-ui-development\\src\\components\\cards\\index.tsx";


const Cards = () => {
  var _data$plugins;

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: "flex-1 container my-8 max-w-screen-lg mx-auto p-5",
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6",
      children: ((_data$plugins = _public_meta_json__WEBPACK_IMPORTED_MODULE_2__ === null || _public_meta_json__WEBPACK_IMPORTED_MODULE_2__ === void 0 ? void 0 : _public_meta_json__WEBPACK_IMPORTED_MODULE_2__.plugins) !== null && _data$plugins !== void 0 ? _data$plugins : []).map(plugin => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "col-span-1 rounded-md border border-gray-300 p-5",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h2", {
          className: "text-xl font-semibold mb-2",
          children: plugin.name
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 14,
          columnNumber: 13
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
          className: "m-0",
          children: plugin.description
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 15,
          columnNumber: 13
        }, undefined)]
      }, plugin.name, true, {
        fileName: _jsxFileName,
        lineNumber: 10,
        columnNumber: 11
      }, undefined))
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 8,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 7,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/components/container/index.tsx":
/*!********************************************!*\
  !*** ./src/components/container/index.tsx ***!
  \********************************************/
/*! exports provided: Container */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Container", function() { return Container; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);

var _jsxFileName = "C:\\Users\\KARTHIK\\Documents\\workspace\\matrix-cms-ui-development\\src\\components\\container\\index.tsx";
const Container = ({
  children
}) => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: "min-h-screen flex flex-col",
    children: children
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 2,
    columnNumber: 10
  }, undefined);
};

/***/ }),

/***/ "./src/components/contentItem/contentItemWithTags.tsx":
/*!************************************************************!*\
  !*** ./src/components/contentItem/contentItemWithTags.tsx ***!
  \************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @components */ "./src/components/index.ts");
/* harmony import */ var _utils_getContentTypeImageUrl__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../../../utils/getContentTypeImageUrl */ "./utils/getContentTypeImageUrl.ts");

var _jsxFileName = "C:\\Users\\KARTHIK\\Documents\\workspace\\matrix-cms-ui-development\\src\\components\\contentItem\\contentItemWithTags.tsx";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }





const ContentItemWithTags = ({
  image_url,
  image_caption,
  title,
  author,
  designation,
  onClick,
  content_id,
  content_type,
  read_duration,
  author_image_url,
  tags,
  className = "",
  style = {
    marginBottom: 62
  }
}) => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: `${className} relative`,
    style: _objectSpread({
      height: 313,
      width: 1035
    }, style),
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "relative",
      style: {
        top: 0,
        left: 0,
        height: 313,
        width: 329.06
      },
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "absolute",
        style: {
          width: 298,
          height: 253,
          background: "#01576E",
          bottom: 0
        }
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 46,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_2__["Image"], {
        src: image_url,
        alt: "",
        className: "absolute",
        style: {
          height: 255,
          width: 315,
          background: "red",
          left: 6,
          bottom: 6
        }
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 50,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "absolute flex items-center",
        style: {
          background: "#01576E",
          height: 42,
          left: 0,
          bottom: 6,
          textAlign: "center"
        },
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "text-xl font-normal text-secondary-light text-center",
          style: {
            lineHeight: "30px",
            paddingTop: 6,
            paddingBottom: 6,
            paddingLeft: 17,
            paddingRight: 17
          },
          children: image_caption
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 72,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 62,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 42,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "absolute bg-secondary-light",
      style: {
        width: 741,
        bottom: -61,
        right: 0
      },
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        style: {
          marginLeft: 45,
          marginTop: 20,
          marginBottom: 20
        },
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "text-xs text-primary-dark p-0.5 pl-0 pt-0",
          style: {
            lineHeight: "14px",
            letterSpacing: "0.1em"
          },
          children: [read_duration, " READ", " "]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 91,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "text-primary-dark mt-3",
          style: {
            fontSize: "28px",
            lineHeight: "34px"
          },
          children: title
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 97,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "flex items-center mt-4 pt-1",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_2__["Image"], {
            src: Object(_utils_getContentTypeImageUrl__WEBPACK_IMPORTED_MODULE_3__["default"])(content_type),
            height: 38,
            width: 22,
            alt: "Writer Image"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 104,
            columnNumber: 13
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "flex ",
            style: {
              marginLeft: 30
            },
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_2__["Image"], {
              src: author_image_url,
              alt: "profileImage"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 111,
              columnNumber: 15
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              style: {
                marginLeft: 18
              },
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "font-medium text-lg leading-6 text-primary-dark",
                children: author
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 113,
                columnNumber: 17
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "mt-0.5 font-light text-xs ",
                style: {
                  lineHeight: "14px"
                },
                children: designation
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 116,
                columnNumber: 17
              }, undefined)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 112,
              columnNumber: 15
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 110,
            columnNumber: 13
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 103,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "flex flex-row flex-wrap",
          style: {
            marginTop: 30
          },
          children: tags.map((item, index) => {
            return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_2__["Tag"], {
              title: "LEADERSHIP",
              id: "leadership",
              selected: false,
              className: "text-xs opacity-80 mr-2 bg-secondary-light",
              style: {
                lineHeight: "14px",
                fontSize: "12px",
                letterSpacing: "0.1em",
                height: 34,
                color: "rgba(0, 0, 0, 0.65)",
                border: 0,
                background: "rgba(0, 0, 0, 0.08)",
                marginBottom: 10
              }
            }, index, false, {
              fileName: _jsxFileName,
              lineNumber: 128,
              columnNumber: 17
            }, undefined);
          })
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 125,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 90,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 86,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 38,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ __webpack_exports__["default"] = (ContentItemWithTags);

/***/ }),

/***/ "./src/components/contentItem/index.tsx":
/*!**********************************************!*\
  !*** ./src/components/contentItem/index.tsx ***!
  \**********************************************/
/*! exports provided: ContentItem */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ContentItem", function() { return ContentItem; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @components */ "./src/components/index.ts");
/* harmony import */ var _components_button_PrimaryButtonIconRight__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @components/button/PrimaryButtonIconRight */ "./src/components/button/PrimaryButtonIconRight.tsx");
/* harmony import */ var _utils_getContentTypeImageUrl__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../utils/getContentTypeImageUrl */ "./utils/getContentTypeImageUrl.ts");

var _jsxFileName = "C:\\Users\\KARTHIK\\Documents\\workspace\\matrix-cms-ui-development\\src\\components\\contentItem\\index.tsx";




const ContentItem = ({
  image_url,
  className = "",
  title,
  author,
  onClick,
  content_id,
  content_type,
  read_duration,
  style = {}
}) => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: `${className} relative mb-11 ml-0`,
    style: style,
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_2__["Image"], {
      src: image_url,
      alt: "content-image",
      className: ""
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 34,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "content-item-desc bg-secondary-light absolute top-4 p-3",
      style: {
        top: "2.5rem",
        left: "9.5rem"
      },
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h5", {
        className: "text-lg font-medium leading-6 text-primary-dark ml-2 p-0.5",
        children: title
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 39,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "flex justify-between ml-2 pl-0.5 pt-0.5",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
          className: "font-normal text-xs leading-3  text-primary-dark opacity-50",
          children: ["BY ", " " + author]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 43,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
          className: "font-normal text-xs leading-3  text-primary-dark opacity-50 mr-1",
          children: read_duration + " READ"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 46,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 42,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "flex justify-between mt-3",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_button_PrimaryButtonIconRight__WEBPACK_IMPORTED_MODULE_3__["default"], {
          title: "Read More",
          className: "h-8 w-36 text-accent",
          url: "/icons/rightArrowGray.svg"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 52,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_2__["Image"], {
          src: Object(_utils_getContentTypeImageUrl__WEBPACK_IMPORTED_MODULE_4__["default"])(content_type),
          alt: "content type image",
          className: "mr-1"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 57,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 50,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 35,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 30,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/components/contentSlider/ContentSlider.tsx":
/*!********************************************************!*\
  !*** ./src/components/contentSlider/ContentSlider.tsx ***!
  \********************************************************/
/*! exports provided: ContentSlider */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ContentSlider", function() { return ContentSlider; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_contentItem__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @components/contentItem */ "./src/components/contentItem/index.tsx");

var _jsxFileName = "C:\\Users\\KARTHIK\\Documents\\workspace\\matrix-cms-ui-development\\src\\components\\contentSlider\\ContentSlider.tsx";


const ContentSlider = ({
  contentList,
  className,
  header,
  style = {}
}) => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: `${className}`,
    style: style,
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        children: header
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 15,
        columnNumber: 17
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 16,
        columnNumber: 17
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 14,
      columnNumber: 13
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "flex",
      children: contentList.map(contentItem => {
        return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_contentItem__WEBPACK_IMPORTED_MODULE_2__["ContentItem"], {
          image_url: contentItem.image_url,
          title: contentItem.title,
          author: contentItem.author,
          content_id: contentItem.content_id,
          content_type: contentItem.content_type,
          read_duration: contentItem.read_duration,
          onClick: id => console.log(id),
          style: {
            width: 610
          },
          className: "mr-3 mt-2 text-lg leading-6"
        }, contentItem.content_id, false, {
          fileName: _jsxFileName,
          lineNumber: 21,
          columnNumber: 25
        }, undefined);
      })
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 18,
      columnNumber: 13
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 13,
    columnNumber: 9
  }, undefined);
};

/***/ }),

/***/ "./src/components/footer/footerMenu.tsx":
/*!**********************************************!*\
  !*** ./src/components/footer/footerMenu.tsx ***!
  \**********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _constants_footerMenu__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../constants/footerMenu */ "./constants/footerMenu.ts");

var _jsxFileName = "C:\\Users\\KARTHIK\\Documents\\workspace\\matrix-cms-ui-development\\src\\components\\footer\\footerMenu.tsx";



const FooterMenu = () => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: "sm:grid sm:grid-cols-2 sm:gap-y-0.5  bg-primary   sub-h2 laptop:flex laptop:items-center laptop:pl-56 ",
    children: _constants_footerMenu__WEBPACK_IMPORTED_MODULE_2__["default"].map((item, index) => {
      return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
        className: "p-1.5",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
          href: item.link,
          className: "text-secondary h-14 p-0.5 mr-11 leading-4.5",
          children: [" ", item.name]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 10,
          columnNumber: 11
        }, undefined)
      }, index, false, {
        fileName: _jsxFileName,
        lineNumber: 9,
        columnNumber: 17
      }, undefined);
    })
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 6,
    columnNumber: 11
  }, undefined);
};

/* harmony default export */ __webpack_exports__["default"] = (FooterMenu);

/***/ }),

/***/ "./src/components/footer/index.tsx":
/*!*****************************************!*\
  !*** ./src/components/footer/index.tsx ***!
  \*****************************************/
/*! exports provided: Footer */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Footer", function() { return Footer; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _footerMenu__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./footerMenu */ "./src/components/footer/footerMenu.tsx");
/* harmony import */ var _components_button_PrimaryButtonIconRight__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @components/button/PrimaryButtonIconRight */ "./src/components/button/PrimaryButtonIconRight.tsx");
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../constants */ "./constants/index.ts");

var _jsxFileName = "C:\\Users\\KARTHIK\\Documents\\workspace\\matrix-cms-ui-development\\src\\components\\footer\\index.tsx";




const Footer = () => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: "flex  justify-end flex-col text-secondary w-full align-bottom mt-auto",
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "bg-accent-dark footer-top flex laptop:justify-between sm:flex-col sm:pl-11 sm:pr-11 sm:pt-11",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "laptop:flex laptop:mt-16 p-0.5 laptop:ml-56",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h6", {
          className: "laptop:w-48 font-normal leading-9 text-4xl tracking-wider p-0.5",
          children: " Let's stay engaged"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 12,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
          className: "p-1 ml-4",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h6", {
            className: "sub-h2 font-medium text-lg leading-6",
            children: "Sign up for the Matrix Moments series"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 14,
            columnNumber: 13
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("input", {
            className: "mt-2 text-secondary bg-accent p-0.5 pl-3 w-full",
            style: {
              color: "#FBF9F5"
            },
            type: "email",
            placeholder: "Your email address goes here"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 15,
            columnNumber: 13
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_button_PrimaryButtonIconRight__WEBPACK_IMPORTED_MODULE_3__["default"], {
            title: "Subscribe",
            url: "/icons/arrow.svg",
            className: "p-1 text-cta",
            onClick: () => console.log("subscribe")
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 16,
            columnNumber: 13
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 13,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 11,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: " laptop:mt-16 p-0.5 laptop:mr-52 sm:flex sm:justify-between ",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h6", {
            className: "sub-h2 font-medium text-lg",
            children: " Matrix Partner Us "
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 21,
            columnNumber: 13
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h6", {
            className: " sub-h2 font-medium text-lg",
            children: " Matrix Partner China"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 22,
            columnNumber: 13
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 20,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "flex mt-2 laptop:mt-8 items-start p-0.5",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
            className: " pl-0",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
              src: "/icons/linkedin.svg"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 25,
              columnNumber: 34
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 25,
            columnNumber: 13
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
            className: " pl-9",
            children: [" ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
              src: "/icons/twitter.svg"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 26,
              columnNumber: 35
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 26,
            columnNumber: 13
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 24,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 19,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 10,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: " laptop:flex justify-between footer-menu bg-primary align-middle sm:pl-11 sm:pt-6",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_footerMenu__WEBPACK_IMPORTED_MODULE_2__["default"], {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 31,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: " text-secondary flex items-center sm:mt-2 sm:grid sm:grid-cols-2 sm:gap-0",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
          className: "caption p-1 w-28 text-sm sm:mt-2",
          children: "PRIVACY POLICY"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 33,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
          className: "caption p-0.5 laptop:ml-20 laptop:mr-40 ",
          children: [_constants__WEBPACK_IMPORTED_MODULE_4__["PRIVACY_POLICY"], " "]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 34,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 32,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 30,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 9,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/components/founder/Founder.tsx":
/*!********************************************!*\
  !*** ./src/components/founder/Founder.tsx ***!
  \********************************************/
/*! exports provided: Founder */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Founder", function() { return Founder; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-slick */ "react-slick");
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_slick__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! slick-carousel/slick/slick.css */ "./node_modules/slick-carousel/slick/slick.css");
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! slick-carousel/slick/slick-theme.css */ "./node_modules/slick-carousel/slick/slick-theme.css");
/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @components */ "./src/components/index.ts");

var _jsxFileName = "C:\\Users\\KARTHIK\\Documents\\workspace\\matrix-cms-ui-development\\src\\components\\founder\\Founder.tsx";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }






const Founder = ({
  className,
  style = {}
}) => {
  const heros = [{
    firstName: 'Bhavish',
    lastName: 'AGGARWAL',
    firstName1: null,
    lastName1: null,
    caption: 'Mobility',
    caption1: 'Electric Cars',
    logo: '/icons/ola.svg',
    image: '/icons/Bhavish_image.svg',
    heading: ['We are', 'founders', 'first']
  }, {
    firstName: 'ROHIT',
    lastName: 'M.A.',
    firstName1: null,
    lastName1: null,
    caption: 'Healthcare',
    caption1: null,
    logo: '/icons/Cloudnine.svg',
    image: '/icons/Rohit_Treatment.svg',
    heading: ['We ', 'partner', 'closely']
  }, {
    firstName: 'ANINDYA',
    lastName: 'DUTTA',
    firstName1: 'SANDEEP',
    lastName1: 'DALMIA',
    caption: 'Student Housing Platform',
    caption1: null,
    logo: '/icons/Stanza.svg',
    image: '/icons/Anindya.svg',
    heading: ['We ', 'invest', 'early']
  }, {
    firstName: 'Asish',
    lastName: 'MOHAPATRA',
    firstName1: null,
    lastName1: null,
    caption: 'Fintech',
    caption1: 'SME Lending',
    logo: '/icons/OfBusiness.svg',
    image: '/icons/Asish.svg',
    heading: ['We', 'commit', 'personally']
  }, {
    firstName: 'Mr.',
    lastName: 'LAKSHIPATHY',
    firstName1: null,
    lastName1: null,
    caption: 'Fintech',
    caption1: 'NBFC',
    logo: '/icons/mx.svg',
    image: '/icons/Laxmipathy.svg',
    heading: ['We are', 'founders', 'first']
  }, {
    firstName: 'CHAKRADHAR',
    lastName: 'GADE',
    firstName1: 'NITIN',
    lastName1: 'KAUSHAL',
    caption: 'Fintech',
    caption1: 'NBFC',
    logo: '/icons/Country.svg',
    heading: ['We', 'commit', 'personally'],
    image: '/icons/Chakradhar.svg'
  }];
  const data = [{
    image_url: "/icons/content1.svg",
    title: "From both sides of the table : Kunal Bahl unplugged",
    author: "TARUN DAVDA",
    content_id: "abcdef",
    content_type: "blog",
    read_duration: "4 MIN"
  }, {
    image_url: "/icons/content1.svg",
    title: "From both sides of the table : Kunal Bahl unplugged",
    author: "TARUN DAVDA",
    content_id: "abcdefg",
    content_type: "blog",
    read_duration: "4 MIN"
  }];
  const settings = {
    dots: true,
    infinite: true,
    speed: 500,
    autoplaySpeed: 5000,
    slidesToShow: 1,
    slidesToScroll: 1 // autoplay: true

  };
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_slick__WEBPACK_IMPORTED_MODULE_2___default.a, _objectSpread(_objectSpread({}, settings), {}, {
    children: heros.map(hero => {
      return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: `${className}`,
          style: _objectSpread({
            width: 615.94,
            height: 863.91,
            position: "relative"
          }, style),
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "",
            style: {
              width: 571,
              height: 762,
              position: "absolute",
              background: "#083A4A",
              bottom: 50,
              left: 0
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 113,
            columnNumber: 13
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "",
            style: {
              width: 594,
              height: 788,
              bottom: 65,
              left: 15,
              position: "absolute",
              display: "flex",
              flexDirection: "column"
            },
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_5__["Image"], {
              src: hero.image,
              alt: "founder image",
              style: {
                flexGrow: 1
              }
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 115,
              columnNumber: 15
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_5__["Image"], {
              src: "/icons/rectangle.svg",
              alt: "reactangle",
              className: "absolute",
              style: {
                left: 38,
                bottom: 254
              }
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 116,
              columnNumber: 15
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              style: {
                height: 209,
                background: "#01576E"
              },
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "text-center flex items-center",
                style: {
                  height: 118,
                  borderBottom: "1px solid #EBEBE9"
                },
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h6", {
                  className: "font-bold text-secondary",
                  style: {
                    fontSize: 32,
                    lineHeight: "36px",
                    letterSpacing: "0.05em",
                    marginLeft: 31,
                    marginRight: 8
                  },
                  children: hero.firstName
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 120,
                  columnNumber: 19
                }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h6", {
                  className: "font-light text-secondary",
                  style: {
                    fontSize: 32,
                    lineHeight: "36px",
                    letterSpacing: "0.05em"
                  },
                  children: hero.lastName
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 123,
                  columnNumber: 19
                }, undefined)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 119,
                columnNumber: 17
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "flex justify-between items-center",
                style: {
                  height: 88
                },
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  style: {
                    marginLeft: 31,
                    display: 'flex',
                    justifyContent: 'space-around'
                  },
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                    className: "text-secondary font-medium text-lg leading-6",
                    children: [" ", hero.caption]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 130,
                    columnNumber: 21
                  }, undefined), hero.caption1 && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                    className: "text-secondary font-medium text-lg leading-6",
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("hr", {
                      style: {
                        width: 30,
                        transform: 'rotate(90deg)'
                      }
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 131,
                      columnNumber: 102
                    }, undefined)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 131,
                    columnNumber: 39
                  }, undefined), hero.caption1 && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                    className: "text-secondary font-medium text-lg leading-6",
                    children: [" ", hero.caption1]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 132,
                    columnNumber: 39
                  }, undefined)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 129,
                  columnNumber: 19
                }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_5__["Image"], {
                  src: hero.logo,
                  alt: "ola",
                  style: {
                    marginRight: 57
                  }
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 134,
                  columnNumber: 19
                }, undefined)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 128,
                columnNumber: 17
              }, undefined)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 118,
              columnNumber: 15
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 114,
            columnNumber: 13
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "",
            style: {
              left: 760,
              position: "absolute"
            },
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
              className: "slide-header",
              children: [hero.heading[0], /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                style: {
                  color: '#01576E'
                },
                children: [" ", hero.heading[1], " "]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 140,
                columnNumber: 60
              }, undefined), " ", hero.heading[2]]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 140,
              columnNumber: 15
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_5__["ContentSlider"], {
              style: {
                left: -12,
                background: "#EBEBE9",
                border: "1px solid #EBEBE9",
                boxSizing: "border-box",
                fontSize: 28,
                lineHeight: "34px",
                paddingTop: 24,
                paddingLeft: 34,
                width: '155%',
                bottom: -347,
                height: 301
              },
              contentList: data,
              className: "absolute bottom-0 right-0 text-primary-dark",
              header: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                children: ["Insights from market ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                  className: "text-accent",
                  children: "disruptors & investors"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 158,
                  columnNumber: 52
                }, undefined)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 158,
                columnNumber: 25
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 142,
              columnNumber: 15
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 139,
            columnNumber: 13
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 112,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 111,
        columnNumber: 17
      }, undefined);
    })
  }), void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 109,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/components/founder/FounderDetail.tsx":
/*!**************************************************!*\
  !*** ./src/components/founder/FounderDetail.tsx ***!
  \**************************************************/
/*! exports provided: FounderDetail */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "FounderDetail", function() { return FounderDetail; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @components */ "./src/components/index.ts");

var _jsxFileName = "C:\\Users\\KARTHIK\\Documents\\workspace\\matrix-cms-ui-development\\src\\components\\founder\\FounderDetail.tsx";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



const FounderDetail = ({
  className = "",
  style = {}
}) => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: "",
    style: _objectSpread(_objectSpread({}, {
      width: 650,
      height: 744,
      position: "relative"
    }), style),
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "",
      style: {
        width: 620,
        height: 711,
        position: "absolute",
        background: "#083A4A",
        bottom: 0,
        left: 0
      }
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 29,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "",
      style: {
        width: 638,
        height: 732,
        position: "absolute",
        left: 15,
        bottom: 15,
        display: "flex",
        flexDirection: "column"
      },
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_2__["Image"], {
        src: "/icons/founderDetail.jpg",
        alt: "founder detail",
        style: {
          flexGrow: 1
        }
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 52,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_2__["Image"], {
        src: "/icons/rectangle.svg",
        alt: "reactangle",
        className: "absolute",
        style: {
          left: 38,
          bottom: 253
        }
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 57,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        style: {
          height: 232,
          background: "#01576E"
        },
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "text-center flex  flex-col justify-center",
          style: {
            height: 118,
            borderBottom: "0.89491px solid #EBEBE9"
          },
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "flex",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h6", {
              className: "font-bold text-secondary",
              style: {
                fontSize: 32,
                lineHeight: "36px",
                letterSpacing: "0.05em",
                marginLeft: 31,
                marginRight: 8
              },
              children: "ANINYA"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 69,
              columnNumber: 15
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h6", {
              className: "font-light text-secondary",
              style: {
                fontSize: 32,
                lineHeight: "36px",
                letterSpacing: "0.05em"
              },
              children: "DUTTA"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 81,
              columnNumber: 15
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 68,
            columnNumber: 13
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "flex",
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h6", {
              className: "font-bold text-secondary",
              style: {
                fontSize: 32,
                lineHeight: "36px",
                letterSpacing: "0.05em",
                marginLeft: 31,
                marginRight: 8
              },
              children: "SANDEEP"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 93,
              columnNumber: 15
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h6", {
              className: "font-light text-secondary",
              style: {
                fontSize: 32,
                lineHeight: "36px",
                letterSpacing: "0.05em"
              },
              children: "DALMIA"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 105,
              columnNumber: 15
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 92,
            columnNumber: 13
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 64,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 63,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 40,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 18,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/components/founder/index.ts":
/*!*****************************************!*\
  !*** ./src/components/founder/index.ts ***!
  \*****************************************/
/*! exports provided: Founder */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Founder__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Founder */ "./src/components/founder/Founder.tsx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Founder", function() { return _Founder__WEBPACK_IMPORTED_MODULE_0__["Founder"]; });



/***/ }),

/***/ "./src/components/header/index.tsx":
/*!*****************************************!*\
  !*** ./src/components/header/index.tsx ***!
  \*****************************************/
/*! exports provided: Header */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Header", function() { return Header; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @components */ "./src/components/index.ts");

var _jsxFileName = "C:\\Users\\KARTHIK\\Documents\\workspace\\matrix-cms-ui-development\\src\\components\\header\\index.tsx";


const Header = ({
  toggle
}) => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: "absolute flex w-full z-20 justify-between items-start laptop:pl-8 mt-11 sm:mt-0 sm:p-5",
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_2__["Logo"], {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 12,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "flex  items-center justify-start mt-2 text-accent ",
      onClick: () => toggle(),
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h6", {
        className: "sub-h1 pr-1 menu-text",
        children: "Menu"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 17,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
        src: "/icons/menu.svg",
        className: "pl-2 laptop:mr-20 text-blue"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 18,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 13,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 11,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/components/image/index.tsx":
/*!****************************************!*\
  !*** ./src/components/image/index.tsx ***!
  \****************************************/
/*! exports provided: Image */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Image", function() { return Image; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);

var _jsxFileName = "C:\\Users\\KARTHIK\\Documents\\workspace\\matrix-cms-ui-development\\src\\components\\image\\index.tsx";

const Image = ({
  src,
  alt,
  className,
  width,
  height,
  style = {}
}) => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
    src: src,
    alt: alt,
    className: className,
    height: height,
    width: width,
    style: style
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 13,
    columnNumber: 12
  }, undefined);
};

/***/ }),

/***/ "./src/components/index.ts":
/*!*********************************!*\
  !*** ./src/components/index.ts ***!
  \*********************************/
/*! exports provided: Header, Logo, Main, Button, Cards, Footer, Container, Image, Tag, NavItem, ContentItem, Founder, ContentSlider, Banner */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _header__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./header */ "./src/components/header/index.tsx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Header", function() { return _header__WEBPACK_IMPORTED_MODULE_0__["Header"]; });

/* harmony import */ var _logo__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./logo */ "./src/components/logo/index.tsx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Logo", function() { return _logo__WEBPACK_IMPORTED_MODULE_1__["Logo"]; });

/* harmony import */ var _main__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./main */ "./src/components/main/index.tsx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Main", function() { return _main__WEBPACK_IMPORTED_MODULE_2__["Main"]; });

/* harmony import */ var _button__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./button */ "./src/components/button/index.tsx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Button", function() { return _button__WEBPACK_IMPORTED_MODULE_3__["Button"]; });

/* harmony import */ var _cards__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./cards */ "./src/components/cards/index.tsx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Cards", function() { return _cards__WEBPACK_IMPORTED_MODULE_4__["Cards"]; });

/* harmony import */ var _footer__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./footer */ "./src/components/footer/index.tsx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Footer", function() { return _footer__WEBPACK_IMPORTED_MODULE_5__["Footer"]; });

/* harmony import */ var _container__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./container */ "./src/components/container/index.tsx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Container", function() { return _container__WEBPACK_IMPORTED_MODULE_6__["Container"]; });

/* harmony import */ var _image__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./image */ "./src/components/image/index.tsx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Image", function() { return _image__WEBPACK_IMPORTED_MODULE_7__["Image"]; });

/* harmony import */ var _tag__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./tag */ "./src/components/tag/index.tsx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Tag", function() { return _tag__WEBPACK_IMPORTED_MODULE_8__["Tag"]; });

/* harmony import */ var _navItem__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./navItem */ "./src/components/navItem/index.tsx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "NavItem", function() { return _navItem__WEBPACK_IMPORTED_MODULE_9__["NavItem"]; });

/* harmony import */ var _contentItem__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./contentItem */ "./src/components/contentItem/index.tsx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ContentItem", function() { return _contentItem__WEBPACK_IMPORTED_MODULE_10__["ContentItem"]; });

/* harmony import */ var _founder__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./founder */ "./src/components/founder/index.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Founder", function() { return _founder__WEBPACK_IMPORTED_MODULE_11__["Founder"]; });

/* harmony import */ var _contentSlider_ContentSlider__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./contentSlider/ContentSlider */ "./src/components/contentSlider/ContentSlider.tsx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ContentSlider", function() { return _contentSlider_ContentSlider__WEBPACK_IMPORTED_MODULE_12__["ContentSlider"]; });

/* harmony import */ var _banner__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./banner */ "./src/components/banner/index.tsx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Banner", function() { return _banner__WEBPACK_IMPORTED_MODULE_13__["Banner"]; });
















/***/ }),

/***/ "./src/components/logo/index.tsx":
/*!***************************************!*\
  !*** ./src/components/logo/index.tsx ***!
  \***************************************/
/*! exports provided: Logo */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Logo", function() { return Logo; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/image */ "./node_modules/next/image.js");
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);

var _jsxFileName = "C:\\Users\\KARTHIK\\Documents\\workspace\\matrix-cms-ui-development\\src\\components\\logo\\index.tsx";


const Logo = () => {
  return (
    /*#__PURE__*/
    // <Image src="/icons/matrixLogo_White.svg" alt="nextjs" width="156.19px" height="65px" className="company-logo" />
    Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_image__WEBPACK_IMPORTED_MODULE_2___default.a, {
      src: "/icons/matrixLogo.svg",
      alt: "nextjs",
      width: "156.19px",
      height: "65px",
      className: "company-logo"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 7,
      columnNumber: 5
    }, undefined)
  );
};

/***/ }),

/***/ "./src/components/main/index.tsx":
/*!***************************************!*\
  !*** ./src/components/main/index.tsx ***!
  \***************************************/
/*! exports provided: Main */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Main", function() { return Main; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @components */ "./src/components/index.ts");

var _jsxFileName = "C:\\Users\\KARTHIK\\Documents\\workspace\\matrix-cms-ui-development\\src\\components\\main\\index.tsx";


const Main = () => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: "text-center font-light py-5 bg-gray-700",
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "container mx-auto",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h1", {
        className: "text-white text-8xl mb-2",
        children: "matrix"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 9,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
        className: "text-lg text-white mb-3",
        children: "The frontend boilerplate with superpowers!"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 10,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_2__["Button"], {
        type: "button",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
          href: "https://pankod.github.io/superplate/",
          target: "_blank",
          children: "Docs"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 14,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 13,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 8,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 7,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/components/navItem/index.tsx":
/*!******************************************!*\
  !*** ./src/components/navItem/index.tsx ***!
  \******************************************/
/*! exports provided: NavItem */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NavItem", function() { return NavItem; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @components */ "./src/components/index.ts");

var _jsxFileName = "C:\\Users\\KARTHIK\\Documents\\workspace\\matrix-cms-ui-development\\src\\components\\navItem\\index.tsx";


const NavItem = ({
  title,
  selected,
  id,
  onClick,
  className = "",
  arrow = true
}) => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: `${className} flex justify-between menu-primary-nav-text text-primary-dark`,
    style: {
      marginBottom: 25
    },
    onClick: () => onClick(id),
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
      children: title
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 28,
      columnNumber: 7
    }, undefined), selected || arrow ? !selected ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
      className: "menu-primary-nav-icon",
      children: [" ", ">", " "]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 32,
      columnNumber: 11
    }, undefined) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_2__["Image"], {
      src: "/icons/sideNavButton.svg",
      alt: "nav button",
      className: "-mr-5 opacity-100"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 34,
      columnNumber: 11
    }, undefined) : null]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 23,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/components/tag/index.tsx":
/*!**************************************!*\
  !*** ./src/components/tag/index.tsx ***!
  \**************************************/
/*! exports provided: Tag */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Tag", function() { return Tag; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);

var _jsxFileName = "C:\\Users\\KARTHIK\\Documents\\workspace\\matrix-cms-ui-development\\src\\components\\tag\\index.tsx";

const Tag = ({
  selected,
  title,
  id,
  onClick,
  className = "",
  style = {}
}) => {
  const _className = selected ? "tag-selected" : "tag";

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
    className: className + " " + _className,
    style: style,
    onClick: () => {
      if (onClick) onClick(id);
    },
    children: title
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 15,
    columnNumber: 13
  }, undefined);
};

/***/ }),

/***/ "./src/modules/home/home.tsx":
/*!***********************************!*\
  !*** ./src/modules/home/home.tsx ***!
  \***********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _homeContent__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./homeContent */ "./src/modules/home/homeContent/index.tsx");
/* harmony import */ var _homeCarousal__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./homeCarousal */ "./src/modules/home/homeCarousal/index.ts");
/* harmony import */ var _homeFounder__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./homeFounder */ "./src/modules/home/homeFounder/index.ts");

var _jsxFileName = "C:\\Users\\KARTHIK\\Documents\\workspace\\matrix-cms-ui-development\\src\\modules\\home\\home.tsx";





const Home = () => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: "bg-secondary-light",
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_homeFounder__WEBPACK_IMPORTED_MODULE_4__["default"], {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 9,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_homeCarousal__WEBPACK_IMPORTED_MODULE_3__["default"], {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 10,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h4", {
      className: "font-extralight text-primary-dark",
      style: {
        marginTop: 119,
        marginLeft: 116,
        marginBottom: 120,
        fontSize: 85,
        lineHeight: "95px"
      },
      children: [" ", "Scroll through for the latest from ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 22,
        columnNumber: 44
      }, undefined), " the", " ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
        className: "text-accent",
        children: "Matrix Moments "
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 23,
        columnNumber: 9
      }, undefined), " series ...", " "]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 11,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_homeContent__WEBPACK_IMPORTED_MODULE_2__["default"], {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 25,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 8,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ __webpack_exports__["default"] = (Home);

/***/ }),

/***/ "./src/modules/home/homeCarousal/HomeCarousal.tsx":
/*!********************************************************!*\
  !*** ./src/modules/home/homeCarousal/HomeCarousal.tsx ***!
  \********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @components */ "./src/components/index.ts");
/* harmony import */ var _components_founder_FounderDetail__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @components/founder/FounderDetail */ "./src/components/founder/FounderDetail.tsx");

var _jsxFileName = "C:\\Users\\KARTHIK\\Documents\\workspace\\matrix-cms-ui-development\\src\\modules\\home\\homeCarousal\\HomeCarousal.tsx";



const data = [{
  image_url: "/icons/content1.svg",
  title: "From both sides of the table : Kunal Bahl unplugged",
  author: "TARUN DAVDA",
  content_id: "abcdef",
  content_type: "blog",
  read_duration: "4 MIN"
}, {
  image_url: "/icons/content1.svg",
  title: "From both sides of the table : Kunal Bahl unplugged",
  author: "TARUN DAVDA",
  content_id: "abcdefg",
  content_type: "blog",
  read_duration: "4 MIN"
}];
const heros = [{
  firstName: 'ROHIT',
  lastName: 'M.A.',
  firstName1: null,
  lastName1: null,
  caption: 'At Cloudnine, we believe that a child is life’s greatest gift and pregnancy is one of the most magical experiences nature can offer. ',
  logo: '/icons/Cloudnine.svg',
  image: '/icons/Rohit_Treatment.svg',
  heading: ['Leading chain of ', 'maternity hospitals', ''],
  bg: ''
}, {
  firstName: 'ANINDYA',
  lastName: 'DUTTA',
  firstName1: 'SANDEEP',
  lastName1: 'DALMIA',
  caption: 'Stanza Living provides fully-managed shared living accommodations to students and young professionals.',
  logo: '/icons/Stanza.svg',
  image: '/icons/Anindya.svg',
  heading: ['Tech-enabled ', 'student housing', 'platform'],
  bg: ''
}, {
  firstName: 'Asish',
  lastName: 'MOHAPATRA',
  firstName1: null,
  lastName1: null,
  caption: 'OFB Tech (OfBusiness) is a tech-enabled platform that facilitates raw material procurement and credit for SMEs,',
  logo: '/icons/OfBusiness.svg',
  image: '/icons/Asish.svg',
  heading: ['SME', 'lending', '']
}, {
  firstName: 'Mr.',
  lastName: 'LAKSHIPATHY',
  firstName1: null,
  lastName1: null,
  caption: 'A specialized financial services company funding the people who were perceived to be unfundable',
  logo: '/icons/mx.svg',
  image: '/icons/Laxmipathy.svg',
  heading: ['Credit led', 'B2B marketplace', '']
}, {
  firstName: 'CHAKRADHAR',
  lastName: 'GADE',
  firstName1: 'NITIN',
  lastName1: 'KAUSHAL',
  caption: 'Country Delight aims to bring back the basics of Milk. It promises natural, fresh and unadulterated milk directly to the doorstep of the consumer.',
  logo: '/icons/Country.svg',
  heading: ['D2C', 'dairy & fresh foods', 'brand'],
  image: '/icons/Chakradhar.svg'
}, {
  firstName: 'Bhavish',
  lastName: 'AGGARWAL',
  firstName1: null,
  lastName1: null,
  caption: 'Ola is India’s largest mobility platform and one of the world’s largest ride-hailing companies, serving 250+ cities across India, Australia, New Zealand, and the UK.',
  logo: '/icons/ola.svg',
  image: '/icons/Bhavish_image.svg',
  heading: ['India’s leading', 'mobility', 'player']
}];

const HomeCarousal = () => {
  const [backgroundUrl, setBackgroundUrl] = react__WEBPACK_IMPORTED_MODULE_1___default.a.useState("/icons/backgroundCarousalImage.png");
  return (
    /*#__PURE__*/
    // <Carousel>
    Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "relative",
      style: {
        height: 1080
      },
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "absolute h-full w-full flex flex-col",
        style: {
          backgroundImage: `url(${backgroundUrl})`,
          backgroundSize: "cover"
        },
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "flex",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_2__["Image"], {
            src: "/icons/leftArrow.svg",
            alt: "right Icon",
            height: 73,
            width: 37,
            style: {
              marginLeft: 179
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 99,
            columnNumber: 11
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            style: {
              width: 533,
              marginLeft: 100
            },
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              style: {
                fontWeight: 300,
                fontSize: "100px",
                lineHeight: "120px",
                letterSpacing: "-0.01em",
                opacity: 0.35,
                marginTop: 117
              },
              children: [" ", "01/05"]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 107,
              columnNumber: 13
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              className: "text-secondary-light",
              style: {
                fontWeight: 200,
                fontSize: "85px",
                lineHeight: "95px",
                opacity: 1,
                marginTop: 151,
                minWidth: 545
              },
              children: ["Tech-enabled", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 132,
                columnNumber: 15
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                className: "font-bold",
                children: " Student housing"
              }, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 133,
                columnNumber: 15
              }, undefined), " ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("br", {}, void 0, false, {
                fileName: _jsxFileName,
                lineNumber: 133,
                columnNumber: 67
              }, undefined), "Platform"]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 120,
              columnNumber: 13
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 106,
            columnNumber: 11
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_founder_FounderDetail__WEBPACK_IMPORTED_MODULE_3__["FounderDetail"], {
            style: {
              marginTop: 36,
              marginLeft: 103
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 137,
            columnNumber: 11
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_2__["Image"], {
            src: "/icons/rightArrow.large.svg",
            alt: "right Icon",
            height: 73,
            width: 37,
            style: {
              marginLeft: 103
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 138,
            columnNumber: 11
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 98,
          columnNumber: 9
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "absolute bg-accent",
          style: {
            bottom: 33,
            left: 269,
            height: 246,
            width: 564
          },
          children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
            className: "text-secondary font-medium text-lg leading-6 text-center h-full flex justify-center items-center",
            style: {
              writingMode: "vertical-lr",
              width: 56
            },
            children: [" ", "Hospitality Sector", " "]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 150,
            columnNumber: 11
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 146,
          columnNumber: 9
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_2__["ContentSlider"], {
          style: {
            left: 325,
            background: "#EBEBE9",
            border: "1px solid #EBEBE9",
            boxSizing: "border-box",
            fontSize: 28,
            lineHeight: "34px",
            paddingTop: 24,
            paddingLeft: 34
          },
          contentList: data,
          className: "absolute bottom-0 right-0 text-primary-dark",
          header: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
            children: ["Dive into the ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
              className: "text-accent",
              children: "Matrix Moments"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 171,
              columnNumber: 39
            }, undefined), " series"]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 171,
            columnNumber: 19
          }, undefined)
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 158,
          columnNumber: 9
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 91,
        columnNumber: 7
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 90,
      columnNumber: 5
    }, undefined) // </Carousel>

  );
};

/* harmony default export */ __webpack_exports__["default"] = (HomeCarousal);

/***/ }),

/***/ "./src/modules/home/homeCarousal/index.ts":
/*!************************************************!*\
  !*** ./src/modules/home/homeCarousal/index.ts ***!
  \************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _HomeCarousal__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./HomeCarousal */ "./src/modules/home/homeCarousal/HomeCarousal.tsx");

/* harmony default export */ __webpack_exports__["default"] = (_HomeCarousal__WEBPACK_IMPORTED_MODULE_0__["default"]);

/***/ }),

/***/ "./src/modules/home/homeContent/ContentTabs.tsx":
/*!******************************************************!*\
  !*** ./src/modules/home/homeContent/ContentTabs.tsx ***!
  \******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @components */ "./src/components/index.ts");

var _jsxFileName = "C:\\Users\\KARTHIK\\Documents\\workspace\\matrix-cms-ui-development\\src\\modules\\home\\homeContent\\ContentTabs.tsx";



const ContentTabs = ({
  selectedTab,
  onTabSelected,
  tabList
}) => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: "home-content-side-nav-container bg-secondary items-center flex flex-col justify-center",
    children: tabList.map(({
      name,
      id,
      link
    }) => {
      const tabStyle = id === selectedTab ? "opacity-100  text-accent" : "opacity-40 text-primary-dark";
      return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_2__["NavItem"], {
        title: name,
        id: id,
        arrow: false,
        onClick: onTabSelected,
        selected: id === selectedTab,
        className: `w-full font-extralight home-content-tab ${tabStyle}`
      }, id, false, {
        fileName: _jsxFileName,
        lineNumber: 23,
        columnNumber: 11
      }, undefined);
    })
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 16,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ __webpack_exports__["default"] = (ContentTabs);

/***/ }),

/***/ "./src/modules/home/homeContent/HomeContentList.tsx":
/*!**********************************************************!*\
  !*** ./src/modules/home/homeContent/HomeContentList.tsx ***!
  \**********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_contentItem_contentItemWithTags__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @components/contentItem/contentItemWithTags */ "./src/components/contentItem/contentItemWithTags.tsx");

var _jsxFileName = "C:\\Users\\KARTHIK\\Documents\\workspace\\matrix-cms-ui-development\\src\\modules\\home\\homeContent\\HomeContentList.tsx";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



const data = {
  image_url: "/icons/homeContentImage.svg",
  image_caption: "MOST SEARCHED",
  title: "Redefining wellness , one mosaic at a time",
  author: "Sanjot Malhi",
  designation: "Director",
  author_image_url: "/icons/profileImage.svg",
  content_id: "abcdef",
  content_type: "blog",
  read_duration: "4 MIN",
  tags: [{
    title: "LEADERSHIP",
    id: "leadership"
  }]
};

const HomeContentList = ({
  contentList
}) => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: "overflow-auto home-content-container",
    children: contentList.map(() => {
      return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_contentItem_contentItemWithTags__WEBPACK_IMPORTED_MODULE_2__["default"], _objectSpread({}, data), void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 30,
        columnNumber: 16
      }, undefined);
    })
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 28,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ __webpack_exports__["default"] = (HomeContentList);

/***/ }),

/***/ "./src/modules/home/homeContent/index.tsx":
/*!************************************************!*\
  !*** ./src/modules/home/homeContent/index.tsx ***!
  \************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _ContentTabs__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./ContentTabs */ "./src/modules/home/homeContent/ContentTabs.tsx");
/* harmony import */ var _HomeContentList__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./HomeContentList */ "./src/modules/home/homeContent/HomeContentList.tsx");

var _jsxFileName = "C:\\Users\\KARTHIK\\Documents\\workspace\\matrix-cms-ui-development\\src\\modules\\home\\homeContent\\index.tsx";



const homeContentTabs = [{
  name: "Blogs",
  id: "blogs",
  link: ""
}, {
  name: "Podcast",
  id: "podcast",
  link: ""
}, {
  name: "VideoCasts",
  id: "videocasts",
  link: ""
}];
const contentList = [{}, {}, {}, {}, {}];

const HomeContent = () => {
  const [selectedTab, setSelectedTab] = react__WEBPACK_IMPORTED_MODULE_1___default.a.useState(homeContentTabs[0].id);

  const onTabSelected = id => {
    setSelectedTab(id);
  };

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: "flex",
    style: {
      marginLeft: 80,
      height: 1400,
      marginBottom: 107
    },
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_ContentTabs__WEBPACK_IMPORTED_MODULE_2__["default"], {
      tabList: homeContentTabs,
      selectedTab: selectedTab,
      onTabSelected: onTabSelected
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 39,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_HomeContentList__WEBPACK_IMPORTED_MODULE_3__["default"], {
      contentList: contentList
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 44,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 35,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ __webpack_exports__["default"] = (HomeContent);

/***/ }),

/***/ "./src/modules/home/homeFounder/HomeFounder.tsx":
/*!******************************************************!*\
  !*** ./src/modules/home/homeFounder/HomeFounder.tsx ***!
  \******************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @components */ "./src/components/index.ts");

var _jsxFileName = "C:\\Users\\KARTHIK\\Documents\\workspace\\matrix-cms-ui-development\\src\\modules\\home\\homeFounder\\HomeFounder.tsx";



const HomeFounder = () => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    style: {
      marginTop: 64.56,
      marginLeft: 82
    },
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_2__["Founder"], {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 7,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 6,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ __webpack_exports__["default"] = (HomeFounder);

/***/ }),

/***/ "./src/modules/home/homeFounder/index.ts":
/*!***********************************************!*\
  !*** ./src/modules/home/homeFounder/index.ts ***!
  \***********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _HomeFounder__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./HomeFounder */ "./src/modules/home/homeFounder/HomeFounder.tsx");

/* harmony default export */ __webpack_exports__["default"] = (_HomeFounder__WEBPACK_IMPORTED_MODULE_0__["default"]);

/***/ }),

/***/ "./src/modules/home/index.ts":
/*!***********************************!*\
  !*** ./src/modules/home/index.ts ***!
  \***********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _home__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./home */ "./src/modules/home/home.tsx");

/* harmony default export */ __webpack_exports__["default"] = (_home__WEBPACK_IMPORTED_MODULE_0__["default"]);

/***/ }),

/***/ "./utils/getContentTypeImageUrl.ts":
/*!*****************************************!*\
  !*** ./utils/getContentTypeImageUrl.ts ***!
  \*****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (function (type) {
  switch (type) {}

  return "/icons/video.svg";
});

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),

/***/ "react-slick":
/*!******************************!*\
  !*** external "react-slick" ***!
  \******************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react-slick");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react/jsx-dev-runtime");

/***/ })

/******/ });
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwibmV4dC9kaXN0L25leHQtc2VydmVyL2xpYi9oZWFkLmpzXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwibmV4dC9kaXN0L25leHQtc2VydmVyL2xpYi90by1iYXNlLTY0LmpzXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwibmV4dC9kaXN0L25leHQtc2VydmVyL3NlcnZlci9pbWFnZS1jb25maWcuanNcIiIsIndlYnBhY2s6Ly8vLi9jb25zdGFudHMvZm9vdGVyTWVudS50cyIsIndlYnBhY2s6Ly8vLi9jb25zdGFudHMvaW5kZXgudHMiLCJ3ZWJwYWNrOi8vLy4vY29uc3RhbnRzL25hdk1lbnUudHMiLCJ3ZWJwYWNrOi8vLy4vbm9kZV9tb2R1bGVzL0BiYWJlbC9ydW50aW1lL2hlbHBlcnMvZXh0ZW5kcy5qcyIsIndlYnBhY2s6Ly8vLi9ub2RlX21vZHVsZXMvQGJhYmVsL3J1bnRpbWUvaGVscGVycy9pbnRlcm9wUmVxdWlyZURlZmF1bHQuanMiLCJ3ZWJwYWNrOi8vLy4vbm9kZV9tb2R1bGVzL0BiYWJlbC9ydW50aW1lL2hlbHBlcnMvb2JqZWN0V2l0aG91dFByb3BlcnRpZXNMb29zZS5qcyIsIndlYnBhY2s6Ly8vLi4vLi4vY2xpZW50L2ltYWdlLnRzeCIsIndlYnBhY2s6Ly8vLi4vLi4vY2xpZW50L3JlcXVlc3QtaWRsZS1jYWxsYmFjay50cyIsIndlYnBhY2s6Ly8vLi4vLi4vY2xpZW50L3VzZS1pbnRlcnNlY3Rpb24udHN4Iiwid2VicGFjazovLy8uL25vZGVfbW9kdWxlcy9uZXh0L2ltYWdlLmpzIiwid2VicGFjazovLy8uL3BhZ2VzL2hvbWUvaW5kZXgudHN4Iiwid2VicGFjazovLy8uL3NyYy9jb21wb25lbnRzL2Jhbm5lci9pbmRleC50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL2NvbXBvbmVudHMvYnV0dG9uL1ByaW1hcnlCdXR0b25JY29uUmlnaHQudHN4Iiwid2VicGFjazovLy8uL3NyYy9jb21wb25lbnRzL2J1dHRvbi9pbmRleC50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL2NvbXBvbmVudHMvY2FyZHMvaW5kZXgudHN4Iiwid2VicGFjazovLy8uL3NyYy9jb21wb25lbnRzL2NvbnRhaW5lci9pbmRleC50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL2NvbXBvbmVudHMvY29udGVudEl0ZW0vY29udGVudEl0ZW1XaXRoVGFncy50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL2NvbXBvbmVudHMvY29udGVudEl0ZW0vaW5kZXgudHN4Iiwid2VicGFjazovLy8uL3NyYy9jb21wb25lbnRzL2NvbnRlbnRTbGlkZXIvQ29udGVudFNsaWRlci50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL2NvbXBvbmVudHMvZm9vdGVyL2Zvb3Rlck1lbnUudHN4Iiwid2VicGFjazovLy8uL3NyYy9jb21wb25lbnRzL2Zvb3Rlci9pbmRleC50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL2NvbXBvbmVudHMvZm91bmRlci9Gb3VuZGVyLnRzeCIsIndlYnBhY2s6Ly8vLi9zcmMvY29tcG9uZW50cy9mb3VuZGVyL0ZvdW5kZXJEZXRhaWwudHN4Iiwid2VicGFjazovLy8uL3NyYy9jb21wb25lbnRzL2ZvdW5kZXIvaW5kZXgudHMiLCJ3ZWJwYWNrOi8vLy4vc3JjL2NvbXBvbmVudHMvaGVhZGVyL2luZGV4LnRzeCIsIndlYnBhY2s6Ly8vLi9zcmMvY29tcG9uZW50cy9pbWFnZS9pbmRleC50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL2NvbXBvbmVudHMvaW5kZXgudHMiLCJ3ZWJwYWNrOi8vLy4vc3JjL2NvbXBvbmVudHMvbG9nby9pbmRleC50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL2NvbXBvbmVudHMvbWFpbi9pbmRleC50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL2NvbXBvbmVudHMvbmF2SXRlbS9pbmRleC50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL2NvbXBvbmVudHMvdGFnL2luZGV4LnRzeCIsIndlYnBhY2s6Ly8vLi9zcmMvbW9kdWxlcy9ob21lL2hvbWUudHN4Iiwid2VicGFjazovLy8uL3NyYy9tb2R1bGVzL2hvbWUvaG9tZUNhcm91c2FsL0hvbWVDYXJvdXNhbC50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL21vZHVsZXMvaG9tZS9ob21lQ2Fyb3VzYWwvaW5kZXgudHMiLCJ3ZWJwYWNrOi8vLy4vc3JjL21vZHVsZXMvaG9tZS9ob21lQ29udGVudC9Db250ZW50VGFicy50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL21vZHVsZXMvaG9tZS9ob21lQ29udGVudC9Ib21lQ29udGVudExpc3QudHN4Iiwid2VicGFjazovLy8uL3NyYy9tb2R1bGVzL2hvbWUvaG9tZUNvbnRlbnQvaW5kZXgudHN4Iiwid2VicGFjazovLy8uL3NyYy9tb2R1bGVzL2hvbWUvaG9tZUZvdW5kZXIvSG9tZUZvdW5kZXIudHN4Iiwid2VicGFjazovLy8uL3NyYy9tb2R1bGVzL2hvbWUvaG9tZUZvdW5kZXIvaW5kZXgudHMiLCJ3ZWJwYWNrOi8vLy4vc3JjL21vZHVsZXMvaG9tZS9pbmRleC50cyIsIndlYnBhY2s6Ly8vLi91dGlscy9nZXRDb250ZW50VHlwZUltYWdlVXJsLnRzIiwid2VicGFjazovLy9leHRlcm5hbCBcInJlYWN0XCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwicmVhY3Qtc2xpY2tcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJyZWFjdC9qc3gtZGV2LXJ1bnRpbWVcIiJdLCJuYW1lcyI6WyJmb290ZXJtZW51Iiwia2V5IiwibmFtZSIsImxpbmsiLCJQUklWQUNZX1BPTElDWSIsIm5hdk1lbnUiLCJwcmltYXJ5Iiwic2Vjb25kYXJ5IiwiZ2xvYmFsIiwiVkFMSURfTE9BRElOR19WQUxVRVMiLCJsb2FkZXJzIiwiVkFMSURfTEFZT1VUX1ZBTFVFUyIsImRldmljZVNpemVzIiwiaW1hZ2VTaXplcyIsImxvYWRlciIsInBhdGgiLCJkb21haW5zIiwicHJvY2VzcyIsImltYWdlQ29uZmlnRGVmYXVsdCIsImFsbFNpemVzIiwiY29uZmlnRGV2aWNlU2l6ZXMiLCJhIiwic2l6ZXMiLCJsYXlvdXQiLCJwZXJjZW50U2l6ZXMiLCJtIiwicGFyc2VJbnQiLCJzbWFsbGVzdFJhdGlvIiwiTWF0aCIsIndpZHRocyIsInMiLCJraW5kIiwid2lkdGgiLCJ3IiwicCIsInNyY1NldCIsImdldFdpZHRocyIsImxhc3QiLCJpIiwic3JjIiwibG9hZCIsInJvb3QiLCJWQUxJRF9MT0FERVJTIiwiY29uZmlnTG9hZGVyIiwidW5vcHRpbWl6ZWQiLCJwcmlvcml0eSIsImFsbCIsInJlc3QiLCJ1bnNpemVkIiwiQm9vbGVhbiIsIkpTT04iLCJsb2FkaW5nIiwiaXNMYXp5Iiwicm9vdE1hcmdpbiIsImRpc2FibGVkIiwiaXNWaXNpYmxlIiwid2lkdGhJbnQiLCJnZXRJbnQiLCJoZWlnaHRJbnQiLCJxdWFsaXR5SW50IiwiaW1nU3R5bGUiLCJwb3NpdGlvbiIsInRvcCIsImxlZnQiLCJib3R0b20iLCJyaWdodCIsImJveFNpemluZyIsInBhZGRpbmciLCJib3JkZXIiLCJtYXJnaW4iLCJkaXNwbGF5IiwiaGVpZ2h0IiwibWluV2lkdGgiLCJtYXhXaWR0aCIsIm1pbkhlaWdodCIsIm1heEhlaWdodCIsInF1b3RpZW50IiwicGFkZGluZ1RvcCIsImlzTmFOIiwid3JhcHBlclN0eWxlIiwib3ZlcmZsb3ciLCJzaXplclN0eWxlIiwic2l6ZXJTdmciLCJpbWdBdHRyaWJ1dGVzIiwiZ2VuZXJhdGVJbWdBdHRycyIsInF1YWxpdHkiLCJwYXJhbXMiLCJwYXJhbXNTdHJpbmciLCJub3JtYWxpemVTcmMiLCJtaXNzaW5nVmFsdWVzIiwicGFyc2VkU3JjIiwiY29uc29sZSIsImNvbmZpZ0RvbWFpbnMiLCJob3N0bmFtZSIsImVuY29kZVVSSUNvbXBvbmVudCIsInJlcXVlc3RJZGxlQ2FsbGJhY2siLCJzZWxmIiwic3RhcnQiLCJEYXRlIiwic2V0VGltZW91dCIsImNiIiwiZGlkVGltZW91dCIsInRpbWVSZW1haW5pbmciLCJjYW5jZWxJZGxlQ2FsbGJhY2siLCJjbGVhclRpbWVvdXQiLCJoYXNJbnRlcnNlY3Rpb25PYnNlcnZlciIsImlzRGlzYWJsZWQiLCJ1bm9ic2VydmUiLCJzZXRSZWYiLCJlbCIsIm9ic2VydmUiLCJzZXRWaXNpYmxlIiwiaWRsZUNhbGxiYWNrIiwiY3JlYXRlT2JzZXJ2ZXIiLCJlbGVtZW50cyIsIm9ic2VydmVyIiwib2JzZXJ2ZXJzIiwiaWQiLCJvcHRpb25zIiwiaW5zdGFuY2UiLCJlbnRyaWVzIiwiZW50cnkiLCJjYWxsYmFjayIsIkhvbWVQYWdlIiwiQmFubmVyIiwidGl0bGUiLCJzdWJUaXRsZSIsImJhbm5lckltZyIsIm1vYmlsZUJhbm5lckltZyIsImJhY2tncm91bmRJbWFnZSIsIkJ1dHRvbiIsInVybCIsIm9uQ2xpY2siLCJjbGFzc05hbWUiLCJzdHlsZSIsImNoaWxkcmVuIiwiQ2FyZHMiLCJkYXRhIiwicGx1Z2lucyIsIm1hcCIsInBsdWdpbiIsImRlc2NyaXB0aW9uIiwiQ29udGFpbmVyIiwiQ29udGVudEl0ZW1XaXRoVGFncyIsImltYWdlX3VybCIsImltYWdlX2NhcHRpb24iLCJhdXRob3IiLCJkZXNpZ25hdGlvbiIsImNvbnRlbnRfaWQiLCJjb250ZW50X3R5cGUiLCJyZWFkX2R1cmF0aW9uIiwiYXV0aG9yX2ltYWdlX3VybCIsInRhZ3MiLCJtYXJnaW5Cb3R0b20iLCJiYWNrZ3JvdW5kIiwidGV4dEFsaWduIiwibGluZUhlaWdodCIsInBhZGRpbmdCb3R0b20iLCJwYWRkaW5nTGVmdCIsInBhZGRpbmdSaWdodCIsIm1hcmdpbkxlZnQiLCJtYXJnaW5Ub3AiLCJsZXR0ZXJTcGFjaW5nIiwiZm9udFNpemUiLCJnZXRDb250ZW50VHlwZUltYWdlVXJsIiwiaXRlbSIsImluZGV4IiwiY29sb3IiLCJDb250ZW50SXRlbSIsIkNvbnRlbnRTbGlkZXIiLCJjb250ZW50TGlzdCIsImhlYWRlciIsImNvbnRlbnRJdGVtIiwibG9nIiwiRm9vdGVyTWVudSIsIm1lbnUiLCJGb290ZXIiLCJGb3VuZGVyIiwiaGVyb3MiLCJmaXJzdE5hbWUiLCJsYXN0TmFtZSIsImZpcnN0TmFtZTEiLCJsYXN0TmFtZTEiLCJjYXB0aW9uIiwiY2FwdGlvbjEiLCJsb2dvIiwiaW1hZ2UiLCJoZWFkaW5nIiwic2V0dGluZ3MiLCJkb3RzIiwiaW5maW5pdGUiLCJzcGVlZCIsImF1dG9wbGF5U3BlZWQiLCJzbGlkZXNUb1Nob3ciLCJzbGlkZXNUb1Njcm9sbCIsImhlcm8iLCJmbGV4RGlyZWN0aW9uIiwiZmxleEdyb3ciLCJib3JkZXJCb3R0b20iLCJtYXJnaW5SaWdodCIsImp1c3RpZnlDb250ZW50IiwidHJhbnNmb3JtIiwiRm91bmRlckRldGFpbCIsIkhlYWRlciIsInRvZ2dsZSIsIkltYWdlIiwiYWx0IiwiTG9nbyIsIk1haW4iLCJOYXZJdGVtIiwic2VsZWN0ZWQiLCJhcnJvdyIsIlRhZyIsIl9jbGFzc05hbWUiLCJIb21lIiwiYmciLCJIb21lQ2Fyb3VzYWwiLCJiYWNrZ3JvdW5kVXJsIiwic2V0QmFja2dyb3VuZFVybCIsIlJlYWN0IiwidXNlU3RhdGUiLCJiYWNrZ3JvdW5kU2l6ZSIsImZvbnRXZWlnaHQiLCJvcGFjaXR5Iiwid3JpdGluZ01vZGUiLCJDb250ZW50VGFicyIsInNlbGVjdGVkVGFiIiwib25UYWJTZWxlY3RlZCIsInRhYkxpc3QiLCJ0YWJTdHlsZSIsIkhvbWVDb250ZW50TGlzdCIsImhvbWVDb250ZW50VGFicyIsIkhvbWVDb250ZW50Iiwic2V0U2VsZWN0ZWRUYWIiLCJIb21lRm91bmRlciIsInR5cGUiXSwibWFwcGluZ3MiOiI7O1FBQUE7UUFDQTs7UUFFQTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQSxJQUFJO1FBQ0o7UUFDQTs7UUFFQTtRQUNBOztRQUVBO1FBQ0E7UUFDQTs7O1FBR0E7UUFDQTs7UUFFQTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBLDBDQUEwQyxnQ0FBZ0M7UUFDMUU7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQSx3REFBd0Qsa0JBQWtCO1FBQzFFO1FBQ0EsaURBQWlELGNBQWM7UUFDL0Q7O1FBRUE7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBLHlDQUF5QyxpQ0FBaUM7UUFDMUUsZ0hBQWdILG1CQUFtQixFQUFFO1FBQ3JJO1FBQ0E7O1FBRUE7UUFDQTtRQUNBO1FBQ0EsMkJBQTJCLDBCQUEwQixFQUFFO1FBQ3ZELGlDQUFpQyxlQUFlO1FBQ2hEO1FBQ0E7UUFDQTs7UUFFQTtRQUNBLHNEQUFzRCwrREFBK0Q7O1FBRXJIO1FBQ0E7OztRQUdBO1FBQ0E7Ozs7Ozs7Ozs7OztBQ3hGQSw4RDs7Ozs7Ozs7Ozs7QUNBQSxvRTs7Ozs7Ozs7Ozs7QUNBQSx5RTs7Ozs7Ozs7Ozs7O0FDQUE7QUFBQSxNQUFNQSxVQUFVLEdBQUcsQ0FDakI7QUFDRUMsS0FBRyxFQUFFLGNBRFA7QUFFRUMsTUFBSSxFQUFFLE9BRlI7QUFHRUMsTUFBSSxFQUFFO0FBSFIsQ0FEaUIsRUFNakI7QUFDRUYsS0FBRyxFQUFFLGtCQURQO0FBRUVDLE1BQUksRUFBRSxXQUZSO0FBR0VDLE1BQUksRUFBRTtBQUhSLENBTmlCLEVBV2pCO0FBQ0VGLEtBQUcsRUFBRSxhQURQO0FBRUVDLE1BQUksRUFBRSxNQUZSO0FBR0VDLE1BQUksRUFBRTtBQUhSLENBWGlCLEVBZ0JqQjtBQUNFRixLQUFHLEVBQUUsc0JBRFA7QUFFRUMsTUFBSSxFQUFFLGVBRlI7QUFHRUMsTUFBSSxFQUFFO0FBSFIsQ0FoQmlCLEVBcUJqQjtBQUNFRixLQUFHLEVBQUUsZ0JBRFA7QUFFRUMsTUFBSSxFQUFFLFNBRlI7QUFHRUMsTUFBSSxFQUFFO0FBSFIsQ0FyQmlCLEVBMEJqQjtBQUNFRixLQUFHLEVBQUUsZ0JBRFA7QUFFRUMsTUFBSSxFQUFFLFNBRlI7QUFHRUMsTUFBSSxFQUFFO0FBSFIsQ0ExQmlCLENBQW5CO0FBaUNlSCx5RUFBZixFOzs7Ozs7Ozs7Ozs7QUNqQ0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUNPLE1BQU1JLGNBQWMsR0FBRywrQkFBdkIsQzs7Ozs7Ozs7Ozs7O0FDRlA7QUFBQTtBQUFPLE1BQU1DLE9BQU8sR0FBRztBQUNyQkMsU0FBTyxFQUFFLENBQ1A7QUFDRUwsT0FBRyxFQUFFLGNBRFA7QUFFRUMsUUFBSSxFQUFFLE9BRlI7QUFHRUMsUUFBSSxFQUFFO0FBSFIsR0FETyxFQU1QO0FBQ0VGLE9BQUcsRUFBRSxrQkFEUDtBQUVFQyxRQUFJLEVBQUUsV0FGUjtBQUdFQyxRQUFJLEVBQUU7QUFIUixHQU5PLEVBV1A7QUFDRUYsT0FBRyxFQUFFLGFBRFA7QUFFRUMsUUFBSSxFQUFFLE1BRlI7QUFHRUMsUUFBSSxFQUFFO0FBSFIsR0FYTyxDQURZO0FBa0JyQkksV0FBUyxFQUFFLENBQ1Q7QUFDRU4sT0FBRyxFQUFFLHNCQURQO0FBRUVDLFFBQUksRUFBRSxlQUZSO0FBR0VDLFFBQUksRUFBRTtBQUhSLEdBRFMsRUFNVDtBQUNFRixPQUFHLEVBQUUsZ0JBRFA7QUFFRUMsUUFBSSxFQUFFLFNBRlI7QUFHRUMsUUFBSSxFQUFFO0FBSFIsR0FOUyxFQVdUO0FBQ0VGLE9BQUcsRUFBRSxnQkFEUDtBQUVFQyxRQUFJLEVBQUUsU0FGUjtBQUdFQyxRQUFJLEVBQUU7QUFIUixHQVhTO0FBbEJVLENBQWhCO0FBcUNRRSxzRUFBZixFOzs7Ozs7Ozs7OztBQ3JDQTtBQUNBO0FBQ0EsbUJBQW1CLHNCQUFzQjtBQUN6Qzs7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQTtBQUNBOztBQUVBLDBCOzs7Ozs7Ozs7OztBQ2xCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLHdDOzs7Ozs7Ozs7OztBQ05BO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsYUFBYSx1QkFBdUI7QUFDcEM7QUFDQTtBQUNBO0FBQ0E7O0FBRUE7QUFDQTs7QUFFQSwrQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNmQTs7QUFDQTs7QUFDQTs7QUFDQTs7QUFNQTs7QUFFQSxVQUFtQztBQUNqQztBQUFFRyxRQUFELHNCQUFDQSxHQUFELElBQUNBO0FBR0o7O0FBQUEsTUFBTUMsb0JBQW9CLEdBQUcsa0JBQTdCLFNBQTZCLENBQTdCO0FBYUEsTUFBTUMsT0FBTyxHQUFHLFFBR2QsQ0FDQSxVQURBLFdBQ0EsQ0FEQSxFQUVBLGVBRkEsZ0JBRUEsQ0FGQSxFQUdBLFdBSEEsWUFHQSxDQUhBLEVBSUEsWUFQRixhQU9FLENBSkEsQ0FIYyxDQUFoQjtBQVVBLE1BQU1DLG1CQUFtQixHQUFHLDZDQUE1QixTQUE0QixDQUE1QjtBQXNDQSxNQUFNO0FBQ0pDLGFBQVcsRUFEUDtBQUVKQyxZQUFVLEVBRk47QUFHSkMsUUFBTSxFQUhGO0FBSUpDLE1BQUksRUFKQTtBQUtKQyxTQUFPLEVBTEg7QUFBQSxJQU9GQywwSkFBeURDLGFBUDdELG1CLENBUUE7O0FBQ0EsTUFBTUMsUUFBUSxHQUFHLENBQUMsR0FBRCxtQkFBdUIsR0FBeEMsZ0JBQWlCLENBQWpCO0FBQ0FDLGlCQUFpQixDQUFqQkEsS0FBdUIsVUFBVUMsQ0FBQyxHQUFsQ0Q7QUFDQUQsUUFBUSxDQUFSQSxLQUFjLFVBQVVFLENBQUMsR0FBekJGOztBQUVBLHlDQUl5QztBQUN2QyxNQUFJRyxLQUFLLEtBQUtDLE1BQU0sS0FBTkEsVUFBcUJBLE1BQU0sS0FBekMsWUFBUyxDQUFULEVBQTZEO0FBQzNEO0FBQ0EsVUFBTUMsWUFBWSxHQUFHLENBQUMsR0FBR0YsS0FBSyxDQUFMQSxTQUFKLG9CQUFJQSxDQUFKLE1BQStDRyxDQUFELElBQ2pFQyxRQUFRLENBQUNELENBQUMsQ0FEWixDQUNZLENBQUYsQ0FEVyxDQUFyQjs7QUFHQSxRQUFJRCxZQUFZLENBQWhCLFFBQXlCO0FBQ3ZCLFlBQU1HLGFBQWEsR0FBR0MsSUFBSSxDQUFKQSxJQUFTLEdBQVRBLGdCQUF0QjtBQUNBLGFBQU87QUFDTEMsY0FBTSxFQUFFVixRQUFRLENBQVJBLE9BQ0xXLENBQUQsSUFBT0EsQ0FBQyxJQUFJVixpQkFBaUIsQ0FBakJBLENBQWlCLENBQWpCQSxHQUZULGFBQ0dELENBREg7QUFJTFksWUFBSSxFQUpOO0FBQU8sT0FBUDtBQU9GOztBQUFBLFdBQU87QUFBRUYsWUFBTSxFQUFSO0FBQW9CRSxVQUFJLEVBQS9CO0FBQU8sS0FBUDtBQUVGOztBQUFBLE1BQ0UsNkJBQ0FSLE1BQU0sS0FETixVQUVBQSxNQUFNLEtBSFIsY0FJRTtBQUNBLFdBQU87QUFBRU0sWUFBTSxFQUFSO0FBQTZCRSxVQUFJLEVBQXhDO0FBQU8sS0FBUDtBQUdGOztBQUFBLFFBQU1GLE1BQU0sR0FBRyxDQUNiLEdBQUcsU0FDRDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsVUFBUUcsS0FBSyxHQUFHO0FBQWhCO0FBQUEsUUFDR0MsQ0FBRCxJQUFPZCxRQUFRLENBQVJBLEtBQWVlLENBQUQsSUFBT0EsQ0FBQyxJQUF0QmYsTUFBZ0NBLFFBQVEsQ0FBQ0EsUUFBUSxDQUFSQSxTQVh0RCxDQVdxRCxDQURqRCxDQVRDLENBRFUsQ0FBZjtBQWVBLFNBQU87QUFBQTtBQUFVWSxRQUFJLEVBQXJCO0FBQU8sR0FBUDtBQW1CRjs7QUFBQSwwQkFBMEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBMUI7QUFBMEIsQ0FBMUIsRUFRdUM7QUFDckMsbUJBQWlCO0FBQ2YsV0FBTztBQUFBO0FBQU9JLFlBQU0sRUFBYjtBQUEwQmIsV0FBSyxFQUF0QztBQUFPLEtBQVA7QUFHRjs7QUFBQSxRQUFNO0FBQUE7QUFBQTtBQUFBLE1BQW1CYyxTQUFTLGdCQUFsQyxLQUFrQyxDQUFsQztBQUNBLFFBQU1DLElBQUksR0FBR1IsTUFBTSxDQUFOQSxTQUFiO0FBRUEsU0FBTztBQUNMUCxTQUFLLEVBQUUsVUFBVVMsSUFBSSxLQUFkLGdCQURGO0FBRUxJLFVBQU0sRUFBRU4sTUFBTSxDQUFOQSxJQUVKLFVBQ0csR0FBRWYsTUFBTSxDQUFDO0FBQUE7QUFBQTtBQUFnQmtCLFdBQUssRUFBdEI7QUFBQyxLQUFELENBQTZCLElBQ3BDRCxJQUFJLEtBQUpBLFVBQW1CTyxDQUFDLEdBQUcsQ0FDeEIsR0FBRVAsSUFMREYsU0FGSCxJQUVHQSxDQUZIO0FBV0w7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0FVLE9BQUcsRUFBRXpCLE1BQU0sQ0FBQztBQUFBO0FBQUE7QUFBZ0JrQixXQUFLLEVBQUVILE1BQU0sQ0FqQjNDLElBaUIyQztBQUE3QixLQUFEO0FBakJOLEdBQVA7QUFxQkY7O0FBQUEsbUJBQWdEO0FBQzlDLE1BQUksYUFBSixVQUEyQjtBQUN6QjtBQUVGOztBQUFBLE1BQUksYUFBSixVQUEyQjtBQUN6QixXQUFPSCxRQUFRLElBQWYsRUFBZSxDQUFmO0FBRUY7O0FBQUE7QUFHRjs7QUFBQSx5Q0FBMkQ7QUFDekQsUUFBTWMsSUFBSSxHQUFHOUIsT0FBTyxDQUFQQSxJQUFiLFlBQWFBLENBQWI7O0FBQ0EsWUFBVTtBQUNSLFdBQU84QixJQUFJO0FBQUdDLFVBQUksRUFBUDtBQUFBLE9BQVgsV0FBVyxFQUFYO0FBRUY7O0FBQUEsUUFBTSxVQUNILHlEQUF3REMscUNBRXZELGVBQWNDLFlBSGxCLEVBQU0sQ0FBTjtBQU9hOztBQUFBLHFCQWNBO0FBQUEsTUFkZTtBQUFBO0FBQUE7QUFHNUJDLGVBQVcsR0FIaUI7QUFJNUJDLFlBQVEsR0FKb0I7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQVk1Qi9CLFVBQU0sR0Fac0I7QUFBQSxNQWNmO0FBQUEsTUFEVmdDLEdBQ1U7QUFDYixNQUFJQyxJQUF5QixHQUE3QjtBQUNBLE1BQUl4QixNQUFnQyxHQUFHRCxLQUFLLGtCQUE1QztBQUNBLE1BQUkwQixPQUFPLEdBQVg7O0FBQ0EsTUFBSSxhQUFKLE1BQXVCO0FBQ3JCQSxXQUFPLEdBQUdDLE9BQU8sQ0FBQ0YsSUFBSSxDQUF0QkMsT0FBaUIsQ0FBakJBLENBRHFCLENBRXJCOztBQUNBLFdBQU9ELElBQUksQ0FBWCxTQUFXLENBQVg7QUFIRixTQUlPLElBQUksWUFBSixNQUFzQjtBQUMzQjtBQUNBLFFBQUlBLElBQUksQ0FBUixRQUFpQnhCLE1BQU0sR0FBR3dCLElBQUksQ0FBYnhCLE9BRlUsQ0FJM0I7O0FBQ0EsV0FBT3dCLElBQUksQ0FBWCxRQUFXLENBQVg7QUFHRjs7QUFBQSxZQUEyQztBQUN6QyxRQUFJLENBQUosS0FBVTtBQUNSLFlBQU0sVUFDSCwwSEFBeUhHLElBQUksQ0FBSkEsVUFDeEg7QUFBQTtBQUFBO0FBRHdIQTtBQUN4SCxPQUR3SEEsQ0FENUgsRUFBTSxDQUFOO0FBTUY7O0FBQUEsUUFBSSxDQUFDdkMsbUJBQW1CLENBQW5CQSxTQUFMLE1BQUtBLENBQUwsRUFBMkM7QUFDekMsWUFBTSxVQUNILG1CQUFrQjRCLEdBQUksOENBQTZDaEIsTUFBTyxzQkFBcUJaLG1CQUFtQixDQUFuQkEscUJBRGxHLEdBQU0sQ0FBTjtBQU1GOztBQUFBLFFBQUksQ0FBQ0Ysb0JBQW9CLENBQXBCQSxTQUFMLE9BQUtBLENBQUwsRUFBNkM7QUFDM0MsWUFBTSxVQUNILG1CQUFrQjhCLEdBQUksK0NBQThDWSxPQUFRLHNCQUFxQjFDLG9CQUFvQixDQUFwQkEscUJBRHBHLEdBQU0sQ0FBTjtBQU1GOztBQUFBLFFBQUlvQyxRQUFRLElBQUlNLE9BQU8sS0FBdkIsUUFBb0M7QUFDbEMsWUFBTSxVQUNILG1CQUFrQlosR0FEckIsaUZBQU0sQ0FBTjtBQUlGOztBQUFBLGlCQUFhO0FBQ1gsWUFBTSxVQUNILG1CQUFrQkEsR0FEckIsaUdBQU0sQ0FBTjtBQUlIO0FBRUQ7O0FBQUEsTUFBSWEsTUFBTSxHQUNSLGNBQWNELE9BQU8sS0FBUEEsVUFBc0IsbUJBRHRDLFdBQ0UsQ0FERjs7QUFFQSxNQUFJWixHQUFHLElBQUlBLEdBQUcsQ0FBSEEsV0FBWCxPQUFXQSxDQUFYLEVBQW9DO0FBQ2xDO0FBQ0FLLGVBQVcsR0FBWEE7QUFDQVEsVUFBTSxHQUFOQTtBQUdGOztBQUFBLFFBQU0sMEJBQTBCLHNDQUFrQztBQUNoRUMsY0FBVSxFQURzRDtBQUVoRUMsWUFBUSxFQUFFLENBRlo7QUFBa0UsR0FBbEMsQ0FBaEM7QUFJQSxRQUFNQyxTQUFTLEdBQUcsV0FBbEI7QUFFQSxRQUFNQyxRQUFRLEdBQUdDLE1BQU0sQ0FBdkIsS0FBdUIsQ0FBdkI7QUFDQSxRQUFNQyxTQUFTLEdBQUdELE1BQU0sQ0FBeEIsTUFBd0IsQ0FBeEI7QUFDQSxRQUFNRSxVQUFVLEdBQUdGLE1BQU0sQ0FBekIsT0FBeUIsQ0FBekI7QUFFQTtBQUNBO0FBQ0E7QUFDQSxNQUFJRyxRQUFxQyxHQUFHO0FBQzFDQyxZQUFRLEVBRGtDO0FBRTFDQyxPQUFHLEVBRnVDO0FBRzFDQyxRQUFJLEVBSHNDO0FBSTFDQyxVQUFNLEVBSm9DO0FBSzFDQyxTQUFLLEVBTHFDO0FBTzFDQyxhQUFTLEVBUGlDO0FBUTFDQyxXQUFPLEVBUm1DO0FBUzFDQyxVQUFNLEVBVG9DO0FBVTFDQyxVQUFNLEVBVm9DO0FBWTFDQyxXQUFPLEVBWm1DO0FBYTFDdEMsU0FBSyxFQWJxQztBQWMxQ3VDLFVBQU0sRUFkb0M7QUFlMUNDLFlBQVEsRUFma0M7QUFnQjFDQyxZQUFRLEVBaEJrQztBQWlCMUNDLGFBQVMsRUFqQmlDO0FBa0IxQ0MsYUFBUyxFQWxCaUM7QUFBQTtBQUE1QztBQUE0QyxHQUE1Qzs7QUF1QkEsTUFDRSxtQ0FDQSxxQkFEQSxlQUVBcEQsTUFBTSxLQUhSLFFBSUU7QUFDQTtBQUNBLFVBQU1xRCxRQUFRLEdBQUdsQixTQUFTLEdBQTFCO0FBQ0EsVUFBTW1CLFVBQVUsR0FBR0MsS0FBSyxDQUFMQSxRQUFLLENBQUxBLFlBQTRCLEdBQUVGLFFBQVEsR0FBRyxHQUE1RDs7QUFDQSxRQUFJckQsTUFBTSxLQUFWLGNBQTZCO0FBQzNCO0FBQ0F3RCxrQkFBWSxHQUFHO0FBQ2JULGVBQU8sRUFETTtBQUViVSxnQkFBUSxFQUZLO0FBR2JuQixnQkFBUSxFQUhLO0FBS2JLLGlCQUFTLEVBTEk7QUFNYkcsY0FBTSxFQU5SVTtBQUFlLE9BQWZBO0FBUUFFLGdCQUFVLEdBQUc7QUFBRVgsZUFBTyxFQUFUO0FBQW9CSixpQkFBUyxFQUE3QjtBQUFiZTtBQUFhLE9BQWJBO0FBVkYsV0FXTyxJQUFJMUQsTUFBTSxLQUFWLGFBQTRCO0FBQ2pDO0FBQ0F3RCxrQkFBWSxHQUFHO0FBQ2JULGVBQU8sRUFETTtBQUViRyxnQkFBUSxFQUZLO0FBR2JPLGdCQUFRLEVBSEs7QUFJYm5CLGdCQUFRLEVBSks7QUFLYkssaUJBQVMsRUFMSTtBQU1iRyxjQUFNLEVBTlJVO0FBQWUsT0FBZkE7QUFRQUUsZ0JBQVUsR0FBRztBQUNYZixpQkFBUyxFQURFO0FBRVhJLGVBQU8sRUFGSTtBQUdYRyxnQkFBUSxFQUhWUTtBQUFhLE9BQWJBO0FBS0FDLGNBQVEsR0FBSSxlQUFjMUIsUUFBUyxhQUFZRSxTQUEvQ3dCO0FBZkssV0FnQkEsSUFBSTNELE1BQU0sS0FBVixTQUF3QjtBQUM3QjtBQUNBd0Qsa0JBQVksR0FBRztBQUNiQyxnQkFBUSxFQURLO0FBRWJkLGlCQUFTLEVBRkk7QUFHYkksZUFBTyxFQUhNO0FBSWJULGdCQUFRLEVBSks7QUFLYjdCLGFBQUssRUFMUTtBQU1idUMsY0FBTSxFQU5SUTtBQUFlLE9BQWZBO0FBU0g7QUE5Q0QsU0E4Q08sSUFDTCxtQ0FDQSxxQkFEQSxlQUVBeEQsTUFBTSxLQUhELFFBSUw7QUFDQTtBQUNBd0QsZ0JBQVksR0FBRztBQUNiVCxhQUFPLEVBRE07QUFFYlUsY0FBUSxFQUZLO0FBSWJuQixjQUFRLEVBSks7QUFLYkMsU0FBRyxFQUxVO0FBTWJDLFVBQUksRUFOUztBQU9iQyxZQUFNLEVBUE87QUFRYkMsV0FBSyxFQVJRO0FBVWJDLGVBQVMsRUFWSTtBQVdiRyxZQUFNLEVBWFJVO0FBQWUsS0FBZkE7QUFOSyxTQW1CQTtBQUNMO0FBQ0EsY0FBMkM7QUFDekMsWUFBTSxVQUNILG1CQUFrQnhDLEdBRHJCLHlFQUFNLENBQU47QUFJSDtBQUVEOztBQUFBLE1BQUk0QyxhQUFnQyxHQUFHO0FBQ3JDNUMsT0FBRyxFQURrQztBQUdyQ0osVUFBTSxFQUgrQjtBQUlyQ2IsU0FBSyxFQUpQO0FBQXVDLEdBQXZDOztBQU9BLGlCQUFlO0FBQ2I2RCxpQkFBYSxHQUFHQyxnQkFBZ0IsQ0FBQztBQUFBO0FBQUE7QUFBQTtBQUkvQnBELFdBQUssRUFKMEI7QUFLL0JxRCxhQUFPLEVBTHdCO0FBQUE7QUFBakNGO0FBQWlDLEtBQUQsQ0FBaENBO0FBV0Y7O0FBQUEsZUFBYTtBQUNYSixnQkFBWSxHQUFaQTtBQUNBRSxjQUFVLEdBQVZBO0FBQ0FyQixZQUFRLEdBQVJBO0FBRUY7O0FBQUEsc0JBQ0U7QUFBSyxTQUFLLEVBQVY7QUFBQSxLQUNHcUIsVUFBVSxnQkFDVDtBQUFLLFNBQUssRUFBVjtBQUFBLEtBQ0dDLFFBQVEsZ0JBQ1A7QUFDRSxTQUFLLEVBQUU7QUFDTFQsY0FBUSxFQURIO0FBRUxILGFBQU8sRUFGRjtBQUdMRCxZQUFNLEVBSEQ7QUFJTEQsWUFBTSxFQUpEO0FBS0xELGFBQU8sRUFOWDtBQUNTLEtBRFQ7QUFRRSxPQUFHLEVBUkw7QUFTRSxtQkFURjtBQVVFLFFBQUksRUFWTjtBQVdFLE9BQUcsRUFBRyw2QkFBNEIsK0JBWjdCO0FBQ1AsSUFETyxHQUZGLElBQ1QsQ0FEUyxHQURiLE1Bb0JHLDJCQUNDLDREQUNFLDREQUVNaUIsZ0JBQWdCLENBQUM7QUFBQTtBQUFBO0FBQUE7QUFJbkJwRCxTQUFLLEVBSmM7QUFLbkJxRCxXQUFPLEVBTFk7QUFBQTtBQUZ2QjtBQUV1QixHQUFELENBRnRCO0FBV0UsT0FBRyxFQVhMO0FBWUUsWUFBUSxFQVpWO0FBYUUsU0FBSyxFQWJQO0FBY0UsU0FBSyxFQWRQO0FBZUUsYUFBUyxFQXJDakI7QUFzQk0sS0FERixDQXJCSixlQXlDRTtBQUdFLFlBQVEsRUFIVjtBQUlFLGFBQVMsRUFKWDtBQUtFLE9BQUcsRUFMTDtBQU1FLFNBQUssRUEvQ1Q7QUF5Q0UsS0F6Q0YsRUFpREd4QyxRQUFRO0FBQUE7QUFDUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0EsK0JBQUMsTUFBRCw0QkFDRTtBQUNFLE9BQUcsRUFDRCxZQUNBc0MsYUFBYSxDQURiLE1BRUFBLGFBQWEsQ0FGYixTQUdBQSxhQUFhLENBTGpCO0FBT0UsT0FBRyxFQVBMO0FBUUUsTUFBRSxFQVJKO0FBU0UsUUFBSSxFQUFFQSxhQUFhLENBQWJBLHFCQUFtQ0EsYUFBYSxDQUFDNUMsR0FUekQsQ0FVRTtBQVZGO0FBV0UsZUFBVyxFQUFFNEMsYUFBYSxDQUFDaEQsTUFYN0IsQ0FZRTtBQVpGO0FBYUUsY0FBVSxFQUFFZ0QsYUFBYSxDQXBCdEI7QUFPTCxJQURGLENBTk8sR0FsRGIsSUFDRSxDQURGO0FBOEVGLEMsQ0FBQTs7O0FBRUEsMkJBQTJDO0FBQ3pDLFNBQU81QyxHQUFHLENBQUhBLENBQUcsQ0FBSEEsV0FBaUJBLEdBQUcsQ0FBSEEsTUFBakJBLENBQWlCQSxDQUFqQkEsR0FBUDtBQUdGOztBQUFBLHFCQUFxQjtBQUFBO0FBQUE7QUFBQTtBQUFyQjtBQUFxQixDQUFyQixFQUtvQztBQUNsQztBQUNBLFFBQU0rQyxNQUFNLEdBQUcsMkJBQTJCLE9BQTFDLEtBQWUsQ0FBZjtBQUNBLE1BQUlDLFlBQVksR0FBaEI7O0FBQ0EsZUFBYTtBQUNYRCxVQUFNLENBQU5BLEtBQVksT0FBWkE7QUFHRjs7QUFBQSxNQUFJQSxNQUFNLENBQVYsUUFBbUI7QUFDakJDLGdCQUFZLEdBQUcsTUFBTUQsTUFBTSxDQUFOQSxLQUFyQkMsR0FBcUJELENBQXJCQztBQUVGOztBQUFBLFNBQVEsR0FBRTlDLElBQUssR0FBRStDLFlBQVksS0FBTSxHQUFFRCxZQUFyQztBQUdGOztBQUFBLHNCQUFzQjtBQUFBO0FBQUE7QUFBdEI7QUFBc0IsQ0FBdEIsRUFBNkU7QUFDM0UsU0FBUSxHQUFFOUMsSUFBSyxHQUFFK0MsWUFBWSxLQUFNLFlBQVd4RCxLQUE5QztBQUdGOztBQUFBLDBCQUEwQjtBQUFBO0FBQUE7QUFBQTtBQUExQjtBQUEwQixDQUExQixFQUtvQztBQUNsQztBQUNBLFFBQU1zRCxNQUFNLEdBQUcsc0JBQXNCLE9BQXRCLE9BQW9DLFFBQVFELE9BQU8sSUFBbEUsTUFBbUQsQ0FBcEMsQ0FBZjtBQUNBLE1BQUlFLFlBQVksR0FBR0QsTUFBTSxDQUFOQSxZQUFuQjtBQUNBLFNBQVEsR0FBRTdDLElBQUssR0FBRThDLFlBQWEsR0FBRUMsWUFBWSxLQUE1QztBQUdGOztBQUFBLHVCQUF1QjtBQUFBO0FBQUE7QUFBQTtBQUF2QjtBQUF1QixDQUF2QixFQUtvQztBQUNsQyxZQUEyQztBQUN6QyxVQUFNQyxhQUFhLEdBQW5CLEdBRHlDLENBR3pDOztBQUNBLFFBQUksQ0FBSixLQUFVQSxhQUFhLENBQWJBO0FBQ1YsUUFBSSxDQUFKLE9BQVlBLGFBQWEsQ0FBYkE7O0FBRVosUUFBSUEsYUFBYSxDQUFiQSxTQUFKLEdBQThCO0FBQzVCLFlBQU0sVUFDSCxvQ0FBbUNBLGFBQWEsQ0FBYkEsVUFFbEMsZ0dBQStGdkMsSUFBSSxDQUFKQSxVQUMvRjtBQUFBO0FBQUE7QUFEK0ZBO0FBQy9GLE9BRCtGQSxDQUhuRyxFQUFNLENBQU47QUFTRjs7QUFBQSxRQUFJWCxHQUFHLENBQUhBLFdBQUosSUFBSUEsQ0FBSixFQUEwQjtBQUN4QixZQUFNLFVBQ0gsd0JBQXVCQSxHQUQxQiwwR0FBTSxDQUFOO0FBS0Y7O0FBQUEsUUFBSSxDQUFDQSxHQUFHLENBQUhBLFdBQUQsR0FBQ0EsQ0FBRCxJQUFKLGVBQTJDO0FBQ3pDOztBQUNBLFVBQUk7QUFDRm1ELGlCQUFTLEdBQUcsUUFBWkEsR0FBWSxDQUFaQTtBQUNBLE9BRkYsQ0FFRSxZQUFZO0FBQ1pDLGVBQU8sQ0FBUEE7QUFDQSxjQUFNLFVBQ0gsd0JBQXVCcEQsR0FEMUIsaUlBQU0sQ0FBTjtBQUtGOztBQUFBLFVBQUksQ0FBQ3FELGFBQWEsQ0FBYkEsU0FBdUJGLFNBQVMsQ0FBckMsUUFBS0UsQ0FBTCxFQUFpRDtBQUMvQyxjQUFNLFVBQ0gscUJBQW9CckQsR0FBSSxrQ0FBaUNtRCxTQUFTLENBQUNHLFFBQXBFLCtEQUFDLEdBREgsOEVBQU0sQ0FBTjtBQUtIO0FBQ0Y7QUFFRDs7QUFBQSxTQUFRLEdBQUVwRCxJQUFLLFFBQU9xRCxrQkFBa0IsS0FBTSxNQUFLOUQsS0FBTSxNQUFLcUQsT0FBTyxJQUFJLEVBQXpFO0FBQ0QsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN2akJNLE1BQU1VLG1CQUFtQixHQUM3QiwrQkFBK0JDLElBQUksQ0FBcEMsbUJBQUMsSUFDRCxjQUVrQjtBQUNoQixNQUFJQyxLQUFLLEdBQUdDLElBQUksQ0FBaEIsR0FBWUEsRUFBWjtBQUNBLFNBQU9DLFVBQVUsQ0FBQyxZQUFZO0FBQzVCQyxNQUFFLENBQUM7QUFDREMsZ0JBQVUsRUFEVDtBQUVEQyxtQkFBYSxFQUFFLFlBQVk7QUFDekIsZUFBTzFFLElBQUksQ0FBSkEsT0FBWSxNQUFNc0UsSUFBSSxDQUFKQSxRQUF6QixLQUFtQixDQUFadEUsQ0FBUDtBQUhKd0U7QUFBRyxLQUFELENBQUZBO0FBRGUsS0FBakIsQ0FBaUIsQ0FBakI7QUFORzs7OztBQWdCQSxNQUFNRyxrQkFBa0IsR0FDNUIsK0JBQStCUCxJQUFJLENBQXBDLGtCQUFDLElBQ0QsY0FBeUM7QUFDdkMsU0FBT1EsWUFBWSxDQUFuQixFQUFtQixDQUFuQjtBQUhHOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDbkNQOztBQUNBOztBQWNBLE1BQU1DLHVCQUF1QixHQUFHLGdDQUFoQzs7QUFFTyx5QkFBNEM7QUFBQTtBQUE1QztBQUE0QyxDQUE1QyxFQUdxRDtBQUMxRCxRQUFNQyxVQUFtQixHQUFHcEQsUUFBUSxJQUFJLENBQXhDO0FBRUEsUUFBTXFELFNBQVMsR0FBRyxXQUFsQixNQUFrQixHQUFsQjtBQUNBLFFBQU0sd0JBQXdCLHFCQUE5QixLQUE4QixDQUE5QjtBQUVBLFFBQU1DLE1BQU0sR0FBRyx3QkFDWkMsRUFBRCxJQUFrQjtBQUNoQixRQUFJRixTQUFTLENBQWIsU0FBdUI7QUFDckJBLGVBQVMsQ0FBVEE7QUFDQUEsZUFBUyxDQUFUQTtBQUdGOztBQUFBLFFBQUlELFVBQVUsSUFBZCxTQUEyQjs7QUFFM0IsUUFBSUcsRUFBRSxJQUFJQSxFQUFFLENBQVosU0FBc0I7QUFDcEJGLGVBQVMsQ0FBVEEsVUFBb0JHLE9BQU8sS0FFeEJ2RCxTQUFELElBQWVBLFNBQVMsSUFBSXdELFVBQVUsQ0FGYixTQUVhLENBRmIsRUFHekI7QUFIRko7QUFHRSxPQUh5QixDQUEzQkE7QUFNSDtBQWhCWSxLQWlCYix5QkFqQkYsT0FpQkUsQ0FqQmEsQ0FBZjtBQW9CQSx3QkFBVSxNQUFNO0FBQ2QsUUFBSSxDQUFKLHlCQUE4QjtBQUM1QixVQUFJLENBQUosU0FBYztBQUNaLGNBQU1LLFlBQVksR0FBRyw4Q0FBb0IsTUFBTUQsVUFBVSxDQUF6RCxJQUF5RCxDQUFwQyxDQUFyQjtBQUNBLGVBQU8sTUFBTSw2Q0FBYixZQUFhLENBQWI7QUFFSDtBQUNGO0FBUEQsS0FPRyxDQVBILE9BT0csQ0FQSDtBQVNBLFNBQU8sU0FBUCxPQUFPLENBQVA7QUFHRjs7QUFBQSw2Q0FJYztBQUNaLFFBQU07QUFBQTtBQUFBO0FBQUE7QUFBQSxNQUE2QkUsY0FBYyxDQUFqRCxPQUFpRCxDQUFqRDtBQUNBQyxVQUFRLENBQVJBO0FBRUFDLFVBQVEsQ0FBUkE7QUFDQSxTQUFPLHFCQUEyQjtBQUNoQ0QsWUFBUSxDQUFSQTtBQUNBQyxZQUFRLENBQVJBLG1CQUZnQyxDQUloQzs7QUFDQSxRQUFJRCxRQUFRLENBQVJBLFNBQUosR0FBeUI7QUFDdkJDLGNBQVEsQ0FBUkE7QUFDQUMsZUFBUyxDQUFUQTtBQUVIO0FBVEQ7QUFZRjs7QUFBQSxNQUFNQSxTQUFTLEdBQUcsSUFBbEIsR0FBa0IsRUFBbEI7O0FBQ0EsaUNBQXdFO0FBQ3RFLFFBQU1DLEVBQUUsR0FBR0MsT0FBTyxDQUFQQSxjQUFYO0FBQ0EsTUFBSUMsUUFBUSxHQUFHSCxTQUFTLENBQVRBLElBQWYsRUFBZUEsQ0FBZjs7QUFDQSxnQkFBYztBQUNaO0FBR0Y7O0FBQUEsUUFBTUYsUUFBUSxHQUFHLElBQWpCLEdBQWlCLEVBQWpCO0FBQ0EsUUFBTUMsUUFBUSxHQUFHLHlCQUEwQkssT0FBRCxJQUFhO0FBQ3JEQSxXQUFPLENBQVBBLFFBQWlCQyxLQUFELElBQVc7QUFDekIsWUFBTUMsUUFBUSxHQUFHUixRQUFRLENBQVJBLElBQWFPLEtBQUssQ0FBbkMsTUFBaUJQLENBQWpCO0FBQ0EsWUFBTTNELFNBQVMsR0FBR2tFLEtBQUssQ0FBTEEsa0JBQXdCQSxLQUFLLENBQUxBLG9CQUExQzs7QUFDQSxVQUFJQyxRQUFRLElBQVosV0FBMkI7QUFDekJBLGdCQUFRLENBQVJBLFNBQVEsQ0FBUkE7QUFFSDtBQU5ERjtBQURlLEtBQWpCLE9BQWlCLENBQWpCO0FBVUFKLFdBQVMsQ0FBVEEsUUFFR0csUUFBUSxHQUFHO0FBQUE7QUFBQTtBQUZkSDtBQUVjLEdBRmRBO0FBUUE7QUFDRCxDOzs7Ozs7Ozs7OztBQzNHRCxpQkFBaUIsbUJBQU8sQ0FBQyxxRUFBcUI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNBOUM7QUFDQTs7QUFFQSxTQUFTTyxRQUFULEdBQW9CO0FBQ2xCLHNCQUFPLHFFQUFDLHlEQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsVUFBUDtBQUNEOztBQUVjQSx1RUFBZixFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ1BBO0FBU08sTUFBTUMsTUFBdUIsR0FBRyxDQUFDO0FBQUVDLE9BQUY7QUFBU0MsVUFBVDtBQUFtQkMsV0FBbkI7QUFBOEJDO0FBQTlCLENBQUQsS0FBcUQ7QUFFMUYsc0JBQ0U7QUFBQSw0QkFDRTtBQUFLLGVBQVMsRUFBQyxtREFBZjtBQUFtRSxXQUFLLEVBQUU7QUFBRUMsdUJBQWUsRUFBRyxPQUFNRixTQUFVO0FBQXBDLE9BQTFFO0FBQUEsNkJBQ0U7QUFBSyxpQkFBUyxFQUFDLDBFQUFmO0FBQUEsK0JBQ0U7QUFBSyxtQkFBUyxFQUFDLGFBQWY7QUFBQSxrQ0FDRTtBQUFJLHFCQUFTLEVBQUMscUVBQWQ7QUFBQSxzQkFBcUZGO0FBQXJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBREYsZUFFRTtBQUFHLHFCQUFTLEVBQUMsZ0NBQWI7QUFBQSxzQkFBK0NDO0FBQS9DO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRkYsZUFHRTtBQUFLLHFCQUFTLEVBQUM7QUFBZjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURGLGVBcUJFO0FBQUssZUFBUyxFQUFDLHlEQUFmO0FBQXlFLFdBQUssRUFBRTtBQUFFRyx1QkFBZSxFQUFHLCtEQUE4REQsZUFBZ0I7QUFBbEcsT0FBaEY7QUFBQSw2QkFDRTtBQUFLLGlCQUFTLEVBQUMsMEVBQWY7QUFBQSwrQkFDRTtBQUFLLG1CQUFTLEVBQUMsS0FBZjtBQUFBLGtDQUNFO0FBQUkscUJBQVMsRUFBQyw0REFBZDtBQUFBLHNCQUE0RUg7QUFBNUU7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFERixlQUVFO0FBQUcscUJBQVMsRUFBQyxpQ0FBYjtBQUFBLHNCQUFnREM7QUFBaEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFGRixlQUdFO0FBQUsscUJBQVMsRUFBQztBQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBckJGO0FBQUEsa0JBREY7QUFrQ0QsQ0FwQ00sQzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ1RQOztBQVVBLE1BQU1JLE1BQXVCLEdBQUcsQ0FBQztBQUMvQkwsT0FEK0I7QUFFL0JNLEtBRitCO0FBRy9CQyxTQUgrQjtBQUkvQkMsV0FBUyxHQUFHLEVBSm1CO0FBSy9CQyxPQUFLLEdBQUc7QUFMdUIsQ0FBRCxLQU0xQjtBQUNKLHNCQUNFO0FBQ0UsV0FBTyxFQUFFRixPQURYO0FBRUUsU0FBSyxFQUFFRSxLQUZUO0FBR0UsYUFBUyxFQUFHLHFDQUFvQ0QsU0FBVSxFQUg1RDtBQUFBLGVBS0csR0FMSCxFQU1HUixLQU5ILG9CQU1VO0FBQUssZUFBUyxFQUFDLE1BQWY7QUFBc0IsU0FBRyxFQUFFTTtBQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU5WO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBVUQsQ0FqQkQ7O0FBbUJlRCxxRUFBZixFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDN0JBO0FBT08sTUFBTUEsTUFBeUIsR0FBRyxVQUluQztBQUFBLE1BSm9DO0FBQ3hDRyxhQUFTLEdBQUcsRUFENEI7QUFFeENFO0FBRndDLEdBSXBDO0FBQUEsTUFERHhGLElBQ0M7O0FBQ0osc0JBQ0U7QUFDRSxhQUFTLEVBQUcscUlBQW9Jc0YsU0FBVTtBQUQ1SixLQUVNdEYsSUFGTjtBQUFBLGNBSUd3RjtBQUpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQVFELENBYk0sQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ1BQO0FBRUE7QUFFTyxNQUFNQyxLQUFlLEdBQUcsTUFBTTtBQUFBOztBQUNuQyxzQkFDRTtBQUFLLGFBQVMsRUFBQyxtREFBZjtBQUFBLDJCQUNFO0FBQUssZUFBUyxFQUFDLHNEQUFmO0FBQUEsZ0JBQ0csa0JBQUNDLDhDQUFELGFBQUNBLDhDQUFELHVCQUFDQSw4Q0FBSSxDQUFFQyxPQUFQLHlEQUFrQixFQUFsQixFQUFzQkMsR0FBdEIsQ0FBMkJDLE1BQUQsaUJBQ3pCO0FBRUUsaUJBQVMsRUFBQyxrREFGWjtBQUFBLGdDQUlFO0FBQUksbUJBQVMsRUFBQyw0QkFBZDtBQUFBLG9CQUE0Q0EsTUFBTSxDQUFDMUk7QUFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFKRixlQUtFO0FBQUcsbUJBQVMsRUFBQyxLQUFiO0FBQUEsb0JBQW9CMEksTUFBTSxDQUFDQztBQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUxGO0FBQUEsU0FDT0QsTUFBTSxDQUFDMUksSUFEZDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUREO0FBREg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQWVELENBaEJNLEM7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0pBLE1BQU00SSxTQUFTLEdBQUcsQ0FBQztBQUFFUDtBQUFGLENBQUQsS0FBa0I7QUFDekMsc0JBQU87QUFBSyxhQUFTLEVBQUMsNEJBQWY7QUFBQSxjQUE2Q0E7QUFBN0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFQO0FBQ0QsQ0FGTSxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDQVA7QUFDQTtBQUVBOztBQWtCQSxNQUFNUSxtQkFBb0MsR0FBRyxDQUFDO0FBQzVDQyxXQUQ0QztBQUU1Q0MsZUFGNEM7QUFHNUNwQixPQUg0QztBQUk1Q3FCLFFBSjRDO0FBSzVDQyxhQUw0QztBQU01Q2YsU0FONEM7QUFPNUNnQixZQVA0QztBQVE1Q0MsY0FSNEM7QUFTNUNDLGVBVDRDO0FBVTVDQyxrQkFWNEM7QUFXNUNDLE1BWDRDO0FBWTVDbkIsV0FBUyxHQUFHLEVBWmdDO0FBYTVDQyxPQUFLLEdBQUc7QUFBRW1CLGdCQUFZLEVBQUU7QUFBaEI7QUFib0MsQ0FBRCxLQWN2QztBQUNKLHNCQUNFO0FBQ0UsYUFBUyxFQUFHLEdBQUVwQixTQUFVLFdBRDFCO0FBRUUsU0FBSztBQUFJOUQsWUFBTSxFQUFFLEdBQVo7QUFBaUJ2QyxXQUFLLEVBQUU7QUFBeEIsT0FBaUNzRyxLQUFqQyxDQUZQO0FBQUEsNEJBSUU7QUFDRSxlQUFTLEVBQUMsVUFEWjtBQUVFLFdBQUssRUFBRTtBQUFFeEUsV0FBRyxFQUFFLENBQVA7QUFBVUMsWUFBSSxFQUFFLENBQWhCO0FBQW1CUSxjQUFNLEVBQUUsR0FBM0I7QUFBZ0N2QyxhQUFLLEVBQUU7QUFBdkMsT0FGVDtBQUFBLDhCQUlFO0FBQ0UsaUJBQVMsRUFBQyxVQURaO0FBRUUsYUFBSyxFQUFFO0FBQUVBLGVBQUssRUFBRSxHQUFUO0FBQWN1QyxnQkFBTSxFQUFFLEdBQXRCO0FBQTJCbUYsb0JBQVUsRUFBRSxTQUF2QztBQUFrRDFGLGdCQUFNLEVBQUU7QUFBMUQ7QUFGVDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUpGLGVBUUUscUVBQUMsaURBQUQ7QUFDRSxXQUFHLEVBQUVnRixTQURQO0FBRUUsV0FBRyxFQUFDLEVBRk47QUFHRSxpQkFBUyxFQUFDLFVBSFo7QUFJRSxhQUFLLEVBQUU7QUFDTHpFLGdCQUFNLEVBQUUsR0FESDtBQUVMdkMsZUFBSyxFQUFFLEdBRkY7QUFHTDBILG9CQUFVLEVBQUUsS0FIUDtBQUlMM0YsY0FBSSxFQUFFLENBSkQ7QUFLTEMsZ0JBQU0sRUFBRTtBQUxIO0FBSlQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFSRixlQW9CRTtBQUNFLGlCQUFTLEVBQUMsNEJBRFo7QUFFRSxhQUFLLEVBQUU7QUFDTDBGLG9CQUFVLEVBQUUsU0FEUDtBQUVMbkYsZ0JBQU0sRUFBRSxFQUZIO0FBR0xSLGNBQUksRUFBRSxDQUhEO0FBSUxDLGdCQUFNLEVBQUUsQ0FKSDtBQUtMMkYsbUJBQVMsRUFBRTtBQUxOLFNBRlQ7QUFBQSwrQkFVRTtBQUNFLG1CQUFTLEVBQUMsc0RBRFo7QUFFRSxlQUFLLEVBQUU7QUFDTEMsc0JBQVUsRUFBRSxNQURQO0FBRUwvRSxzQkFBVSxFQUFFLENBRlA7QUFHTGdGLHlCQUFhLEVBQUUsQ0FIVjtBQUlMQyx1QkFBVyxFQUFFLEVBSlI7QUFLTEMsd0JBQVksRUFBRTtBQUxULFdBRlQ7QUFBQSxvQkFVR2Q7QUFWSDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBVkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUpGLGVBZ0RFO0FBQ0UsZUFBUyxFQUFDLDZCQURaO0FBRUUsV0FBSyxFQUFFO0FBQUVqSCxhQUFLLEVBQUUsR0FBVDtBQUFjZ0MsY0FBTSxFQUFFLENBQUMsRUFBdkI7QUFBMkJDLGFBQUssRUFBRTtBQUFsQyxPQUZUO0FBQUEsNkJBSUU7QUFBSyxhQUFLLEVBQUU7QUFBRStGLG9CQUFVLEVBQUUsRUFBZDtBQUFrQkMsbUJBQVMsRUFBRSxFQUE3QjtBQUFpQ1Isc0JBQVksRUFBRTtBQUEvQyxTQUFaO0FBQUEsZ0NBQ0U7QUFDRSxtQkFBUyxFQUFDLDJDQURaO0FBRUUsZUFBSyxFQUFFO0FBQUVHLHNCQUFVLEVBQUUsTUFBZDtBQUFzQk0seUJBQWEsRUFBRTtBQUFyQyxXQUZUO0FBQUEscUJBSUdaLGFBSkgsV0FJdUIsR0FKdkI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQURGLGVBT0U7QUFDRSxtQkFBUyxFQUFDLHdCQURaO0FBRUUsZUFBSyxFQUFFO0FBQUVhLG9CQUFRLEVBQUUsTUFBWjtBQUFvQlAsc0JBQVUsRUFBRTtBQUFoQyxXQUZUO0FBQUEsb0JBSUcvQjtBQUpIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBUEYsZUFhRTtBQUFLLG1CQUFTLEVBQUMsNkJBQWY7QUFBQSxrQ0FDRSxxRUFBQyxpREFBRDtBQUNFLGVBQUcsRUFBRXVDLDZFQUFzQixDQUFDZixZQUFELENBRDdCO0FBRUUsa0JBQU0sRUFBRSxFQUZWO0FBR0UsaUJBQUssRUFBRSxFQUhUO0FBSUUsZUFBRyxFQUFDO0FBSk47QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFERixlQU9FO0FBQUsscUJBQVMsRUFBQyxPQUFmO0FBQXVCLGlCQUFLLEVBQUU7QUFBRVcsd0JBQVUsRUFBRTtBQUFkLGFBQTlCO0FBQUEsb0NBQ0UscUVBQUMsaURBQUQ7QUFBTyxpQkFBRyxFQUFFVCxnQkFBWjtBQUE4QixpQkFBRyxFQUFDO0FBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBREYsZUFFRTtBQUFLLG1CQUFLLEVBQUU7QUFBRVMsMEJBQVUsRUFBRTtBQUFkLGVBQVo7QUFBQSxzQ0FDRTtBQUFLLHlCQUFTLEVBQUMsaURBQWY7QUFBQSwwQkFDR2Q7QUFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQURGLGVBSUU7QUFDRSx5QkFBUyxFQUFDLDRCQURaO0FBRUUscUJBQUssRUFBRTtBQUFFVSw0QkFBVSxFQUFFO0FBQWQsaUJBRlQ7QUFBQSwwQkFJR1Q7QUFKSDtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQWJGLGVBbUNFO0FBQUssbUJBQVMsRUFBQyx5QkFBZjtBQUF5QyxlQUFLLEVBQUU7QUFBRWMscUJBQVMsRUFBRTtBQUFiLFdBQWhEO0FBQUEsb0JBQ0dULElBQUksQ0FBQ2IsR0FBTCxDQUFTLENBQUMwQixJQUFELEVBQU9DLEtBQVAsS0FBaUI7QUFDekIsZ0NBQ0UscUVBQUMsK0NBQUQ7QUFFRSxtQkFBSyxFQUFDLFlBRlI7QUFHRSxnQkFBRSxFQUFDLFlBSEw7QUFJRSxzQkFBUSxFQUFFLEtBSlo7QUFLRSx1QkFBUyxFQUFDLDRDQUxaO0FBTUUsbUJBQUssRUFBRTtBQUNMViwwQkFBVSxFQUFFLE1BRFA7QUFFTE8sd0JBQVEsRUFBRSxNQUZMO0FBR0xELDZCQUFhLEVBQUUsT0FIVjtBQUlMM0Ysc0JBQU0sRUFBRSxFQUpIO0FBS0xnRyxxQkFBSyxFQUFFLHFCQUxGO0FBTUxuRyxzQkFBTSxFQUFFLENBTkg7QUFPTHNGLDBCQUFVLEVBQUUscUJBUFA7QUFRTEQsNEJBQVksRUFBRTtBQVJUO0FBTlQsZUFDT2EsS0FEUDtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQURGO0FBbUJELFdBcEJBO0FBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFuQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFoREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUFtSEQsQ0FsSUQ7O0FBb0lldkIsa0ZBQWYsRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN6SkE7QUFDQTtBQUNBO0FBQ0E7QUFjTyxNQUFNeUIsV0FBNEIsR0FBRyxDQUFDO0FBQzNDeEIsV0FEMkM7QUFFM0NYLFdBQVMsR0FBRyxFQUYrQjtBQUczQ1IsT0FIMkM7QUFJM0NxQixRQUoyQztBQUszQ2QsU0FMMkM7QUFNM0NnQixZQU4yQztBQU8zQ0MsY0FQMkM7QUFRM0NDLGVBUjJDO0FBUzNDaEIsT0FBSyxHQUFHO0FBVG1DLENBQUQsS0FVdEM7QUFDSixzQkFDRTtBQUNFLGFBQVMsRUFBRyxHQUFFRCxTQUFVLHNCQUQxQjtBQUVFLFNBQUssRUFBRUMsS0FGVDtBQUFBLDRCQUlFLHFFQUFDLGlEQUFEO0FBQU8sU0FBRyxFQUFFVSxTQUFaO0FBQXVCLFNBQUcsRUFBQyxlQUEzQjtBQUEyQyxlQUFTLEVBQUM7QUFBckQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFKRixlQUtFO0FBQ0UsZUFBUyxFQUFDLHlEQURaO0FBRUUsV0FBSyxFQUFFO0FBQUVsRixXQUFHLEVBQUUsUUFBUDtBQUFpQkMsWUFBSSxFQUFFO0FBQXZCLE9BRlQ7QUFBQSw4QkFJRTtBQUFJLGlCQUFTLEVBQUMsNERBQWQ7QUFBQSxrQkFDRzhEO0FBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFKRixlQU9FO0FBQUssaUJBQVMsRUFBQyx5Q0FBZjtBQUFBLGdDQUNFO0FBQU0sbUJBQVMsRUFBQyw2REFBaEI7QUFBQSw0QkFDTSxNQUFNcUIsTUFEWjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREYsZUFJRTtBQUFNLG1CQUFTLEVBQUMsa0VBQWhCO0FBQUEsb0JBQ0dJLGFBQWEsR0FBRztBQURuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFQRixlQWVFO0FBQUssaUJBQVMsRUFBQywyQkFBZjtBQUFBLGdDQUVFLHFFQUFDLGlGQUFEO0FBQ0UsZUFBSyxFQUFFLFdBRFQ7QUFFRSxtQkFBUyxFQUFDLHNCQUZaO0FBR0UsYUFBRyxFQUFDO0FBSE47QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFGRixlQU9FLHFFQUFDLGlEQUFEO0FBQ0UsYUFBRyxFQUFFYyw2RUFBc0IsQ0FBQ2YsWUFBRCxDQUQ3QjtBQUVFLGFBQUcsRUFBQyxvQkFGTjtBQUdFLG1CQUFTLEVBQUM7QUFIWjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFmRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUFxQ0QsQ0FoRE0sQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDakJQO0FBQ0E7QUFTTyxNQUFNb0IsYUFBOEIsR0FBRyxDQUFDO0FBQUVDLGFBQUY7QUFBZXJDLFdBQWY7QUFBMkJzQyxRQUEzQjtBQUFtQ3JDLE9BQUssR0FBQztBQUF6QyxDQUFELEtBQWtEO0FBQzVGLHNCQUNJO0FBQUssYUFBUyxFQUFHLEdBQUVELFNBQVUsRUFBN0I7QUFBZ0MsU0FBSyxFQUFFQyxLQUF2QztBQUFBLDRCQUNJO0FBQUEsOEJBQ0k7QUFBQSxrQkFBTXFDO0FBQU47QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFESixlQUVJO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURKLGVBS0k7QUFBSyxlQUFTLEVBQUMsTUFBZjtBQUFBLGdCQUNLRCxXQUFXLENBQUMvQixHQUFaLENBQWlCaUMsV0FBRCxJQUFpQjtBQUM5Qiw0QkFDSSxxRUFBQyxtRUFBRDtBQUVJLG1CQUFTLEVBQUVBLFdBQVcsQ0FBQzVCLFNBRjNCO0FBR0ksZUFBSyxFQUFFNEIsV0FBVyxDQUFDL0MsS0FIdkI7QUFJSSxnQkFBTSxFQUFFK0MsV0FBVyxDQUFDMUIsTUFKeEI7QUFLSSxvQkFBVSxFQUFFMEIsV0FBVyxDQUFDeEIsVUFMNUI7QUFNSSxzQkFBWSxFQUFFd0IsV0FBVyxDQUFDdkIsWUFOOUI7QUFPSSx1QkFBYSxFQUFFdUIsV0FBVyxDQUFDdEIsYUFQL0I7QUFRSSxpQkFBTyxFQUFHakMsRUFBRCxJQUFRMUIsT0FBTyxDQUFDa0YsR0FBUixDQUFZeEQsRUFBWixDQVJyQjtBQVNJLGVBQUssRUFBRTtBQUFDckYsaUJBQUssRUFBQztBQUFQLFdBVFg7QUFVSSxtQkFBUyxFQUFDO0FBVmQsV0FDUzRJLFdBQVcsQ0FBQ3hCLFVBRHJCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREo7QUFjSCxPQWZBO0FBREw7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFMSjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFESjtBQTBCSCxDQTNCTSxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ1ZQO0FBQ0E7O0FBR0EsTUFBTTBCLFVBQW9CLEdBQUcsTUFBTTtBQUNqQyxzQkFBUTtBQUFLLGFBQVMsRUFBQyx3R0FBZjtBQUFBLGNBRUpDLDZEQUFJLENBQUNwQyxHQUFMLENBQVMsQ0FBQzBCLElBQUQsRUFBWUMsS0FBWixLQUE4QjtBQUNyQywwQkFBUTtBQUFrQixpQkFBUyxFQUFDLE9BQTVCO0FBQUEsK0JBQ047QUFBRyxjQUFJLEVBQUVELElBQUksQ0FBQ2xLLElBQWQ7QUFBb0IsbUJBQVMsRUFBQyw2Q0FBOUI7QUFBQSwwQkFBOEVrSyxJQUFJLENBQUNuSyxJQUFuRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFETSxTQUFXb0ssS0FBWDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFSO0FBR0QsS0FKRDtBQUZJO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBUjtBQVNELENBVkQ7O0FBWWVRLHlFQUFmLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDZkE7QUFDQTtBQUNBO0FBQ0E7QUFFTyxNQUFNRSxNQUFnQixHQUFHLE1BQU07QUFDcEMsc0JBQ0U7QUFBSyxhQUFTLEVBQUMsdUVBQWY7QUFBQSw0QkFDRTtBQUFLLGVBQVMsRUFBQyw4RkFBZjtBQUFBLDhCQUNFO0FBQUssaUJBQVMsRUFBQyw2Q0FBZjtBQUFBLGdDQUNFO0FBQUksbUJBQVMsRUFBQyxpRUFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFERixlQUVFO0FBQU0sbUJBQVMsRUFBQyxVQUFoQjtBQUFBLGtDQUNFO0FBQUkscUJBQVMsRUFBQyxzQ0FBZDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFERixlQUVFO0FBQU8scUJBQVMsRUFBQyxpREFBakI7QUFBbUUsaUJBQUssRUFBRTtBQUFFVCxtQkFBSyxFQUFFO0FBQVQsYUFBMUU7QUFBZ0csZ0JBQUksRUFBQyxPQUFyRztBQUE2Ryx1QkFBVyxFQUFDO0FBQXpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRkYsZUFHRSxxRUFBQyxpRkFBRDtBQUFRLGlCQUFLLEVBQUMsV0FBZDtBQUEwQixlQUFHLEVBQUMsa0JBQTlCO0FBQWlELHFCQUFTLEVBQUUsY0FBNUQ7QUFBNEUsbUJBQU8sRUFBRSxNQUFNNUUsT0FBTyxDQUFDa0YsR0FBUixDQUFZLFdBQVo7QUFBM0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFIRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURGLGVBU0U7QUFBSyxpQkFBUyxFQUFDLDhEQUFmO0FBQUEsZ0NBQ0U7QUFBQSxrQ0FDRTtBQUFJLHFCQUFTLEVBQUMsNEJBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBREYsZUFFRTtBQUFJLHFCQUFTLEVBQUMsNkJBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQURGLGVBS0U7QUFBSyxtQkFBUyxFQUFDLHlDQUFmO0FBQUEsa0NBQ0U7QUFBRyxxQkFBUyxFQUFDLE9BQWI7QUFBQSxtQ0FBcUI7QUFBSyxpQkFBRyxFQUFDO0FBQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQURGLGVBRUU7QUFBRyxxQkFBUyxFQUFDLE9BQWI7QUFBQSx5Q0FBc0I7QUFBSyxpQkFBRyxFQUFDO0FBQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBdEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURGLGVBcUJFO0FBQUssZUFBUyxFQUFDLG1GQUFmO0FBQUEsOEJBQ0UscUVBQUMsbURBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFERixlQUVFO0FBQUssaUJBQVMsRUFBQywyRUFBZjtBQUFBLGdDQUNFO0FBQU0sbUJBQVMsRUFBQyxrQ0FBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREYsZUFFRTtBQUFHLG1CQUFTLEVBQUMsMENBQWI7QUFBQSxxQkFBeUR6Syx5REFBekQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBckJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBZ0NELENBakNNLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNOUDtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBV08sTUFBTTZLLE9BQXdCLEdBQUcsQ0FBQztBQUFFNUMsV0FBRjtBQUFhQyxPQUFLLEdBQUc7QUFBckIsQ0FBRCxLQUErQjtBQUNyRSxRQUFNNEMsS0FBSyxHQUFHLENBQUM7QUFDYkMsYUFBUyxFQUFFLFNBREU7QUFFYkMsWUFBUSxFQUFFLFVBRkc7QUFHYkMsY0FBVSxFQUFFLElBSEM7QUFJYkMsYUFBUyxFQUFFLElBSkU7QUFLYkMsV0FBTyxFQUFFLFVBTEk7QUFNYkMsWUFBUSxFQUFFLGVBTkc7QUFPYkMsUUFBSSxFQUFFLGdCQVBPO0FBUWJDLFNBQUssRUFBRSwwQkFSTTtBQVNiQyxXQUFPLEVBQUUsQ0FBQyxRQUFELEVBQVcsVUFBWCxFQUF1QixPQUF2QjtBQVRJLEdBQUQsRUFVWDtBQUNEUixhQUFTLEVBQUUsT0FEVjtBQUVEQyxZQUFRLEVBQUUsTUFGVDtBQUdEQyxjQUFVLEVBQUUsSUFIWDtBQUlEQyxhQUFTLEVBQUUsSUFKVjtBQUtEQyxXQUFPLEVBQUUsWUFMUjtBQU1EQyxZQUFRLEVBQUUsSUFOVDtBQU9EQyxRQUFJLEVBQUUsc0JBUEw7QUFRREMsU0FBSyxFQUFFLDRCQVJOO0FBU0RDLFdBQU8sRUFBRSxDQUFDLEtBQUQsRUFBUSxTQUFSLEVBQW1CLFNBQW5CO0FBVFIsR0FWVyxFQW9CWDtBQUNEUixhQUFTLEVBQUUsU0FEVjtBQUVEQyxZQUFRLEVBQUUsT0FGVDtBQUdEQyxjQUFVLEVBQUUsU0FIWDtBQUlEQyxhQUFTLEVBQUUsUUFKVjtBQUtEQyxXQUFPLEVBQUUsMEJBTFI7QUFNREMsWUFBUSxFQUFFLElBTlQ7QUFPREMsUUFBSSxFQUFFLG1CQVBMO0FBUURDLFNBQUssRUFBRSxvQkFSTjtBQVNEQyxXQUFPLEVBQUUsQ0FBQyxLQUFELEVBQVEsUUFBUixFQUFrQixPQUFsQjtBQVRSLEdBcEJXLEVBOEJYO0FBQ0RSLGFBQVMsRUFBRSxPQURWO0FBRURDLFlBQVEsRUFBRSxXQUZUO0FBR0RDLGNBQVUsRUFBRSxJQUhYO0FBSURDLGFBQVMsRUFBRSxJQUpWO0FBS0RDLFdBQU8sRUFBRSxTQUxSO0FBTURDLFlBQVEsRUFBRSxhQU5UO0FBT0RDLFFBQUksRUFBRSx1QkFQTDtBQVFEQyxTQUFLLEVBQUUsa0JBUk47QUFTREMsV0FBTyxFQUFFLENBQUMsSUFBRCxFQUFPLFFBQVAsRUFBaUIsWUFBakI7QUFUUixHQTlCVyxFQXdDWDtBQUNEUixhQUFTLEVBQUUsS0FEVjtBQUVEQyxZQUFRLEVBQUUsYUFGVDtBQUdEQyxjQUFVLEVBQUUsSUFIWDtBQUlEQyxhQUFTLEVBQUUsSUFKVjtBQUtEQyxXQUFPLEVBQUUsU0FMUjtBQU1EQyxZQUFRLEVBQUUsTUFOVDtBQU9EQyxRQUFJLEVBQUUsZUFQTDtBQVFEQyxTQUFLLEVBQUUsdUJBUk47QUFTREMsV0FBTyxFQUFFLENBQUMsUUFBRCxFQUFXLFVBQVgsRUFBdUIsT0FBdkI7QUFUUixHQXhDVyxFQWtEWDtBQUNEUixhQUFTLEVBQUUsWUFEVjtBQUVEQyxZQUFRLEVBQUUsTUFGVDtBQUdEQyxjQUFVLEVBQUUsT0FIWDtBQUlEQyxhQUFTLEVBQUUsU0FKVjtBQUtEQyxXQUFPLEVBQUUsU0FMUjtBQU1EQyxZQUFRLEVBQUUsTUFOVDtBQU9EQyxRQUFJLEVBQUUsb0JBUEw7QUFRREUsV0FBTyxFQUFFLENBQUMsSUFBRCxFQUFPLFFBQVAsRUFBaUIsWUFBakIsQ0FSUjtBQVNERCxTQUFLLEVBQUU7QUFUTixHQWxEVyxDQUFkO0FBOERBLFFBQU1qRCxJQUFJLEdBQUcsQ0FDWDtBQUNFTyxhQUFTLEVBQUUscUJBRGI7QUFFRW5CLFNBQUssRUFBRSxxREFGVDtBQUdFcUIsVUFBTSxFQUFFLGFBSFY7QUFJRUUsY0FBVSxFQUFFLFFBSmQ7QUFLRUMsZ0JBQVksRUFBRSxNQUxoQjtBQU1FQyxpQkFBYSxFQUFFO0FBTmpCLEdBRFcsRUFTWDtBQUNFTixhQUFTLEVBQUUscUJBRGI7QUFFRW5CLFNBQUssRUFBRSxxREFGVDtBQUdFcUIsVUFBTSxFQUFFLGFBSFY7QUFJRUUsY0FBVSxFQUFFLFNBSmQ7QUFLRUMsZ0JBQVksRUFBRSxNQUxoQjtBQU1FQyxpQkFBYSxFQUFFO0FBTmpCLEdBVFcsQ0FBYjtBQW9CQSxRQUFNc0MsUUFBUSxHQUFHO0FBQ2ZDLFFBQUksRUFBRSxJQURTO0FBRWZDLFlBQVEsRUFBRSxJQUZLO0FBR2ZDLFNBQUssRUFBRSxHQUhRO0FBSWZDLGlCQUFhLEVBQUUsSUFKQTtBQUtmQyxnQkFBWSxFQUFFLENBTEM7QUFNZkMsa0JBQWMsRUFBRSxDQU5ELENBT2Y7O0FBUGUsR0FBakI7QUFTQSxzQkFDRSxxRUFBQyxrREFBRCxrQ0FBWU4sUUFBWjtBQUFBLGNBQ0dWLEtBQUssQ0FBQ3ZDLEdBQU4sQ0FBVXdELElBQUksSUFBSTtBQUNqQiwwQkFBUTtBQUFBLCtCQUNOO0FBQUssbUJBQVMsRUFBRyxHQUFFOUQsU0FBVSxFQUE3QjtBQUFnQyxlQUFLO0FBQUlyRyxpQkFBSyxFQUFFLE1BQVg7QUFBbUJ1QyxrQkFBTSxFQUFFLE1BQTNCO0FBQW1DVixvQkFBUSxFQUFFO0FBQTdDLGFBQTREeUUsS0FBNUQsQ0FBckM7QUFBQSxrQ0FDRTtBQUFLLHFCQUFTLEVBQUMsRUFBZjtBQUFrQixpQkFBSyxFQUFFO0FBQUV0RyxtQkFBSyxFQUFFLEdBQVQ7QUFBY3VDLG9CQUFNLEVBQUUsR0FBdEI7QUFBMkJWLHNCQUFRLEVBQUUsVUFBckM7QUFBaUQ2Rix3QkFBVSxFQUFFLFNBQTdEO0FBQXdFMUYsb0JBQU0sRUFBRSxFQUFoRjtBQUFvRkQsa0JBQUksRUFBRTtBQUExRjtBQUF6QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQURGLGVBRUU7QUFBSyxxQkFBUyxFQUFDLEVBQWY7QUFBa0IsaUJBQUssRUFBRTtBQUFFL0IsbUJBQUssRUFBRSxHQUFUO0FBQWN1QyxvQkFBTSxFQUFFLEdBQXRCO0FBQTJCUCxvQkFBTSxFQUFFLEVBQW5DO0FBQXVDRCxrQkFBSSxFQUFFLEVBQTdDO0FBQWlERixzQkFBUSxFQUFFLFVBQTNEO0FBQXVFUyxxQkFBTyxFQUFFLE1BQWhGO0FBQXdGOEgsMkJBQWEsRUFBRTtBQUF2RyxhQUF6QjtBQUFBLG9DQUNFLHFFQUFDLGlEQUFEO0FBQU8saUJBQUcsRUFBRUQsSUFBSSxDQUFDVCxLQUFqQjtBQUF3QixpQkFBRyxFQUFDLGVBQTVCO0FBQTRDLG1CQUFLLEVBQUU7QUFBRVcsd0JBQVEsRUFBRTtBQUFaO0FBQW5EO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBREYsZUFFRSxxRUFBQyxpREFBRDtBQUFPLGlCQUFHLEVBQUMsc0JBQVg7QUFBa0MsaUJBQUcsRUFBRSxZQUF2QztBQUFxRCx1QkFBUyxFQUFDLFVBQS9EO0FBQTBFLG1CQUFLLEVBQUU7QUFBRXRJLG9CQUFJLEVBQUUsRUFBUjtBQUFZQyxzQkFBTSxFQUFFO0FBQXBCO0FBQWpGO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBRkYsZUFJRTtBQUFLLG1CQUFLLEVBQUU7QUFBRU8sc0JBQU0sRUFBRSxHQUFWO0FBQWVtRiwwQkFBVSxFQUFFO0FBQTNCLGVBQVo7QUFBQSxzQ0FDRTtBQUFLLHlCQUFTLEVBQUMsK0JBQWY7QUFBK0MscUJBQUssRUFBRTtBQUFFbkYsd0JBQU0sRUFBRSxHQUFWO0FBQWUrSCw4QkFBWSxFQUFFO0FBQTdCLGlCQUF0RDtBQUFBLHdDQUNFO0FBQUksMkJBQVMsRUFBQywwQkFBZDtBQUF5Qyx1QkFBSyxFQUFFO0FBQUVuQyw0QkFBUSxFQUFFLEVBQVo7QUFBZ0JQLDhCQUFVLEVBQUUsTUFBNUI7QUFBb0NNLGlDQUFhLEVBQUUsUUFBbkQ7QUFBNkRGLDhCQUFVLEVBQUUsRUFBekU7QUFBNkV1QywrQkFBVyxFQUFFO0FBQTFGLG1CQUFoRDtBQUFBLDRCQUNHSixJQUFJLENBQUNoQjtBQURSO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBREYsZUFJRTtBQUFJLDJCQUFTLEVBQUMsMkJBQWQ7QUFBMEMsdUJBQUssRUFBRTtBQUFFaEIsNEJBQVEsRUFBRSxFQUFaO0FBQWdCUCw4QkFBVSxFQUFFLE1BQTVCO0FBQW9DTSxpQ0FBYSxFQUFFO0FBQW5ELG1CQUFqRDtBQUFBLDRCQUNHaUMsSUFBSSxDQUFDZjtBQURSO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDJCQURGLGVBVUU7QUFBSyx5QkFBUyxFQUFDLG1DQUFmO0FBQW1ELHFCQUFLLEVBQUU7QUFBRTdHLHdCQUFNLEVBQUU7QUFBVixpQkFBMUQ7QUFBQSx3Q0FDRTtBQUFLLHVCQUFLLEVBQUU7QUFBRXlGLDhCQUFVLEVBQUUsRUFBZDtBQUFrQjFGLDJCQUFPLEVBQUUsTUFBM0I7QUFBbUNrSSxrQ0FBYyxFQUFFO0FBQW5ELG1CQUFaO0FBQUEsMENBQ0U7QUFBTSw2QkFBUyxFQUFDLDhDQUFoQjtBQUFBLG9DQUFpRUwsSUFBSSxDQUFDWixPQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBREYsRUFFR1ksSUFBSSxDQUFDWCxRQUFMLGlCQUFpQjtBQUFNLDZCQUFTLEVBQUMsOENBQWhCO0FBQUEsMkNBQStEO0FBQUksMkJBQUssRUFBRTtBQUFFeEosNkJBQUssRUFBRSxFQUFUO0FBQWF5SyxpQ0FBUyxFQUFFO0FBQXhCO0FBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUEvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUZwQixFQUdHTixJQUFJLENBQUNYLFFBQUwsaUJBQWlCO0FBQU0sNkJBQVMsRUFBQyw4Q0FBaEI7QUFBQSxvQ0FBaUVXLElBQUksQ0FBQ1gsUUFBdEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLCtCQUhwQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBREYsZUFNRSxxRUFBQyxpREFBRDtBQUFPLHFCQUFHLEVBQUVXLElBQUksQ0FBQ1YsSUFBakI7QUFBdUIscUJBQUcsRUFBRSxLQUE1QjtBQUFtQyx1QkFBSyxFQUFFO0FBQUVjLCtCQUFXLEVBQUU7QUFBZjtBQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUZGLGVBMkJFO0FBQUsscUJBQVMsRUFBQyxFQUFmO0FBQWtCLGlCQUFLLEVBQUU7QUFBRXhJLGtCQUFJLEVBQUUsR0FBUjtBQUFhRixzQkFBUSxFQUFFO0FBQXZCLGFBQXpCO0FBQUEsb0NBQ0U7QUFBRyx1QkFBUyxFQUFDLGNBQWI7QUFBQSx5QkFBNkJzSSxJQUFJLENBQUNSLE9BQUwsQ0FBYSxDQUFiLENBQTdCLGVBQTZDO0FBQU0scUJBQUssRUFBRTtBQUFFcEIsdUJBQUssRUFBRTtBQUFULGlCQUFiO0FBQUEsZ0NBQXFDNEIsSUFBSSxDQUFDUixPQUFMLENBQWEsQ0FBYixDQUFyQztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBQTdDLE9BQTRHUSxJQUFJLENBQUNSLE9BQUwsQ0FBYSxDQUFiLENBQTVHO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFERixlQUdFLHFFQUFDLHlEQUFEO0FBQ0UsbUJBQUssRUFBRTtBQUNMNUgsb0JBQUksRUFBRSxDQUFDLEVBREY7QUFFTDJGLDBCQUFVLEVBQUUsU0FGUDtBQUdMdEYsc0JBQU0sRUFBRSxtQkFISDtBQUlMRix5QkFBUyxFQUFFLFlBSk47QUFLTGlHLHdCQUFRLEVBQUUsRUFMTDtBQU1MUCwwQkFBVSxFQUFFLE1BTlA7QUFPTC9FLDBCQUFVLEVBQUUsRUFQUDtBQVFMaUYsMkJBQVcsRUFBRSxFQVJSO0FBU0w5SCxxQkFBSyxFQUFFLE1BVEY7QUFVTGdDLHNCQUFNLEVBQUUsQ0FBQyxHQVZKO0FBV0xPLHNCQUFNLEVBQUU7QUFYSCxlQURUO0FBY0UseUJBQVcsRUFBRWtFLElBZGY7QUFlRSx1QkFBUyxFQUFDLDZDQWZaO0FBZ0JFLG9CQUFNLGVBQUU7QUFBQSxpRUFBMkI7QUFBTSwyQkFBUyxFQUFDLGFBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFoQlY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFIRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBM0JGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURNO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBQVI7QUFvREQsS0FyREE7QUFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUE4REQsQ0ExSk0sQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2ZQO0FBQ0E7QUFXTyxNQUFNaUUsYUFBOEIsR0FBRyxDQUFDO0FBQzdDckUsV0FBUyxHQUFHLEVBRGlDO0FBRTdDQyxPQUFLLEdBQUc7QUFGcUMsQ0FBRCxLQUd4QztBQUNKLHNCQUNFO0FBQ0UsYUFBUyxFQUFDLEVBRFo7QUFFRSxTQUFLLGtDQUNBO0FBQ0R0RyxXQUFLLEVBQUUsR0FETjtBQUVEdUMsWUFBTSxFQUFFLEdBRlA7QUFHRFYsY0FBUSxFQUFFO0FBSFQsS0FEQSxHQU1BeUUsS0FOQSxDQUZQO0FBQUEsNEJBV0U7QUFDRSxlQUFTLEVBQUMsRUFEWjtBQUVFLFdBQUssRUFBRTtBQUNMdEcsYUFBSyxFQUFFLEdBREY7QUFFTHVDLGNBQU0sRUFBRSxHQUZIO0FBR0xWLGdCQUFRLEVBQUUsVUFITDtBQUlMNkYsa0JBQVUsRUFBRSxTQUpQO0FBS0wxRixjQUFNLEVBQUUsQ0FMSDtBQU1MRCxZQUFJLEVBQUU7QUFORDtBQUZUO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBWEYsZUFzQkU7QUFDRSxlQUFTLEVBQUMsRUFEWjtBQUVFLFdBQUssRUFBRTtBQUNML0IsYUFBSyxFQUFFLEdBREY7QUFFTHVDLGNBQU0sRUFBRSxHQUZIO0FBR0xWLGdCQUFRLEVBQUUsVUFITDtBQUlMRSxZQUFJLEVBQUUsRUFKRDtBQUtMQyxjQUFNLEVBQUUsRUFMSDtBQU1MTSxlQUFPLEVBQUUsTUFOSjtBQU9MOEgscUJBQWEsRUFBRTtBQVBWLE9BRlQ7QUFBQSw4QkFZRSxxRUFBQyxpREFBRDtBQUNFLFdBQUcsRUFBQywwQkFETjtBQUVFLFdBQUcsRUFBQyxnQkFGTjtBQUdFLGFBQUssRUFBRTtBQUFFQyxrQkFBUSxFQUFFO0FBQVo7QUFIVDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVpGLGVBaUJFLHFFQUFDLGlEQUFEO0FBQ0UsV0FBRyxFQUFDLHNCQUROO0FBRUUsV0FBRyxFQUFFLFlBRlA7QUFHRSxpQkFBUyxFQUFDLFVBSFo7QUFJRSxhQUFLLEVBQUU7QUFBRXRJLGNBQUksRUFBRSxFQUFSO0FBQVlDLGdCQUFNLEVBQUU7QUFBcEI7QUFKVDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWpCRixlQXVCRTtBQUFLLGFBQUssRUFBRTtBQUFFTyxnQkFBTSxFQUFFLEdBQVY7QUFBZW1GLG9CQUFVLEVBQUU7QUFBM0IsU0FBWjtBQUFBLCtCQUNFO0FBQ0UsbUJBQVMsRUFBQywyQ0FEWjtBQUVFLGVBQUssRUFBRTtBQUFFbkYsa0JBQU0sRUFBRSxHQUFWO0FBQWUrSCx3QkFBWSxFQUFFO0FBQTdCLFdBRlQ7QUFBQSxrQ0FJRTtBQUFLLHFCQUFTLEVBQUMsTUFBZjtBQUFBLG9DQUNFO0FBQ0UsdUJBQVMsRUFBQywwQkFEWjtBQUVFLG1CQUFLLEVBQUU7QUFDTG5DLHdCQUFRLEVBQUUsRUFETDtBQUVMUCwwQkFBVSxFQUFFLE1BRlA7QUFHTE0sNkJBQWEsRUFBRSxRQUhWO0FBSUxGLDBCQUFVLEVBQUUsRUFKUDtBQUtMdUMsMkJBQVcsRUFBRTtBQUxSLGVBRlQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBREYsZUFhRTtBQUNFLHVCQUFTLEVBQUMsMkJBRFo7QUFFRSxtQkFBSyxFQUFFO0FBQ0xwQyx3QkFBUSxFQUFFLEVBREw7QUFFTFAsMEJBQVUsRUFBRSxNQUZQO0FBR0xNLDZCQUFhLEVBQUU7QUFIVixlQUZUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFKRixlQTRCRTtBQUFLLHFCQUFTLEVBQUMsTUFBZjtBQUFBLG9DQUNFO0FBQ0UsdUJBQVMsRUFBQywwQkFEWjtBQUVFLG1CQUFLLEVBQUU7QUFDTEMsd0JBQVEsRUFBRSxFQURMO0FBRUxQLDBCQUFVLEVBQUUsTUFGUDtBQUdMTSw2QkFBYSxFQUFFLFFBSFY7QUFJTEYsMEJBQVUsRUFBRSxFQUpQO0FBS0x1QywyQkFBVyxFQUFFO0FBTFIsZUFGVDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFERixlQWFFO0FBQ0UsdUJBQVMsRUFBQywyQkFEWjtBQUVFLG1CQUFLLEVBQUU7QUFDTHBDLHdCQUFRLEVBQUUsRUFETDtBQUVMUCwwQkFBVSxFQUFFLE1BRlA7QUFHTE0sNkJBQWEsRUFBRTtBQUhWLGVBRlQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBYkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQTVCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBdEJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBd0dELENBNUdNLEM7Ozs7Ozs7Ozs7OztBQ1pQO0FBQUE7QUFBQTtBQUFBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDQUE7QUFFQTtBQU1PLE1BQU15QyxNQUF1QixHQUFHLENBQUM7QUFBRUM7QUFBRixDQUFELEtBQWdCO0FBQ3JELHNCQUNFO0FBQUssYUFBUyxFQUFDLHdGQUFmO0FBQUEsNEJBQ0UscUVBQUMsZ0RBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFERixlQUVFO0FBQ0UsZUFBUyxFQUFDLG9EQURaO0FBRUUsYUFBTyxFQUFFLE1BQU1BLE1BQU0sRUFGdkI7QUFBQSw4QkFJRTtBQUFJLGlCQUFTLEVBQUMsdUJBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSkYsZUFLRTtBQUNFLFdBQUcsRUFBQyxpQkFETjtBQUVFLGlCQUFTLEVBQUM7QUFGWjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQWVELENBaEJNLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDUlA7QUFXTyxNQUFNQyxLQUFzQixHQUFHLENBQUM7QUFBRXRLLEtBQUY7QUFBT3VLLEtBQVA7QUFBWXpFLFdBQVo7QUFBd0JyRyxPQUF4QjtBQUErQnVDLFFBQS9CO0FBQXdDK0QsT0FBSyxHQUFDO0FBQTlDLENBQUQsS0FBd0Q7QUFDMUYsc0JBQU87QUFBSyxPQUFHLEVBQUUvRixHQUFWO0FBQWUsT0FBRyxFQUFFdUssR0FBcEI7QUFBeUIsYUFBUyxFQUFFekUsU0FBcEM7QUFBK0MsVUFBTSxFQUFFOUQsTUFBdkQ7QUFBK0QsU0FBSyxFQUFFdkMsS0FBdEU7QUFBNkUsU0FBSyxFQUFFc0c7QUFBcEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFQO0FBQ0gsQ0FGTSxDOzs7Ozs7Ozs7Ozs7QUNYUDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ1pBO0FBQ0E7QUFFTyxNQUFNeUUsSUFBYyxHQUFHLE1BQU07QUFDbEM7QUFBQTtBQUNFO0FBQ0EseUVBQUMsaURBQUQ7QUFBTyxTQUFHLEVBQUMsdUJBQVg7QUFBbUMsU0FBRyxFQUFDLFFBQXZDO0FBQWdELFdBQUssRUFBQyxVQUF0RDtBQUFpRSxZQUFNLEVBQUMsTUFBeEU7QUFBK0UsZUFBUyxFQUFDO0FBQXpGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFGRjtBQUlELENBTE0sQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDSFA7QUFFQTtBQUVPLE1BQU1DLElBQWMsR0FBRyxNQUFNO0FBQ2xDLHNCQUNFO0FBQUssYUFBUyxFQUFDLHlDQUFmO0FBQUEsMkJBQ0U7QUFBSyxlQUFTLEVBQUMsbUJBQWY7QUFBQSw4QkFDRTtBQUFJLGlCQUFTLEVBQUMsMEJBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREYsZUFFRTtBQUFHLGlCQUFTLEVBQUMseUJBQWI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRkYsZUFLRSxxRUFBQyxrREFBRDtBQUFRLFlBQUksRUFBQyxRQUFiO0FBQUEsK0JBQ0U7QUFBRyxjQUFJLEVBQUMsc0NBQVI7QUFBK0MsZ0JBQU0sRUFBQyxRQUF0RDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBZUQsQ0FoQk0sQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDSFA7QUFDQTtBQVdPLE1BQU1DLE9BQXdCLEdBQUcsQ0FBQztBQUN2Q3BGLE9BRHVDO0FBRXZDcUYsVUFGdUM7QUFHdkM3RixJQUh1QztBQUl2Q2UsU0FKdUM7QUFLdkNDLFdBQVMsR0FBRyxFQUwyQjtBQU12QzhFLE9BQUssR0FBRztBQU4rQixDQUFELEtBT2xDO0FBQ0osc0JBQ0U7QUFDRSxhQUFTLEVBQUcsR0FBRTlFLFNBQVUsK0RBRDFCO0FBRUUsU0FBSyxFQUFFO0FBQUVvQixrQkFBWSxFQUFFO0FBQWhCLEtBRlQ7QUFHRSxXQUFPLEVBQUUsTUFBTXJCLE9BQU8sQ0FBQ2YsRUFBRCxDQUh4QjtBQUFBLDRCQUtFO0FBQUEsZ0JBQU9RO0FBQVA7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFMRixFQU9LcUYsUUFBUSxJQUFJQyxLQUFiLEdBQ0MsQ0FBQ0QsUUFBRixnQkFDRTtBQUFNLGVBQVMsRUFBQyx1QkFBaEI7QUFBQSxzQkFBMEMsR0FBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURGLGdCQUdFLHFFQUFDLGlEQUFEO0FBQ0UsU0FBRyxFQUFFLDBCQURQO0FBRUUsU0FBRyxFQUFDLFlBRk47QUFHRSxlQUFTLEVBQUM7QUFIWjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUpGLEdBVUUsSUFqQk47QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUFxQkQsQ0E3Qk0sQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNiUDtBQVlPLE1BQU1FLEdBQW9CLEdBQUcsQ0FBQztBQUFFRixVQUFGO0FBQVlyRixPQUFaO0FBQW1CUixJQUFuQjtBQUF1QmUsU0FBdkI7QUFBZ0NDLFdBQVMsR0FBRyxFQUE1QztBQUFnREMsT0FBSyxHQUFHO0FBQXhELENBQUQsS0FBeUU7QUFDekcsUUFBTStFLFVBQVUsR0FBR0gsUUFBUSxHQUFHLGNBQUgsR0FBb0IsS0FBL0M7O0FBQ0Esc0JBQVE7QUFBTSxhQUFTLEVBQUU3RSxTQUFTLEdBQUcsR0FBWixHQUFrQmdGLFVBQW5DO0FBQStDLFNBQUssRUFBRS9FLEtBQXREO0FBQTZELFdBQU8sRUFBRSxNQUFNO0FBQUUsVUFBSUYsT0FBSixFQUFhQSxPQUFPLENBQUNmLEVBQUQsQ0FBUDtBQUFhLEtBQXhHO0FBQUEsY0FDSFE7QUFERztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQVI7QUFHSCxDQUxNLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNaUDtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxNQUFNeUYsSUFBYyxHQUFHLE1BQU07QUFDM0Isc0JBQ0U7QUFBSyxhQUFTLEVBQUMsb0JBQWY7QUFBQSw0QkFDRSxxRUFBQyxvREFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURGLGVBRUUscUVBQUMscURBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFGRixlQUdFO0FBQ0UsZUFBUyxFQUFDLG1DQURaO0FBRUUsV0FBSyxFQUFFO0FBQ0xyRCxpQkFBUyxFQUFFLEdBRE47QUFFTEQsa0JBQVUsRUFBRSxHQUZQO0FBR0xQLG9CQUFZLEVBQUUsR0FIVDtBQUlMVSxnQkFBUSxFQUFFLEVBSkw7QUFLTFAsa0JBQVUsRUFBRTtBQUxQLE9BRlQ7QUFBQSxpQkFVRyxHQVZILHNEQVdxQztBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVhyQyxVQVdnRCxHQVhoRCxlQVlFO0FBQU0saUJBQVMsRUFBQyxhQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFaRixpQkFZa0UsR0FabEU7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUhGLGVBaUJFLHFFQUFDLG9EQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBcUJELENBdEJEOztBQXdCZTBELG1FQUFmLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzdCQTtBQUNBO0FBQ0E7QUFHQSxNQUFNN0UsSUFBSSxHQUFHLENBQ1g7QUFDRU8sV0FBUyxFQUFFLHFCQURiO0FBRUVuQixPQUFLLEVBQUUscURBRlQ7QUFHRXFCLFFBQU0sRUFBRSxhQUhWO0FBSUVFLFlBQVUsRUFBRSxRQUpkO0FBS0VDLGNBQVksRUFBRSxNQUxoQjtBQU1FQyxlQUFhLEVBQUU7QUFOakIsQ0FEVyxFQVNYO0FBQ0VOLFdBQVMsRUFBRSxxQkFEYjtBQUVFbkIsT0FBSyxFQUFFLHFEQUZUO0FBR0VxQixRQUFNLEVBQUUsYUFIVjtBQUlFRSxZQUFVLEVBQUUsU0FKZDtBQUtFQyxjQUFZLEVBQUUsTUFMaEI7QUFNRUMsZUFBYSxFQUFFO0FBTmpCLENBVFcsQ0FBYjtBQW9CQSxNQUFNNEIsS0FBSyxHQUFHLENBQUM7QUFDYkMsV0FBUyxFQUFFLE9BREU7QUFFYkMsVUFBUSxFQUFFLE1BRkc7QUFHYkMsWUFBVSxFQUFFLElBSEM7QUFJYkMsV0FBUyxFQUFFLElBSkU7QUFLYkMsU0FBTyxFQUFFLHVJQUxJO0FBTWJFLE1BQUksRUFBRSxzQkFOTztBQU9iQyxPQUFLLEVBQUUsNEJBUE07QUFRYkMsU0FBTyxFQUFFLENBQUMsbUJBQUQsRUFBc0IscUJBQXRCLEVBQTZDLEVBQTdDLENBUkk7QUFTYjRCLElBQUUsRUFBRTtBQVRTLENBQUQsRUFVWDtBQUNEcEMsV0FBUyxFQUFFLFNBRFY7QUFFREMsVUFBUSxFQUFFLE9BRlQ7QUFHREMsWUFBVSxFQUFFLFNBSFg7QUFJREMsV0FBUyxFQUFFLFFBSlY7QUFLREMsU0FBTyxFQUFFLHdHQUxSO0FBTURFLE1BQUksRUFBRSxtQkFOTDtBQU9EQyxPQUFLLEVBQUUsb0JBUE47QUFRREMsU0FBTyxFQUFFLENBQUMsZUFBRCxFQUFrQixpQkFBbEIsRUFBcUMsVUFBckMsQ0FSUjtBQVNENEIsSUFBRSxFQUFFO0FBVEgsQ0FWVyxFQW9CWDtBQUNEcEMsV0FBUyxFQUFFLE9BRFY7QUFFREMsVUFBUSxFQUFFLFdBRlQ7QUFHREMsWUFBVSxFQUFFLElBSFg7QUFJREMsV0FBUyxFQUFFLElBSlY7QUFLREMsU0FBTyxFQUFFLGlIQUxSO0FBTURFLE1BQUksRUFBRSx1QkFOTDtBQU9EQyxPQUFLLEVBQUUsa0JBUE47QUFRREMsU0FBTyxFQUFFLENBQUMsS0FBRCxFQUFRLFNBQVIsRUFBbUIsRUFBbkI7QUFSUixDQXBCVyxFQTZCWDtBQUNEUixXQUFTLEVBQUUsS0FEVjtBQUVEQyxVQUFRLEVBQUUsYUFGVDtBQUdEQyxZQUFVLEVBQUUsSUFIWDtBQUlEQyxXQUFTLEVBQUUsSUFKVjtBQUtEQyxTQUFPLEVBQUUsaUdBTFI7QUFNREUsTUFBSSxFQUFFLGVBTkw7QUFPREMsT0FBSyxFQUFFLHVCQVBOO0FBUURDLFNBQU8sRUFBRSxDQUFDLFlBQUQsRUFBZSxpQkFBZixFQUFrQyxFQUFsQztBQVJSLENBN0JXLEVBc0NYO0FBQ0RSLFdBQVMsRUFBRSxZQURWO0FBRURDLFVBQVEsRUFBRSxNQUZUO0FBR0RDLFlBQVUsRUFBRSxPQUhYO0FBSURDLFdBQVMsRUFBRSxTQUpWO0FBS0RDLFNBQU8sRUFBRSxvSkFMUjtBQU1ERSxNQUFJLEVBQUUsb0JBTkw7QUFPREUsU0FBTyxFQUFFLENBQUMsS0FBRCxFQUFRLHFCQUFSLEVBQStCLE9BQS9CLENBUFI7QUFRREQsT0FBSyxFQUFFO0FBUk4sQ0F0Q1csRUErQ1g7QUFDRFAsV0FBUyxFQUFFLFNBRFY7QUFFREMsVUFBUSxFQUFFLFVBRlQ7QUFHREMsWUFBVSxFQUFFLElBSFg7QUFJREMsV0FBUyxFQUFFLElBSlY7QUFLREMsU0FBTyxFQUFFLHVLQUxSO0FBTURFLE1BQUksRUFBRSxnQkFOTDtBQU9EQyxPQUFLLEVBQUUsMEJBUE47QUFRREMsU0FBTyxFQUFFLENBQUMsaUJBQUQsRUFBb0IsVUFBcEIsRUFBZ0MsUUFBaEM7QUFSUixDQS9DVyxDQUFkOztBQTBEQSxNQUFNNkIsWUFBWSxHQUFHLE1BQU07QUFDekIsUUFBTSxDQUFDQyxhQUFELEVBQWdCQyxnQkFBaEIsSUFBb0NDLDRDQUFLLENBQUNDLFFBQU4sQ0FDeEMsb0NBRHdDLENBQTFDO0FBR0E7QUFBQTtBQUNFO0FBQ0E7QUFBSyxlQUFTLEVBQUMsVUFBZjtBQUEwQixXQUFLLEVBQUU7QUFBRXJKLGNBQU0sRUFBRTtBQUFWLE9BQWpDO0FBQUEsNkJBQ0U7QUFDRSxpQkFBUyxFQUFDLHNDQURaO0FBRUUsYUFBSyxFQUFFO0FBQ0wwRCx5QkFBZSxFQUFHLE9BQU13RixhQUFjLEdBRGpDO0FBRUxJLHdCQUFjLEVBQUU7QUFGWCxTQUZUO0FBQUEsZ0NBT0U7QUFBSyxtQkFBUyxFQUFDLE1BQWY7QUFBQSxrQ0FDRSxxRUFBQyxpREFBRDtBQUNFLGVBQUcsRUFBQyxzQkFETjtBQUVFLGVBQUcsRUFBRSxZQUZQO0FBR0Usa0JBQU0sRUFBRSxFQUhWO0FBSUUsaUJBQUssRUFBRSxFQUpUO0FBS0UsaUJBQUssRUFBRTtBQUFFN0Qsd0JBQVUsRUFBRTtBQUFkO0FBTFQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFERixlQVFFO0FBQUssaUJBQUssRUFBRTtBQUFFaEksbUJBQUssRUFBRSxHQUFUO0FBQWNnSSx3QkFBVSxFQUFFO0FBQTFCLGFBQVo7QUFBQSxvQ0FDRTtBQUNFLG1CQUFLLEVBQUU7QUFDTDhELDBCQUFVLEVBQUUsR0FEUDtBQUVMM0Qsd0JBQVEsRUFBRSxPQUZMO0FBR0xQLDBCQUFVLEVBQUUsT0FIUDtBQUlMTSw2QkFBYSxFQUFFLFNBSlY7QUFLTDZELHVCQUFPLEVBQUUsSUFMSjtBQU1MOUQseUJBQVMsRUFBRTtBQU5OLGVBRFQ7QUFBQSx5QkFVRyxHQVZIO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFERixlQWNFO0FBQ0UsdUJBQVMsRUFBQyxzQkFEWjtBQUVFLG1CQUFLLEVBQUU7QUFDTDZELDBCQUFVLEVBQUUsR0FEUDtBQUVMM0Qsd0JBQVEsRUFBRSxNQUZMO0FBR0xQLDBCQUFVLEVBQUUsTUFIUDtBQUlMbUUsdUJBQU8sRUFBRSxDQUpKO0FBS0w5RCx5QkFBUyxFQUFFLEdBTE47QUFNTHpGLHdCQUFRLEVBQUU7QUFOTCxlQUZUO0FBQUEsc0RBWUU7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFaRixlQWFFO0FBQU0seUJBQVMsRUFBQyxXQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFiRixvQkFhc0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFidEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFSRixlQXVDRSxxRUFBQywrRUFBRDtBQUFlLGlCQUFLLEVBQUU7QUFBRXlGLHVCQUFTLEVBQUUsRUFBYjtBQUFpQkQsd0JBQVUsRUFBRTtBQUE3QjtBQUF0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQXZDRixlQXdDRSxxRUFBQyxpREFBRDtBQUNFLGVBQUcsRUFBQyw2QkFETjtBQUVFLGVBQUcsRUFBRSxZQUZQO0FBR0Usa0JBQU0sRUFBRSxFQUhWO0FBSUUsaUJBQUssRUFBRSxFQUpUO0FBS0UsaUJBQUssRUFBRTtBQUFFQSx3QkFBVSxFQUFFO0FBQWQ7QUFMVDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQXhDRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBUEYsZUF1REU7QUFDRSxtQkFBUyxFQUFDLG9CQURaO0FBRUUsZUFBSyxFQUFFO0FBQUVoRyxrQkFBTSxFQUFFLEVBQVY7QUFBY0QsZ0JBQUksRUFBRSxHQUFwQjtBQUF5QlEsa0JBQU0sRUFBRSxHQUFqQztBQUFzQ3ZDLGlCQUFLLEVBQUU7QUFBN0MsV0FGVDtBQUFBLGlDQUlFO0FBQ0UscUJBQVMsRUFBQyxrR0FEWjtBQUVFLGlCQUFLLEVBQUU7QUFBRWdNLHlCQUFXLEVBQUUsYUFBZjtBQUE4QmhNLG1CQUFLLEVBQUU7QUFBckMsYUFGVDtBQUFBLHVCQUlHLEdBSkgsd0JBS3FCLEdBTHJCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUpGO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBdkRGLGVBbUVFLHFFQUFDLHlEQUFEO0FBQ0UsZUFBSyxFQUFFO0FBQ0wrQixnQkFBSSxFQUFFLEdBREQ7QUFFTDJGLHNCQUFVLEVBQUUsU0FGUDtBQUdMdEYsa0JBQU0sRUFBRSxtQkFISDtBQUlMRixxQkFBUyxFQUFFLFlBSk47QUFLTGlHLG9CQUFRLEVBQUUsRUFMTDtBQU1MUCxzQkFBVSxFQUFFLE1BTlA7QUFPTC9FLHNCQUFVLEVBQUUsRUFQUDtBQVFMaUYsdUJBQVcsRUFBRTtBQVJSLFdBRFQ7QUFXRSxxQkFBVyxFQUFFckIsSUFYZjtBQVlFLG1CQUFTLEVBQUMsNkNBWlo7QUFhRSxnQkFBTSxlQUFFO0FBQUEsc0RBQW9CO0FBQU0sdUJBQVMsRUFBQyxhQUFoQjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFBcEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBYlY7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFuRUY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFGRixDQXdGRTs7QUF4RkY7QUEwRkQsQ0E5RkQ7O0FBZ0dlK0UsMkVBQWYsRTs7Ozs7Ozs7Ozs7O0FDbExBO0FBQUE7QUFBQTtBQUVlQSxvSEFBZixFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0hBO0FBQ0E7O0FBUUEsTUFBTVMsV0FBNEIsR0FBRyxDQUFDO0FBQ3BDQyxhQURvQztBQUVwQ0MsZUFGb0M7QUFHcENDO0FBSG9DLENBQUQsS0FJL0I7QUFDSixzQkFDRTtBQUFLLGFBQVMsRUFBQyx3RkFBZjtBQUFBLGNBQ0dBLE9BQU8sQ0FBQ3pGLEdBQVIsQ0FBWSxDQUFDO0FBQUV6SSxVQUFGO0FBQVFtSCxRQUFSO0FBQVlsSDtBQUFaLEtBQUQsS0FBd0I7QUFDbkMsWUFBTWtPLFFBQVEsR0FDWmhILEVBQUUsS0FBSzZHLFdBQVAsR0FDSSwwQkFESixHQUVJLDhCQUhOO0FBSUEsMEJBQ0UscUVBQUMsbURBQUQ7QUFFRSxhQUFLLEVBQUVoTyxJQUZUO0FBR0UsVUFBRSxFQUFFbUgsRUFITjtBQUlFLGFBQUssRUFBRSxLQUpUO0FBS0UsZUFBTyxFQUFFOEcsYUFMWDtBQU1FLGdCQUFRLEVBQUU5RyxFQUFFLEtBQUs2RyxXQU5uQjtBQU9FLGlCQUFTLEVBQUcsMkNBQTBDRyxRQUFTO0FBUGpFLFNBQ09oSCxFQURQO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREY7QUFXRCxLQWhCQTtBQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQXFCRCxDQTFCRDs7QUE0QmU0RywwRUFBZixFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNyQ0E7QUFDQTtBQU1BLE1BQU14RixJQUFJLEdBQUc7QUFDWE8sV0FBUyxFQUFFLDZCQURBO0FBRVhDLGVBQWEsRUFBRSxlQUZKO0FBR1hwQixPQUFLLEVBQUUsNENBSEk7QUFJWHFCLFFBQU0sRUFBRSxjQUpHO0FBS1hDLGFBQVcsRUFBRSxVQUxGO0FBTVhJLGtCQUFnQixFQUFFLHlCQU5QO0FBT1hILFlBQVUsRUFBRSxRQVBEO0FBUVhDLGNBQVksRUFBRSxNQVJIO0FBU1hDLGVBQWEsRUFBQyxPQVRIO0FBVVhFLE1BQUksRUFBRSxDQUNKO0FBQ0UzQixTQUFLLEVBQUUsWUFEVDtBQUVFUixNQUFFLEVBQUU7QUFGTixHQURJO0FBVkssQ0FBYjs7QUFrQkEsTUFBTWlILGVBQWdDLEdBQUcsQ0FBQztBQUFFNUQ7QUFBRixDQUFELEtBQXFCO0FBQzVELHNCQUNFO0FBQUssYUFBUyxFQUFDLHNDQUFmO0FBQUEsY0FDR0EsV0FBVyxDQUFDL0IsR0FBWixDQUFnQixNQUFNO0FBQ3JCLDBCQUFPLHFFQUFDLG1GQUFELG9CQUFpQkYsSUFBakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBUDtBQUNELEtBRkE7QUFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUFPRCxDQVJEOztBQVVlNkYsOEVBQWYsRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDbkNBO0FBQ0E7QUFDQTtBQUVBLE1BQU1DLGVBQWUsR0FBRyxDQUN0QjtBQUNFck8sTUFBSSxFQUFFLE9BRFI7QUFFRW1ILElBQUUsRUFBRSxPQUZOO0FBR0VsSCxNQUFJLEVBQUU7QUFIUixDQURzQixFQU10QjtBQUNFRCxNQUFJLEVBQUUsU0FEUjtBQUVFbUgsSUFBRSxFQUFFLFNBRk47QUFHRWxILE1BQUksRUFBRTtBQUhSLENBTnNCLEVBV3RCO0FBQ0VELE1BQUksRUFBRSxZQURSO0FBRUVtSCxJQUFFLEVBQUUsWUFGTjtBQUdFbEgsTUFBSSxFQUFFO0FBSFIsQ0FYc0IsQ0FBeEI7QUFrQkEsTUFBTXVLLFdBQVcsR0FBRyxDQUFDLEVBQUQsRUFBSyxFQUFMLEVBQVMsRUFBVCxFQUFhLEVBQWIsRUFBaUIsRUFBakIsQ0FBcEI7O0FBRUEsTUFBTThELFdBQXFCLEdBQUcsTUFBTTtBQUNsQyxRQUFNLENBQUNOLFdBQUQsRUFBY08sY0FBZCxJQUFnQ2QsNENBQUssQ0FBQ0MsUUFBTixDQUNwQ1csZUFBZSxDQUFDLENBQUQsQ0FBZixDQUFtQmxILEVBRGlCLENBQXRDOztBQUlBLFFBQU04RyxhQUFhLEdBQUk5RyxFQUFELElBQWdCO0FBQ3BDb0gsa0JBQWMsQ0FBQ3BILEVBQUQsQ0FBZDtBQUNELEdBRkQ7O0FBSUEsc0JBQ0U7QUFDRSxhQUFTLEVBQUMsTUFEWjtBQUVFLFNBQUssRUFBRTtBQUFFMkMsZ0JBQVUsRUFBRSxFQUFkO0FBQWtCekYsWUFBTSxFQUFFLElBQTFCO0FBQWdDa0Ysa0JBQVksRUFBRTtBQUE5QyxLQUZUO0FBQUEsNEJBSUUscUVBQUMsb0RBQUQ7QUFDRSxhQUFPLEVBQUU4RSxlQURYO0FBRUUsaUJBQVcsRUFBRUwsV0FGZjtBQUdFLG1CQUFhLEVBQUVDO0FBSGpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBSkYsZUFTRSxxRUFBQyx3REFBRDtBQUFhLGlCQUFXLEVBQUV6RDtBQUExQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBYUQsQ0F0QkQ7O0FBd0JlOEQsMEVBQWYsRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNoREE7QUFDQTs7QUFFQSxNQUFNRSxXQUFXLEdBQUcsTUFBTTtBQUN4QixzQkFDRTtBQUFLLFNBQUssRUFBRTtBQUFFekUsZUFBUyxFQUFFLEtBQWI7QUFBb0JELGdCQUFVLEVBQUU7QUFBaEMsS0FBWjtBQUFBLDJCQUNFLHFFQUFDLG1EQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUFLRCxDQU5EOztBQVFlMEUsMEVBQWYsRTs7Ozs7Ozs7Ozs7O0FDWEE7QUFBQTtBQUFBO0FBRWVBLG1IQUFmLEU7Ozs7Ozs7Ozs7OztBQ0ZBO0FBQUE7QUFBQTtBQUVlcEIsNEdBQWYsRTs7Ozs7Ozs7Ozs7O0FDQUE7QUFBZSx5RUFBVXFCLElBQVYsRUFBZTtBQUMxQixVQUFRQSxJQUFSOztBQUdBLFNBQU8sa0JBQVA7QUFDSCxDOzs7Ozs7Ozs7OztBQ1BELGtDOzs7Ozs7Ozs7OztBQ0FBLHdDOzs7Ozs7Ozs7OztBQ0FBLGtEIiwiZmlsZSI6InBhZ2VzL2hvbWUuanMiLCJzb3VyY2VzQ29udGVudCI6WyIgXHQvLyBUaGUgbW9kdWxlIGNhY2hlXG4gXHR2YXIgaW5zdGFsbGVkTW9kdWxlcyA9IHJlcXVpcmUoJy4uL3Nzci1tb2R1bGUtY2FjaGUuanMnKTtcblxuIFx0Ly8gVGhlIHJlcXVpcmUgZnVuY3Rpb25cbiBcdGZ1bmN0aW9uIF9fd2VicGFja19yZXF1aXJlX18obW9kdWxlSWQpIHtcblxuIFx0XHQvLyBDaGVjayBpZiBtb2R1bGUgaXMgaW4gY2FjaGVcbiBcdFx0aWYoaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF0pIHtcbiBcdFx0XHRyZXR1cm4gaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF0uZXhwb3J0cztcbiBcdFx0fVxuIFx0XHQvLyBDcmVhdGUgYSBuZXcgbW9kdWxlIChhbmQgcHV0IGl0IGludG8gdGhlIGNhY2hlKVxuIFx0XHR2YXIgbW9kdWxlID0gaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF0gPSB7XG4gXHRcdFx0aTogbW9kdWxlSWQsXG4gXHRcdFx0bDogZmFsc2UsXG4gXHRcdFx0ZXhwb3J0czoge31cbiBcdFx0fTtcblxuIFx0XHQvLyBFeGVjdXRlIHRoZSBtb2R1bGUgZnVuY3Rpb25cbiBcdFx0dmFyIHRocmV3ID0gdHJ1ZTtcbiBcdFx0dHJ5IHtcbiBcdFx0XHRtb2R1bGVzW21vZHVsZUlkXS5jYWxsKG1vZHVsZS5leHBvcnRzLCBtb2R1bGUsIG1vZHVsZS5leHBvcnRzLCBfX3dlYnBhY2tfcmVxdWlyZV9fKTtcbiBcdFx0XHR0aHJldyA9IGZhbHNlO1xuIFx0XHR9IGZpbmFsbHkge1xuIFx0XHRcdGlmKHRocmV3KSBkZWxldGUgaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF07XG4gXHRcdH1cblxuIFx0XHQvLyBGbGFnIHRoZSBtb2R1bGUgYXMgbG9hZGVkXG4gXHRcdG1vZHVsZS5sID0gdHJ1ZTtcblxuIFx0XHQvLyBSZXR1cm4gdGhlIGV4cG9ydHMgb2YgdGhlIG1vZHVsZVxuIFx0XHRyZXR1cm4gbW9kdWxlLmV4cG9ydHM7XG4gXHR9XG5cblxuIFx0Ly8gZXhwb3NlIHRoZSBtb2R1bGVzIG9iamVjdCAoX193ZWJwYWNrX21vZHVsZXNfXylcbiBcdF9fd2VicGFja19yZXF1aXJlX18ubSA9IG1vZHVsZXM7XG5cbiBcdC8vIGV4cG9zZSB0aGUgbW9kdWxlIGNhY2hlXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLmMgPSBpbnN0YWxsZWRNb2R1bGVzO1xuXG4gXHQvLyBkZWZpbmUgZ2V0dGVyIGZ1bmN0aW9uIGZvciBoYXJtb255IGV4cG9ydHNcbiBcdF9fd2VicGFja19yZXF1aXJlX18uZCA9IGZ1bmN0aW9uKGV4cG9ydHMsIG5hbWUsIGdldHRlcikge1xuIFx0XHRpZighX193ZWJwYWNrX3JlcXVpcmVfXy5vKGV4cG9ydHMsIG5hbWUpKSB7XG4gXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIG5hbWUsIHsgZW51bWVyYWJsZTogdHJ1ZSwgZ2V0OiBnZXR0ZXIgfSk7XG4gXHRcdH1cbiBcdH07XG5cbiBcdC8vIGRlZmluZSBfX2VzTW9kdWxlIG9uIGV4cG9ydHNcbiBcdF9fd2VicGFja19yZXF1aXJlX18uciA9IGZ1bmN0aW9uKGV4cG9ydHMpIHtcbiBcdFx0aWYodHlwZW9mIFN5bWJvbCAhPT0gJ3VuZGVmaW5lZCcgJiYgU3ltYm9sLnRvU3RyaW5nVGFnKSB7XG4gXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFN5bWJvbC50b1N0cmluZ1RhZywgeyB2YWx1ZTogJ01vZHVsZScgfSk7XG4gXHRcdH1cbiBcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsICdfX2VzTW9kdWxlJywgeyB2YWx1ZTogdHJ1ZSB9KTtcbiBcdH07XG5cbiBcdC8vIGNyZWF0ZSBhIGZha2UgbmFtZXNwYWNlIG9iamVjdFxuIFx0Ly8gbW9kZSAmIDE6IHZhbHVlIGlzIGEgbW9kdWxlIGlkLCByZXF1aXJlIGl0XG4gXHQvLyBtb2RlICYgMjogbWVyZ2UgYWxsIHByb3BlcnRpZXMgb2YgdmFsdWUgaW50byB0aGUgbnNcbiBcdC8vIG1vZGUgJiA0OiByZXR1cm4gdmFsdWUgd2hlbiBhbHJlYWR5IG5zIG9iamVjdFxuIFx0Ly8gbW9kZSAmIDh8MTogYmVoYXZlIGxpa2UgcmVxdWlyZVxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy50ID0gZnVuY3Rpb24odmFsdWUsIG1vZGUpIHtcbiBcdFx0aWYobW9kZSAmIDEpIHZhbHVlID0gX193ZWJwYWNrX3JlcXVpcmVfXyh2YWx1ZSk7XG4gXHRcdGlmKG1vZGUgJiA4KSByZXR1cm4gdmFsdWU7XG4gXHRcdGlmKChtb2RlICYgNCkgJiYgdHlwZW9mIHZhbHVlID09PSAnb2JqZWN0JyAmJiB2YWx1ZSAmJiB2YWx1ZS5fX2VzTW9kdWxlKSByZXR1cm4gdmFsdWU7XG4gXHRcdHZhciBucyA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG4gXHRcdF9fd2VicGFja19yZXF1aXJlX18ucihucyk7XG4gXHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShucywgJ2RlZmF1bHQnLCB7IGVudW1lcmFibGU6IHRydWUsIHZhbHVlOiB2YWx1ZSB9KTtcbiBcdFx0aWYobW9kZSAmIDIgJiYgdHlwZW9mIHZhbHVlICE9ICdzdHJpbmcnKSBmb3IodmFyIGtleSBpbiB2YWx1ZSkgX193ZWJwYWNrX3JlcXVpcmVfXy5kKG5zLCBrZXksIGZ1bmN0aW9uKGtleSkgeyByZXR1cm4gdmFsdWVba2V5XTsgfS5iaW5kKG51bGwsIGtleSkpO1xuIFx0XHRyZXR1cm4gbnM7XG4gXHR9O1xuXG4gXHQvLyBnZXREZWZhdWx0RXhwb3J0IGZ1bmN0aW9uIGZvciBjb21wYXRpYmlsaXR5IHdpdGggbm9uLWhhcm1vbnkgbW9kdWxlc1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5uID0gZnVuY3Rpb24obW9kdWxlKSB7XG4gXHRcdHZhciBnZXR0ZXIgPSBtb2R1bGUgJiYgbW9kdWxlLl9fZXNNb2R1bGUgP1xuIFx0XHRcdGZ1bmN0aW9uIGdldERlZmF1bHQoKSB7IHJldHVybiBtb2R1bGVbJ2RlZmF1bHQnXTsgfSA6XG4gXHRcdFx0ZnVuY3Rpb24gZ2V0TW9kdWxlRXhwb3J0cygpIHsgcmV0dXJuIG1vZHVsZTsgfTtcbiBcdFx0X193ZWJwYWNrX3JlcXVpcmVfXy5kKGdldHRlciwgJ2EnLCBnZXR0ZXIpO1xuIFx0XHRyZXR1cm4gZ2V0dGVyO1xuIFx0fTtcblxuIFx0Ly8gT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm8gPSBmdW5jdGlvbihvYmplY3QsIHByb3BlcnR5KSB7IHJldHVybiBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob2JqZWN0LCBwcm9wZXJ0eSk7IH07XG5cbiBcdC8vIF9fd2VicGFja19wdWJsaWNfcGF0aF9fXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLnAgPSBcIlwiO1xuXG5cbiBcdC8vIExvYWQgZW50cnkgbW9kdWxlIGFuZCByZXR1cm4gZXhwb3J0c1xuIFx0cmV0dXJuIF9fd2VicGFja19yZXF1aXJlX18oX193ZWJwYWNrX3JlcXVpcmVfXy5zID0gXCIuL3BhZ2VzL2hvbWUvaW5kZXgudHN4XCIpO1xuIiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwibmV4dC9kaXN0L25leHQtc2VydmVyL2xpYi9oZWFkLmpzXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIm5leHQvZGlzdC9uZXh0LXNlcnZlci9saWIvdG8tYmFzZS02NC5qc1wiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJuZXh0L2Rpc3QvbmV4dC1zZXJ2ZXIvc2VydmVyL2ltYWdlLWNvbmZpZy5qc1wiKTsiLCJjb25zdCBmb290ZXJtZW51ID0gW1xuICB7XG4gICAga2V5OiBcImZvb3Rlcl9hYm91dFwiLFxuICAgIG5hbWU6IFwiQWJvdXRcIixcbiAgICBsaW5rOiBcIlwiLFxuICB9LFxuICB7XG4gICAga2V5OiBcImZvb3Rlcl9wb3J0Zm9saW9cIixcbiAgICBuYW1lOiBcIlBvcnRmb2xpb1wiLFxuICAgIGxpbms6IFwiL3BvcnRmb2xpb1wiLFxuICB9LFxuICB7XG4gICAga2V5OiBcImZvb3Rlcl9ibG9nXCIsXG4gICAgbmFtZTogXCJCbG9nXCIsXG4gICAgbGluazogXCJcIixcbiAgfSxcbiAge1xuICAgIGtleTogXCJmb290ZXJfYWR2aXNvcnlfdGVhbVwiLFxuICAgIG5hbWU6IFwiQWR2aXNvcnkgVGVhbVwiLFxuICAgIGxpbms6IFwiL2Fkdmlzb3J5VGVhbVwiLFxuICB9LFxuICB7XG4gICAga2V5OiBcImZvb3Rlcl9jb250YWN0XCIsXG4gICAgbmFtZTogXCJDb250YWN0XCIsXG4gICAgbGluazogXCJcIixcbiAgfSxcbiAge1xuICAgIGtleTogXCJmb290ZXJfY2FyZWVyc1wiLFxuICAgIG5hbWU6IFwiQ2FyZWVyc1wiLFxuICAgIGxpbms6IFwiXCIsXG4gIH0sXG5dO1xuXG5leHBvcnQgZGVmYXVsdCBmb290ZXJtZW51O1xuIiwiZXhwb3J0ICogZnJvbSBcIi4vZm9vdGVyTWVudVwiO1xuZXhwb3J0ICogZnJvbSBcIi4vbmF2TWVudVwiO1xuZXhwb3J0IGNvbnN0IFBSSVZBQ1lfUE9MSUNZID0gXCJNQURFIFdJVEggTE9WRSBCWSBQTEVBU0UgU0VFIFwiXG4iLCJleHBvcnQgY29uc3QgbmF2TWVudSA9IHtcbiAgcHJpbWFyeTogW1xuICAgIHtcbiAgICAgIGtleTogXCJmb290ZXJfYWJvdXRcIixcbiAgICAgIG5hbWU6IFwiQWJvdXRcIixcbiAgICAgIGxpbms6IFwiXCIsXG4gICAgfSxcbiAgICB7XG4gICAgICBrZXk6IFwiZm9vdGVyX3BvcnRmb2xpb1wiLFxuICAgICAgbmFtZTogXCJQb3J0Zm9saW9cIixcbiAgICAgIGxpbms6IFwiXCIsXG4gICAgfSxcbiAgICB7XG4gICAgICBrZXk6IFwiZm9vdGVyX2Jsb2dcIixcbiAgICAgIG5hbWU6IFwiQmxvZ1wiLFxuICAgICAgbGluazogXCJcIixcbiAgICB9LFxuICBdLFxuICBzZWNvbmRhcnk6IFtcbiAgICB7XG4gICAgICBrZXk6IFwiZm9vdGVyX2Fkdmlzb3J5X3RlYW1cIixcbiAgICAgIG5hbWU6IFwiQWR2aXNvcnkgVGVhbVwiLFxuICAgICAgbGluazogXCJcIixcbiAgICB9LFxuICAgIHtcbiAgICAgIGtleTogXCJmb290ZXJfY29udGFjdFwiLFxuICAgICAgbmFtZTogXCJDb250YWN0XCIsXG4gICAgICBsaW5rOiBcIlwiLFxuICAgIH0sXG4gICAge1xuICAgICAga2V5OiBcImZvb3Rlcl9jYXJlZXJzXCIsXG4gICAgICBuYW1lOiBcIkNhcmVlcnNcIixcbiAgICAgIGxpbms6IFwiXCIsXG4gICAgfSxcbiAgXSxcbn07XG5cbmV4cG9ydCBkZWZhdWx0IG5hdk1lbnU7XG4iLCJmdW5jdGlvbiBfZXh0ZW5kcygpIHtcbiAgbW9kdWxlLmV4cG9ydHMgPSBfZXh0ZW5kcyA9IE9iamVjdC5hc3NpZ24gfHwgZnVuY3Rpb24gKHRhcmdldCkge1xuICAgIGZvciAodmFyIGkgPSAxOyBpIDwgYXJndW1lbnRzLmxlbmd0aDsgaSsrKSB7XG4gICAgICB2YXIgc291cmNlID0gYXJndW1lbnRzW2ldO1xuXG4gICAgICBmb3IgKHZhciBrZXkgaW4gc291cmNlKSB7XG4gICAgICAgIGlmIChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwoc291cmNlLCBrZXkpKSB7XG4gICAgICAgICAgdGFyZ2V0W2tleV0gPSBzb3VyY2Vba2V5XTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiB0YXJnZXQ7XG4gIH07XG5cbiAgcmV0dXJuIF9leHRlbmRzLmFwcGx5KHRoaXMsIGFyZ3VtZW50cyk7XG59XG5cbm1vZHVsZS5leHBvcnRzID0gX2V4dGVuZHM7IiwiZnVuY3Rpb24gX2ludGVyb3BSZXF1aXJlRGVmYXVsdChvYmopIHtcbiAgcmV0dXJuIG9iaiAmJiBvYmouX19lc01vZHVsZSA/IG9iaiA6IHtcbiAgICBcImRlZmF1bHRcIjogb2JqXG4gIH07XG59XG5cbm1vZHVsZS5leHBvcnRzID0gX2ludGVyb3BSZXF1aXJlRGVmYXVsdDsiLCJmdW5jdGlvbiBfb2JqZWN0V2l0aG91dFByb3BlcnRpZXNMb29zZShzb3VyY2UsIGV4Y2x1ZGVkKSB7XG4gIGlmIChzb3VyY2UgPT0gbnVsbCkgcmV0dXJuIHt9O1xuICB2YXIgdGFyZ2V0ID0ge307XG4gIHZhciBzb3VyY2VLZXlzID0gT2JqZWN0LmtleXMoc291cmNlKTtcbiAgdmFyIGtleSwgaTtcblxuICBmb3IgKGkgPSAwOyBpIDwgc291cmNlS2V5cy5sZW5ndGg7IGkrKykge1xuICAgIGtleSA9IHNvdXJjZUtleXNbaV07XG4gICAgaWYgKGV4Y2x1ZGVkLmluZGV4T2Yoa2V5KSA+PSAwKSBjb250aW51ZTtcbiAgICB0YXJnZXRba2V5XSA9IHNvdXJjZVtrZXldO1xuICB9XG5cbiAgcmV0dXJuIHRhcmdldDtcbn1cblxubW9kdWxlLmV4cG9ydHMgPSBfb2JqZWN0V2l0aG91dFByb3BlcnRpZXNMb29zZTsiLCJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnXG5pbXBvcnQgSGVhZCBmcm9tICcuLi9uZXh0LXNlcnZlci9saWIvaGVhZCdcbmltcG9ydCB7IHRvQmFzZTY0IH0gZnJvbSAnLi4vbmV4dC1zZXJ2ZXIvbGliL3RvLWJhc2UtNjQnXG5pbXBvcnQge1xuICBJbWFnZUNvbmZpZyxcbiAgaW1hZ2VDb25maWdEZWZhdWx0LFxuICBMb2FkZXJWYWx1ZSxcbiAgVkFMSURfTE9BREVSUyxcbn0gZnJvbSAnLi4vbmV4dC1zZXJ2ZXIvc2VydmVyL2ltYWdlLWNvbmZpZydcbmltcG9ydCB7IHVzZUludGVyc2VjdGlvbiB9IGZyb20gJy4vdXNlLWludGVyc2VjdGlvbidcblxuaWYgKHR5cGVvZiB3aW5kb3cgPT09ICd1bmRlZmluZWQnKSB7XG4gIDsoZ2xvYmFsIGFzIGFueSkuX19ORVhUX0lNQUdFX0lNUE9SVEVEID0gdHJ1ZVxufVxuXG5jb25zdCBWQUxJRF9MT0FESU5HX1ZBTFVFUyA9IFsnbGF6eScsICdlYWdlcicsIHVuZGVmaW5lZF0gYXMgY29uc3RcbnR5cGUgTG9hZGluZ1ZhbHVlID0gdHlwZW9mIFZBTElEX0xPQURJTkdfVkFMVUVTW251bWJlcl1cblxuZXhwb3J0IHR5cGUgSW1hZ2VMb2FkZXIgPSAocmVzb2x2ZXJQcm9wczogSW1hZ2VMb2FkZXJQcm9wcykgPT4gc3RyaW5nXG5cbmV4cG9ydCB0eXBlIEltYWdlTG9hZGVyUHJvcHMgPSB7XG4gIHNyYzogc3RyaW5nXG4gIHdpZHRoOiBudW1iZXJcbiAgcXVhbGl0eT86IG51bWJlclxufVxuXG50eXBlIERlZmF1bHRJbWFnZUxvYWRlclByb3BzID0gSW1hZ2VMb2FkZXJQcm9wcyAmIHsgcm9vdDogc3RyaW5nIH1cblxuY29uc3QgbG9hZGVycyA9IG5ldyBNYXA8XG4gIExvYWRlclZhbHVlLFxuICAocHJvcHM6IERlZmF1bHRJbWFnZUxvYWRlclByb3BzKSA9PiBzdHJpbmdcbj4oW1xuICBbJ2ltZ2l4JywgaW1naXhMb2FkZXJdLFxuICBbJ2Nsb3VkaW5hcnknLCBjbG91ZGluYXJ5TG9hZGVyXSxcbiAgWydha2FtYWknLCBha2FtYWlMb2FkZXJdLFxuICBbJ2RlZmF1bHQnLCBkZWZhdWx0TG9hZGVyXSxcbl0pXG5cbmNvbnN0IFZBTElEX0xBWU9VVF9WQUxVRVMgPSBbXG4gICdmaWxsJyxcbiAgJ2ZpeGVkJyxcbiAgJ2ludHJpbnNpYycsXG4gICdyZXNwb25zaXZlJyxcbiAgdW5kZWZpbmVkLFxuXSBhcyBjb25zdFxudHlwZSBMYXlvdXRWYWx1ZSA9IHR5cGVvZiBWQUxJRF9MQVlPVVRfVkFMVUVTW251bWJlcl1cblxudHlwZSBJbWdFbGVtZW50U3R5bGUgPSBOb25OdWxsYWJsZTxKU1guSW50cmluc2ljRWxlbWVudHNbJ2ltZyddWydzdHlsZSddPlxuXG5leHBvcnQgdHlwZSBJbWFnZVByb3BzID0gT21pdDxcbiAgSlNYLkludHJpbnNpY0VsZW1lbnRzWydpbWcnXSxcbiAgJ3NyYycgfCAnc3JjU2V0JyB8ICdyZWYnIHwgJ3dpZHRoJyB8ICdoZWlnaHQnIHwgJ2xvYWRpbmcnIHwgJ3N0eWxlJ1xuPiAmIHtcbiAgc3JjOiBzdHJpbmdcbiAgbG9hZGVyPzogSW1hZ2VMb2FkZXJcbiAgcXVhbGl0eT86IG51bWJlciB8IHN0cmluZ1xuICBwcmlvcml0eT86IGJvb2xlYW5cbiAgbG9hZGluZz86IExvYWRpbmdWYWx1ZVxuICB1bm9wdGltaXplZD86IGJvb2xlYW5cbiAgb2JqZWN0Rml0PzogSW1nRWxlbWVudFN0eWxlWydvYmplY3RGaXQnXVxuICBvYmplY3RQb3NpdGlvbj86IEltZ0VsZW1lbnRTdHlsZVsnb2JqZWN0UG9zaXRpb24nXVxufSAmIChcbiAgICB8IHtcbiAgICAgICAgd2lkdGg/OiBuZXZlclxuICAgICAgICBoZWlnaHQ/OiBuZXZlclxuICAgICAgICAvKiogQGRlcHJlY2F0ZWQgVXNlIGBsYXlvdXQ9XCJmaWxsXCJgIGluc3RlYWQgKi9cbiAgICAgICAgdW5zaXplZDogdHJ1ZVxuICAgICAgfVxuICAgIHwgeyB3aWR0aD86IG5ldmVyOyBoZWlnaHQ/OiBuZXZlcjsgbGF5b3V0OiAnZmlsbCcgfVxuICAgIHwge1xuICAgICAgICB3aWR0aDogbnVtYmVyIHwgc3RyaW5nXG4gICAgICAgIGhlaWdodDogbnVtYmVyIHwgc3RyaW5nXG4gICAgICAgIGxheW91dD86IEV4Y2x1ZGU8TGF5b3V0VmFsdWUsICdmaWxsJz5cbiAgICAgIH1cbiAgKVxuXG5jb25zdCB7XG4gIGRldmljZVNpemVzOiBjb25maWdEZXZpY2VTaXplcyxcbiAgaW1hZ2VTaXplczogY29uZmlnSW1hZ2VTaXplcyxcbiAgbG9hZGVyOiBjb25maWdMb2FkZXIsXG4gIHBhdGg6IGNvbmZpZ1BhdGgsXG4gIGRvbWFpbnM6IGNvbmZpZ0RvbWFpbnMsXG59ID1cbiAgKChwcm9jZXNzLmVudi5fX05FWFRfSU1BR0VfT1BUUyBhcyBhbnkpIGFzIEltYWdlQ29uZmlnKSB8fCBpbWFnZUNvbmZpZ0RlZmF1bHRcbi8vIHNvcnQgc21hbGxlc3QgdG8gbGFyZ2VzdFxuY29uc3QgYWxsU2l6ZXMgPSBbLi4uY29uZmlnRGV2aWNlU2l6ZXMsIC4uLmNvbmZpZ0ltYWdlU2l6ZXNdXG5jb25maWdEZXZpY2VTaXplcy5zb3J0KChhLCBiKSA9PiBhIC0gYilcbmFsbFNpemVzLnNvcnQoKGEsIGIpID0+IGEgLSBiKVxuXG5mdW5jdGlvbiBnZXRXaWR0aHMoXG4gIHdpZHRoOiBudW1iZXIgfCB1bmRlZmluZWQsXG4gIGxheW91dDogTGF5b3V0VmFsdWUsXG4gIHNpemVzOiBzdHJpbmcgfCB1bmRlZmluZWRcbik6IHsgd2lkdGhzOiBudW1iZXJbXTsga2luZDogJ3cnIHwgJ3gnIH0ge1xuICBpZiAoc2l6ZXMgJiYgKGxheW91dCA9PT0gJ2ZpbGwnIHx8IGxheW91dCA9PT0gJ3Jlc3BvbnNpdmUnKSkge1xuICAgIC8vIEZpbmQgYWxsIHRoZSBcInZ3XCIgcGVyY2VudCBzaXplcyB1c2VkIGluIHRoZSBzaXplcyBwcm9wXG4gICAgY29uc3QgcGVyY2VudFNpemVzID0gWy4uLnNpemVzLm1hdGNoQWxsKC8oXnxcXHMpKDE/XFxkP1xcZCl2dy9nKV0ubWFwKChtKSA9PlxuICAgICAgcGFyc2VJbnQobVsyXSlcbiAgICApXG4gICAgaWYgKHBlcmNlbnRTaXplcy5sZW5ndGgpIHtcbiAgICAgIGNvbnN0IHNtYWxsZXN0UmF0aW8gPSBNYXRoLm1pbiguLi5wZXJjZW50U2l6ZXMpICogMC4wMVxuICAgICAgcmV0dXJuIHtcbiAgICAgICAgd2lkdGhzOiBhbGxTaXplcy5maWx0ZXIoXG4gICAgICAgICAgKHMpID0+IHMgPj0gY29uZmlnRGV2aWNlU2l6ZXNbMF0gKiBzbWFsbGVzdFJhdGlvXG4gICAgICAgICksXG4gICAgICAgIGtpbmQ6ICd3JyxcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHsgd2lkdGhzOiBhbGxTaXplcywga2luZDogJ3cnIH1cbiAgfVxuICBpZiAoXG4gICAgdHlwZW9mIHdpZHRoICE9PSAnbnVtYmVyJyB8fFxuICAgIGxheW91dCA9PT0gJ2ZpbGwnIHx8XG4gICAgbGF5b3V0ID09PSAncmVzcG9uc2l2ZSdcbiAgKSB7XG4gICAgcmV0dXJuIHsgd2lkdGhzOiBjb25maWdEZXZpY2VTaXplcywga2luZDogJ3cnIH1cbiAgfVxuXG4gIGNvbnN0IHdpZHRocyA9IFtcbiAgICAuLi5uZXcgU2V0KFxuICAgICAgLy8gPiBUaGlzIG1lYW5zIHRoYXQgbW9zdCBPTEVEIHNjcmVlbnMgdGhhdCBzYXkgdGhleSBhcmUgM3ggcmVzb2x1dGlvbixcbiAgICAgIC8vID4gYXJlIGFjdHVhbGx5IDN4IGluIHRoZSBncmVlbiBjb2xvciwgYnV0IG9ubHkgMS41eCBpbiB0aGUgcmVkIGFuZFxuICAgICAgLy8gPiBibHVlIGNvbG9ycy4gU2hvd2luZyBhIDN4IHJlc29sdXRpb24gaW1hZ2UgaW4gdGhlIGFwcCB2cyBhIDJ4XG4gICAgICAvLyA+IHJlc29sdXRpb24gaW1hZ2Ugd2lsbCBiZSB2aXN1YWxseSB0aGUgc2FtZSwgdGhvdWdoIHRoZSAzeCBpbWFnZVxuICAgICAgLy8gPiB0YWtlcyBzaWduaWZpY2FudGx5IG1vcmUgZGF0YS4gRXZlbiB0cnVlIDN4IHJlc29sdXRpb24gc2NyZWVucyBhcmVcbiAgICAgIC8vID4gd2FzdGVmdWwgYXMgdGhlIGh1bWFuIGV5ZSBjYW5ub3Qgc2VlIHRoYXQgbGV2ZWwgb2YgZGV0YWlsIHdpdGhvdXRcbiAgICAgIC8vID4gc29tZXRoaW5nIGxpa2UgYSBtYWduaWZ5aW5nIGdsYXNzLlxuICAgICAgLy8gaHR0cHM6Ly9ibG9nLnR3aXR0ZXIuY29tL2VuZ2luZWVyaW5nL2VuX3VzL3RvcGljcy9pbmZyYXN0cnVjdHVyZS8yMDE5L2NhcHBpbmctaW1hZ2UtZmlkZWxpdHktb24tdWx0cmEtaGlnaC1yZXNvbHV0aW9uLWRldmljZXMuaHRtbFxuICAgICAgW3dpZHRoLCB3aWR0aCAqIDIgLyosIHdpZHRoICogMyovXS5tYXAoXG4gICAgICAgICh3KSA9PiBhbGxTaXplcy5maW5kKChwKSA9PiBwID49IHcpIHx8IGFsbFNpemVzW2FsbFNpemVzLmxlbmd0aCAtIDFdXG4gICAgICApXG4gICAgKSxcbiAgXVxuICByZXR1cm4geyB3aWR0aHMsIGtpbmQ6ICd4JyB9XG59XG5cbnR5cGUgR2VuSW1nQXR0cnNEYXRhID0ge1xuICBzcmM6IHN0cmluZ1xuICB1bm9wdGltaXplZDogYm9vbGVhblxuICBsYXlvdXQ6IExheW91dFZhbHVlXG4gIGxvYWRlcjogSW1hZ2VMb2FkZXJcbiAgd2lkdGg/OiBudW1iZXJcbiAgcXVhbGl0eT86IG51bWJlclxuICBzaXplcz86IHN0cmluZ1xufVxuXG50eXBlIEdlbkltZ0F0dHJzUmVzdWx0ID0ge1xuICBzcmM6IHN0cmluZ1xuICBzcmNTZXQ6IHN0cmluZyB8IHVuZGVmaW5lZFxuICBzaXplczogc3RyaW5nIHwgdW5kZWZpbmVkXG59XG5cbmZ1bmN0aW9uIGdlbmVyYXRlSW1nQXR0cnMoe1xuICBzcmMsXG4gIHVub3B0aW1pemVkLFxuICBsYXlvdXQsXG4gIHdpZHRoLFxuICBxdWFsaXR5LFxuICBzaXplcyxcbiAgbG9hZGVyLFxufTogR2VuSW1nQXR0cnNEYXRhKTogR2VuSW1nQXR0cnNSZXN1bHQge1xuICBpZiAodW5vcHRpbWl6ZWQpIHtcbiAgICByZXR1cm4geyBzcmMsIHNyY1NldDogdW5kZWZpbmVkLCBzaXplczogdW5kZWZpbmVkIH1cbiAgfVxuXG4gIGNvbnN0IHsgd2lkdGhzLCBraW5kIH0gPSBnZXRXaWR0aHMod2lkdGgsIGxheW91dCwgc2l6ZXMpXG4gIGNvbnN0IGxhc3QgPSB3aWR0aHMubGVuZ3RoIC0gMVxuXG4gIHJldHVybiB7XG4gICAgc2l6ZXM6ICFzaXplcyAmJiBraW5kID09PSAndycgPyAnMTAwdncnIDogc2l6ZXMsXG4gICAgc3JjU2V0OiB3aWR0aHNcbiAgICAgIC5tYXAoXG4gICAgICAgICh3LCBpKSA9PlxuICAgICAgICAgIGAke2xvYWRlcih7IHNyYywgcXVhbGl0eSwgd2lkdGg6IHcgfSl9ICR7XG4gICAgICAgICAgICBraW5kID09PSAndycgPyB3IDogaSArIDFcbiAgICAgICAgICB9JHtraW5kfWBcbiAgICAgIClcbiAgICAgIC5qb2luKCcsICcpLFxuXG4gICAgLy8gSXQncyBpbnRlbmRlZCB0byBrZWVwIGBzcmNgIHRoZSBsYXN0IGF0dHJpYnV0ZSBiZWNhdXNlIFJlYWN0IHVwZGF0ZXNcbiAgICAvLyBhdHRyaWJ1dGVzIGluIG9yZGVyLiBJZiB3ZSBrZWVwIGBzcmNgIHRoZSBmaXJzdCBvbmUsIFNhZmFyaSB3aWxsXG4gICAgLy8gaW1tZWRpYXRlbHkgc3RhcnQgdG8gZmV0Y2ggYHNyY2AsIGJlZm9yZSBgc2l6ZXNgIGFuZCBgc3JjU2V0YCBhcmUgZXZlblxuICAgIC8vIHVwZGF0ZWQgYnkgUmVhY3QuIFRoYXQgY2F1c2VzIG11bHRpcGxlIHVubmVjZXNzYXJ5IHJlcXVlc3RzIGlmIGBzcmNTZXRgXG4gICAgLy8gYW5kIGBzaXplc2AgYXJlIGRlZmluZWQuXG4gICAgLy8gVGhpcyBidWcgY2Fubm90IGJlIHJlcHJvZHVjZWQgaW4gQ2hyb21lIG9yIEZpcmVmb3guXG4gICAgc3JjOiBsb2FkZXIoeyBzcmMsIHF1YWxpdHksIHdpZHRoOiB3aWR0aHNbbGFzdF0gfSksXG4gIH1cbn1cblxuZnVuY3Rpb24gZ2V0SW50KHg6IHVua25vd24pOiBudW1iZXIgfCB1bmRlZmluZWQge1xuICBpZiAodHlwZW9mIHggPT09ICdudW1iZXInKSB7XG4gICAgcmV0dXJuIHhcbiAgfVxuICBpZiAodHlwZW9mIHggPT09ICdzdHJpbmcnKSB7XG4gICAgcmV0dXJuIHBhcnNlSW50KHgsIDEwKVxuICB9XG4gIHJldHVybiB1bmRlZmluZWRcbn1cblxuZnVuY3Rpb24gZGVmYXVsdEltYWdlTG9hZGVyKGxvYWRlclByb3BzOiBJbWFnZUxvYWRlclByb3BzKSB7XG4gIGNvbnN0IGxvYWQgPSBsb2FkZXJzLmdldChjb25maWdMb2FkZXIpXG4gIGlmIChsb2FkKSB7XG4gICAgcmV0dXJuIGxvYWQoeyByb290OiBjb25maWdQYXRoLCAuLi5sb2FkZXJQcm9wcyB9KVxuICB9XG4gIHRocm93IG5ldyBFcnJvcihcbiAgICBgVW5rbm93biBcImxvYWRlclwiIGZvdW5kIGluIFwibmV4dC5jb25maWcuanNcIi4gRXhwZWN0ZWQ6ICR7VkFMSURfTE9BREVSUy5qb2luKFxuICAgICAgJywgJ1xuICAgICl9LiBSZWNlaXZlZDogJHtjb25maWdMb2FkZXJ9YFxuICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEltYWdlKHtcbiAgc3JjLFxuICBzaXplcyxcbiAgdW5vcHRpbWl6ZWQgPSBmYWxzZSxcbiAgcHJpb3JpdHkgPSBmYWxzZSxcbiAgbG9hZGluZyxcbiAgY2xhc3NOYW1lLFxuICBxdWFsaXR5LFxuICB3aWR0aCxcbiAgaGVpZ2h0LFxuICBvYmplY3RGaXQsXG4gIG9iamVjdFBvc2l0aW9uLFxuICBsb2FkZXIgPSBkZWZhdWx0SW1hZ2VMb2FkZXIsXG4gIC4uLmFsbFxufTogSW1hZ2VQcm9wcykge1xuICBsZXQgcmVzdDogUGFydGlhbDxJbWFnZVByb3BzPiA9IGFsbFxuICBsZXQgbGF5b3V0OiBOb25OdWxsYWJsZTxMYXlvdXRWYWx1ZT4gPSBzaXplcyA/ICdyZXNwb25zaXZlJyA6ICdpbnRyaW5zaWMnXG4gIGxldCB1bnNpemVkID0gZmFsc2VcbiAgaWYgKCd1bnNpemVkJyBpbiByZXN0KSB7XG4gICAgdW5zaXplZCA9IEJvb2xlYW4ocmVzdC51bnNpemVkKVxuICAgIC8vIFJlbW92ZSBwcm9wZXJ0eSBzbyBpdCdzIG5vdCBzcHJlYWQgaW50byBpbWFnZTpcbiAgICBkZWxldGUgcmVzdFsndW5zaXplZCddXG4gIH0gZWxzZSBpZiAoJ2xheW91dCcgaW4gcmVzdCkge1xuICAgIC8vIE92ZXJyaWRlIGRlZmF1bHQgbGF5b3V0IGlmIHRoZSB1c2VyIHNwZWNpZmllZCBvbmU6XG4gICAgaWYgKHJlc3QubGF5b3V0KSBsYXlvdXQgPSByZXN0LmxheW91dFxuXG4gICAgLy8gUmVtb3ZlIHByb3BlcnR5IHNvIGl0J3Mgbm90IHNwcmVhZCBpbnRvIGltYWdlOlxuICAgIGRlbGV0ZSByZXN0WydsYXlvdXQnXVxuICB9XG5cbiAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHtcbiAgICBpZiAoIXNyYykge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICBgSW1hZ2UgaXMgbWlzc2luZyByZXF1aXJlZCBcInNyY1wiIHByb3BlcnR5LiBNYWtlIHN1cmUgeW91IHBhc3MgXCJzcmNcIiBpbiBwcm9wcyB0byB0aGUgXFxgbmV4dC9pbWFnZVxcYCBjb21wb25lbnQuIFJlY2VpdmVkOiAke0pTT04uc3RyaW5naWZ5KFxuICAgICAgICAgIHsgd2lkdGgsIGhlaWdodCwgcXVhbGl0eSB9XG4gICAgICAgICl9YFxuICAgICAgKVxuICAgIH1cbiAgICBpZiAoIVZBTElEX0xBWU9VVF9WQUxVRVMuaW5jbHVkZXMobGF5b3V0KSkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICBgSW1hZ2Ugd2l0aCBzcmMgXCIke3NyY31cIiBoYXMgaW52YWxpZCBcImxheW91dFwiIHByb3BlcnR5LiBQcm92aWRlZCBcIiR7bGF5b3V0fVwiIHNob3VsZCBiZSBvbmUgb2YgJHtWQUxJRF9MQVlPVVRfVkFMVUVTLm1hcChcbiAgICAgICAgICBTdHJpbmdcbiAgICAgICAgKS5qb2luKCcsJyl9LmBcbiAgICAgIClcbiAgICB9XG4gICAgaWYgKCFWQUxJRF9MT0FESU5HX1ZBTFVFUy5pbmNsdWRlcyhsb2FkaW5nKSkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICBgSW1hZ2Ugd2l0aCBzcmMgXCIke3NyY31cIiBoYXMgaW52YWxpZCBcImxvYWRpbmdcIiBwcm9wZXJ0eS4gUHJvdmlkZWQgXCIke2xvYWRpbmd9XCIgc2hvdWxkIGJlIG9uZSBvZiAke1ZBTElEX0xPQURJTkdfVkFMVUVTLm1hcChcbiAgICAgICAgICBTdHJpbmdcbiAgICAgICAgKS5qb2luKCcsJyl9LmBcbiAgICAgIClcbiAgICB9XG4gICAgaWYgKHByaW9yaXR5ICYmIGxvYWRpbmcgPT09ICdsYXp5Jykge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICBgSW1hZ2Ugd2l0aCBzcmMgXCIke3NyY31cIiBoYXMgYm90aCBcInByaW9yaXR5XCIgYW5kIFwibG9hZGluZz0nbGF6eSdcIiBwcm9wZXJ0aWVzLiBPbmx5IG9uZSBzaG91bGQgYmUgdXNlZC5gXG4gICAgICApXG4gICAgfVxuICAgIGlmICh1bnNpemVkKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgIGBJbWFnZSB3aXRoIHNyYyBcIiR7c3JjfVwiIGhhcyBkZXByZWNhdGVkIFwidW5zaXplZFwiIHByb3BlcnR5LCB3aGljaCB3YXMgcmVtb3ZlZCBpbiBmYXZvciBvZiB0aGUgXCJsYXlvdXQ9J2ZpbGwnXCIgcHJvcGVydHlgXG4gICAgICApXG4gICAgfVxuICB9XG5cbiAgbGV0IGlzTGF6eSA9XG4gICAgIXByaW9yaXR5ICYmIChsb2FkaW5nID09PSAnbGF6eScgfHwgdHlwZW9mIGxvYWRpbmcgPT09ICd1bmRlZmluZWQnKVxuICBpZiAoc3JjICYmIHNyYy5zdGFydHNXaXRoKCdkYXRhOicpKSB7XG4gICAgLy8gaHR0cHM6Ly9kZXZlbG9wZXIubW96aWxsYS5vcmcvZW4tVVMvZG9jcy9XZWIvSFRUUC9CYXNpY3Nfb2ZfSFRUUC9EYXRhX1VSSXNcbiAgICB1bm9wdGltaXplZCA9IHRydWVcbiAgICBpc0xhenkgPSBmYWxzZVxuICB9XG5cbiAgY29uc3QgW3NldFJlZiwgaXNJbnRlcnNlY3RlZF0gPSB1c2VJbnRlcnNlY3Rpb248SFRNTEltYWdlRWxlbWVudD4oe1xuICAgIHJvb3RNYXJnaW46ICcyMDBweCcsXG4gICAgZGlzYWJsZWQ6ICFpc0xhenksXG4gIH0pXG4gIGNvbnN0IGlzVmlzaWJsZSA9ICFpc0xhenkgfHwgaXNJbnRlcnNlY3RlZFxuXG4gIGNvbnN0IHdpZHRoSW50ID0gZ2V0SW50KHdpZHRoKVxuICBjb25zdCBoZWlnaHRJbnQgPSBnZXRJbnQoaGVpZ2h0KVxuICBjb25zdCBxdWFsaXR5SW50ID0gZ2V0SW50KHF1YWxpdHkpXG5cbiAgbGV0IHdyYXBwZXJTdHlsZTogSlNYLkludHJpbnNpY0VsZW1lbnRzWydkaXYnXVsnc3R5bGUnXSB8IHVuZGVmaW5lZFxuICBsZXQgc2l6ZXJTdHlsZTogSlNYLkludHJpbnNpY0VsZW1lbnRzWydkaXYnXVsnc3R5bGUnXSB8IHVuZGVmaW5lZFxuICBsZXQgc2l6ZXJTdmc6IHN0cmluZyB8IHVuZGVmaW5lZFxuICBsZXQgaW1nU3R5bGU6IEltZ0VsZW1lbnRTdHlsZSB8IHVuZGVmaW5lZCA9IHtcbiAgICBwb3NpdGlvbjogJ2Fic29sdXRlJyxcbiAgICB0b3A6IDAsXG4gICAgbGVmdDogMCxcbiAgICBib3R0b206IDAsXG4gICAgcmlnaHQ6IDAsXG5cbiAgICBib3hTaXppbmc6ICdib3JkZXItYm94JyxcbiAgICBwYWRkaW5nOiAwLFxuICAgIGJvcmRlcjogJ25vbmUnLFxuICAgIG1hcmdpbjogJ2F1dG8nLFxuXG4gICAgZGlzcGxheTogJ2Jsb2NrJyxcbiAgICB3aWR0aDogMCxcbiAgICBoZWlnaHQ6IDAsXG4gICAgbWluV2lkdGg6ICcxMDAlJyxcbiAgICBtYXhXaWR0aDogJzEwMCUnLFxuICAgIG1pbkhlaWdodDogJzEwMCUnLFxuICAgIG1heEhlaWdodDogJzEwMCUnLFxuXG4gICAgb2JqZWN0Rml0LFxuICAgIG9iamVjdFBvc2l0aW9uLFxuICB9XG4gIGlmIChcbiAgICB0eXBlb2Ygd2lkdGhJbnQgIT09ICd1bmRlZmluZWQnICYmXG4gICAgdHlwZW9mIGhlaWdodEludCAhPT0gJ3VuZGVmaW5lZCcgJiZcbiAgICBsYXlvdXQgIT09ICdmaWxsJ1xuICApIHtcbiAgICAvLyA8SW1hZ2Ugc3JjPVwiaS5wbmdcIiB3aWR0aD1cIjEwMFwiIGhlaWdodD1cIjEwMFwiIC8+XG4gICAgY29uc3QgcXVvdGllbnQgPSBoZWlnaHRJbnQgLyB3aWR0aEludFxuICAgIGNvbnN0IHBhZGRpbmdUb3AgPSBpc05hTihxdW90aWVudCkgPyAnMTAwJScgOiBgJHtxdW90aWVudCAqIDEwMH0lYFxuICAgIGlmIChsYXlvdXQgPT09ICdyZXNwb25zaXZlJykge1xuICAgICAgLy8gPEltYWdlIHNyYz1cImkucG5nXCIgd2lkdGg9XCIxMDBcIiBoZWlnaHQ9XCIxMDBcIiBsYXlvdXQ9XCJyZXNwb25zaXZlXCIgLz5cbiAgICAgIHdyYXBwZXJTdHlsZSA9IHtcbiAgICAgICAgZGlzcGxheTogJ2Jsb2NrJyxcbiAgICAgICAgb3ZlcmZsb3c6ICdoaWRkZW4nLFxuICAgICAgICBwb3NpdGlvbjogJ3JlbGF0aXZlJyxcblxuICAgICAgICBib3hTaXppbmc6ICdib3JkZXItYm94JyxcbiAgICAgICAgbWFyZ2luOiAwLFxuICAgICAgfVxuICAgICAgc2l6ZXJTdHlsZSA9IHsgZGlzcGxheTogJ2Jsb2NrJywgYm94U2l6aW5nOiAnYm9yZGVyLWJveCcsIHBhZGRpbmdUb3AgfVxuICAgIH0gZWxzZSBpZiAobGF5b3V0ID09PSAnaW50cmluc2ljJykge1xuICAgICAgLy8gPEltYWdlIHNyYz1cImkucG5nXCIgd2lkdGg9XCIxMDBcIiBoZWlnaHQ9XCIxMDBcIiBsYXlvdXQ9XCJpbnRyaW5zaWNcIiAvPlxuICAgICAgd3JhcHBlclN0eWxlID0ge1xuICAgICAgICBkaXNwbGF5OiAnaW5saW5lLWJsb2NrJyxcbiAgICAgICAgbWF4V2lkdGg6ICcxMDAlJyxcbiAgICAgICAgb3ZlcmZsb3c6ICdoaWRkZW4nLFxuICAgICAgICBwb3NpdGlvbjogJ3JlbGF0aXZlJyxcbiAgICAgICAgYm94U2l6aW5nOiAnYm9yZGVyLWJveCcsXG4gICAgICAgIG1hcmdpbjogMCxcbiAgICAgIH1cbiAgICAgIHNpemVyU3R5bGUgPSB7XG4gICAgICAgIGJveFNpemluZzogJ2JvcmRlci1ib3gnLFxuICAgICAgICBkaXNwbGF5OiAnYmxvY2snLFxuICAgICAgICBtYXhXaWR0aDogJzEwMCUnLFxuICAgICAgfVxuICAgICAgc2l6ZXJTdmcgPSBgPHN2ZyB3aWR0aD1cIiR7d2lkdGhJbnR9XCIgaGVpZ2h0PVwiJHtoZWlnaHRJbnR9XCIgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiIHZlcnNpb249XCIxLjFcIi8+YFxuICAgIH0gZWxzZSBpZiAobGF5b3V0ID09PSAnZml4ZWQnKSB7XG4gICAgICAvLyA8SW1hZ2Ugc3JjPVwiaS5wbmdcIiB3aWR0aD1cIjEwMFwiIGhlaWdodD1cIjEwMFwiIGxheW91dD1cImZpeGVkXCIgLz5cbiAgICAgIHdyYXBwZXJTdHlsZSA9IHtcbiAgICAgICAgb3ZlcmZsb3c6ICdoaWRkZW4nLFxuICAgICAgICBib3hTaXppbmc6ICdib3JkZXItYm94JyxcbiAgICAgICAgZGlzcGxheTogJ2lubGluZS1ibG9jaycsXG4gICAgICAgIHBvc2l0aW9uOiAncmVsYXRpdmUnLFxuICAgICAgICB3aWR0aDogd2lkdGhJbnQsXG4gICAgICAgIGhlaWdodDogaGVpZ2h0SW50LFxuICAgICAgfVxuICAgIH1cbiAgfSBlbHNlIGlmIChcbiAgICB0eXBlb2Ygd2lkdGhJbnQgPT09ICd1bmRlZmluZWQnICYmXG4gICAgdHlwZW9mIGhlaWdodEludCA9PT0gJ3VuZGVmaW5lZCcgJiZcbiAgICBsYXlvdXQgPT09ICdmaWxsJ1xuICApIHtcbiAgICAvLyA8SW1hZ2Ugc3JjPVwiaS5wbmdcIiBsYXlvdXQ9XCJmaWxsXCIgLz5cbiAgICB3cmFwcGVyU3R5bGUgPSB7XG4gICAgICBkaXNwbGF5OiAnYmxvY2snLFxuICAgICAgb3ZlcmZsb3c6ICdoaWRkZW4nLFxuXG4gICAgICBwb3NpdGlvbjogJ2Fic29sdXRlJyxcbiAgICAgIHRvcDogMCxcbiAgICAgIGxlZnQ6IDAsXG4gICAgICBib3R0b206IDAsXG4gICAgICByaWdodDogMCxcblxuICAgICAgYm94U2l6aW5nOiAnYm9yZGVyLWJveCcsXG4gICAgICBtYXJnaW46IDAsXG4gICAgfVxuICB9IGVsc2Uge1xuICAgIC8vIDxJbWFnZSBzcmM9XCJpLnBuZ1wiIC8+XG4gICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICAgYEltYWdlIHdpdGggc3JjIFwiJHtzcmN9XCIgbXVzdCB1c2UgXCJ3aWR0aFwiIGFuZCBcImhlaWdodFwiIHByb3BlcnRpZXMgb3IgXCJsYXlvdXQ9J2ZpbGwnXCIgcHJvcGVydHkuYFxuICAgICAgKVxuICAgIH1cbiAgfVxuXG4gIGxldCBpbWdBdHRyaWJ1dGVzOiBHZW5JbWdBdHRyc1Jlc3VsdCA9IHtcbiAgICBzcmM6XG4gICAgICAnZGF0YTppbWFnZS9naWY7YmFzZTY0LFIwbEdPRGxoQVFBQkFJQUFBQUFBQVAvLy95SDVCQUVBQUFBQUxBQUFBQUFCQUFFQUFBSUJSQUE3JyxcbiAgICBzcmNTZXQ6IHVuZGVmaW5lZCxcbiAgICBzaXplczogdW5kZWZpbmVkLFxuICB9XG5cbiAgaWYgKGlzVmlzaWJsZSkge1xuICAgIGltZ0F0dHJpYnV0ZXMgPSBnZW5lcmF0ZUltZ0F0dHJzKHtcbiAgICAgIHNyYyxcbiAgICAgIHVub3B0aW1pemVkLFxuICAgICAgbGF5b3V0LFxuICAgICAgd2lkdGg6IHdpZHRoSW50LFxuICAgICAgcXVhbGl0eTogcXVhbGl0eUludCxcbiAgICAgIHNpemVzLFxuICAgICAgbG9hZGVyLFxuICAgIH0pXG4gIH1cblxuICBpZiAodW5zaXplZCkge1xuICAgIHdyYXBwZXJTdHlsZSA9IHVuZGVmaW5lZFxuICAgIHNpemVyU3R5bGUgPSB1bmRlZmluZWRcbiAgICBpbWdTdHlsZSA9IHVuZGVmaW5lZFxuICB9XG4gIHJldHVybiAoXG4gICAgPGRpdiBzdHlsZT17d3JhcHBlclN0eWxlfT5cbiAgICAgIHtzaXplclN0eWxlID8gKFxuICAgICAgICA8ZGl2IHN0eWxlPXtzaXplclN0eWxlfT5cbiAgICAgICAgICB7c2l6ZXJTdmcgPyAoXG4gICAgICAgICAgICA8aW1nXG4gICAgICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICAgICAgbWF4V2lkdGg6ICcxMDAlJyxcbiAgICAgICAgICAgICAgICBkaXNwbGF5OiAnYmxvY2snLFxuICAgICAgICAgICAgICAgIG1hcmdpbjogMCxcbiAgICAgICAgICAgICAgICBib3JkZXI6ICdub25lJyxcbiAgICAgICAgICAgICAgICBwYWRkaW5nOiAwLFxuICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICBhbHQ9XCJcIlxuICAgICAgICAgICAgICBhcmlhLWhpZGRlbj17dHJ1ZX1cbiAgICAgICAgICAgICAgcm9sZT1cInByZXNlbnRhdGlvblwiXG4gICAgICAgICAgICAgIHNyYz17YGRhdGE6aW1hZ2Uvc3ZnK3htbDtiYXNlNjQsJHt0b0Jhc2U2NChzaXplclN2Zyl9YH1cbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgKSA6IG51bGx9XG4gICAgICAgIDwvZGl2PlxuICAgICAgKSA6IG51bGx9XG4gICAgICB7IWlzVmlzaWJsZSAmJiAoXG4gICAgICAgIDxub3NjcmlwdD5cbiAgICAgICAgICA8aW1nXG4gICAgICAgICAgICB7Li4ucmVzdH1cbiAgICAgICAgICAgIHsuLi5nZW5lcmF0ZUltZ0F0dHJzKHtcbiAgICAgICAgICAgICAgc3JjLFxuICAgICAgICAgICAgICB1bm9wdGltaXplZCxcbiAgICAgICAgICAgICAgbGF5b3V0LFxuICAgICAgICAgICAgICB3aWR0aDogd2lkdGhJbnQsXG4gICAgICAgICAgICAgIHF1YWxpdHk6IHF1YWxpdHlJbnQsXG4gICAgICAgICAgICAgIHNpemVzLFxuICAgICAgICAgICAgICBsb2FkZXIsXG4gICAgICAgICAgICB9KX1cbiAgICAgICAgICAgIHNyYz17c3JjfVxuICAgICAgICAgICAgZGVjb2Rpbmc9XCJhc3luY1wiXG4gICAgICAgICAgICBzaXplcz17c2l6ZXN9XG4gICAgICAgICAgICBzdHlsZT17aW1nU3R5bGV9XG4gICAgICAgICAgICBjbGFzc05hbWU9e2NsYXNzTmFtZX1cbiAgICAgICAgICAvPlxuICAgICAgICA8L25vc2NyaXB0PlxuICAgICAgKX1cbiAgICAgIDxpbWdcbiAgICAgICAgey4uLnJlc3R9XG4gICAgICAgIHsuLi5pbWdBdHRyaWJ1dGVzfVxuICAgICAgICBkZWNvZGluZz1cImFzeW5jXCJcbiAgICAgICAgY2xhc3NOYW1lPXtjbGFzc05hbWV9XG4gICAgICAgIHJlZj17c2V0UmVmfVxuICAgICAgICBzdHlsZT17aW1nU3R5bGV9XG4gICAgICAvPlxuICAgICAge3ByaW9yaXR5ID8gKFxuICAgICAgICAvLyBOb3RlIGhvdyB3ZSBvbWl0IHRoZSBgaHJlZmAgYXR0cmlidXRlLCBhcyBpdCB3b3VsZCBvbmx5IGJlIHJlbGV2YW50XG4gICAgICAgIC8vIGZvciBicm93c2VycyB0aGF0IGRvIG5vdCBzdXBwb3J0IGBpbWFnZXNyY3NldGAsIGFuZCBpbiB0aG9zZSBjYXNlc1xuICAgICAgICAvLyBpdCB3b3VsZCBsaWtlbHkgY2F1c2UgdGhlIGluY29ycmVjdCBpbWFnZSB0byBiZSBwcmVsb2FkZWQuXG4gICAgICAgIC8vXG4gICAgICAgIC8vIGh0dHBzOi8vaHRtbC5zcGVjLndoYXR3Zy5vcmcvbXVsdGlwYWdlL3NlbWFudGljcy5odG1sI2F0dHItbGluay1pbWFnZXNyY3NldFxuICAgICAgICA8SGVhZD5cbiAgICAgICAgICA8bGlua1xuICAgICAgICAgICAga2V5PXtcbiAgICAgICAgICAgICAgJ19fbmltZy0nICtcbiAgICAgICAgICAgICAgaW1nQXR0cmlidXRlcy5zcmMgK1xuICAgICAgICAgICAgICBpbWdBdHRyaWJ1dGVzLnNyY1NldCArXG4gICAgICAgICAgICAgIGltZ0F0dHJpYnV0ZXMuc2l6ZXNcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJlbD1cInByZWxvYWRcIlxuICAgICAgICAgICAgYXM9XCJpbWFnZVwiXG4gICAgICAgICAgICBocmVmPXtpbWdBdHRyaWJ1dGVzLnNyY1NldCA/IHVuZGVmaW5lZCA6IGltZ0F0dHJpYnV0ZXMuc3JjfVxuICAgICAgICAgICAgLy8gQHRzLWlnbm9yZTogaW1hZ2VzcmNzZXQgaXMgbm90IHlldCBpbiB0aGUgbGluayBlbGVtZW50IHR5cGVcbiAgICAgICAgICAgIGltYWdlc3Jjc2V0PXtpbWdBdHRyaWJ1dGVzLnNyY1NldH1cbiAgICAgICAgICAgIC8vIEB0cy1pZ25vcmU6IGltYWdlc2l6ZXMgaXMgbm90IHlldCBpbiB0aGUgbGluayBlbGVtZW50IHR5cGVcbiAgICAgICAgICAgIGltYWdlc2l6ZXM9e2ltZ0F0dHJpYnV0ZXMuc2l6ZXN9XG4gICAgICAgICAgPjwvbGluaz5cbiAgICAgICAgPC9IZWFkPlxuICAgICAgKSA6IG51bGx9XG4gICAgPC9kaXY+XG4gIClcbn1cblxuLy9CVUlMVCBJTiBMT0FERVJTXG5cbmZ1bmN0aW9uIG5vcm1hbGl6ZVNyYyhzcmM6IHN0cmluZyk6IHN0cmluZyB7XG4gIHJldHVybiBzcmNbMF0gPT09ICcvJyA/IHNyYy5zbGljZSgxKSA6IHNyY1xufVxuXG5mdW5jdGlvbiBpbWdpeExvYWRlcih7XG4gIHJvb3QsXG4gIHNyYyxcbiAgd2lkdGgsXG4gIHF1YWxpdHksXG59OiBEZWZhdWx0SW1hZ2VMb2FkZXJQcm9wcyk6IHN0cmluZyB7XG4gIC8vIERlbW86IGh0dHBzOi8vc3RhdGljLmltZ2l4Lm5ldC9kYWlzeS5wbmc/Zm9ybWF0PWF1dG8mZml0PW1heCZ3PTMwMFxuICBjb25zdCBwYXJhbXMgPSBbJ2F1dG89Zm9ybWF0JywgJ2ZpdD1tYXgnLCAndz0nICsgd2lkdGhdXG4gIGxldCBwYXJhbXNTdHJpbmcgPSAnJ1xuICBpZiAocXVhbGl0eSkge1xuICAgIHBhcmFtcy5wdXNoKCdxPScgKyBxdWFsaXR5KVxuICB9XG5cbiAgaWYgKHBhcmFtcy5sZW5ndGgpIHtcbiAgICBwYXJhbXNTdHJpbmcgPSAnPycgKyBwYXJhbXMuam9pbignJicpXG4gIH1cbiAgcmV0dXJuIGAke3Jvb3R9JHtub3JtYWxpemVTcmMoc3JjKX0ke3BhcmFtc1N0cmluZ31gXG59XG5cbmZ1bmN0aW9uIGFrYW1haUxvYWRlcih7IHJvb3QsIHNyYywgd2lkdGggfTogRGVmYXVsdEltYWdlTG9hZGVyUHJvcHMpOiBzdHJpbmcge1xuICByZXR1cm4gYCR7cm9vdH0ke25vcm1hbGl6ZVNyYyhzcmMpfT9pbXdpZHRoPSR7d2lkdGh9YFxufVxuXG5mdW5jdGlvbiBjbG91ZGluYXJ5TG9hZGVyKHtcbiAgcm9vdCxcbiAgc3JjLFxuICB3aWR0aCxcbiAgcXVhbGl0eSxcbn06IERlZmF1bHRJbWFnZUxvYWRlclByb3BzKTogc3RyaW5nIHtcbiAgLy8gRGVtbzogaHR0cHM6Ly9yZXMuY2xvdWRpbmFyeS5jb20vZGVtby9pbWFnZS91cGxvYWQvd18zMDAsY19saW1pdCxxX2F1dG8vdHVydGxlcy5qcGdcbiAgY29uc3QgcGFyYW1zID0gWydmX2F1dG8nLCAnY19saW1pdCcsICd3XycgKyB3aWR0aCwgJ3FfJyArIChxdWFsaXR5IHx8ICdhdXRvJyldXG4gIGxldCBwYXJhbXNTdHJpbmcgPSBwYXJhbXMuam9pbignLCcpICsgJy8nXG4gIHJldHVybiBgJHtyb290fSR7cGFyYW1zU3RyaW5nfSR7bm9ybWFsaXplU3JjKHNyYyl9YFxufVxuXG5mdW5jdGlvbiBkZWZhdWx0TG9hZGVyKHtcbiAgcm9vdCxcbiAgc3JjLFxuICB3aWR0aCxcbiAgcXVhbGl0eSxcbn06IERlZmF1bHRJbWFnZUxvYWRlclByb3BzKTogc3RyaW5nIHtcbiAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHtcbiAgICBjb25zdCBtaXNzaW5nVmFsdWVzID0gW11cblxuICAgIC8vIHRoZXNlIHNob3VsZCBhbHdheXMgYmUgcHJvdmlkZWQgYnV0IG1ha2Ugc3VyZSB0aGV5IGFyZVxuICAgIGlmICghc3JjKSBtaXNzaW5nVmFsdWVzLnB1c2goJ3NyYycpXG4gICAgaWYgKCF3aWR0aCkgbWlzc2luZ1ZhbHVlcy5wdXNoKCd3aWR0aCcpXG5cbiAgICBpZiAobWlzc2luZ1ZhbHVlcy5sZW5ndGggPiAwKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgIGBOZXh0IEltYWdlIE9wdGltaXphdGlvbiByZXF1aXJlcyAke21pc3NpbmdWYWx1ZXMuam9pbihcbiAgICAgICAgICAnLCAnXG4gICAgICAgICl9IHRvIGJlIHByb3ZpZGVkLiBNYWtlIHN1cmUgeW91IHBhc3MgdGhlbSBhcyBwcm9wcyB0byB0aGUgXFxgbmV4dC9pbWFnZVxcYCBjb21wb25lbnQuIFJlY2VpdmVkOiAke0pTT04uc3RyaW5naWZ5KFxuICAgICAgICAgIHsgc3JjLCB3aWR0aCwgcXVhbGl0eSB9XG4gICAgICAgICl9YFxuICAgICAgKVxuICAgIH1cblxuICAgIGlmIChzcmMuc3RhcnRzV2l0aCgnLy8nKSkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICBgRmFpbGVkIHRvIHBhcnNlIHNyYyBcIiR7c3JjfVwiIG9uIFxcYG5leHQvaW1hZ2VcXGAsIHByb3RvY29sLXJlbGF0aXZlIFVSTCAoLy8pIG11c3QgYmUgY2hhbmdlZCB0byBhbiBhYnNvbHV0ZSBVUkwgKGh0dHA6Ly8gb3IgaHR0cHM6Ly8pYFxuICAgICAgKVxuICAgIH1cblxuICAgIGlmICghc3JjLnN0YXJ0c1dpdGgoJy8nKSAmJiBjb25maWdEb21haW5zKSB7XG4gICAgICBsZXQgcGFyc2VkU3JjOiBVUkxcbiAgICAgIHRyeSB7XG4gICAgICAgIHBhcnNlZFNyYyA9IG5ldyBVUkwoc3JjKVxuICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoZXJyKVxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgICAgYEZhaWxlZCB0byBwYXJzZSBzcmMgXCIke3NyY31cIiBvbiBcXGBuZXh0L2ltYWdlXFxgLCBpZiB1c2luZyByZWxhdGl2ZSBpbWFnZSBpdCBtdXN0IHN0YXJ0IHdpdGggYSBsZWFkaW5nIHNsYXNoIFwiL1wiIG9yIGJlIGFuIGFic29sdXRlIFVSTCAoaHR0cDovLyBvciBodHRwczovLylgXG4gICAgICAgIClcbiAgICAgIH1cblxuICAgICAgaWYgKCFjb25maWdEb21haW5zLmluY2x1ZGVzKHBhcnNlZFNyYy5ob3N0bmFtZSkpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICAgIGBJbnZhbGlkIHNyYyBwcm9wICgke3NyY30pIG9uIFxcYG5leHQvaW1hZ2VcXGAsIGhvc3RuYW1lIFwiJHtwYXJzZWRTcmMuaG9zdG5hbWV9XCIgaXMgbm90IGNvbmZpZ3VyZWQgdW5kZXIgaW1hZ2VzIGluIHlvdXIgXFxgbmV4dC5jb25maWcuanNcXGBcXG5gICtcbiAgICAgICAgICAgIGBTZWUgbW9yZSBpbmZvOiBodHRwczovL25leHRqcy5vcmcvZG9jcy9tZXNzYWdlcy9uZXh0LWltYWdlLXVuY29uZmlndXJlZC1ob3N0YFxuICAgICAgICApXG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIGAke3Jvb3R9P3VybD0ke2VuY29kZVVSSUNvbXBvbmVudChzcmMpfSZ3PSR7d2lkdGh9JnE9JHtxdWFsaXR5IHx8IDc1fWBcbn1cbiIsInR5cGUgUmVxdWVzdElkbGVDYWxsYmFja0hhbmRsZSA9IGFueVxudHlwZSBSZXF1ZXN0SWRsZUNhbGxiYWNrT3B0aW9ucyA9IHtcbiAgdGltZW91dDogbnVtYmVyXG59XG50eXBlIFJlcXVlc3RJZGxlQ2FsbGJhY2tEZWFkbGluZSA9IHtcbiAgcmVhZG9ubHkgZGlkVGltZW91dDogYm9vbGVhblxuICB0aW1lUmVtYWluaW5nOiAoKSA9PiBudW1iZXJcbn1cblxuZGVjbGFyZSBnbG9iYWwge1xuICBpbnRlcmZhY2UgV2luZG93IHtcbiAgICByZXF1ZXN0SWRsZUNhbGxiYWNrOiAoXG4gICAgICBjYWxsYmFjazogKGRlYWRsaW5lOiBSZXF1ZXN0SWRsZUNhbGxiYWNrRGVhZGxpbmUpID0+IHZvaWQsXG4gICAgICBvcHRzPzogUmVxdWVzdElkbGVDYWxsYmFja09wdGlvbnNcbiAgICApID0+IFJlcXVlc3RJZGxlQ2FsbGJhY2tIYW5kbGVcbiAgICBjYW5jZWxJZGxlQ2FsbGJhY2s6IChpZDogUmVxdWVzdElkbGVDYWxsYmFja0hhbmRsZSkgPT4gdm9pZFxuICB9XG59XG5cbmV4cG9ydCBjb25zdCByZXF1ZXN0SWRsZUNhbGxiYWNrID1cbiAgKHR5cGVvZiBzZWxmICE9PSAndW5kZWZpbmVkJyAmJiBzZWxmLnJlcXVlc3RJZGxlQ2FsbGJhY2spIHx8XG4gIGZ1bmN0aW9uIChcbiAgICBjYjogKGRlYWRsaW5lOiBSZXF1ZXN0SWRsZUNhbGxiYWNrRGVhZGxpbmUpID0+IHZvaWRcbiAgKTogTm9kZUpTLlRpbWVvdXQge1xuICAgIGxldCBzdGFydCA9IERhdGUubm93KClcbiAgICByZXR1cm4gc2V0VGltZW91dChmdW5jdGlvbiAoKSB7XG4gICAgICBjYih7XG4gICAgICAgIGRpZFRpbWVvdXQ6IGZhbHNlLFxuICAgICAgICB0aW1lUmVtYWluaW5nOiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgcmV0dXJuIE1hdGgubWF4KDAsIDUwIC0gKERhdGUubm93KCkgLSBzdGFydCkpXG4gICAgICAgIH0sXG4gICAgICB9KVxuICAgIH0sIDEpXG4gIH1cblxuZXhwb3J0IGNvbnN0IGNhbmNlbElkbGVDYWxsYmFjayA9XG4gICh0eXBlb2Ygc2VsZiAhPT0gJ3VuZGVmaW5lZCcgJiYgc2VsZi5jYW5jZWxJZGxlQ2FsbGJhY2spIHx8XG4gIGZ1bmN0aW9uIChpZDogUmVxdWVzdElkbGVDYWxsYmFja0hhbmRsZSkge1xuICAgIHJldHVybiBjbGVhclRpbWVvdXQoaWQpXG4gIH1cbiIsImltcG9ydCB7IHVzZUNhbGxiYWNrLCB1c2VFZmZlY3QsIHVzZVJlZiwgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7XG4gIHJlcXVlc3RJZGxlQ2FsbGJhY2ssXG4gIGNhbmNlbElkbGVDYWxsYmFjayxcbn0gZnJvbSAnLi9yZXF1ZXN0LWlkbGUtY2FsbGJhY2snXG5cbnR5cGUgVXNlSW50ZXJzZWN0aW9uT2JzZXJ2ZXJJbml0ID0gUGljazxJbnRlcnNlY3Rpb25PYnNlcnZlckluaXQsICdyb290TWFyZ2luJz5cbnR5cGUgVXNlSW50ZXJzZWN0aW9uID0geyBkaXNhYmxlZD86IGJvb2xlYW4gfSAmIFVzZUludGVyc2VjdGlvbk9ic2VydmVySW5pdFxudHlwZSBPYnNlcnZlQ2FsbGJhY2sgPSAoaXNWaXNpYmxlOiBib29sZWFuKSA9PiB2b2lkXG50eXBlIE9ic2VydmVyID0ge1xuICBpZDogc3RyaW5nXG4gIG9ic2VydmVyOiBJbnRlcnNlY3Rpb25PYnNlcnZlclxuICBlbGVtZW50czogTWFwPEVsZW1lbnQsIE9ic2VydmVDYWxsYmFjaz5cbn1cblxuY29uc3QgaGFzSW50ZXJzZWN0aW9uT2JzZXJ2ZXIgPSB0eXBlb2YgSW50ZXJzZWN0aW9uT2JzZXJ2ZXIgIT09ICd1bmRlZmluZWQnXG5cbmV4cG9ydCBmdW5jdGlvbiB1c2VJbnRlcnNlY3Rpb248VCBleHRlbmRzIEVsZW1lbnQ+KHtcbiAgcm9vdE1hcmdpbixcbiAgZGlzYWJsZWQsXG59OiBVc2VJbnRlcnNlY3Rpb24pOiBbKGVsZW1lbnQ6IFQgfCBudWxsKSA9PiB2b2lkLCBib29sZWFuXSB7XG4gIGNvbnN0IGlzRGlzYWJsZWQ6IGJvb2xlYW4gPSBkaXNhYmxlZCB8fCAhaGFzSW50ZXJzZWN0aW9uT2JzZXJ2ZXJcblxuICBjb25zdCB1bm9ic2VydmUgPSB1c2VSZWY8RnVuY3Rpb24+KClcbiAgY29uc3QgW3Zpc2libGUsIHNldFZpc2libGVdID0gdXNlU3RhdGUoZmFsc2UpXG5cbiAgY29uc3Qgc2V0UmVmID0gdXNlQ2FsbGJhY2soXG4gICAgKGVsOiBUIHwgbnVsbCkgPT4ge1xuICAgICAgaWYgKHVub2JzZXJ2ZS5jdXJyZW50KSB7XG4gICAgICAgIHVub2JzZXJ2ZS5jdXJyZW50KClcbiAgICAgICAgdW5vYnNlcnZlLmN1cnJlbnQgPSB1bmRlZmluZWRcbiAgICAgIH1cblxuICAgICAgaWYgKGlzRGlzYWJsZWQgfHwgdmlzaWJsZSkgcmV0dXJuXG5cbiAgICAgIGlmIChlbCAmJiBlbC50YWdOYW1lKSB7XG4gICAgICAgIHVub2JzZXJ2ZS5jdXJyZW50ID0gb2JzZXJ2ZShcbiAgICAgICAgICBlbCxcbiAgICAgICAgICAoaXNWaXNpYmxlKSA9PiBpc1Zpc2libGUgJiYgc2V0VmlzaWJsZShpc1Zpc2libGUpLFxuICAgICAgICAgIHsgcm9vdE1hcmdpbiB9XG4gICAgICAgIClcbiAgICAgIH1cbiAgICB9LFxuICAgIFtpc0Rpc2FibGVkLCByb290TWFyZ2luLCB2aXNpYmxlXVxuICApXG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoIWhhc0ludGVyc2VjdGlvbk9ic2VydmVyKSB7XG4gICAgICBpZiAoIXZpc2libGUpIHtcbiAgICAgICAgY29uc3QgaWRsZUNhbGxiYWNrID0gcmVxdWVzdElkbGVDYWxsYmFjaygoKSA9PiBzZXRWaXNpYmxlKHRydWUpKVxuICAgICAgICByZXR1cm4gKCkgPT4gY2FuY2VsSWRsZUNhbGxiYWNrKGlkbGVDYWxsYmFjaylcbiAgICAgIH1cbiAgICB9XG4gIH0sIFt2aXNpYmxlXSlcblxuICByZXR1cm4gW3NldFJlZiwgdmlzaWJsZV1cbn1cblxuZnVuY3Rpb24gb2JzZXJ2ZShcbiAgZWxlbWVudDogRWxlbWVudCxcbiAgY2FsbGJhY2s6IE9ic2VydmVDYWxsYmFjayxcbiAgb3B0aW9uczogVXNlSW50ZXJzZWN0aW9uT2JzZXJ2ZXJJbml0XG4pOiAoKSA9PiB2b2lkIHtcbiAgY29uc3QgeyBpZCwgb2JzZXJ2ZXIsIGVsZW1lbnRzIH0gPSBjcmVhdGVPYnNlcnZlcihvcHRpb25zKVxuICBlbGVtZW50cy5zZXQoZWxlbWVudCwgY2FsbGJhY2spXG5cbiAgb2JzZXJ2ZXIub2JzZXJ2ZShlbGVtZW50KVxuICByZXR1cm4gZnVuY3Rpb24gdW5vYnNlcnZlKCk6IHZvaWQge1xuICAgIGVsZW1lbnRzLmRlbGV0ZShlbGVtZW50KVxuICAgIG9ic2VydmVyLnVub2JzZXJ2ZShlbGVtZW50KVxuXG4gICAgLy8gRGVzdHJveSBvYnNlcnZlciB3aGVuIHRoZXJlJ3Mgbm90aGluZyBsZWZ0IHRvIHdhdGNoOlxuICAgIGlmIChlbGVtZW50cy5zaXplID09PSAwKSB7XG4gICAgICBvYnNlcnZlci5kaXNjb25uZWN0KClcbiAgICAgIG9ic2VydmVycy5kZWxldGUoaWQpXG4gICAgfVxuICB9XG59XG5cbmNvbnN0IG9ic2VydmVycyA9IG5ldyBNYXA8c3RyaW5nLCBPYnNlcnZlcj4oKVxuZnVuY3Rpb24gY3JlYXRlT2JzZXJ2ZXIob3B0aW9uczogVXNlSW50ZXJzZWN0aW9uT2JzZXJ2ZXJJbml0KTogT2JzZXJ2ZXIge1xuICBjb25zdCBpZCA9IG9wdGlvbnMucm9vdE1hcmdpbiB8fCAnJ1xuICBsZXQgaW5zdGFuY2UgPSBvYnNlcnZlcnMuZ2V0KGlkKVxuICBpZiAoaW5zdGFuY2UpIHtcbiAgICByZXR1cm4gaW5zdGFuY2VcbiAgfVxuXG4gIGNvbnN0IGVsZW1lbnRzID0gbmV3IE1hcDxFbGVtZW50LCBPYnNlcnZlQ2FsbGJhY2s+KClcbiAgY29uc3Qgb2JzZXJ2ZXIgPSBuZXcgSW50ZXJzZWN0aW9uT2JzZXJ2ZXIoKGVudHJpZXMpID0+IHtcbiAgICBlbnRyaWVzLmZvckVhY2goKGVudHJ5KSA9PiB7XG4gICAgICBjb25zdCBjYWxsYmFjayA9IGVsZW1lbnRzLmdldChlbnRyeS50YXJnZXQpXG4gICAgICBjb25zdCBpc1Zpc2libGUgPSBlbnRyeS5pc0ludGVyc2VjdGluZyB8fCBlbnRyeS5pbnRlcnNlY3Rpb25SYXRpbyA+IDBcbiAgICAgIGlmIChjYWxsYmFjayAmJiBpc1Zpc2libGUpIHtcbiAgICAgICAgY2FsbGJhY2soaXNWaXNpYmxlKVxuICAgICAgfVxuICAgIH0pXG4gIH0sIG9wdGlvbnMpXG5cbiAgb2JzZXJ2ZXJzLnNldChcbiAgICBpZCxcbiAgICAoaW5zdGFuY2UgPSB7XG4gICAgICBpZCxcbiAgICAgIG9ic2VydmVyLFxuICAgICAgZWxlbWVudHMsXG4gICAgfSlcbiAgKVxuICByZXR1cm4gaW5zdGFuY2Vcbn1cbiIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZSgnLi9kaXN0L2NsaWVudC9pbWFnZScpXG4iLCJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgSG9tZSBmcm9tIFwiLi4vLi4vc3JjL21vZHVsZXMvaG9tZVwiO1xuXG5mdW5jdGlvbiBIb21lUGFnZSgpIHtcbiAgcmV0dXJuIDxIb21lIC8+O1xufVxuXG5leHBvcnQgZGVmYXVsdCBIb21lUGFnZTtcbiIsImltcG9ydCBSZWFjdCwgeyB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuXG5leHBvcnQgdHlwZSBQcm9wcyA9IHtcbiAgdGl0bGU/OiBzdHJpbmc7XG4gIHN1YlRpdGxlPzogc3RyaW5nO1xuICBiYW5uZXJJbWc/OiBhbnk7XG4gIG1vYmlsZUJhbm5lckltZz86IGFueTtcbn07XG5cbmV4cG9ydCBjb25zdCBCYW5uZXI6IFJlYWN0LkZDPFByb3BzPiA9ICh7IHRpdGxlLCBzdWJUaXRsZSwgYmFubmVySW1nLCBtb2JpbGVCYW5uZXJJbWcgfSkgPT4ge1xuXG4gIHJldHVybiAoXG4gICAgPD5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwic206aGlkZGVuIHctZnVsbCBiZy1jb3ZlciBiZy1jZW50ZXIgYy1iZyByZWxhdGl2ZVwiIHN0eWxlPXt7IGJhY2tncm91bmRJbWFnZTogYHVybCgke2Jhbm5lckltZ30pYCB9fT5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBoLWZ1bGwgdy1mdWxsIGJnLWdyYXktOTAwIGJnLW9wYWNpdHktNTBcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyXCI+XG4gICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC13aGl0ZSB0ZXh0LTdsZyBtZDpsZWFkaW5nLTEwIGZvbnQtYm9sZCB4bDp0ZXh0LTR4bCBzbTp0ZXh0LTJ4bFwiPnt0aXRsZX08L2gxPlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC13aGl0ZSB0ZXh0LTNtZCBtZDp0ZXh0LXhsXCI+e3N1YlRpdGxlfTwvcD5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCB3LWZ1bGwgcmVsYXRpdmUgcG9zaXRpb24tYm90dG9tXCI+XG5cbiAgICAgICAgICAgICAgey8qIDxkaXYgY2xhc3NOYW1lPVwiY29udGVudC1jZW50ZXIgbS1hdXRvXCI+XG4gICAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwidGV4dC13aGl0ZSBwdC0xOXAgcGwtM3AgYnRuLWFjdGl2ZS1iZyBweS0yIHRleHQtM3hsIFwiPlxuICAgICAgICAgICAgICAgIENVUlJFTlQgSU5WRVNUTUVOVFNcbiAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgIDxidXR0b24gY2xhc3NOYW1lPVwidHh0LXdoaXRlIHBsLTNwIHB0LTE5cCBweS0yIHRleHQtM3hsXCI+XG4gICAgICAgICAgICAgICAgUEFTVCBJTlZFU1RNRU5UU1xuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgIDwvZGl2PiAqL31cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cInNtOmJsb2NrIGhpZGRlbiB3LWZ1bGwgYmctY292ZXIgYmctY2VudGVyIGMtYmcgcmVsYXRpdmVcIiBzdHlsZT17eyBiYWNrZ3JvdW5kSW1hZ2U6IGBsaW5lYXItZ3JhZGllbnQocmdiYSgwLCAwLCAwLCAwLjUpLCByZ2JhKDAsIDAsIDAsIDAuNSkpLHVybCgke21vYmlsZUJhbm5lckltZ30pYCB9fT5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGl0ZW1zLWNlbnRlciBqdXN0aWZ5LWNlbnRlciBoLWZ1bGwgdy1mdWxsIGJnLWdyYXktOTAwIGJnLW9wYWNpdHktNTBcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInAtOFwiPlxuICAgICAgICAgICAgPGgxIGNsYXNzTmFtZT1cInRleHQtd2hpdGUgbGVhZGluZy10aWdodCB0ZXh0LTVzbSBmb250LW1lZGl1bSBzbTp0ZXh0LWxlZnRcIj57dGl0bGV9PC9oMT5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cInRleHQtd2hpdGUgdGV4dC14bCBzbTp0ZXh0LWxlZnRcIj57c3ViVGl0bGV9PC9wPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IHctZnVsbCByZWxhdGl2ZSBwb3NpdGlvbi1ib3R0b21cIj5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvPlxuICApO1xufTtcbiIsImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcblxuZXhwb3J0IHR5cGUgUHJvcHMgPSB7XG4gIHRpdGxlOiBzdHJpbmc7XG4gIHVybDogc3RyaW5nO1xuICBvbkNsaWNrPzogKCkgPT4gdm9pZDtcbiAgY2xhc3NOYW1lPzogc3RyaW5nO1xuICBzdHlsZT86IGFueTtcbn07XG5cbmNvbnN0IEJ1dHRvbjogUmVhY3QuRkM8UHJvcHM+ID0gKHtcbiAgdGl0bGUsXG4gIHVybCxcbiAgb25DbGljayxcbiAgY2xhc3NOYW1lID0gXCJcIixcbiAgc3R5bGUgPSB7fSxcbn0pID0+IHtcbiAgcmV0dXJuIChcbiAgICA8YnV0dG9uXG4gICAgICBvbkNsaWNrPXtvbkNsaWNrfVxuICAgICAgc3R5bGU9e3N0eWxlfVxuICAgICAgY2xhc3NOYW1lPXtgZmxleCBwLTAuNSBwbC0wIGl0ZW1zLWNlbnRlciBtdC0yICR7Y2xhc3NOYW1lfWB9XG4gICAgPlxuICAgICAge1wiIFwifVxuICAgICAge3RpdGxlfSA8aW1nIGNsYXNzTmFtZT1cInBsLTJcIiBzcmM9e3VybH0+PC9pbWc+XG4gICAgPC9idXR0b24+XG4gICk7XG59O1xuXG5leHBvcnQgZGVmYXVsdCBCdXR0b247XG4iLCJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5cbmV4cG9ydCB0eXBlIElCdXR0b24gPSBSZWFjdC5EZXRhaWxlZEhUTUxQcm9wczxcbiAgUmVhY3QuQnV0dG9uSFRNTEF0dHJpYnV0ZXM8SFRNTEJ1dHRvbkVsZW1lbnQ+LFxuICBIVE1MQnV0dG9uRWxlbWVudFxuPjtcblxuZXhwb3J0IGNvbnN0IEJ1dHRvbjogUmVhY3QuRkM8SUJ1dHRvbj4gPSAoe1xuICBjbGFzc05hbWUgPSBcIlwiLFxuICBjaGlsZHJlbixcbiAgLi4ucmVzdFxufSkgPT4ge1xuICByZXR1cm4gKFxuICAgIDxidXR0b25cbiAgICAgIGNsYXNzTmFtZT17YHB5LTIgcHgtNCByb3VuZGVkIGJnLWdyZWVuLTUwMCBob3ZlcjpiZy1ncmVlbi02MDAgZm9jdXM6b3V0bGluZS1ub25lIHJpbmctb3BhY2l0eS03NSByaW5nLWdyZWVuLTQwMCBmb2N1czpyaW5nIHRleHQtd2hpdGUgdGV4dC1sZyAke2NsYXNzTmFtZX1gfVxuICAgICAgey4uLnJlc3R9XG4gICAgPlxuICAgICAge2NoaWxkcmVufVxuICAgIDwvYnV0dG9uPlxuICApO1xufTtcbiIsImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcblxuaW1wb3J0IGRhdGEgZnJvbSBcIkBwdWJsaWMvbWV0YS5qc29uXCI7XG5cbmV4cG9ydCBjb25zdCBDYXJkczogUmVhY3QuRkMgPSAoKSA9PiB7XG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LTEgY29udGFpbmVyIG15LTggbWF4LXctc2NyZWVuLWxnIG14LWF1dG8gcC01XCI+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cImdyaWQgZ3JpZC1jb2xzLTEgbWQ6Z3JpZC1jb2xzLTIgbGc6Z3JpZC1jb2xzLTMgZ2FwLTZcIj5cbiAgICAgICAgeyhkYXRhPy5wbHVnaW5zID8/IFtdKS5tYXAoKHBsdWdpbikgPT4gKFxuICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgIGtleT17cGx1Z2luLm5hbWV9XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJjb2wtc3Bhbi0xIHJvdW5kZWQtbWQgYm9yZGVyIGJvcmRlci1ncmF5LTMwMCBwLTVcIlxuICAgICAgICAgID5cbiAgICAgICAgICAgIDxoMiBjbGFzc05hbWU9XCJ0ZXh0LXhsIGZvbnQtc2VtaWJvbGQgbWItMlwiPntwbHVnaW4ubmFtZX08L2gyPlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwibS0wXCI+e3BsdWdpbi5kZXNjcmlwdGlvbn08L3A+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICkpfVxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59O1xuIiwiZXhwb3J0IGNvbnN0IENvbnRhaW5lciA9ICh7IGNoaWxkcmVuIH0pID0+IHtcbiAgcmV0dXJuIDxkaXYgY2xhc3NOYW1lPVwibWluLWgtc2NyZWVuIGZsZXggZmxleC1jb2xcIj57Y2hpbGRyZW59PC9kaXY+O1xufTtcbiIsImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IEltYWdlLCBUYWcgfSBmcm9tIFwiQGNvbXBvbmVudHNcIjtcbmltcG9ydCBCdXR0b24gZnJvbSBcIkBjb21wb25lbnRzL2J1dHRvbi9QcmltYXJ5QnV0dG9uSWNvblJpZ2h0XCI7XG5pbXBvcnQgZ2V0Q29udGVudFR5cGVJbWFnZVVybCBmcm9tIFwiLi4vLi4vLi4vdXRpbHMvZ2V0Q29udGVudFR5cGVJbWFnZVVybFwiO1xuXG5leHBvcnQgdHlwZSBQcm9wcyA9IHtcbiAgaW1hZ2VfdXJsOiBzdHJpbmc7XG4gIGltYWdlX2NhcHRpb246IHN0cmluZztcbiAgdGl0bGU6IHN0cmluZztcbiAgYXV0aG9yOiBzdHJpbmc7XG4gIGRlc2lnbmF0aW9uOiBzdHJpbmc7XG4gIGF1dGhvcl9pbWFnZV91cmw6IHN0cmluZztcbiAgb25DbGljaz86IChpZDogc3RyaW5nKSA9PiB2b2lkO1xuICBjb250ZW50X2lkOiBzdHJpbmc7XG4gIGNvbnRlbnRfdHlwZTogc3RyaW5nO1xuICByZWFkX2R1cmF0aW9uOiBzdHJpbmc7XG4gIHRhZ3M/OiBBcnJheTxhbnk+O1xuICBjbGFzc05hbWU/OiBzdHJpbmc7XG4gIHN0eWxlPzogYW55O1xufTtcblxuY29uc3QgQ29udGVudEl0ZW1XaXRoVGFnczogUmVhY3QuRkM8UHJvcHM+ID0gKHtcbiAgaW1hZ2VfdXJsLFxuICBpbWFnZV9jYXB0aW9uLFxuICB0aXRsZSxcbiAgYXV0aG9yLFxuICBkZXNpZ25hdGlvbixcbiAgb25DbGljayxcbiAgY29udGVudF9pZCxcbiAgY29udGVudF90eXBlLFxuICByZWFkX2R1cmF0aW9uLFxuICBhdXRob3JfaW1hZ2VfdXJsLFxuICB0YWdzLFxuICBjbGFzc05hbWUgPSBcIlwiLFxuICBzdHlsZSA9IHsgbWFyZ2luQm90dG9tOiA2MiB9LFxufSkgPT4ge1xuICByZXR1cm4gKFxuICAgIDxkaXZcbiAgICAgIGNsYXNzTmFtZT17YCR7Y2xhc3NOYW1lfSByZWxhdGl2ZWB9XG4gICAgICBzdHlsZT17eyBoZWlnaHQ6IDMxMywgd2lkdGg6IDEwMzUsIC4uLnN0eWxlIH19XG4gICAgPlxuICAgICAgPGRpdlxuICAgICAgICBjbGFzc05hbWU9XCJyZWxhdGl2ZVwiXG4gICAgICAgIHN0eWxlPXt7IHRvcDogMCwgbGVmdDogMCwgaGVpZ2h0OiAzMTMsIHdpZHRoOiAzMjkuMDYgfX1cbiAgICAgID5cbiAgICAgICAgPGRpdlxuICAgICAgICAgIGNsYXNzTmFtZT1cImFic29sdXRlXCJcbiAgICAgICAgICBzdHlsZT17eyB3aWR0aDogMjk4LCBoZWlnaHQ6IDI1MywgYmFja2dyb3VuZDogXCIjMDE1NzZFXCIsIGJvdHRvbTogMCB9fVxuICAgICAgICA+PC9kaXY+XG4gICAgICAgIDxJbWFnZVxuICAgICAgICAgIHNyYz17aW1hZ2VfdXJsfVxuICAgICAgICAgIGFsdD1cIlwiXG4gICAgICAgICAgY2xhc3NOYW1lPVwiYWJzb2x1dGVcIlxuICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICBoZWlnaHQ6IDI1NSxcbiAgICAgICAgICAgIHdpZHRoOiAzMTUsXG4gICAgICAgICAgICBiYWNrZ3JvdW5kOiBcInJlZFwiLFxuICAgICAgICAgICAgbGVmdDogNixcbiAgICAgICAgICAgIGJvdHRvbTogNixcbiAgICAgICAgICB9fVxuICAgICAgICA+PC9JbWFnZT5cbiAgICAgICAgPGRpdlxuICAgICAgICAgIGNsYXNzTmFtZT1cImFic29sdXRlIGZsZXggaXRlbXMtY2VudGVyXCJcbiAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgYmFja2dyb3VuZDogXCIjMDE1NzZFXCIsXG4gICAgICAgICAgICBoZWlnaHQ6IDQyLFxuICAgICAgICAgICAgbGVmdDogMCxcbiAgICAgICAgICAgIGJvdHRvbTogNixcbiAgICAgICAgICAgIHRleHRBbGlnbjogXCJjZW50ZXJcIixcbiAgICAgICAgICB9fVxuICAgICAgICA+XG4gICAgICAgICAgPGRpdlxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LW5vcm1hbCB0ZXh0LXNlY29uZGFyeS1saWdodCB0ZXh0LWNlbnRlclwiXG4gICAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgICBsaW5lSGVpZ2h0OiBcIjMwcHhcIixcbiAgICAgICAgICAgICAgcGFkZGluZ1RvcDogNixcbiAgICAgICAgICAgICAgcGFkZGluZ0JvdHRvbTogNixcbiAgICAgICAgICAgICAgcGFkZGluZ0xlZnQ6IDE3LFxuICAgICAgICAgICAgICBwYWRkaW5nUmlnaHQ6IDE3LFxuICAgICAgICAgICAgfX1cbiAgICAgICAgICA+XG4gICAgICAgICAgICB7aW1hZ2VfY2FwdGlvbn1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICAgIDxkaXZcbiAgICAgICAgY2xhc3NOYW1lPVwiYWJzb2x1dGUgYmctc2Vjb25kYXJ5LWxpZ2h0XCJcbiAgICAgICAgc3R5bGU9e3sgd2lkdGg6IDc0MSwgYm90dG9tOiAtNjEsIHJpZ2h0OiAwIH19XG4gICAgICA+XG4gICAgICAgIDxkaXYgc3R5bGU9e3sgbWFyZ2luTGVmdDogNDUsIG1hcmdpblRvcDogMjAsIG1hcmdpbkJvdHRvbTogMjAgfX0+XG4gICAgICAgICAgPGRpdlxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC14cyB0ZXh0LXByaW1hcnktZGFyayBwLTAuNSBwbC0wIHB0LTBcIlxuICAgICAgICAgICAgc3R5bGU9e3sgbGluZUhlaWdodDogXCIxNHB4XCIsIGxldHRlclNwYWNpbmc6IFwiMC4xZW1cIiB9fVxuICAgICAgICAgID5cbiAgICAgICAgICAgIHtyZWFkX2R1cmF0aW9ufSBSRUFEe1wiIFwifVxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXZcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cInRleHQtcHJpbWFyeS1kYXJrIG10LTNcIlxuICAgICAgICAgICAgc3R5bGU9e3sgZm9udFNpemU6IFwiMjhweFwiLCBsaW5lSGVpZ2h0OiBcIjM0cHhcIiB9fVxuICAgICAgICAgID5cbiAgICAgICAgICAgIHt0aXRsZX1cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIG10LTQgcHQtMVwiPlxuICAgICAgICAgICAgPEltYWdlXG4gICAgICAgICAgICAgIHNyYz17Z2V0Q29udGVudFR5cGVJbWFnZVVybChjb250ZW50X3R5cGUpfVxuICAgICAgICAgICAgICBoZWlnaHQ9ezM4fVxuICAgICAgICAgICAgICB3aWR0aD17MjJ9XG4gICAgICAgICAgICAgIGFsdD1cIldyaXRlciBJbWFnZVwiXG4gICAgICAgICAgICAvPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IFwiIHN0eWxlPXt7IG1hcmdpbkxlZnQ6IDMwIH19PlxuICAgICAgICAgICAgICA8SW1hZ2Ugc3JjPXthdXRob3JfaW1hZ2VfdXJsfSBhbHQ9XCJwcm9maWxlSW1hZ2VcIiAvPlxuICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IG1hcmdpbkxlZnQ6IDE4IH19PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9udC1tZWRpdW0gdGV4dC1sZyBsZWFkaW5nLTYgdGV4dC1wcmltYXJ5LWRhcmtcIj5cbiAgICAgICAgICAgICAgICAgIHthdXRob3J9XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibXQtMC41IGZvbnQtbGlnaHQgdGV4dC14cyBcIlxuICAgICAgICAgICAgICAgICAgc3R5bGU9e3sgbGluZUhlaWdodDogXCIxNHB4XCIgfX1cbiAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICB7ZGVzaWduYXRpb259XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGZsZXgtcm93IGZsZXgtd3JhcFwiIHN0eWxlPXt7IG1hcmdpblRvcDogMzAgfX0+XG4gICAgICAgICAgICB7dGFncy5tYXAoKGl0ZW0sIGluZGV4KSA9PiB7XG4gICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgPFRhZ1xuICAgICAgICAgICAgICAgICAga2V5PXtpbmRleH1cbiAgICAgICAgICAgICAgICAgIHRpdGxlPVwiTEVBREVSU0hJUFwiXG4gICAgICAgICAgICAgICAgICBpZD1cImxlYWRlcnNoaXBcIlxuICAgICAgICAgICAgICAgICAgc2VsZWN0ZWQ9e2ZhbHNlfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC14cyBvcGFjaXR5LTgwIG1yLTIgYmctc2Vjb25kYXJ5LWxpZ2h0XCJcbiAgICAgICAgICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICAgICAgICAgIGxpbmVIZWlnaHQ6IFwiMTRweFwiLFxuICAgICAgICAgICAgICAgICAgICBmb250U2l6ZTogXCIxMnB4XCIsXG4gICAgICAgICAgICAgICAgICAgIGxldHRlclNwYWNpbmc6IFwiMC4xZW1cIixcbiAgICAgICAgICAgICAgICAgICAgaGVpZ2h0OiAzNCxcbiAgICAgICAgICAgICAgICAgICAgY29sb3I6IFwicmdiYSgwLCAwLCAwLCAwLjY1KVwiLFxuICAgICAgICAgICAgICAgICAgICBib3JkZXI6IDAsXG4gICAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6IFwicmdiYSgwLCAwLCAwLCAwLjA4KVwiLFxuICAgICAgICAgICAgICAgICAgICBtYXJnaW5Cb3R0b206IDEwLFxuICAgICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgfSl9XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59O1xuXG5leHBvcnQgZGVmYXVsdCBDb250ZW50SXRlbVdpdGhUYWdzO1xuIiwiaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgSW1hZ2UgfSBmcm9tIFwiQGNvbXBvbmVudHNcIjtcbmltcG9ydCBCdXR0b24gZnJvbSBcIkBjb21wb25lbnRzL2J1dHRvbi9QcmltYXJ5QnV0dG9uSWNvblJpZ2h0XCI7XG5pbXBvcnQgZ2V0Q29udGVudFR5cGVJbWFnZVVybCBmcm9tIFwiLi4vLi4vLi4vdXRpbHMvZ2V0Q29udGVudFR5cGVJbWFnZVVybFwiO1xuXG5leHBvcnQgdHlwZSBQcm9wcyA9IHtcbiAgaW1hZ2VfdXJsOiBzdHJpbmc7XG4gIHRpdGxlOiBzdHJpbmc7XG4gIGF1dGhvcjogc3RyaW5nO1xuICBvbkNsaWNrOiAoaWQ6IHN0cmluZykgPT4gdm9pZDtcbiAgY29udGVudF9pZDogc3RyaW5nO1xuICBjb250ZW50X3R5cGU6IHN0cmluZztcbiAgcmVhZF9kdXJhdGlvbjogc3RyaW5nO1xuICBzdHlsZT86IGFueTtcbiAgY2xhc3NOYW1lPzogc3RyaW5nO1xufTtcblxuZXhwb3J0IGNvbnN0IENvbnRlbnRJdGVtOiBSZWFjdC5GQzxQcm9wcz4gPSAoe1xuICBpbWFnZV91cmwsXG4gIGNsYXNzTmFtZSA9IFwiXCIsXG4gIHRpdGxlLFxuICBhdXRob3IsXG4gIG9uQ2xpY2ssXG4gIGNvbnRlbnRfaWQsXG4gIGNvbnRlbnRfdHlwZSxcbiAgcmVhZF9kdXJhdGlvbixcbiAgc3R5bGUgPSB7fSxcbn0pID0+IHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2XG4gICAgICBjbGFzc05hbWU9e2Ake2NsYXNzTmFtZX0gcmVsYXRpdmUgbWItMTEgbWwtMGB9XG4gICAgICBzdHlsZT17c3R5bGV9XG4gICAgPlxuICAgICAgPEltYWdlIHNyYz17aW1hZ2VfdXJsfSBhbHQ9XCJjb250ZW50LWltYWdlXCIgY2xhc3NOYW1lPVwiXCIgLz5cbiAgICAgIDxkaXZcbiAgICAgICAgY2xhc3NOYW1lPVwiY29udGVudC1pdGVtLWRlc2MgYmctc2Vjb25kYXJ5LWxpZ2h0IGFic29sdXRlIHRvcC00IHAtM1wiXG4gICAgICAgIHN0eWxlPXt7IHRvcDogXCIyLjVyZW1cIiwgbGVmdDogXCI5LjVyZW1cIiB9fVxuICAgICAgPlxuICAgICAgICA8aDUgY2xhc3NOYW1lPVwidGV4dC1sZyBmb250LW1lZGl1bSBsZWFkaW5nLTYgdGV4dC1wcmltYXJ5LWRhcmsgbWwtMiBwLTAuNVwiPlxuICAgICAgICAgIHt0aXRsZX1cbiAgICAgICAgPC9oNT5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IGp1c3RpZnktYmV0d2VlbiBtbC0yIHBsLTAuNSBwdC0wLjVcIj5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW5vcm1hbCB0ZXh0LXhzIGxlYWRpbmctMyAgdGV4dC1wcmltYXJ5LWRhcmsgb3BhY2l0eS01MFwiPlxuICAgICAgICAgICAgQlkge1wiIFwiICsgYXV0aG9yfVxuICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LW5vcm1hbCB0ZXh0LXhzIGxlYWRpbmctMyAgdGV4dC1wcmltYXJ5LWRhcmsgb3BhY2l0eS01MCBtci0xXCI+XG4gICAgICAgICAgICB7cmVhZF9kdXJhdGlvbiArIFwiIFJFQURcIn1cbiAgICAgICAgICA8L3NwYW4+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIG10LTNcIj5cbiAgICAgICAgICB7LyogPGJ1dHRvbiBvbkNsaWNrPXsoKSA9PiBvbkNsaWNrKGNvbnRlbnRfaWQpfSAvPiAqL31cbiAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICB0aXRsZT17XCJSZWFkIE1vcmVcIn1cbiAgICAgICAgICAgIGNsYXNzTmFtZT1cImgtOCB3LTM2IHRleHQtYWNjZW50XCJcbiAgICAgICAgICAgIHVybD1cIi9pY29ucy9yaWdodEFycm93R3JheS5zdmdcIlxuICAgICAgICAgIC8+XG4gICAgICAgICAgPEltYWdlXG4gICAgICAgICAgICBzcmM9e2dldENvbnRlbnRUeXBlSW1hZ2VVcmwoY29udGVudF90eXBlKX1cbiAgICAgICAgICAgIGFsdD1cImNvbnRlbnQgdHlwZSBpbWFnZVwiXG4gICAgICAgICAgICBjbGFzc05hbWU9XCJtci0xXCJcbiAgICAgICAgICAvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufTtcbiIsImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IENvbnRlbnRJdGVtIH0gZnJvbSBcIkBjb21wb25lbnRzL2NvbnRlbnRJdGVtXCI7XG5cbmV4cG9ydCB0eXBlIFByb3BzID0ge1xuICAgIGNsYXNzTmFtZT86IHN0cmluZ1xuICAgIGNvbnRlbnRMaXN0OiBBcnJheTxhbnk+O1xuICAgIHN0eWxlOiBhbnksXG4gICAgaGVhZGVyIDogYW55O1xufTtcblxuZXhwb3J0IGNvbnN0IENvbnRlbnRTbGlkZXI6IFJlYWN0LkZDPFByb3BzPiA9ICh7IGNvbnRlbnRMaXN0LCBjbGFzc05hbWUgLCBoZWFkZXIsIHN0eWxlPXt9fSkgPT4ge1xuICAgIHJldHVybiAoXG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgJHtjbGFzc05hbWV9YH0gc3R5bGU9e3N0eWxlfT5cbiAgICAgICAgICAgIDxkaXYgPlxuICAgICAgICAgICAgICAgIDxkaXY+e2hlYWRlcn08L2Rpdj5cbiAgICAgICAgICAgICAgICA8ZGl2PjwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXhcIj5cbiAgICAgICAgICAgICAgICB7Y29udGVudExpc3QubWFwKChjb250ZW50SXRlbSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gKFxuICAgICAgICAgICAgICAgICAgICAgICAgPENvbnRlbnRJdGVtXG4gICAgICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtjb250ZW50SXRlbS5jb250ZW50X2lkfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGltYWdlX3VybD17Y29udGVudEl0ZW0uaW1hZ2VfdXJsfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHRpdGxlPXtjb250ZW50SXRlbS50aXRsZX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBhdXRob3I9e2NvbnRlbnRJdGVtLmF1dGhvcn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBjb250ZW50X2lkPXtjb250ZW50SXRlbS5jb250ZW50X2lkfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRlbnRfdHlwZT17Y29udGVudEl0ZW0uY29udGVudF90eXBlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIHJlYWRfZHVyYXRpb249e2NvbnRlbnRJdGVtLnJlYWRfZHVyYXRpb259XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KGlkKSA9PiBjb25zb2xlLmxvZyhpZCl9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgc3R5bGU9e3t3aWR0aDo2MTB9fVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1yLTMgbXQtMiB0ZXh0LWxnIGxlYWRpbmctNlwiXG4gICAgICAgICAgICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgICAgICAgICApO1xuICAgICAgICAgICAgICAgIH0pfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICk7XG59O1xuIiwiaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IG1lbnUgZnJvbSBcIi4uLy4uLy4uL2NvbnN0YW50cy9mb290ZXJNZW51XCI7XG5cblxuY29uc3QgRm9vdGVyTWVudTogUmVhY3QuRkMgPSAoKSA9PiB7XG4gIHJldHVybiAoPGRpdiBjbGFzc05hbWU9XCJzbTpncmlkIHNtOmdyaWQtY29scy0yIHNtOmdhcC15LTAuNSAgYmctcHJpbWFyeSAgIHN1Yi1oMiBsYXB0b3A6ZmxleCBsYXB0b3A6aXRlbXMtY2VudGVyIGxhcHRvcDpwbC01NiBcIj5cbiAgICB7XG4gICAgICBtZW51Lm1hcCgoaXRlbTogYW55LCBpbmRleDogbnVtYmVyKSA9PiB7XG4gICAgICAgIHJldHVybiAoPHNwYW4ga2V5PXtpbmRleH0gY2xhc3NOYW1lPVwicC0xLjVcIj5cbiAgICAgICAgICA8YSBocmVmPXtpdGVtLmxpbmt9IGNsYXNzTmFtZT1cInRleHQtc2Vjb25kYXJ5IGgtMTQgcC0wLjUgbXItMTEgbGVhZGluZy00LjVcIj4ge2l0ZW0ubmFtZX08L2E+XG4gICAgICAgIDwvc3Bhbj4pXG4gICAgICB9KVxuICAgIH1cbiAgPC9kaXY+KVxufVxuXG5leHBvcnQgZGVmYXVsdCBGb290ZXJNZW51O1xuIiwiXG5pbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgRm9vdGVyTWVudSBmcm9tIFwiLi9mb290ZXJNZW51XCI7XG5pbXBvcnQgQnV0dG9uIGZyb20gXCJAY29tcG9uZW50cy9idXR0b24vUHJpbWFyeUJ1dHRvbkljb25SaWdodFwiO1xuaW1wb3J0IHsgUFJJVkFDWV9QT0xJQ1kgfSBmcm9tIFwiLi4vLi4vLi4vY29uc3RhbnRzXCJcblxuZXhwb3J0IGNvbnN0IEZvb3RlcjogUmVhY3QuRkMgPSAoKSA9PiB7XG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4ICBqdXN0aWZ5LWVuZCBmbGV4LWNvbCB0ZXh0LXNlY29uZGFyeSB3LWZ1bGwgYWxpZ24tYm90dG9tIG10LWF1dG9cIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmctYWNjZW50LWRhcmsgZm9vdGVyLXRvcCBmbGV4IGxhcHRvcDpqdXN0aWZ5LWJldHdlZW4gc206ZmxleC1jb2wgc206cGwtMTEgc206cHItMTEgc206cHQtMTFcIj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJsYXB0b3A6ZmxleCBsYXB0b3A6bXQtMTYgcC0wLjUgbGFwdG9wOm1sLTU2XCI+XG4gICAgICAgICAgPGg2IGNsYXNzTmFtZT1cImxhcHRvcDp3LTQ4IGZvbnQtbm9ybWFsIGxlYWRpbmctOSB0ZXh0LTR4bCB0cmFja2luZy13aWRlciBwLTAuNVwiPiBMZXQncyBzdGF5IGVuZ2FnZWQ8L2g2PlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cInAtMSBtbC00XCI+XG4gICAgICAgICAgICA8aDYgY2xhc3NOYW1lPVwic3ViLWgyIGZvbnQtbWVkaXVtIHRleHQtbGcgbGVhZGluZy02XCI+U2lnbiB1cCBmb3IgdGhlIE1hdHJpeCBNb21lbnRzIHNlcmllczwvaDY+XG4gICAgICAgICAgICA8aW5wdXQgY2xhc3NOYW1lPVwibXQtMiB0ZXh0LXNlY29uZGFyeSBiZy1hY2NlbnQgcC0wLjUgcGwtMyB3LWZ1bGxcIiBzdHlsZT17eyBjb2xvcjogXCIjRkJGOUY1XCIgfX0gdHlwZT1cImVtYWlsXCIgcGxhY2Vob2xkZXI9XCJZb3VyIGVtYWlsIGFkZHJlc3MgZ29lcyBoZXJlXCIgLz5cbiAgICAgICAgICAgIDxCdXR0b24gdGl0bGU9XCJTdWJzY3JpYmVcIiB1cmw9XCIvaWNvbnMvYXJyb3cuc3ZnXCIgY2xhc3NOYW1lPXtcInAtMSB0ZXh0LWN0YVwifSBvbkNsaWNrPXsoKSA9PiBjb25zb2xlLmxvZyhcInN1YnNjcmliZVwiKX0gLz5cbiAgICAgICAgICA8L3NwYW4+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIiBsYXB0b3A6bXQtMTYgcC0wLjUgbGFwdG9wOm1yLTUyIHNtOmZsZXggc206anVzdGlmeS1iZXR3ZWVuIFwiPlxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8aDYgY2xhc3NOYW1lPVwic3ViLWgyIGZvbnQtbWVkaXVtIHRleHQtbGdcIj4gTWF0cml4IFBhcnRuZXIgVXMgPC9oNj5cbiAgICAgICAgICAgIDxoNiBjbGFzc05hbWU9XCIgc3ViLWgyIGZvbnQtbWVkaXVtIHRleHQtbGdcIj4gTWF0cml4IFBhcnRuZXIgQ2hpbmE8L2g2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBtdC0yIGxhcHRvcDptdC04IGl0ZW1zLXN0YXJ0IHAtMC41XCI+XG4gICAgICAgICAgICA8YSBjbGFzc05hbWU9XCIgcGwtMFwiPjxpbWcgc3JjPVwiL2ljb25zL2xpbmtlZGluLnN2Z1wiIC8+PC9hPlxuICAgICAgICAgICAgPGEgY2xhc3NOYW1lPVwiIHBsLTlcIj4gPGltZyBzcmM9XCIvaWNvbnMvdHdpdHRlci5zdmdcIiAvPjwvYT5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiIGxhcHRvcDpmbGV4IGp1c3RpZnktYmV0d2VlbiBmb290ZXItbWVudSBiZy1wcmltYXJ5IGFsaWduLW1pZGRsZSBzbTpwbC0xMSBzbTpwdC02XCI+XG4gICAgICAgIDxGb290ZXJNZW51IC8+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiIHRleHQtc2Vjb25kYXJ5IGZsZXggaXRlbXMtY2VudGVyIHNtOm10LTIgc206Z3JpZCBzbTpncmlkLWNvbHMtMiBzbTpnYXAtMFwiPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImNhcHRpb24gcC0xIHctMjggdGV4dC1zbSBzbTptdC0yXCIgPlBSSVZBQ1kgUE9MSUNZPC9zcGFuPlxuICAgICAgICAgIDxwIGNsYXNzTmFtZT1cImNhcHRpb24gcC0wLjUgbGFwdG9wOm1sLTIwIGxhcHRvcDptci00MCBcIj57UFJJVkFDWV9QT0xJQ1l9IDwvcD5cbiAgICAgICAgPC9kaXY+XG4gICAgICA8L2Rpdj5cblxuICAgIDwvZGl2PlxuICApO1xufTtcbiIsImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCBTbGlkZXIgZnJvbSBcInJlYWN0LXNsaWNrXCI7XG5pbXBvcnQgXCJzbGljay1jYXJvdXNlbC9zbGljay9zbGljay5jc3NcIjtcbmltcG9ydCBcInNsaWNrLWNhcm91c2VsL3NsaWNrL3NsaWNrLXRoZW1lLmNzc1wiO1xuaW1wb3J0IHsgSW1hZ2UsIENvbnRlbnRTbGlkZXIgfSBmcm9tIFwiQGNvbXBvbmVudHNcIjtcblxuZXhwb3J0IHR5cGUgUHJvcHMgPSB7XG4gIG5hbWVzPzogQXJyYXk8c3RyaW5nPjtcbiAgYmFja2dyb3VuZF91cmw/OiBzdHJpbmc7XG4gIHRhZ3M/OiBBcnJheTxzdHJpbmc+O1xuICBsb2dvPzogc3RyaW5nO1xuICBjbGFzc05hbWU/OiBzdHJpbmc7XG4gIHN0eWxlPzogYW55O1xufTtcblxuZXhwb3J0IGNvbnN0IEZvdW5kZXI6IFJlYWN0LkZDPFByb3BzPiA9ICh7IGNsYXNzTmFtZSwgc3R5bGUgPSB7fSB9KSA9PiB7XG4gIGNvbnN0IGhlcm9zID0gW3tcbiAgICBmaXJzdE5hbWU6ICdCaGF2aXNoJyxcbiAgICBsYXN0TmFtZTogJ0FHR0FSV0FMJyxcbiAgICBmaXJzdE5hbWUxOiBudWxsLFxuICAgIGxhc3ROYW1lMTogbnVsbCxcbiAgICBjYXB0aW9uOiAnTW9iaWxpdHknLFxuICAgIGNhcHRpb24xOiAnRWxlY3RyaWMgQ2FycycsXG4gICAgbG9nbzogJy9pY29ucy9vbGEuc3ZnJyxcbiAgICBpbWFnZTogJy9pY29ucy9CaGF2aXNoX2ltYWdlLnN2ZycsXG4gICAgaGVhZGluZzogWydXZSBhcmUnLCAnZm91bmRlcnMnLCAnZmlyc3QnXVxuICB9LCB7XG4gICAgZmlyc3ROYW1lOiAnUk9ISVQnLFxuICAgIGxhc3ROYW1lOiAnTS5BLicsXG4gICAgZmlyc3ROYW1lMTogbnVsbCxcbiAgICBsYXN0TmFtZTE6IG51bGwsXG4gICAgY2FwdGlvbjogJ0hlYWx0aGNhcmUnLFxuICAgIGNhcHRpb24xOiBudWxsLFxuICAgIGxvZ286ICcvaWNvbnMvQ2xvdWRuaW5lLnN2ZycsXG4gICAgaW1hZ2U6ICcvaWNvbnMvUm9oaXRfVHJlYXRtZW50LnN2ZycsXG4gICAgaGVhZGluZzogWydXZSAnLCAncGFydG5lcicsICdjbG9zZWx5J11cbiAgfSwge1xuICAgIGZpcnN0TmFtZTogJ0FOSU5EWUEnLFxuICAgIGxhc3ROYW1lOiAnRFVUVEEnLFxuICAgIGZpcnN0TmFtZTE6ICdTQU5ERUVQJyxcbiAgICBsYXN0TmFtZTE6ICdEQUxNSUEnLFxuICAgIGNhcHRpb246ICdTdHVkZW50IEhvdXNpbmcgUGxhdGZvcm0nLFxuICAgIGNhcHRpb24xOiBudWxsLFxuICAgIGxvZ286ICcvaWNvbnMvU3RhbnphLnN2ZycsXG4gICAgaW1hZ2U6ICcvaWNvbnMvQW5pbmR5YS5zdmcnLFxuICAgIGhlYWRpbmc6IFsnV2UgJywgJ2ludmVzdCcsICdlYXJseSddXG4gIH0sIHtcbiAgICBmaXJzdE5hbWU6ICdBc2lzaCcsXG4gICAgbGFzdE5hbWU6ICdNT0hBUEFUUkEnLFxuICAgIGZpcnN0TmFtZTE6IG51bGwsXG4gICAgbGFzdE5hbWUxOiBudWxsLFxuICAgIGNhcHRpb246ICdGaW50ZWNoJyxcbiAgICBjYXB0aW9uMTogJ1NNRSBMZW5kaW5nJyxcbiAgICBsb2dvOiAnL2ljb25zL09mQnVzaW5lc3Muc3ZnJyxcbiAgICBpbWFnZTogJy9pY29ucy9Bc2lzaC5zdmcnLFxuICAgIGhlYWRpbmc6IFsnV2UnLCAnY29tbWl0JywgJ3BlcnNvbmFsbHknXVxuICB9LCB7XG4gICAgZmlyc3ROYW1lOiAnTXIuJyxcbiAgICBsYXN0TmFtZTogJ0xBS1NISVBBVEhZJyxcbiAgICBmaXJzdE5hbWUxOiBudWxsLFxuICAgIGxhc3ROYW1lMTogbnVsbCxcbiAgICBjYXB0aW9uOiAnRmludGVjaCcsXG4gICAgY2FwdGlvbjE6ICdOQkZDJyxcbiAgICBsb2dvOiAnL2ljb25zL214LnN2ZycsXG4gICAgaW1hZ2U6ICcvaWNvbnMvTGF4bWlwYXRoeS5zdmcnLFxuICAgIGhlYWRpbmc6IFsnV2UgYXJlJywgJ2ZvdW5kZXJzJywgJ2ZpcnN0J11cbiAgfSwge1xuICAgIGZpcnN0TmFtZTogJ0NIQUtSQURIQVInLFxuICAgIGxhc3ROYW1lOiAnR0FERScsXG4gICAgZmlyc3ROYW1lMTogJ05JVElOJyxcbiAgICBsYXN0TmFtZTE6ICdLQVVTSEFMJyxcbiAgICBjYXB0aW9uOiAnRmludGVjaCcsXG4gICAgY2FwdGlvbjE6ICdOQkZDJyxcbiAgICBsb2dvOiAnL2ljb25zL0NvdW50cnkuc3ZnJyxcbiAgICBoZWFkaW5nOiBbJ1dlJywgJ2NvbW1pdCcsICdwZXJzb25hbGx5J10sXG4gICAgaW1hZ2U6ICcvaWNvbnMvQ2hha3JhZGhhci5zdmcnXG4gIH1dXG5cbiAgY29uc3QgZGF0YSA9IFtcbiAgICB7XG4gICAgICBpbWFnZV91cmw6IFwiL2ljb25zL2NvbnRlbnQxLnN2Z1wiLFxuICAgICAgdGl0bGU6IFwiRnJvbSBib3RoIHNpZGVzIG9mIHRoZSB0YWJsZSA6IEt1bmFsIEJhaGwgdW5wbHVnZ2VkXCIsXG4gICAgICBhdXRob3I6IFwiVEFSVU4gREFWREFcIixcbiAgICAgIGNvbnRlbnRfaWQ6IFwiYWJjZGVmXCIsXG4gICAgICBjb250ZW50X3R5cGU6IFwiYmxvZ1wiLFxuICAgICAgcmVhZF9kdXJhdGlvbjogXCI0IE1JTlwiLFxuICAgIH0sXG4gICAge1xuICAgICAgaW1hZ2VfdXJsOiBcIi9pY29ucy9jb250ZW50MS5zdmdcIixcbiAgICAgIHRpdGxlOiBcIkZyb20gYm90aCBzaWRlcyBvZiB0aGUgdGFibGUgOiBLdW5hbCBCYWhsIHVucGx1Z2dlZFwiLFxuICAgICAgYXV0aG9yOiBcIlRBUlVOIERBVkRBXCIsXG4gICAgICBjb250ZW50X2lkOiBcImFiY2RlZmdcIixcbiAgICAgIGNvbnRlbnRfdHlwZTogXCJibG9nXCIsXG4gICAgICByZWFkX2R1cmF0aW9uOiBcIjQgTUlOXCIsXG4gICAgfSxcblxuICBdO1xuXG4gIGNvbnN0IHNldHRpbmdzID0ge1xuICAgIGRvdHM6IHRydWUsXG4gICAgaW5maW5pdGU6IHRydWUsXG4gICAgc3BlZWQ6IDUwMCxcbiAgICBhdXRvcGxheVNwZWVkOiA1MDAwLFxuICAgIHNsaWRlc1RvU2hvdzogMSxcbiAgICBzbGlkZXNUb1Njcm9sbDogMSxcbiAgICAvLyBhdXRvcGxheTogdHJ1ZVxuICB9O1xuICByZXR1cm4gKFxuICAgIDxTbGlkZXIgey4uLnNldHRpbmdzfT5cbiAgICAgIHtoZXJvcy5tYXAoaGVybyA9PiB7XG4gICAgICAgIHJldHVybiAoPGRpdj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YCR7Y2xhc3NOYW1lfWB9IHN0eWxlPXt7IHdpZHRoOiA2MTUuOTQsIGhlaWdodDogODYzLjkxLCBwb3NpdGlvbjogXCJyZWxhdGl2ZVwiLCAuLi5zdHlsZSwgfX0+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIlwiIHN0eWxlPXt7IHdpZHRoOiA1NzEsIGhlaWdodDogNzYyLCBwb3NpdGlvbjogXCJhYnNvbHV0ZVwiLCBiYWNrZ3JvdW5kOiBcIiMwODNBNEFcIiwgYm90dG9tOiA1MCwgbGVmdDogMCwgfX0+PC9kaXY+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIlwiIHN0eWxlPXt7IHdpZHRoOiA1OTQsIGhlaWdodDogNzg4LCBib3R0b206IDY1LCBsZWZ0OiAxNSwgcG9zaXRpb246IFwiYWJzb2x1dGVcIiwgZGlzcGxheTogXCJmbGV4XCIsIGZsZXhEaXJlY3Rpb246IFwiY29sdW1uXCIsIH19PlxuICAgICAgICAgICAgICA8SW1hZ2Ugc3JjPXtoZXJvLmltYWdlfSBhbHQ9XCJmb3VuZGVyIGltYWdlXCIgc3R5bGU9e3sgZmxleEdyb3c6IDEgfX0+PC9JbWFnZT5cbiAgICAgICAgICAgICAgPEltYWdlIHNyYz1cIi9pY29ucy9yZWN0YW5nbGUuc3ZnXCIgYWx0PXtcInJlYWN0YW5nbGVcIn0gY2xhc3NOYW1lPVwiYWJzb2x1dGVcIiBzdHlsZT17eyBsZWZ0OiAzOCwgYm90dG9tOiAyNTQgfX0gLz5cblxuICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IGhlaWdodDogMjA5LCBiYWNrZ3JvdW5kOiBcIiMwMTU3NkVcIiB9fT5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIGZsZXggaXRlbXMtY2VudGVyXCIgc3R5bGU9e3sgaGVpZ2h0OiAxMTgsIGJvcmRlckJvdHRvbTogXCIxcHggc29saWQgI0VCRUJFOVwiIH19PlxuICAgICAgICAgICAgICAgICAgPGg2IGNsYXNzTmFtZT1cImZvbnQtYm9sZCB0ZXh0LXNlY29uZGFyeVwiIHN0eWxlPXt7IGZvbnRTaXplOiAzMiwgbGluZUhlaWdodDogXCIzNnB4XCIsIGxldHRlclNwYWNpbmc6IFwiMC4wNWVtXCIsIG1hcmdpbkxlZnQ6IDMxLCBtYXJnaW5SaWdodDogOCwgfX0+XG4gICAgICAgICAgICAgICAgICAgIHtoZXJvLmZpcnN0TmFtZX1cbiAgICAgICAgICAgICAgICAgIDwvaDY+XG4gICAgICAgICAgICAgICAgICA8aDYgY2xhc3NOYW1lPVwiZm9udC1saWdodCB0ZXh0LXNlY29uZGFyeVwiIHN0eWxlPXt7IGZvbnRTaXplOiAzMiwgbGluZUhlaWdodDogXCIzNnB4XCIsIGxldHRlclNwYWNpbmc6IFwiMC4wNWVtXCIsIH19PlxuICAgICAgICAgICAgICAgICAgICB7aGVyby5sYXN0TmFtZX1cbiAgICAgICAgICAgICAgICAgIDwvaDY+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIGl0ZW1zLWNlbnRlclwiIHN0eWxlPXt7IGhlaWdodDogODggfX0+XG4gICAgICAgICAgICAgICAgICA8ZGl2IHN0eWxlPXt7IG1hcmdpbkxlZnQ6IDMxLCBkaXNwbGF5OiAnZmxleCcsIGp1c3RpZnlDb250ZW50OiAnc3BhY2UtYXJvdW5kJyB9fT5cbiAgICAgICAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zZWNvbmRhcnkgZm9udC1tZWRpdW0gdGV4dC1sZyBsZWFkaW5nLTZcIj4ge2hlcm8uY2FwdGlvbn08L3NwYW4+XG4gICAgICAgICAgICAgICAgICAgIHtoZXJvLmNhcHRpb24xICYmIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2Vjb25kYXJ5IGZvbnQtbWVkaXVtIHRleHQtbGcgbGVhZGluZy02XCI+PGhyIHN0eWxlPXt7IHdpZHRoOiAzMCwgdHJhbnNmb3JtOiAncm90YXRlKDkwZGVnKScgfX0gLz48L3NwYW4+fVxuICAgICAgICAgICAgICAgICAgICB7aGVyby5jYXB0aW9uMSAmJiA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNlY29uZGFyeSBmb250LW1lZGl1bSB0ZXh0LWxnIGxlYWRpbmctNlwiPiB7aGVyby5jYXB0aW9uMX08L3NwYW4+fVxuICAgICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgICA8SW1hZ2Ugc3JjPXtoZXJvLmxvZ299IGFsdD17XCJvbGFcIn0gc3R5bGU9e3sgbWFyZ2luUmlnaHQ6IDU3IH19IC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiXCIgc3R5bGU9e3sgbGVmdDogNzYwLCBwb3NpdGlvbjogXCJhYnNvbHV0ZVwiIH19PlxuICAgICAgICAgICAgICA8cCBjbGFzc05hbWU9J3NsaWRlLWhlYWRlcic+e2hlcm8uaGVhZGluZ1swXX08c3BhbiBzdHlsZT17eyBjb2xvcjogJyMwMTU3NkUnIH19PiB7aGVyby5oZWFkaW5nWzFdfSA8L3NwYW4+IHtoZXJvLmhlYWRpbmdbMl19PC9wPlxuXG4gICAgICAgICAgICAgIDxDb250ZW50U2xpZGVyXG4gICAgICAgICAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICAgICAgICAgIGxlZnQ6IC0xMixcbiAgICAgICAgICAgICAgICAgIGJhY2tncm91bmQ6IFwiI0VCRUJFOVwiLFxuICAgICAgICAgICAgICAgICAgYm9yZGVyOiBcIjFweCBzb2xpZCAjRUJFQkU5XCIsXG4gICAgICAgICAgICAgICAgICBib3hTaXppbmc6IFwiYm9yZGVyLWJveFwiLFxuICAgICAgICAgICAgICAgICAgZm9udFNpemU6IDI4LFxuICAgICAgICAgICAgICAgICAgbGluZUhlaWdodDogXCIzNHB4XCIsXG4gICAgICAgICAgICAgICAgICBwYWRkaW5nVG9wOiAyNCxcbiAgICAgICAgICAgICAgICAgIHBhZGRpbmdMZWZ0OiAzNCxcbiAgICAgICAgICAgICAgICAgIHdpZHRoOiAnMTU1JScsXG4gICAgICAgICAgICAgICAgICBib3R0b206IC0zNDcsXG4gICAgICAgICAgICAgICAgICBoZWlnaHQ6IDMwMVxuICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgICAgY29udGVudExpc3Q9e2RhdGF9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiYWJzb2x1dGUgYm90dG9tLTAgcmlnaHQtMCB0ZXh0LXByaW1hcnktZGFya1wiXG4gICAgICAgICAgICAgICAgaGVhZGVyPXs8c3Bhbj5JbnNpZ2h0cyBmcm9tIG1hcmtldCA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LWFjY2VudFwiPmRpc3J1cHRvcnMgJiBpbnZlc3RvcnM8L3NwYW4+PC9zcGFuPn1cbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj4pXG4gICAgICB9KX1cblxuXG5cblxuICAgIDwvU2xpZGVyPlxuICApO1xufTtcbiIsImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IEltYWdlIH0gZnJvbSBcIkBjb21wb25lbnRzXCI7XG5cbmV4cG9ydCB0eXBlIFByb3BzID0ge1xuICBuYW1lcz86IEFycmF5PHN0cmluZz47XG4gIGJhY2tncm91bmRfdXJsPzogc3RyaW5nO1xuICB0YWdzPzogQXJyYXk8c3RyaW5nPjtcbiAgbG9nbz86IHN0cmluZztcbiAgY2xhc3NOYW1lPzogc3RyaW5nO1xuICBzdHlsZT86IGFueTtcbn07XG5cbmV4cG9ydCBjb25zdCBGb3VuZGVyRGV0YWlsOiBSZWFjdC5GQzxQcm9wcz4gPSAoe1xuICBjbGFzc05hbWUgPSBcIlwiLFxuICBzdHlsZSA9IHt9LFxufSkgPT4ge1xuICByZXR1cm4gKFxuICAgIDxkaXZcbiAgICAgIGNsYXNzTmFtZT1cIlwiXG4gICAgICBzdHlsZT17e1xuICAgICAgICAuLi57XG4gICAgICAgICAgd2lkdGg6IDY1MCxcbiAgICAgICAgICBoZWlnaHQ6IDc0NCxcbiAgICAgICAgICBwb3NpdGlvbjogXCJyZWxhdGl2ZVwiLFxuICAgICAgICB9LFxuICAgICAgICAuLi5zdHlsZSxcbiAgICAgIH19XG4gICAgPlxuICAgICAgPGRpdlxuICAgICAgICBjbGFzc05hbWU9XCJcIlxuICAgICAgICBzdHlsZT17e1xuICAgICAgICAgIHdpZHRoOiA2MjAsXG4gICAgICAgICAgaGVpZ2h0OiA3MTEsXG4gICAgICAgICAgcG9zaXRpb246IFwiYWJzb2x1dGVcIixcbiAgICAgICAgICBiYWNrZ3JvdW5kOiBcIiMwODNBNEFcIixcbiAgICAgICAgICBib3R0b206IDAsXG4gICAgICAgICAgbGVmdDogMCxcbiAgICAgICAgfX1cbiAgICAgID48L2Rpdj5cbiAgICAgIDxkaXZcbiAgICAgICAgY2xhc3NOYW1lPVwiXCJcbiAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICB3aWR0aDogNjM4LFxuICAgICAgICAgIGhlaWdodDogNzMyLFxuICAgICAgICAgIHBvc2l0aW9uOiBcImFic29sdXRlXCIsXG4gICAgICAgICAgbGVmdDogMTUsXG4gICAgICAgICAgYm90dG9tOiAxNSxcbiAgICAgICAgICBkaXNwbGF5OiBcImZsZXhcIixcbiAgICAgICAgICBmbGV4RGlyZWN0aW9uOiBcImNvbHVtblwiLFxuICAgICAgICB9fVxuICAgICAgPlxuICAgICAgICA8SW1hZ2VcbiAgICAgICAgICBzcmM9XCIvaWNvbnMvZm91bmRlckRldGFpbC5qcGdcIlxuICAgICAgICAgIGFsdD1cImZvdW5kZXIgZGV0YWlsXCJcbiAgICAgICAgICBzdHlsZT17eyBmbGV4R3JvdzogMSB9fVxuICAgICAgICA+PC9JbWFnZT5cbiAgICAgICAgPEltYWdlXG4gICAgICAgICAgc3JjPVwiL2ljb25zL3JlY3RhbmdsZS5zdmdcIlxuICAgICAgICAgIGFsdD17XCJyZWFjdGFuZ2xlXCJ9XG4gICAgICAgICAgY2xhc3NOYW1lPVwiYWJzb2x1dGVcIlxuICAgICAgICAgIHN0eWxlPXt7IGxlZnQ6IDM4LCBib3R0b206IDI1MyB9fVxuICAgICAgICAvPlxuICAgICAgICA8ZGl2IHN0eWxlPXt7IGhlaWdodDogMjMyLCBiYWNrZ3JvdW5kOiBcIiMwMTU3NkVcIiB9fT5cbiAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LWNlbnRlciBmbGV4ICBmbGV4LWNvbCBqdXN0aWZ5LWNlbnRlclwiXG4gICAgICAgICAgICBzdHlsZT17eyBoZWlnaHQ6IDExOCwgYm9yZGVyQm90dG9tOiBcIjAuODk0OTFweCBzb2xpZCAjRUJFQkU5XCIgfX1cbiAgICAgICAgICA+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXhcIj5cbiAgICAgICAgICAgICAgPGg2XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtc2Vjb25kYXJ5XCJcbiAgICAgICAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgICAgICAgZm9udFNpemU6IDMyLFxuICAgICAgICAgICAgICAgICAgbGluZUhlaWdodDogXCIzNnB4XCIsXG4gICAgICAgICAgICAgICAgICBsZXR0ZXJTcGFjaW5nOiBcIjAuMDVlbVwiLFxuICAgICAgICAgICAgICAgICAgbWFyZ2luTGVmdDogMzEsXG4gICAgICAgICAgICAgICAgICBtYXJnaW5SaWdodDogOCxcbiAgICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgQU5JTllBXG4gICAgICAgICAgICAgIDwvaDY+XG4gICAgICAgICAgICAgIDxoNlxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZvbnQtbGlnaHQgdGV4dC1zZWNvbmRhcnlcIlxuICAgICAgICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICAgICAgICBmb250U2l6ZTogMzIsXG4gICAgICAgICAgICAgICAgICBsaW5lSGVpZ2h0OiBcIjM2cHhcIixcbiAgICAgICAgICAgICAgICAgIGxldHRlclNwYWNpbmc6IFwiMC4wNWVtXCIsXG4gICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIERVVFRBXG4gICAgICAgICAgICAgIDwvaDY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleFwiPlxuICAgICAgICAgICAgICA8aDZcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJmb250LWJvbGQgdGV4dC1zZWNvbmRhcnlcIlxuICAgICAgICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICAgICAgICBmb250U2l6ZTogMzIsXG4gICAgICAgICAgICAgICAgICBsaW5lSGVpZ2h0OiBcIjM2cHhcIixcbiAgICAgICAgICAgICAgICAgIGxldHRlclNwYWNpbmc6IFwiMC4wNWVtXCIsXG4gICAgICAgICAgICAgICAgICBtYXJnaW5MZWZ0OiAzMSxcbiAgICAgICAgICAgICAgICAgIG1hcmdpblJpZ2h0OiA4LFxuICAgICAgICAgICAgICAgIH19XG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICBTQU5ERUVQXG4gICAgICAgICAgICAgIDwvaDY+XG4gICAgICAgICAgICAgIDxoNlxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZvbnQtbGlnaHQgdGV4dC1zZWNvbmRhcnlcIlxuICAgICAgICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICAgICAgICBmb250U2l6ZTogMzIsXG4gICAgICAgICAgICAgICAgICBsaW5lSGVpZ2h0OiBcIjM2cHhcIixcbiAgICAgICAgICAgICAgICAgIGxldHRlclNwYWNpbmc6IFwiMC4wNWVtXCIsXG4gICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgIERBTE1JQVxuICAgICAgICAgICAgICA8L2g2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59O1xuIiwiZXhwb3J0IHsgRm91bmRlciB9IGZyb20gXCIuL0ZvdW5kZXJcIjsiLCJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5cbmltcG9ydCB7IExvZ28gfSBmcm9tICdAY29tcG9uZW50cyc7XG5cbmV4cG9ydCB0eXBlIFByb3BzID0ge1xuICB0b2dnbGU6ICgpID0+IHZvaWQ7XG59XG5cbmV4cG9ydCBjb25zdCBIZWFkZXI6IFJlYWN0LkZDPFByb3BzPiA9ICh7IHRvZ2dsZSB9KSA9PiB7XG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBmbGV4IHctZnVsbCB6LTIwIGp1c3RpZnktYmV0d2VlbiBpdGVtcy1zdGFydCBsYXB0b3A6cGwtOCBtdC0xMSBzbTptdC0wIHNtOnAtNVwiPlxuICAgICAgPExvZ28gLz5cbiAgICAgIDxkaXZcbiAgICAgICAgY2xhc3NOYW1lPVwiZmxleCAgaXRlbXMtY2VudGVyIGp1c3RpZnktc3RhcnQgbXQtMiB0ZXh0LWFjY2VudCBcIlxuICAgICAgICBvbkNsaWNrPXsoKSA9PiB0b2dnbGUoKX1cbiAgICAgID5cbiAgICAgICAgPGg2IGNsYXNzTmFtZT1cInN1Yi1oMSBwci0xIG1lbnUtdGV4dFwiPk1lbnU8L2g2PlxuICAgICAgICA8aW1nXG4gICAgICAgICAgc3JjPVwiL2ljb25zL21lbnUuc3ZnXCJcbiAgICAgICAgICBjbGFzc05hbWU9XCJwbC0yIGxhcHRvcDptci0yMCB0ZXh0LWJsdWVcIlxuICAgICAgICA+PC9pbWc+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG4iLCJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5cbmV4cG9ydCB0eXBlIFByb3BzID0ge1xuICAgIHNyYzogc3RyaW5nO1xuICAgIGFsdDogc3RyaW5nO1xuICAgIGNsYXNzTmFtZT86IHN0cmluZztcbiAgICBoZWlnaHQ/OiBudW1iZXI7XG4gICAgd2lkdGg/OiBudW1iZXI7XG4gICAgc3R5bGU/OiBhbnlcbn1cblxuZXhwb3J0IGNvbnN0IEltYWdlOiBSZWFjdC5GQzxQcm9wcz4gPSAoeyBzcmMsIGFsdCwgY2xhc3NOYW1lICwgd2lkdGgsIGhlaWdodCAsIHN0eWxlPXt9IH0pID0+IHtcbiAgICByZXR1cm4gPGltZyBzcmM9e3NyY30gYWx0PXthbHR9IGNsYXNzTmFtZT17Y2xhc3NOYW1lfSBoZWlnaHQ9e2hlaWdodH0gd2lkdGg9e3dpZHRofSBzdHlsZT17c3R5bGV9ID48L2ltZz5cbn1cbiIsImV4cG9ydCB7IEhlYWRlciB9IGZyb20gXCIuL2hlYWRlclwiO1xuZXhwb3J0IHsgTG9nbyB9IGZyb20gXCIuL2xvZ29cIjtcbmV4cG9ydCB7IE1haW4gfSBmcm9tIFwiLi9tYWluXCI7XG5leHBvcnQgeyBCdXR0b24gfSBmcm9tIFwiLi9idXR0b25cIjtcbmV4cG9ydCB7IENhcmRzIH0gZnJvbSBcIi4vY2FyZHNcIjtcbmV4cG9ydCB7IEZvb3RlciB9IGZyb20gXCIuL2Zvb3RlclwiO1xuZXhwb3J0IHsgQ29udGFpbmVyIH0gZnJvbSBcIi4vY29udGFpbmVyXCI7XG5leHBvcnQgeyBJbWFnZSB9IGZyb20gXCIuL2ltYWdlXCI7XG5leHBvcnQgeyBUYWcgfSBmcm9tIFwiLi90YWdcIjtcbmV4cG9ydCB7IE5hdkl0ZW0gfSBmcm9tIFwiLi9uYXZJdGVtXCI7XG5leHBvcnQgeyBDb250ZW50SXRlbSB9IGZyb20gXCIuL2NvbnRlbnRJdGVtXCI7XG5leHBvcnQgeyBGb3VuZGVyIH0gZnJvbSBcIi4vZm91bmRlclwiO1xuZXhwb3J0IHsgQ29udGVudFNsaWRlciB9IGZyb20gXCIuL2NvbnRlbnRTbGlkZXIvQ29udGVudFNsaWRlclwiO1xuZXhwb3J0IHsgQmFubmVyIH0gZnJvbSBcIi4vYmFubmVyXCJcbiIsImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCBJbWFnZSBmcm9tIFwibmV4dC9pbWFnZVwiO1xuXG5leHBvcnQgY29uc3QgTG9nbzogUmVhY3QuRkMgPSAoKSA9PiB7XG4gIHJldHVybiAoXG4gICAgLy8gPEltYWdlIHNyYz1cIi9pY29ucy9tYXRyaXhMb2dvX1doaXRlLnN2Z1wiIGFsdD1cIm5leHRqc1wiIHdpZHRoPVwiMTU2LjE5cHhcIiBoZWlnaHQ9XCI2NXB4XCIgY2xhc3NOYW1lPVwiY29tcGFueS1sb2dvXCIgLz5cbiAgICA8SW1hZ2Ugc3JjPVwiL2ljb25zL21hdHJpeExvZ28uc3ZnXCIgYWx0PVwibmV4dGpzXCIgd2lkdGg9XCIxNTYuMTlweFwiIGhlaWdodD1cIjY1cHhcIiBjbGFzc05hbWU9XCJjb21wYW55LWxvZ29cIiAvPlxuICApO1xufTtcbiIsImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcblxuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSBcIkBjb21wb25lbnRzXCI7XG5cbmV4cG9ydCBjb25zdCBNYWluOiBSZWFjdC5GQyA9ICgpID0+IHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIGZvbnQtbGlnaHQgcHktNSBiZy1ncmF5LTcwMFwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb250YWluZXIgbXgtYXV0b1wiPlxuICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC13aGl0ZSB0ZXh0LTh4bCBtYi0yXCI+bWF0cml4PC9oMT5cbiAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1sZyB0ZXh0LXdoaXRlIG1iLTNcIj5cbiAgICAgICAgICBUaGUgZnJvbnRlbmQgYm9pbGVycGxhdGUgd2l0aCBzdXBlcnBvd2VycyFcbiAgICAgICAgPC9wPlxuICAgICAgICA8QnV0dG9uIHR5cGU9XCJidXR0b25cIj5cbiAgICAgICAgICA8YSBocmVmPVwiaHR0cHM6Ly9wYW5rb2QuZ2l0aHViLmlvL3N1cGVycGxhdGUvXCIgdGFyZ2V0PVwiX2JsYW5rXCI+XG4gICAgICAgICAgICBEb2NzXG4gICAgICAgICAgPC9hPlxuICAgICAgICA8L0J1dHRvbj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufTtcbiIsImltcG9ydCB7IHRpdGxlIH0gZnJvbSBcInByb2Nlc3NcIjtcbmltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IEltYWdlIH0gZnJvbSBcIkBjb21wb25lbnRzXCI7XG5cbmV4cG9ydCB0eXBlIFByb3BzID0ge1xuICB0aXRsZTogc3RyaW5nO1xuICBpZDogc3RyaW5nO1xuICBvbkNsaWNrOiAoaWQ6IHN0cmluZykgPT4gdm9pZDtcbiAgc2VsZWN0ZWQ6IGJvb2xlYW47XG4gIGNsYXNzTmFtZT86IHN0cmluZztcbiAgYXJyb3c6IGJvb2xlYW47XG59O1xuXG5leHBvcnQgY29uc3QgTmF2SXRlbTogUmVhY3QuRkM8UHJvcHM+ID0gKHtcbiAgdGl0bGUsXG4gIHNlbGVjdGVkLFxuICBpZCxcbiAgb25DbGljayxcbiAgY2xhc3NOYW1lID0gXCJcIixcbiAgYXJyb3cgPSB0cnVlLFxufSkgPT4ge1xuICByZXR1cm4gKFxuICAgIDxkaXZcbiAgICAgIGNsYXNzTmFtZT17YCR7Y2xhc3NOYW1lfSBmbGV4IGp1c3RpZnktYmV0d2VlbiBtZW51LXByaW1hcnktbmF2LXRleHQgdGV4dC1wcmltYXJ5LWRhcmtgfVxuICAgICAgc3R5bGU9e3sgbWFyZ2luQm90dG9tOiAyNSB9fVxuICAgICAgb25DbGljaz17KCkgPT4gb25DbGljayhpZCl9XG4gICAgPlxuICAgICAgPHNwYW4+e3RpdGxlfTwvc3Bhbj5cbiAgICAgIHsvKiA8SW1hZ2Ugc3JjPVwiL2ljb25zL3JpZ2h0QXJyb3cubGFyZ2Uuc3ZnXCIgYWx0PVwiaW1hZ2VcIiBjbGFzc05hbWU9XCJtZW51X3ByaW1hcnlfbmF2X2ljb25cIiAgLz4gKi99XG4gICAgICB7IChzZWxlY3RlZCB8fCBhcnJvdyApID8gKFxuICAgICAgICAoIXNlbGVjdGVkKSA/IChcbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtZW51LXByaW1hcnktbmF2LWljb25cIj4ge1wiPlwifSA8L3NwYW4+XG4gICAgICAgICkgOiAoXG4gICAgICAgICAgPEltYWdlXG4gICAgICAgICAgICBzcmM9e1wiL2ljb25zL3NpZGVOYXZCdXR0b24uc3ZnXCJ9XG4gICAgICAgICAgICBhbHQ9XCJuYXYgYnV0dG9uXCJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cIi1tci01IG9wYWNpdHktMTAwXCJcbiAgICAgICAgICAvPlxuICAgICAgICApXG4gICAgICApIDogbnVsbH1cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG4iLCJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5cbmV4cG9ydCB0eXBlIFByb3BzID0ge1xuICAgIHNlbGVjdGVkOiBib29sZWFuO1xuICAgIHRpdGxlOiBzdHJpbmc7XG4gICAgaWQ6IHN0cmluZztcbiAgICBvbkNsaWNrPzogKHN0cmluZykgPT4gdm9pZDtcbiAgICBjbGFzc05hbWU/OiBzdHJpbmc7XG4gICAgc3R5bGU/OiBhbnk7XG59XG5cblxuZXhwb3J0IGNvbnN0IFRhZzogUmVhY3QuRkM8UHJvcHM+ID0gKHsgc2VsZWN0ZWQsIHRpdGxlLCBpZCwgb25DbGljaywgY2xhc3NOYW1lID0gXCJcIiwgc3R5bGUgPSB7fSB9OiBQcm9wcykgPT4ge1xuICAgIGNvbnN0IF9jbGFzc05hbWUgPSBzZWxlY3RlZCA/IFwidGFnLXNlbGVjdGVkXCIgOiBcInRhZ1wiO1xuICAgIHJldHVybiAoPHNwYW4gY2xhc3NOYW1lPXtjbGFzc05hbWUgKyBcIiBcIiArIF9jbGFzc05hbWV9IHN0eWxlPXtzdHlsZX0gb25DbGljaz17KCkgPT4geyBpZiAob25DbGljaykgb25DbGljayhpZCkgfX0+XG4gICAgICAgIHt0aXRsZX1cbiAgICA8L3NwYW4+KVxufSIsImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCBIb21lQ29udGVudCBmcm9tIFwiLi9ob21lQ29udGVudFwiO1xuaW1wb3J0IEhvbWVDYXJvdXNhbCBmcm9tIFwiLi9ob21lQ2Fyb3VzYWxcIjtcbmltcG9ydCBIb21lRm91bmRlciBmcm9tIFwiLi9ob21lRm91bmRlclwiO1xuXG5jb25zdCBIb21lOiBSZWFjdC5GQyA9ICgpID0+IHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImJnLXNlY29uZGFyeS1saWdodFwiPlxuICAgICAgPEhvbWVGb3VuZGVyLz4gXG4gICAgICA8SG9tZUNhcm91c2FsIC8+XG4gICAgICA8aDRcbiAgICAgICAgY2xhc3NOYW1lPVwiZm9udC1leHRyYWxpZ2h0IHRleHQtcHJpbWFyeS1kYXJrXCJcbiAgICAgICAgc3R5bGU9e3tcbiAgICAgICAgICBtYXJnaW5Ub3A6IDExOSxcbiAgICAgICAgICBtYXJnaW5MZWZ0OiAxMTYsXG4gICAgICAgICAgbWFyZ2luQm90dG9tOiAxMjAsXG4gICAgICAgICAgZm9udFNpemU6IDg1LFxuICAgICAgICAgIGxpbmVIZWlnaHQ6IFwiOTVweFwiLFxuICAgICAgICB9fVxuICAgICAgPlxuICAgICAgICB7XCIgXCJ9XG4gICAgICAgIFNjcm9sbCB0aHJvdWdoIGZvciB0aGUgbGF0ZXN0IGZyb20gPGJyIC8+IHRoZXtcIiBcIn1cbiAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1hY2NlbnRcIj5NYXRyaXggTW9tZW50cyA8L3NwYW4+IHNlcmllcyAuLi57XCIgXCJ9XG4gICAgICA8L2g0PlxuICAgICAgPEhvbWVDb250ZW50IC8+XG4gICAgPC9kaXY+XG4gICk7XG59O1xuXG5leHBvcnQgZGVmYXVsdCBIb21lO1xuIiwiaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgSW1hZ2UsIENvbnRlbnRTbGlkZXIgfSBmcm9tIFwiQGNvbXBvbmVudHNcIjtcbmltcG9ydCB7IEZvdW5kZXJEZXRhaWwgfSBmcm9tIFwiQGNvbXBvbmVudHMvZm91bmRlci9Gb3VuZGVyRGV0YWlsXCI7XG5pbXBvcnQgQ2Fyb3VzZWwgZnJvbSBcInJlYWN0LXNsaWNrXCI7XG5cbmNvbnN0IGRhdGEgPSBbXG4gIHtcbiAgICBpbWFnZV91cmw6IFwiL2ljb25zL2NvbnRlbnQxLnN2Z1wiLFxuICAgIHRpdGxlOiBcIkZyb20gYm90aCBzaWRlcyBvZiB0aGUgdGFibGUgOiBLdW5hbCBCYWhsIHVucGx1Z2dlZFwiLFxuICAgIGF1dGhvcjogXCJUQVJVTiBEQVZEQVwiLFxuICAgIGNvbnRlbnRfaWQ6IFwiYWJjZGVmXCIsXG4gICAgY29udGVudF90eXBlOiBcImJsb2dcIixcbiAgICByZWFkX2R1cmF0aW9uOiBcIjQgTUlOXCIsXG4gIH0sXG4gIHtcbiAgICBpbWFnZV91cmw6IFwiL2ljb25zL2NvbnRlbnQxLnN2Z1wiLFxuICAgIHRpdGxlOiBcIkZyb20gYm90aCBzaWRlcyBvZiB0aGUgdGFibGUgOiBLdW5hbCBCYWhsIHVucGx1Z2dlZFwiLFxuICAgIGF1dGhvcjogXCJUQVJVTiBEQVZEQVwiLFxuICAgIGNvbnRlbnRfaWQ6IFwiYWJjZGVmZ1wiLFxuICAgIGNvbnRlbnRfdHlwZTogXCJibG9nXCIsXG4gICAgcmVhZF9kdXJhdGlvbjogXCI0IE1JTlwiLFxuICB9LFxuXG5dO1xuXG5jb25zdCBoZXJvcyA9IFt7XG4gIGZpcnN0TmFtZTogJ1JPSElUJyxcbiAgbGFzdE5hbWU6ICdNLkEuJyxcbiAgZmlyc3ROYW1lMTogbnVsbCxcbiAgbGFzdE5hbWUxOiBudWxsLFxuICBjYXB0aW9uOiAnQXQgQ2xvdWRuaW5lLCB3ZSBiZWxpZXZlIHRoYXQgYSBjaGlsZCBpcyBsaWZl4oCZcyBncmVhdGVzdCBnaWZ0IGFuZCBwcmVnbmFuY3kgaXMgb25lIG9mIHRoZSBtb3N0IG1hZ2ljYWwgZXhwZXJpZW5jZXMgbmF0dXJlIGNhbiBvZmZlci4gJyxcbiAgbG9nbzogJy9pY29ucy9DbG91ZG5pbmUuc3ZnJyxcbiAgaW1hZ2U6ICcvaWNvbnMvUm9oaXRfVHJlYXRtZW50LnN2ZycsXG4gIGhlYWRpbmc6IFsnTGVhZGluZyBjaGFpbiBvZiAnLCAnbWF0ZXJuaXR5IGhvc3BpdGFscycsICcnXSxcbiAgYmc6ICcnXG59LCB7XG4gIGZpcnN0TmFtZTogJ0FOSU5EWUEnLFxuICBsYXN0TmFtZTogJ0RVVFRBJyxcbiAgZmlyc3ROYW1lMTogJ1NBTkRFRVAnLFxuICBsYXN0TmFtZTE6ICdEQUxNSUEnLFxuICBjYXB0aW9uOiAnU3RhbnphIExpdmluZyBwcm92aWRlcyBmdWxseS1tYW5hZ2VkIHNoYXJlZCBsaXZpbmcgYWNjb21tb2RhdGlvbnMgdG8gc3R1ZGVudHMgYW5kIHlvdW5nIHByb2Zlc3Npb25hbHMuJyxcbiAgbG9nbzogJy9pY29ucy9TdGFuemEuc3ZnJyxcbiAgaW1hZ2U6ICcvaWNvbnMvQW5pbmR5YS5zdmcnLFxuICBoZWFkaW5nOiBbJ1RlY2gtZW5hYmxlZCAnLCAnc3R1ZGVudCBob3VzaW5nJywgJ3BsYXRmb3JtJ10sXG4gIGJnOiAnJ1xufSwge1xuICBmaXJzdE5hbWU6ICdBc2lzaCcsXG4gIGxhc3ROYW1lOiAnTU9IQVBBVFJBJyxcbiAgZmlyc3ROYW1lMTogbnVsbCxcbiAgbGFzdE5hbWUxOiBudWxsLFxuICBjYXB0aW9uOiAnT0ZCIFRlY2ggKE9mQnVzaW5lc3MpIGlzIGEgdGVjaC1lbmFibGVkIHBsYXRmb3JtIHRoYXQgZmFjaWxpdGF0ZXMgcmF3IG1hdGVyaWFsIHByb2N1cmVtZW50IGFuZCBjcmVkaXQgZm9yIFNNRXMsJyxcbiAgbG9nbzogJy9pY29ucy9PZkJ1c2luZXNzLnN2ZycsXG4gIGltYWdlOiAnL2ljb25zL0FzaXNoLnN2ZycsXG4gIGhlYWRpbmc6IFsnU01FJywgJ2xlbmRpbmcnLCAnJ11cbn0sIHtcbiAgZmlyc3ROYW1lOiAnTXIuJyxcbiAgbGFzdE5hbWU6ICdMQUtTSElQQVRIWScsXG4gIGZpcnN0TmFtZTE6IG51bGwsXG4gIGxhc3ROYW1lMTogbnVsbCxcbiAgY2FwdGlvbjogJ0Egc3BlY2lhbGl6ZWQgZmluYW5jaWFsIHNlcnZpY2VzIGNvbXBhbnkgZnVuZGluZyB0aGUgcGVvcGxlIHdobyB3ZXJlIHBlcmNlaXZlZCB0byBiZSB1bmZ1bmRhYmxlJyxcbiAgbG9nbzogJy9pY29ucy9teC5zdmcnLFxuICBpbWFnZTogJy9pY29ucy9MYXhtaXBhdGh5LnN2ZycsXG4gIGhlYWRpbmc6IFsnQ3JlZGl0IGxlZCcsICdCMkIgbWFya2V0cGxhY2UnLCAnJ11cbn0sIHtcbiAgZmlyc3ROYW1lOiAnQ0hBS1JBREhBUicsXG4gIGxhc3ROYW1lOiAnR0FERScsXG4gIGZpcnN0TmFtZTE6ICdOSVRJTicsXG4gIGxhc3ROYW1lMTogJ0tBVVNIQUwnLFxuICBjYXB0aW9uOiAnQ291bnRyeSBEZWxpZ2h0IGFpbXMgdG8gYnJpbmcgYmFjayB0aGUgYmFzaWNzIG9mIE1pbGsuIEl0IHByb21pc2VzIG5hdHVyYWwsIGZyZXNoIGFuZCB1bmFkdWx0ZXJhdGVkIG1pbGsgZGlyZWN0bHkgdG8gdGhlIGRvb3JzdGVwIG9mIHRoZSBjb25zdW1lci4nLFxuICBsb2dvOiAnL2ljb25zL0NvdW50cnkuc3ZnJyxcbiAgaGVhZGluZzogWydEMkMnLCAnZGFpcnkgJiBmcmVzaCBmb29kcycsICdicmFuZCddLFxuICBpbWFnZTogJy9pY29ucy9DaGFrcmFkaGFyLnN2Zydcbn0sIHtcbiAgZmlyc3ROYW1lOiAnQmhhdmlzaCcsXG4gIGxhc3ROYW1lOiAnQUdHQVJXQUwnLFxuICBmaXJzdE5hbWUxOiBudWxsLFxuICBsYXN0TmFtZTE6IG51bGwsXG4gIGNhcHRpb246ICdPbGEgaXMgSW5kaWHigJlzIGxhcmdlc3QgbW9iaWxpdHkgcGxhdGZvcm0gYW5kIG9uZSBvZiB0aGUgd29ybGTigJlzIGxhcmdlc3QgcmlkZS1oYWlsaW5nIGNvbXBhbmllcywgc2VydmluZyAyNTArIGNpdGllcyBhY3Jvc3MgSW5kaWEsIEF1c3RyYWxpYSwgTmV3IFplYWxhbmQsIGFuZCB0aGUgVUsuJyxcbiAgbG9nbzogJy9pY29ucy9vbGEuc3ZnJyxcbiAgaW1hZ2U6ICcvaWNvbnMvQmhhdmlzaF9pbWFnZS5zdmcnLFxuICBoZWFkaW5nOiBbJ0luZGlh4oCZcyBsZWFkaW5nJywgJ21vYmlsaXR5JywgJ3BsYXllciddXG59LF1cblxuY29uc3QgSG9tZUNhcm91c2FsID0gKCkgPT4ge1xuICBjb25zdCBbYmFja2dyb3VuZFVybCwgc2V0QmFja2dyb3VuZFVybF0gPSBSZWFjdC51c2VTdGF0ZShcbiAgICBcIi9pY29ucy9iYWNrZ3JvdW5kQ2Fyb3VzYWxJbWFnZS5wbmdcIlxuICApO1xuICByZXR1cm4gKFxuICAgIC8vIDxDYXJvdXNlbD5cbiAgICA8ZGl2IGNsYXNzTmFtZT1cInJlbGF0aXZlXCIgc3R5bGU9e3sgaGVpZ2h0OiAxMDgwIH19PlxuICAgICAgPGRpdlxuICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSBoLWZ1bGwgdy1mdWxsIGZsZXggZmxleC1jb2xcIlxuICAgICAgICBzdHlsZT17e1xuICAgICAgICAgIGJhY2tncm91bmRJbWFnZTogYHVybCgke2JhY2tncm91bmRVcmx9KWAsXG4gICAgICAgICAgYmFja2dyb3VuZFNpemU6IFwiY292ZXJcIixcbiAgICAgICAgfX1cbiAgICAgID5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4XCI+XG4gICAgICAgICAgPEltYWdlXG4gICAgICAgICAgICBzcmM9XCIvaWNvbnMvbGVmdEFycm93LnN2Z1wiXG4gICAgICAgICAgICBhbHQ9e1wicmlnaHQgSWNvblwifVxuICAgICAgICAgICAgaGVpZ2h0PXs3M31cbiAgICAgICAgICAgIHdpZHRoPXszN31cbiAgICAgICAgICAgIHN0eWxlPXt7IG1hcmdpbkxlZnQ6IDE3OSB9fVxuICAgICAgICAgIC8+XG4gICAgICAgICAgPGRpdiBzdHlsZT17eyB3aWR0aDogNTMzLCBtYXJnaW5MZWZ0OiAxMDAgfX0+XG4gICAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICAgICAgZm9udFdlaWdodDogMzAwLFxuICAgICAgICAgICAgICAgIGZvbnRTaXplOiBcIjEwMHB4XCIsXG4gICAgICAgICAgICAgICAgbGluZUhlaWdodDogXCIxMjBweFwiLFxuICAgICAgICAgICAgICAgIGxldHRlclNwYWNpbmc6IFwiLTAuMDFlbVwiLFxuICAgICAgICAgICAgICAgIG9wYWNpdHk6IDAuMzUsXG4gICAgICAgICAgICAgICAgbWFyZ2luVG9wOiAxMTcsXG4gICAgICAgICAgICAgIH19XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIHtcIiBcIn1cbiAgICAgICAgICAgICAgMDEvMDVcbiAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICBjbGFzc05hbWU9XCJ0ZXh0LXNlY29uZGFyeS1saWdodFwiXG4gICAgICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICAgICAgZm9udFdlaWdodDogMjAwLFxuICAgICAgICAgICAgICAgIGZvbnRTaXplOiBcIjg1cHhcIixcbiAgICAgICAgICAgICAgICBsaW5lSGVpZ2h0OiBcIjk1cHhcIixcbiAgICAgICAgICAgICAgICBvcGFjaXR5OiAxLFxuICAgICAgICAgICAgICAgIG1hcmdpblRvcDogMTUxLFxuICAgICAgICAgICAgICAgIG1pbldpZHRoOiA1NDUsXG4gICAgICAgICAgICAgIH19XG4gICAgICAgICAgICA+XG4gICAgICAgICAgICAgIFRlY2gtZW5hYmxlZFxuICAgICAgICAgICAgICA8YnIgLz5cbiAgICAgICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiZm9udC1ib2xkXCI+IFN0dWRlbnQgaG91c2luZzwvc3Bhbj4gPGJyIC8+XG4gICAgICAgICAgICAgIFBsYXRmb3JtXG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICA8Rm91bmRlckRldGFpbCBzdHlsZT17eyBtYXJnaW5Ub3A6IDM2LCBtYXJnaW5MZWZ0OiAxMDMgfX0gLz5cbiAgICAgICAgICA8SW1hZ2VcbiAgICAgICAgICAgIHNyYz1cIi9pY29ucy9yaWdodEFycm93LmxhcmdlLnN2Z1wiXG4gICAgICAgICAgICBhbHQ9e1wicmlnaHQgSWNvblwifVxuICAgICAgICAgICAgaGVpZ2h0PXs3M31cbiAgICAgICAgICAgIHdpZHRoPXszN31cbiAgICAgICAgICAgIHN0eWxlPXt7IG1hcmdpbkxlZnQ6IDEwMyB9fVxuICAgICAgICAgIC8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8ZGl2XG4gICAgICAgICAgY2xhc3NOYW1lPVwiYWJzb2x1dGUgYmctYWNjZW50XCJcbiAgICAgICAgICBzdHlsZT17eyBib3R0b206IDMzLCBsZWZ0OiAyNjksIGhlaWdodDogMjQ2LCB3aWR0aDogNTY0IH19XG4gICAgICAgID5cbiAgICAgICAgICA8c3BhblxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1zZWNvbmRhcnkgZm9udC1tZWRpdW0gdGV4dC1sZyBsZWFkaW5nLTYgdGV4dC1jZW50ZXIgaC1mdWxsIGZsZXgganVzdGlmeS1jZW50ZXIgaXRlbXMtY2VudGVyXCJcbiAgICAgICAgICAgIHN0eWxlPXt7IHdyaXRpbmdNb2RlOiBcInZlcnRpY2FsLWxyXCIsIHdpZHRoOiA1NiB9fVxuICAgICAgICAgID5cbiAgICAgICAgICAgIHtcIiBcIn1cbiAgICAgICAgICAgIEhvc3BpdGFsaXR5IFNlY3RvcntcIiBcIn1cbiAgICAgICAgICA8L3NwYW4+XG4gICAgICAgIDwvZGl2PlxuICAgICAgICA8Q29udGVudFNsaWRlclxuICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICBsZWZ0OiAzMjUsXG4gICAgICAgICAgICBiYWNrZ3JvdW5kOiBcIiNFQkVCRTlcIixcbiAgICAgICAgICAgIGJvcmRlcjogXCIxcHggc29saWQgI0VCRUJFOVwiLFxuICAgICAgICAgICAgYm94U2l6aW5nOiBcImJvcmRlci1ib3hcIixcbiAgICAgICAgICAgIGZvbnRTaXplOiAyOCxcbiAgICAgICAgICAgIGxpbmVIZWlnaHQ6IFwiMzRweFwiLFxuICAgICAgICAgICAgcGFkZGluZ1RvcDogMjQsXG4gICAgICAgICAgICBwYWRkaW5nTGVmdDogMzQsXG4gICAgICAgICAgfX1cbiAgICAgICAgICBjb250ZW50TGlzdD17ZGF0YX1cbiAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSBib3R0b20tMCByaWdodC0wIHRleHQtcHJpbWFyeS1kYXJrXCJcbiAgICAgICAgICBoZWFkZXI9ezxzcGFuPkRpdmUgaW50byB0aGUgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1hY2NlbnRcIj5NYXRyaXggTW9tZW50czwvc3Bhbj4gc2VyaWVzPC9zcGFuPn1cbiAgICAgICAgLz5cbiAgICAgIDwvZGl2PlxuXG4gICAgPC9kaXY+XG4gICAgLy8gPC9DYXJvdXNlbD5cbiAgKTtcbn07XG5cbmV4cG9ydCBkZWZhdWx0IEhvbWVDYXJvdXNhbDtcbiIsImltcG9ydCBIb21lQ29udGVudCBmcm9tIFwiLi4vaG9tZUNvbnRlbnRcIjtcbmltcG9ydCBIb21lQ2Fyb3VzYWwgZnJvbSBcIi4vSG9tZUNhcm91c2FsXCI7XG5cbmV4cG9ydCBkZWZhdWx0IEhvbWVDYXJvdXNhbDtcbiIsImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IE5hdkl0ZW0gfSBmcm9tIFwiQGNvbXBvbmVudHNcIjtcblxuZXhwb3J0IHR5cGUgUHJvcHMgPSB7XG4gIHNlbGVjdGVkVGFiOiBzdHJpbmc7XG4gIG9uVGFiU2VsZWN0ZWQ/OiAoaWQ6IHN0cmluZykgPT4gdm9pZDtcbiAgdGFiTGlzdDogQXJyYXk8YW55Pjtcbn07XG5cbmNvbnN0IENvbnRlbnRUYWJzOiBSZWFjdC5GQzxQcm9wcz4gPSAoe1xuICBzZWxlY3RlZFRhYixcbiAgb25UYWJTZWxlY3RlZCxcbiAgdGFiTGlzdCxcbn0pID0+IHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImhvbWUtY29udGVudC1zaWRlLW5hdi1jb250YWluZXIgYmctc2Vjb25kYXJ5IGl0ZW1zLWNlbnRlciBmbGV4IGZsZXgtY29sIGp1c3RpZnktY2VudGVyXCI+XG4gICAgICB7dGFiTGlzdC5tYXAoKHsgbmFtZSwgaWQsIGxpbmsgfSkgPT4ge1xuICAgICAgICBjb25zdCB0YWJTdHlsZSA9XG4gICAgICAgICAgaWQgPT09IHNlbGVjdGVkVGFiXG4gICAgICAgICAgICA/IFwib3BhY2l0eS0xMDAgIHRleHQtYWNjZW50XCJcbiAgICAgICAgICAgIDogXCJvcGFjaXR5LTQwIHRleHQtcHJpbWFyeS1kYXJrXCI7XG4gICAgICAgIHJldHVybiAoXG4gICAgICAgICAgPE5hdkl0ZW1cbiAgICAgICAgICAgIGtleT17aWR9XG4gICAgICAgICAgICB0aXRsZT17bmFtZX1cbiAgICAgICAgICAgIGlkPXtpZH1cbiAgICAgICAgICAgIGFycm93PXtmYWxzZX1cbiAgICAgICAgICAgIG9uQ2xpY2s9e29uVGFiU2VsZWN0ZWR9XG4gICAgICAgICAgICBzZWxlY3RlZD17aWQgPT09IHNlbGVjdGVkVGFifVxuICAgICAgICAgICAgY2xhc3NOYW1lPXtgdy1mdWxsIGZvbnQtZXh0cmFsaWdodCBob21lLWNvbnRlbnQtdGFiICR7dGFiU3R5bGV9YH1cbiAgICAgICAgICAvPlxuICAgICAgICApO1xuICAgICAgfSl9XG4gICAgPC9kaXY+XG4gICk7XG59O1xuXG5leHBvcnQgZGVmYXVsdCBDb250ZW50VGFicztcbiIsImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCBDb250ZW50SXRlbSBmcm9tIFwiQGNvbXBvbmVudHMvY29udGVudEl0ZW0vY29udGVudEl0ZW1XaXRoVGFnc1wiO1xuXG5leHBvcnQgdHlwZSBQcm9wcyA9IHtcbiAgY29udGVudExpc3Q6IEFycmF5PGFueT47XG59O1xuXG5jb25zdCBkYXRhID0ge1xuICBpbWFnZV91cmw6IFwiL2ljb25zL2hvbWVDb250ZW50SW1hZ2Uuc3ZnXCIsXG4gIGltYWdlX2NhcHRpb246IFwiTU9TVCBTRUFSQ0hFRFwiLFxuICB0aXRsZTogXCJSZWRlZmluaW5nIHdlbGxuZXNzICwgb25lIG1vc2FpYyBhdCBhIHRpbWVcIixcbiAgYXV0aG9yOiBcIlNhbmpvdCBNYWxoaVwiLFxuICBkZXNpZ25hdGlvbjogXCJEaXJlY3RvclwiLFxuICBhdXRob3JfaW1hZ2VfdXJsOiBcIi9pY29ucy9wcm9maWxlSW1hZ2Uuc3ZnXCIsXG4gIGNvbnRlbnRfaWQ6IFwiYWJjZGVmXCIsXG4gIGNvbnRlbnRfdHlwZTogXCJibG9nXCIsXG4gIHJlYWRfZHVyYXRpb246XCI0IE1JTlwiLFxuICB0YWdzOiBbXG4gICAge1xuICAgICAgdGl0bGU6IFwiTEVBREVSU0hJUFwiLFxuICAgICAgaWQ6IFwibGVhZGVyc2hpcFwiLFxuICAgIH0sXG4gIF0sXG59O1xuXG5jb25zdCBIb21lQ29udGVudExpc3Q6IFJlYWN0LkZDPFByb3BzPiA9ICh7IGNvbnRlbnRMaXN0IH0pID0+IHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cIm92ZXJmbG93LWF1dG8gaG9tZS1jb250ZW50LWNvbnRhaW5lclwiPlxuICAgICAge2NvbnRlbnRMaXN0Lm1hcCgoKSA9PiB7XG4gICAgICAgIHJldHVybiA8Q29udGVudEl0ZW0gey4uLmRhdGF9IC8+O1xuICAgICAgfSl9XG4gICAgPC9kaXY+XG4gICk7XG59O1xuXG5leHBvcnQgZGVmYXVsdCBIb21lQ29udGVudExpc3Q7XG4iLCJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgQ29udGVudFRhYnMgZnJvbSBcIi4vQ29udGVudFRhYnNcIjtcbmltcG9ydCBDb250ZW50TGlzdCBmcm9tIFwiLi9Ib21lQ29udGVudExpc3RcIjtcblxuY29uc3QgaG9tZUNvbnRlbnRUYWJzID0gW1xuICB7XG4gICAgbmFtZTogXCJCbG9nc1wiLFxuICAgIGlkOiBcImJsb2dzXCIsXG4gICAgbGluazogXCJcIixcbiAgfSxcbiAge1xuICAgIG5hbWU6IFwiUG9kY2FzdFwiLFxuICAgIGlkOiBcInBvZGNhc3RcIixcbiAgICBsaW5rOiBcIlwiLFxuICB9LFxuICB7XG4gICAgbmFtZTogXCJWaWRlb0Nhc3RzXCIsXG4gICAgaWQ6IFwidmlkZW9jYXN0c1wiLFxuICAgIGxpbms6IFwiXCIsXG4gIH0sXG5dO1xuXG5jb25zdCBjb250ZW50TGlzdCA9IFt7fSwge30sIHt9LCB7fSwge31dO1xuXG5jb25zdCBIb21lQ29udGVudDogUmVhY3QuRkMgPSAoKSA9PiB7XG4gIGNvbnN0IFtzZWxlY3RlZFRhYiwgc2V0U2VsZWN0ZWRUYWJdID0gUmVhY3QudXNlU3RhdGU8c3RyaW5nIHwgbnVsbD4oXG4gICAgaG9tZUNvbnRlbnRUYWJzWzBdLmlkXG4gICk7XG5cbiAgY29uc3Qgb25UYWJTZWxlY3RlZCA9IChpZDogc3RyaW5nKSA9PiB7XG4gICAgc2V0U2VsZWN0ZWRUYWIoaWQpO1xuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdlxuICAgICAgY2xhc3NOYW1lPVwiZmxleFwiXG4gICAgICBzdHlsZT17eyBtYXJnaW5MZWZ0OiA4MCwgaGVpZ2h0OiAxNDAwLCBtYXJnaW5Cb3R0b206IDEwNyB9fVxuICAgID5cbiAgICAgIDxDb250ZW50VGFic1xuICAgICAgICB0YWJMaXN0PXtob21lQ29udGVudFRhYnN9XG4gICAgICAgIHNlbGVjdGVkVGFiPXtzZWxlY3RlZFRhYn1cbiAgICAgICAgb25UYWJTZWxlY3RlZD17b25UYWJTZWxlY3RlZH1cbiAgICAgIC8+XG4gICAgICA8Q29udGVudExpc3QgY29udGVudExpc3Q9e2NvbnRlbnRMaXN0fSAvPlxuICAgIDwvZGl2PlxuICApO1xufTtcblxuZXhwb3J0IGRlZmF1bHQgSG9tZUNvbnRlbnQ7XG4iLCJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBGb3VuZGVyIH0gZnJvbSBcIkBjb21wb25lbnRzXCI7XG5cbmNvbnN0IEhvbWVGb3VuZGVyID0gKCkgPT4ge1xuICByZXR1cm4gKFxuICAgIDxkaXYgc3R5bGU9e3sgbWFyZ2luVG9wOiA2NC41NiwgbWFyZ2luTGVmdDogODIgfX0+XG4gICAgICA8Rm91bmRlciAvPlxuICAgIDwvZGl2PlxuICApO1xufTtcblxuZXhwb3J0IGRlZmF1bHQgSG9tZUZvdW5kZXI7XG4iLCJpbXBvcnQgSG9tZUZvdW5kZXIgZnJvbSBcIi4vSG9tZUZvdW5kZXJcIjtcblxuZXhwb3J0IGRlZmF1bHQgSG9tZUZvdW5kZXI7XG4iLCJpbXBvcnQgSG9tZSBmcm9tIFwiLi9ob21lXCI7XG5cbmV4cG9ydCBkZWZhdWx0IEhvbWU7XG4iLCJcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gKHR5cGUpe1xuICAgIHN3aXRjaCAodHlwZSl7XG5cbiAgICB9XG4gICAgcmV0dXJuIFwiL2ljb25zL3ZpZGVvLnN2Z1wiXG59IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwicmVhY3RcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwicmVhY3Qtc2xpY2tcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwicmVhY3QvanN4LWRldi1ydW50aW1lXCIpOyJdLCJzb3VyY2VSb290IjoiIn0=