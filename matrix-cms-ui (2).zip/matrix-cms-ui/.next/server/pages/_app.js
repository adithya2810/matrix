module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = require('../ssr-module-cache.js');
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		var threw = true;
/******/ 		try {
/******/ 			modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 			threw = false;
/******/ 		} finally {
/******/ 			if(threw) delete installedModules[moduleId];
/******/ 		}
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 0);
/******/ })
/************************************************************************/
/******/ ({

/***/ "../next-server/lib/head":
/*!****************************************************!*\
  !*** external "next/dist/next-server/lib/head.js" ***!
  \****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("next/dist/next-server/lib/head.js");

/***/ }),

/***/ "../next-server/lib/to-base-64":
/*!**********************************************************!*\
  !*** external "next/dist/next-server/lib/to-base-64.js" ***!
  \**********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("next/dist/next-server/lib/to-base-64.js");

/***/ }),

/***/ "../next-server/lib/utils":
/*!*****************************************************!*\
  !*** external "next/dist/next-server/lib/utils.js" ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("next/dist/next-server/lib/utils.js");

/***/ }),

/***/ "../next-server/server/image-config":
/*!***************************************************************!*\
  !*** external "next/dist/next-server/server/image-config.js" ***!
  \***************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("next/dist/next-server/server/image-config.js");

/***/ }),

/***/ "./constants/footerMenu.ts":
/*!*********************************!*\
  !*** ./constants/footerMenu.ts ***!
  \*********************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
const footermenu = [{
  key: "footer_about",
  name: "About",
  link: ""
}, {
  key: "footer_portfolio",
  name: "Portfolio",
  link: "/portfolio"
}, {
  key: "footer_blog",
  name: "Blog",
  link: ""
}, {
  key: "footer_advisory_team",
  name: "Advisory Team",
  link: "/advisoryTeam"
}, {
  key: "footer_contact",
  name: "Contact",
  link: ""
}, {
  key: "footer_careers",
  name: "Careers",
  link: ""
}];
/* harmony default export */ __webpack_exports__["default"] = (footermenu);

/***/ }),

/***/ "./constants/index.ts":
/*!****************************!*\
  !*** ./constants/index.ts ***!
  \****************************/
/*! exports provided: navMenu, PRIVACY_POLICY */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "PRIVACY_POLICY", function() { return PRIVACY_POLICY; });
/* harmony import */ var _footerMenu__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./footerMenu */ "./constants/footerMenu.ts");
/* empty/unused harmony star reexport *//* harmony import */ var _navMenu__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./navMenu */ "./constants/navMenu.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "navMenu", function() { return _navMenu__WEBPACK_IMPORTED_MODULE_1__["navMenu"]; });



const PRIVACY_POLICY = "MADE WITH LOVE BY PLEASE SEE ";

/***/ }),

/***/ "./constants/navMenu.ts":
/*!******************************!*\
  !*** ./constants/navMenu.ts ***!
  \******************************/
/*! exports provided: navMenu, default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "navMenu", function() { return navMenu; });
const navMenu = {
  primary: [{
    key: "footer_about",
    name: "About",
    link: ""
  }, {
    key: "footer_portfolio",
    name: "Portfolio",
    link: ""
  }, {
    key: "footer_blog",
    name: "Blog",
    link: ""
  }],
  secondary: [{
    key: "footer_advisory_team",
    name: "Advisory Team",
    link: ""
  }, {
    key: "footer_contact",
    name: "Contact",
    link: ""
  }, {
    key: "footer_careers",
    name: "Careers",
    link: ""
  }]
};
/* harmony default export */ __webpack_exports__["default"] = (navMenu);

/***/ }),

/***/ "./constants/socialMedia.ts":
/*!**********************************!*\
  !*** ./constants/socialMedia.ts ***!
  \**********************************/
/*! exports provided: socialMedia */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "socialMedia", function() { return socialMedia; });
const socialMedia = [{
  name: "LinkedIn",
  link: "",
  key: "linkedin",
  imageUrl: "/icons/linkedin.svg"
}, {
  name: "Twitter",
  link: "",
  key: "twitter",
  imageUrl: "/icons/twitter.svg"
}];

/***/ }),

/***/ "./helper/apollo.tsx":
/*!***************************!*\
  !*** ./helper/apollo.tsx ***!
  \***************************/
/*! exports provided: APOLLO_STATE_PROPERTY_NAME, COOKIES_TOKEN_NAME, initializeApollo, addApolloState, useApollo */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "APOLLO_STATE_PROPERTY_NAME", function() { return APOLLO_STATE_PROPERTY_NAME; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "COOKIES_TOKEN_NAME", function() { return COOKIES_TOKEN_NAME; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "initializeApollo", function() { return initializeApollo; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "addApolloState", function() { return addApolloState; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "useApollo", function() { return useApollo; });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var deepmerge__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! deepmerge */ "deepmerge");
/* harmony import */ var deepmerge__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(deepmerge__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @apollo/client */ "@apollo/client");
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _apollo_client_link_context__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @apollo/client/link/context */ "@apollo/client/link/context");
/* harmony import */ var _apollo_client_link_context__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_apollo_client_link_context__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _models_AppConfig__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../models/AppConfig */ "./models/AppConfig.ts");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }






const APOLLO_STATE_PROPERTY_NAME = '__APOLLO_STATE__';
const COOKIES_TOKEN_NAME = 'jwt';

const getToken = req => {
  return ''; // todo: implement the logic if required
};

let apolloClient = null;

const createApolloClient = ctx => {
  const httpLink = new _apollo_client__WEBPACK_IMPORTED_MODULE_2__["HttpLink"]({
    uri: process.env.NEXT_PUBLIC_GRAPHQL_URI,
    credentials: 'same-origin'
  });
  const authLink = Object(_apollo_client_link_context__WEBPACK_IMPORTED_MODULE_3__["setContext"])((_, {
    headers
  }) => {
    // Get the authentication token from cookies
    const token = getToken(ctx === null || ctx === void 0 ? void 0 : ctx.req);
    return {
      headers: _objectSpread(_objectSpread({}, headers), {}, {
        authorization: token ? `Bearer ${token}` : ''
      })
    };
  });
  return new _apollo_client__WEBPACK_IMPORTED_MODULE_2__["ApolloClient"]({
    ssrMode: true,
    link: authLink.concat(httpLink),
    cache: new _apollo_client__WEBPACK_IMPORTED_MODULE_2__["InMemoryCache"]({
      typePolicies: {
        Query: {
          fields: {
            appConfig: {
              read() {
                return Object(_models_AppConfig__WEBPACK_IMPORTED_MODULE_4__["appConfigVar"])();
              }

            }
          }
        }
      }
    })
  });
};

function initializeApollo(initialState = null, ctx = null) {
  var _apolloClient;

  const client = (_apolloClient = apolloClient) !== null && _apolloClient !== void 0 ? _apolloClient : createApolloClient(ctx); // If your page has Next.js data fetching methods that use Apollo Client,
  // the initial state gets hydrated here

  if (initialState) {
    // Get existing cache, loaded during client side data fetching
    const existingCache = client.extract(); // Merge the existing cache into data passed from
    // getStaticProps/getServerSideProps

    const data = deepmerge__WEBPACK_IMPORTED_MODULE_1___default()(initialState, existingCache); // Restore the cache with the merged data

    client.cache.restore(data);
  } // For SSG and SSR always create a new Apollo Client


  if (true) {
    return client;
  } // Create the Apollo Client once in the client


  if (!apolloClient) {
    apolloClient = client;
  }

  return client;
}
function addApolloState(client, pageProps) {
  if (pageProps !== null && pageProps !== void 0 && pageProps.props) {
    pageProps.props[APOLLO_STATE_PROPERTY_NAME] = client.cache.extract();
  }

  return pageProps;
}
function useApollo(pageProps) {
  const state = pageProps[APOLLO_STATE_PROPERTY_NAME];
  const store = Object(react__WEBPACK_IMPORTED_MODULE_0__["useMemo"])(() => initializeApollo(state), [state]);
  return store;
}

/***/ }),

/***/ "./helper/useDeviceType.ts":
/*!*********************************!*\
  !*** ./helper/useDeviceType.ts ***!
  \*********************************/
/*! exports provided: useDeviceType */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "useDeviceType", function() { return useDeviceType; });
/* harmony import */ var mobile_detect__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! mobile-detect */ "mobile-detect");
/* harmony import */ var mobile_detect__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mobile_detect__WEBPACK_IMPORTED_MODULE_0__);

function useDeviceType(userAgent) {
  const md = new mobile_detect__WEBPACK_IMPORTED_MODULE_0___default.a(userAgent);
  let mobile = false,
      tablet = false,
      desktop = false;

  if (md.tablet()) {
    tablet = true;
  } else if (md.mobile()) {
    mobile = true;
  } else {
    desktop = true;
  }

  return {
    mobile,
    tablet,
    desktop
  };
}

/***/ }),

/***/ "./models/AppConfig.ts":
/*!*****************************!*\
  !*** ./models/AppConfig.ts ***!
  \*****************************/
/*! exports provided: appConfigVar */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "appConfigVar", function() { return appConfigVar; });
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @apollo/client */ "@apollo/client");
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_0__);

const intialAppconfig = {
  menu: false,
  navMenuSelected: null
};
const appConfigVar = Object(_apollo_client__WEBPACK_IMPORTED_MODULE_0__["makeVar"])(intialAppconfig);

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/extends.js":
/*!********************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/extends.js ***!
  \********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _extends() {
  module.exports = _extends = Object.assign || function (target) {
    for (var i = 1; i < arguments.length; i++) {
      var source = arguments[i];

      for (var key in source) {
        if (Object.prototype.hasOwnProperty.call(source, key)) {
          target[key] = source[key];
        }
      }
    }

    return target;
  };

  return _extends.apply(this, arguments);
}

module.exports = _extends;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js":
/*!**********************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/interopRequireDefault.js ***!
  \**********************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _interopRequireDefault(obj) {
  return obj && obj.__esModule ? obj : {
    "default": obj
  };
}

module.exports = _interopRequireDefault;

/***/ }),

/***/ "./node_modules/@babel/runtime/helpers/objectWithoutPropertiesLoose.js":
/*!*****************************************************************************!*\
  !*** ./node_modules/@babel/runtime/helpers/objectWithoutPropertiesLoose.js ***!
  \*****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

function _objectWithoutPropertiesLoose(source, excluded) {
  if (source == null) return {};
  var target = {};
  var sourceKeys = Object.keys(source);
  var key, i;

  for (i = 0; i < sourceKeys.length; i++) {
    key = sourceKeys[i];
    if (excluded.indexOf(key) >= 0) continue;
    target[key] = source[key];
  }

  return target;
}

module.exports = _objectWithoutPropertiesLoose;

/***/ }),

/***/ "./node_modules/next/app.js":
/*!**********************************!*\
  !*** ./node_modules/next/app.js ***!
  \**********************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! ./dist/pages/_app */ "./node_modules/next/dist/pages/_app.js")


/***/ }),

/***/ "./node_modules/next/dist/client/image.js":
/*!************************************************!*\
  !*** ./node_modules/next/dist/client/image.js ***!
  \************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js");

exports.__esModule = true;
exports.default = Image;

var _objectWithoutPropertiesLoose2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/objectWithoutPropertiesLoose */ "./node_modules/@babel/runtime/helpers/objectWithoutPropertiesLoose.js"));

var _extends2 = _interopRequireDefault(__webpack_require__(/*! @babel/runtime/helpers/extends */ "./node_modules/@babel/runtime/helpers/extends.js"));

var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));

var _head = _interopRequireDefault(__webpack_require__(/*! ../next-server/lib/head */ "../next-server/lib/head"));

var _toBase = __webpack_require__(/*! ../next-server/lib/to-base-64 */ "../next-server/lib/to-base-64");

var _imageConfig = __webpack_require__(/*! ../next-server/server/image-config */ "../next-server/server/image-config");

var _useIntersection = __webpack_require__(/*! ./use-intersection */ "./node_modules/next/dist/client/use-intersection.js");

if (true) {
  ;
  global.__NEXT_IMAGE_IMPORTED = true;
}

const VALID_LOADING_VALUES = ['lazy', 'eager', undefined];
const loaders = new Map([['imgix', imgixLoader], ['cloudinary', cloudinaryLoader], ['akamai', akamaiLoader], ['default', defaultLoader]]);
const VALID_LAYOUT_VALUES = ['fill', 'fixed', 'intrinsic', 'responsive', undefined];
const {
  deviceSizes: configDeviceSizes,
  imageSizes: configImageSizes,
  loader: configLoader,
  path: configPath,
  domains: configDomains
} = {"deviceSizes":[640,750,828,1080,1200,1920,2048,3840],"imageSizes":[16,32,48,64,96,128,256,384],"path":"/_next/image","loader":"default","domains":[]} || _imageConfig.imageConfigDefault; // sort smallest to largest

const allSizes = [...configDeviceSizes, ...configImageSizes];
configDeviceSizes.sort((a, b) => a - b);
allSizes.sort((a, b) => a - b);

function getWidths(width, layout, sizes) {
  if (sizes && (layout === 'fill' || layout === 'responsive')) {
    // Find all the "vw" percent sizes used in the sizes prop
    const percentSizes = [...sizes.matchAll(/(^|\s)(1?\d?\d)vw/g)].map(m => parseInt(m[2]));

    if (percentSizes.length) {
      const smallestRatio = Math.min(...percentSizes) * 0.01;
      return {
        widths: allSizes.filter(s => s >= configDeviceSizes[0] * smallestRatio),
        kind: 'w'
      };
    }

    return {
      widths: allSizes,
      kind: 'w'
    };
  }

  if (typeof width !== 'number' || layout === 'fill' || layout === 'responsive') {
    return {
      widths: configDeviceSizes,
      kind: 'w'
    };
  }

  const widths = [...new Set( // > This means that most OLED screens that say they are 3x resolution,
  // > are actually 3x in the green color, but only 1.5x in the red and
  // > blue colors. Showing a 3x resolution image in the app vs a 2x
  // > resolution image will be visually the same, though the 3x image
  // > takes significantly more data. Even true 3x resolution screens are
  // > wasteful as the human eye cannot see that level of detail without
  // > something like a magnifying glass.
  // https://blog.twitter.com/engineering/en_us/topics/infrastructure/2019/capping-image-fidelity-on-ultra-high-resolution-devices.html
  [width, width * 2
  /*, width * 3*/
  ].map(w => allSizes.find(p => p >= w) || allSizes[allSizes.length - 1]))];
  return {
    widths,
    kind: 'x'
  };
}

function generateImgAttrs({
  src,
  unoptimized,
  layout,
  width,
  quality,
  sizes,
  loader
}) {
  if (unoptimized) {
    return {
      src,
      srcSet: undefined,
      sizes: undefined
    };
  }

  const {
    widths,
    kind
  } = getWidths(width, layout, sizes);
  const last = widths.length - 1;
  return {
    sizes: !sizes && kind === 'w' ? '100vw' : sizes,
    srcSet: widths.map((w, i) => `${loader({
      src,
      quality,
      width: w
    })} ${kind === 'w' ? w : i + 1}${kind}`).join(', '),
    // It's intended to keep `src` the last attribute because React updates
    // attributes in order. If we keep `src` the first one, Safari will
    // immediately start to fetch `src`, before `sizes` and `srcSet` are even
    // updated by React. That causes multiple unnecessary requests if `srcSet`
    // and `sizes` are defined.
    // This bug cannot be reproduced in Chrome or Firefox.
    src: loader({
      src,
      quality,
      width: widths[last]
    })
  };
}

function getInt(x) {
  if (typeof x === 'number') {
    return x;
  }

  if (typeof x === 'string') {
    return parseInt(x, 10);
  }

  return undefined;
}

function defaultImageLoader(loaderProps) {
  const load = loaders.get(configLoader);

  if (load) {
    return load((0, _extends2.default)({
      root: configPath
    }, loaderProps));
  }

  throw new Error(`Unknown "loader" found in "next.config.js". Expected: ${_imageConfig.VALID_LOADERS.join(', ')}. Received: ${configLoader}`);
}

function Image(_ref) {
  let {
    src,
    sizes,
    unoptimized = false,
    priority = false,
    loading,
    className,
    quality,
    width,
    height,
    objectFit,
    objectPosition,
    loader = defaultImageLoader
  } = _ref,
      all = (0, _objectWithoutPropertiesLoose2.default)(_ref, ["src", "sizes", "unoptimized", "priority", "loading", "className", "quality", "width", "height", "objectFit", "objectPosition", "loader"]);
  let rest = all;
  let layout = sizes ? 'responsive' : 'intrinsic';
  let unsized = false;

  if ('unsized' in rest) {
    unsized = Boolean(rest.unsized); // Remove property so it's not spread into image:

    delete rest['unsized'];
  } else if ('layout' in rest) {
    // Override default layout if the user specified one:
    if (rest.layout) layout = rest.layout; // Remove property so it's not spread into image:

    delete rest['layout'];
  }

  if (true) {
    if (!src) {
      throw new Error(`Image is missing required "src" property. Make sure you pass "src" in props to the \`next/image\` component. Received: ${JSON.stringify({
        width,
        height,
        quality
      })}`);
    }

    if (!VALID_LAYOUT_VALUES.includes(layout)) {
      throw new Error(`Image with src "${src}" has invalid "layout" property. Provided "${layout}" should be one of ${VALID_LAYOUT_VALUES.map(String).join(',')}.`);
    }

    if (!VALID_LOADING_VALUES.includes(loading)) {
      throw new Error(`Image with src "${src}" has invalid "loading" property. Provided "${loading}" should be one of ${VALID_LOADING_VALUES.map(String).join(',')}.`);
    }

    if (priority && loading === 'lazy') {
      throw new Error(`Image with src "${src}" has both "priority" and "loading='lazy'" properties. Only one should be used.`);
    }

    if (unsized) {
      throw new Error(`Image with src "${src}" has deprecated "unsized" property, which was removed in favor of the "layout='fill'" property`);
    }
  }

  let isLazy = !priority && (loading === 'lazy' || typeof loading === 'undefined');

  if (src && src.startsWith('data:')) {
    // https://developer.mozilla.org/en-US/docs/Web/HTTP/Basics_of_HTTP/Data_URIs
    unoptimized = true;
    isLazy = false;
  }

  const [setRef, isIntersected] = (0, _useIntersection.useIntersection)({
    rootMargin: '200px',
    disabled: !isLazy
  });
  const isVisible = !isLazy || isIntersected;
  const widthInt = getInt(width);
  const heightInt = getInt(height);
  const qualityInt = getInt(quality);
  let wrapperStyle;
  let sizerStyle;
  let sizerSvg;
  let imgStyle = {
    position: 'absolute',
    top: 0,
    left: 0,
    bottom: 0,
    right: 0,
    boxSizing: 'border-box',
    padding: 0,
    border: 'none',
    margin: 'auto',
    display: 'block',
    width: 0,
    height: 0,
    minWidth: '100%',
    maxWidth: '100%',
    minHeight: '100%',
    maxHeight: '100%',
    objectFit,
    objectPosition
  };

  if (typeof widthInt !== 'undefined' && typeof heightInt !== 'undefined' && layout !== 'fill') {
    // <Image src="i.png" width="100" height="100" />
    const quotient = heightInt / widthInt;
    const paddingTop = isNaN(quotient) ? '100%' : `${quotient * 100}%`;

    if (layout === 'responsive') {
      // <Image src="i.png" width="100" height="100" layout="responsive" />
      wrapperStyle = {
        display: 'block',
        overflow: 'hidden',
        position: 'relative',
        boxSizing: 'border-box',
        margin: 0
      };
      sizerStyle = {
        display: 'block',
        boxSizing: 'border-box',
        paddingTop
      };
    } else if (layout === 'intrinsic') {
      // <Image src="i.png" width="100" height="100" layout="intrinsic" />
      wrapperStyle = {
        display: 'inline-block',
        maxWidth: '100%',
        overflow: 'hidden',
        position: 'relative',
        boxSizing: 'border-box',
        margin: 0
      };
      sizerStyle = {
        boxSizing: 'border-box',
        display: 'block',
        maxWidth: '100%'
      };
      sizerSvg = `<svg width="${widthInt}" height="${heightInt}" xmlns="http://www.w3.org/2000/svg" version="1.1"/>`;
    } else if (layout === 'fixed') {
      // <Image src="i.png" width="100" height="100" layout="fixed" />
      wrapperStyle = {
        overflow: 'hidden',
        boxSizing: 'border-box',
        display: 'inline-block',
        position: 'relative',
        width: widthInt,
        height: heightInt
      };
    }
  } else if (typeof widthInt === 'undefined' && typeof heightInt === 'undefined' && layout === 'fill') {
    // <Image src="i.png" layout="fill" />
    wrapperStyle = {
      display: 'block',
      overflow: 'hidden',
      position: 'absolute',
      top: 0,
      left: 0,
      bottom: 0,
      right: 0,
      boxSizing: 'border-box',
      margin: 0
    };
  } else {
    // <Image src="i.png" />
    if (true) {
      throw new Error(`Image with src "${src}" must use "width" and "height" properties or "layout='fill'" property.`);
    }
  }

  let imgAttributes = {
    src: 'data:image/gif;base64,R0lGODlhAQABAIAAAAAAAP///yH5BAEAAAAALAAAAAABAAEAAAIBRAA7',
    srcSet: undefined,
    sizes: undefined
  };

  if (isVisible) {
    imgAttributes = generateImgAttrs({
      src,
      unoptimized,
      layout,
      width: widthInt,
      quality: qualityInt,
      sizes,
      loader
    });
  }

  if (unsized) {
    wrapperStyle = undefined;
    sizerStyle = undefined;
    imgStyle = undefined;
  }

  return /*#__PURE__*/_react.default.createElement("div", {
    style: wrapperStyle
  }, sizerStyle ? /*#__PURE__*/_react.default.createElement("div", {
    style: sizerStyle
  }, sizerSvg ? /*#__PURE__*/_react.default.createElement("img", {
    style: {
      maxWidth: '100%',
      display: 'block',
      margin: 0,
      border: 'none',
      padding: 0
    },
    alt: "",
    "aria-hidden": true,
    role: "presentation",
    src: `data:image/svg+xml;base64,${(0, _toBase.toBase64)(sizerSvg)}`
  }) : null) : null, !isVisible && /*#__PURE__*/_react.default.createElement("noscript", null, /*#__PURE__*/_react.default.createElement("img", Object.assign({}, rest, generateImgAttrs({
    src,
    unoptimized,
    layout,
    width: widthInt,
    quality: qualityInt,
    sizes,
    loader
  }), {
    src: src,
    decoding: "async",
    sizes: sizes,
    style: imgStyle,
    className: className
  }))), /*#__PURE__*/_react.default.createElement("img", Object.assign({}, rest, imgAttributes, {
    decoding: "async",
    className: className,
    ref: setRef,
    style: imgStyle
  })), priority ?
  /*#__PURE__*/
  // Note how we omit the `href` attribute, as it would only be relevant
  // for browsers that do not support `imagesrcset`, and in those cases
  // it would likely cause the incorrect image to be preloaded.
  //
  // https://html.spec.whatwg.org/multipage/semantics.html#attr-link-imagesrcset
  _react.default.createElement(_head.default, null, /*#__PURE__*/_react.default.createElement("link", {
    key: '__nimg-' + imgAttributes.src + imgAttributes.srcSet + imgAttributes.sizes,
    rel: "preload",
    as: "image",
    href: imgAttributes.srcSet ? undefined : imgAttributes.src // @ts-ignore: imagesrcset is not yet in the link element type
    ,
    imagesrcset: imgAttributes.srcSet // @ts-ignore: imagesizes is not yet in the link element type
    ,
    imagesizes: imgAttributes.sizes
  })) : null);
} //BUILT IN LOADERS


function normalizeSrc(src) {
  return src[0] === '/' ? src.slice(1) : src;
}

function imgixLoader({
  root,
  src,
  width,
  quality
}) {
  // Demo: https://static.imgix.net/daisy.png?format=auto&fit=max&w=300
  const params = ['auto=format', 'fit=max', 'w=' + width];
  let paramsString = '';

  if (quality) {
    params.push('q=' + quality);
  }

  if (params.length) {
    paramsString = '?' + params.join('&');
  }

  return `${root}${normalizeSrc(src)}${paramsString}`;
}

function akamaiLoader({
  root,
  src,
  width
}) {
  return `${root}${normalizeSrc(src)}?imwidth=${width}`;
}

function cloudinaryLoader({
  root,
  src,
  width,
  quality
}) {
  // Demo: https://res.cloudinary.com/demo/image/upload/w_300,c_limit,q_auto/turtles.jpg
  const params = ['f_auto', 'c_limit', 'w_' + width, 'q_' + (quality || 'auto')];
  let paramsString = params.join(',') + '/';
  return `${root}${paramsString}${normalizeSrc(src)}`;
}

function defaultLoader({
  root,
  src,
  width,
  quality
}) {
  if (true) {
    const missingValues = []; // these should always be provided but make sure they are

    if (!src) missingValues.push('src');
    if (!width) missingValues.push('width');

    if (missingValues.length > 0) {
      throw new Error(`Next Image Optimization requires ${missingValues.join(', ')} to be provided. Make sure you pass them as props to the \`next/image\` component. Received: ${JSON.stringify({
        src,
        width,
        quality
      })}`);
    }

    if (src.startsWith('//')) {
      throw new Error(`Failed to parse src "${src}" on \`next/image\`, protocol-relative URL (//) must be changed to an absolute URL (http:// or https://)`);
    }

    if (!src.startsWith('/') && configDomains) {
      let parsedSrc;

      try {
        parsedSrc = new URL(src);
      } catch (err) {
        console.error(err);
        throw new Error(`Failed to parse src "${src}" on \`next/image\`, if using relative image it must start with a leading slash "/" or be an absolute URL (http:// or https://)`);
      }

      if (!configDomains.includes(parsedSrc.hostname)) {
        throw new Error(`Invalid src prop (${src}) on \`next/image\`, hostname "${parsedSrc.hostname}" is not configured under images in your \`next.config.js\`\n` + `See more info: https://nextjs.org/docs/messages/next-image-unconfigured-host`);
      }
    }
  }

  return `${root}?url=${encodeURIComponent(src)}&w=${width}&q=${quality || 75}`;
}

/***/ }),

/***/ "./node_modules/next/dist/client/request-idle-callback.js":
/*!****************************************************************!*\
  !*** ./node_modules/next/dist/client/request-idle-callback.js ***!
  \****************************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.cancelIdleCallback = exports.requestIdleCallback = void 0;

const requestIdleCallback = typeof self !== 'undefined' && self.requestIdleCallback || function (cb) {
  let start = Date.now();
  return setTimeout(function () {
    cb({
      didTimeout: false,
      timeRemaining: function () {
        return Math.max(0, 50 - (Date.now() - start));
      }
    });
  }, 1);
};

exports.requestIdleCallback = requestIdleCallback;

const cancelIdleCallback = typeof self !== 'undefined' && self.cancelIdleCallback || function (id) {
  return clearTimeout(id);
};

exports.cancelIdleCallback = cancelIdleCallback;

/***/ }),

/***/ "./node_modules/next/dist/client/use-intersection.js":
/*!***********************************************************!*\
  !*** ./node_modules/next/dist/client/use-intersection.js ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


exports.__esModule = true;
exports.useIntersection = useIntersection;

var _react = __webpack_require__(/*! react */ "react");

var _requestIdleCallback = __webpack_require__(/*! ./request-idle-callback */ "./node_modules/next/dist/client/request-idle-callback.js");

const hasIntersectionObserver = typeof IntersectionObserver !== 'undefined';

function useIntersection({
  rootMargin,
  disabled
}) {
  const isDisabled = disabled || !hasIntersectionObserver;
  const unobserve = (0, _react.useRef)();
  const [visible, setVisible] = (0, _react.useState)(false);
  const setRef = (0, _react.useCallback)(el => {
    if (unobserve.current) {
      unobserve.current();
      unobserve.current = undefined;
    }

    if (isDisabled || visible) return;

    if (el && el.tagName) {
      unobserve.current = observe(el, isVisible => isVisible && setVisible(isVisible), {
        rootMargin
      });
    }
  }, [isDisabled, rootMargin, visible]);
  (0, _react.useEffect)(() => {
    if (!hasIntersectionObserver) {
      if (!visible) {
        const idleCallback = (0, _requestIdleCallback.requestIdleCallback)(() => setVisible(true));
        return () => (0, _requestIdleCallback.cancelIdleCallback)(idleCallback);
      }
    }
  }, [visible]);
  return [setRef, visible];
}

function observe(element, callback, options) {
  const {
    id,
    observer,
    elements
  } = createObserver(options);
  elements.set(element, callback);
  observer.observe(element);
  return function unobserve() {
    elements.delete(element);
    observer.unobserve(element); // Destroy observer when there's nothing left to watch:

    if (elements.size === 0) {
      observer.disconnect();
      observers.delete(id);
    }
  };
}

const observers = new Map();

function createObserver(options) {
  const id = options.rootMargin || '';
  let instance = observers.get(id);

  if (instance) {
    return instance;
  }

  const elements = new Map();
  const observer = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      const callback = elements.get(entry.target);
      const isVisible = entry.isIntersecting || entry.intersectionRatio > 0;

      if (callback && isVisible) {
        callback(isVisible);
      }
    });
  }, options);
  observers.set(id, instance = {
    id,
    observer,
    elements
  });
  return instance;
}

/***/ }),

/***/ "./node_modules/next/dist/pages/_app.js":
/*!**********************************************!*\
  !*** ./node_modules/next/dist/pages/_app.js ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


var _interopRequireDefault = __webpack_require__(/*! @babel/runtime/helpers/interopRequireDefault */ "./node_modules/@babel/runtime/helpers/interopRequireDefault.js");

exports.__esModule = true;
exports.Container = Container;
exports.createUrl = createUrl;
exports.default = void 0;

var _react = _interopRequireDefault(__webpack_require__(/*! react */ "react"));

var _utils = __webpack_require__(/*! ../next-server/lib/utils */ "../next-server/lib/utils");

exports.AppInitialProps = _utils.AppInitialProps;
exports.NextWebVitalsMetric = _utils.NextWebVitalsMetric;
/**
* `App` component is used for initialize of pages. It allows for overwriting and full control of the `page` initialization.
* This allows for keeping state between navigation, custom error handling, injecting additional data.
*/

async function appGetInitialProps({
  Component,
  ctx
}) {
  const pageProps = await (0, _utils.loadGetInitialProps)(Component, ctx);
  return {
    pageProps
  };
}

class App extends _react.default.Component {
  // Kept here for backwards compatibility.
  // When someone ended App they could call `super.componentDidCatch`.
  // @deprecated This method is no longer needed. Errors are caught at the top level
  componentDidCatch(error, _errorInfo) {
    throw error;
  }

  render() {
    const {
      router,
      Component,
      pageProps,
      __N_SSG,
      __N_SSP
    } = this.props;
    return /*#__PURE__*/_react.default.createElement(Component, Object.assign({}, pageProps, // we don't add the legacy URL prop if it's using non-legacy
    // methods like getStaticProps and getServerSideProps
    !(__N_SSG || __N_SSP) ? {
      url: createUrl(router)
    } : {}));
  }

}

exports.default = App;
App.origGetInitialProps = appGetInitialProps;
App.getInitialProps = appGetInitialProps;
let warnContainer;
let warnUrl;

if (true) {
  warnContainer = (0, _utils.execOnce)(() => {
    console.warn(`Warning: the \`Container\` in \`_app\` has been deprecated and should be removed. https://nextjs.org/docs/messages/app-container-deprecated`);
  });
  warnUrl = (0, _utils.execOnce)(() => {
    console.error(`Warning: the 'url' property is deprecated. https://nextjs.org/docs/messages/url-deprecated`);
  });
} // @deprecated noop for now until removal


function Container(p) {
  if (true) warnContainer();
  return p.children;
}

function createUrl(router) {
  // This is to make sure we don't references the router object at call time
  const {
    pathname,
    asPath,
    query
  } = router;
  return {
    get query() {
      if (true) warnUrl();
      return query;
    },

    get pathname() {
      if (true) warnUrl();
      return pathname;
    },

    get asPath() {
      if (true) warnUrl();
      return asPath;
    },

    back: () => {
      if (true) warnUrl();
      router.back();
    },
    push: (url, as) => {
      if (true) warnUrl();
      return router.push(url, as);
    },
    pushTo: (href, as) => {
      if (true) warnUrl();
      const pushRoute = as ? href : '';
      const pushUrl = as || href;
      return router.push(pushRoute, pushUrl);
    },
    replace: (url, as) => {
      if (true) warnUrl();
      return router.replace(url, as);
    },
    replaceTo: (href, as) => {
      if (true) warnUrl();
      const replaceRoute = as ? href : '';
      const replaceUrl = as || href;
      return router.replace(replaceRoute, replaceUrl);
    }
  };
}

/***/ }),

/***/ "./node_modules/next/image.js":
/*!************************************!*\
  !*** ./node_modules/next/image.js ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! ./dist/client/image */ "./node_modules/next/dist/client/image.js")


/***/ }),

/***/ "./node_modules/nprogress/nprogress.css":
/*!**********************************************!*\
  !*** ./node_modules/nprogress/nprogress.css ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports) {



/***/ }),

/***/ "./node_modules/react-responsive-carousel/lib/styles/carousel.min.css":
/*!****************************************************************************!*\
  !*** ./node_modules/react-responsive-carousel/lib/styles/carousel.min.css ***!
  \****************************************************************************/
/*! no static exports found */
/***/ (function(module, exports) {



/***/ }),

/***/ "./node_modules/slick-carousel/slick/slick-theme.css":
/*!***********************************************************!*\
  !*** ./node_modules/slick-carousel/slick/slick-theme.css ***!
  \***********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {



/***/ }),

/***/ "./node_modules/slick-carousel/slick/slick.css":
/*!*****************************************************!*\
  !*** ./node_modules/slick-carousel/slick/slick.css ***!
  \*****************************************************/
/*! no static exports found */
/***/ (function(module, exports) {



/***/ }),

/***/ "./node_modules/tailwindcss/tailwind.css":
/*!***********************************************!*\
  !*** ./node_modules/tailwindcss/tailwind.css ***!
  \***********************************************/
/*! no static exports found */
/***/ (function(module, exports) {



/***/ }),

/***/ "./operations/appConfig/appConfig.mutation.ts":
/*!****************************************************!*\
  !*** ./operations/appConfig/appConfig.mutation.ts ***!
  \****************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _models_AppConfig__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../models/AppConfig */ "./models/AppConfig.ts");
function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }



const toogleMenu = function (appConfig) {
  return () => {
    const _appConfig = _objectSpread({}, appConfig());

    _appConfig.menu = !_appConfig.menu;
    appConfig(_appConfig);
  };
};

const setSelectedNavMenu = function (appConfig) {
  return navMenuId => {
    const _appConfig = _objectSpread({}, appConfig());

    _appConfig.navMenuSelected = navMenuId;
    appConfig(_appConfig);
  };
};

const appConfigMutations = {
  toogleMenu: toogleMenu(_models_AppConfig__WEBPACK_IMPORTED_MODULE_0__["appConfigVar"]),
  setSelectedNavMenu: setSelectedNavMenu(_models_AppConfig__WEBPACK_IMPORTED_MODULE_0__["appConfigVar"])
};
/* harmony default export */ __webpack_exports__["default"] = (appConfigMutations);

/***/ }),

/***/ "./operations/appConfig/appConfig.queries.ts":
/*!***************************************************!*\
  !*** ./operations/appConfig/appConfig.queries.ts ***!
  \***************************************************/
/*! exports provided: GET_NAV_MENU_STATE */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "GET_NAV_MENU_STATE", function() { return GET_NAV_MENU_STATE; });
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @apollo/client */ "@apollo/client");
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_0__);

const GET_NAV_MENU_STATE = _apollo_client__WEBPACK_IMPORTED_MODULE_0__["gql"]`
  query GetNavMenuState {
    appConfig @client {
      menu
      navMenuSelected
    }
  }
`;

/***/ }),

/***/ "./operations/appConfig/index.ts":
/*!***************************************!*\
  !*** ./operations/appConfig/index.ts ***!
  \***************************************/
/*! exports provided: appConfigMutation, appConfiqQuery */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "appConfiqQuery", function() { return appConfiqQuery; });
/* harmony import */ var _appConfig_queries__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./appConfig.queries */ "./operations/appConfig/appConfig.queries.ts");
/* harmony import */ var _appConfig_mutation__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./appConfig.mutation */ "./operations/appConfig/appConfig.mutation.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "appConfigMutation", function() { return _appConfig_mutation__WEBPACK_IMPORTED_MODULE_1__["default"]; });



const appConfiqQuery = {
  GET_NAV_MENU_STATE: _appConfig_queries__WEBPACK_IMPORTED_MODULE_0__["GET_NAV_MENU_STATE"]
};


/***/ }),

/***/ "./pages/_app.tsx":
/*!************************!*\
  !*** ./pages/_app.tsx ***!
  \************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "default", function() { return ExtendedApp; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_app__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/app */ "./node_modules/next/app.js");
/* harmony import */ var next_app__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_app__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var tailwindcss_tailwind_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! tailwindcss/tailwind.css */ "./node_modules/tailwindcss/tailwind.css");
/* harmony import */ var tailwindcss_tailwind_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(tailwindcss_tailwind_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _styles_global_scss__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @styles/global.scss */ "./src/styles/global.scss");
/* harmony import */ var _styles_global_scss__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_styles_global_scss__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var react_responsive_carousel_lib_styles_carousel_min_css__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react-responsive-carousel/lib/styles/carousel.min.css */ "./node_modules/react-responsive-carousel/lib/styles/carousel.min.css");
/* harmony import */ var react_responsive_carousel_lib_styles_carousel_min_css__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_responsive_carousel_lib_styles_carousel_min_css__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @apollo/client */ "@apollo/client");
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var helper_apollo__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! helper/apollo */ "./helper/apollo.tsx");
/* harmony import */ var helper_useDeviceType__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! helper/useDeviceType */ "./helper/useDeviceType.ts");
/* harmony import */ var _src_modules_root__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ../src/modules/root */ "./src/modules/root/index.tsx");


var _jsxFileName = "C:\\Users\\KARTHIK\\Documents\\workspace\\matrix-cms-ui-development\\pages\\_app.tsx";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }





 // requires a loader




 // import 'bootstrap/dist/css/bootstrap.css'
// import Head from "next/head";

function ExtendedApp({
  Component,
  pageProps,
  userAgent
}) {
  const apolloClient = Object(helper_apollo__WEBPACK_IMPORTED_MODULE_7__["useApollo"])(pageProps);
  const deviceType = Object(helper_useDeviceType__WEBPACK_IMPORTED_MODULE_8__["useDeviceType"])(userAgent);
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_apollo_client__WEBPACK_IMPORTED_MODULE_6__["ApolloProvider"], {
      client: apolloClient,
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_src_modules_root__WEBPACK_IMPORTED_MODULE_9__["Root"], {
        deviceType: deviceType,
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(Component, _objectSpread(_objectSpread({}, pageProps), {}, {
          deviceType: deviceType
        }), void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 29,
          columnNumber: 11
        }, this)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 28,
        columnNumber: 9
      }, this)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 27,
      columnNumber: 7
    }, this)
  }, void 0, false);
}

ExtendedApp.getInitialProps = async appContext => {
  const appProps = await next_app__WEBPACK_IMPORTED_MODULE_2___default.a.getInitialProps(appContext);
  const {
    req,
    query
  } = appContext.ctx;
  const userAgent = req ? req.headers['user-agent'] : navigator.userAgent;
  return _objectSpread(_objectSpread({}, appProps), {}, {
    userAgent,
    query
  });
};

/***/ }),

/***/ "./public/meta.json":
/*!**************************!*\
  !*** ./public/meta.json ***!
  \**************************/
/*! exports provided: name, plugins, default */
/***/ (function(module) {

module.exports = JSON.parse("{\"name\":\"matrix-cms-ui\",\"plugins\":[{\"name\":\"TailwindCSS\",\"description\":\"A utility-first CSS framework packed with classes like flex, pt-4, text-center and rotate-90 that can be composed to build any design, directly in your markup.\",\"url\":\"https://tailwindcss.com/docs\"},{\"name\":\"SASS/SCSS\",\"description\":\"Sass is a stylesheet language that’s compiled to CSS. It allows you to use variables, nested rules, mixins, functions, and more, all with a fully CSS-compatible syntax.\",\"url\":\"https://sass-lang.com/documentation\"},{\"name\":\"next-i18next\",\"description\":\"next-i18next is a plugin for Next.js projects that allows you to get translations up and running quickly and easily, while fully supporting SSR, multiple namespaces with codesplitting, etc.\",\"url\":\"https://github.com/isaachinman/next-i18next\"},{\"name\":\"Docker\",\"description\":\"Docker simplifies and accelerates your workflow, while giving developers the freedom to innovate with their choice of tools, application stacks, and deployment environments for each project.\",\"url\":\"https://www.docker.com/get-started\"},{\"name\":\"Github Actions\",\"description\":\"GitHub Actions makes it easy to automate all your software workflows, now with world-class CI/CD. Build, test, and deploy your code right from GitHub.\",\"url\":\"https://docs.github.com/en/actions\"}]}");

/***/ }),

/***/ "./src/components/banner/index.tsx":
/*!*****************************************!*\
  !*** ./src/components/banner/index.tsx ***!
  \*****************************************/
/*! exports provided: Banner */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Banner", function() { return Banner; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


var _jsxFileName = "C:\\Users\\KARTHIK\\Documents\\workspace\\matrix-cms-ui-development\\src\\components\\banner\\index.tsx";

const Banner = ({
  title,
  subTitle,
  bannerImg,
  mobileBannerImg
}) => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "sm:hidden w-full bg-cover bg-center c-bg relative",
      style: {
        backgroundImage: `url(${bannerImg})`
      },
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "flex items-center justify-center h-full w-full bg-gray-900 bg-opacity-50",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "text-center",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h1", {
            className: "text-white text-7lg md:leading-10 font-bold xl:text-4xl sm:text-2xl",
            children: title
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 17,
            columnNumber: 13
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
            className: "text-white text-3md md:text-xl",
            children: subTitle
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 18,
            columnNumber: 13
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "flex w-full relative position-bottom"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 19,
            columnNumber: 13
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 16,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 15,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 14,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "sm:block hidden w-full bg-cover bg-center c-bg relative",
      style: {
        backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)),url(${mobileBannerImg})`
      },
      children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "flex items-center justify-center h-full w-full bg-gray-900 bg-opacity-50",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "p-8",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h1", {
            className: "text-white leading-tight text-5sm font-medium sm:text-left",
            children: title
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 37,
            columnNumber: 13
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
            className: "text-white text-xl sm:text-left",
            children: subTitle
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 38,
            columnNumber: 13
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "flex w-full relative position-bottom"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 39,
            columnNumber: 13
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 36,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 35,
        columnNumber: 9
      }, undefined)
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 34,
      columnNumber: 7
    }, undefined)]
  }, void 0, true);
};

/***/ }),

/***/ "./src/components/button/PrimaryButtonIconRight.tsx":
/*!**********************************************************!*\
  !*** ./src/components/button/PrimaryButtonIconRight.tsx ***!
  \**********************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);

var _jsxFileName = "C:\\Users\\KARTHIK\\Documents\\workspace\\matrix-cms-ui-development\\src\\components\\button\\PrimaryButtonIconRight.tsx";


const Button = ({
  title,
  url,
  onClick,
  className = "",
  style = {}
}) => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("button", {
    onClick: onClick,
    style: style,
    className: `flex p-0.5 pl-0 items-center mt-2 ${className}`,
    children: [" ", title, " ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
      className: "pl-2",
      src: url
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 25,
      columnNumber: 15
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 19,
    columnNumber: 5
  }, undefined);
};

/* harmony default export */ __webpack_exports__["default"] = (Button);

/***/ }),

/***/ "./src/components/button/SecondaryButton.tsx":
/*!***************************************************!*\
  !*** ./src/components/button/SecondaryButton.tsx ***!
  \***************************************************/
/*! exports provided: SecondaryButton */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SecondaryButton", function() { return SecondaryButton; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);

var _jsxFileName = "C:\\Users\\KARTHIK\\Documents\\workspace\\matrix-cms-ui-development\\src\\components\\button\\SecondaryButton.tsx";

const SecondaryButton = ({
  title,
  onClick,
  className
}) => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("button", {
    className: `text-lg leading-6 font-medium underline text-accent-dark  ${className}`,
    children: [" ", title]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 11,
    columnNumber: 13
  }, undefined);
};

/***/ }),

/***/ "./src/components/button/index.tsx":
/*!*****************************************!*\
  !*** ./src/components/button/index.tsx ***!
  \*****************************************/
/*! exports provided: Button */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Button", function() { return Button; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);

var _jsxFileName = "C:\\Users\\KARTHIK\\Documents\\workspace\\matrix-cms-ui-development\\src\\components\\button\\index.tsx";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _objectWithoutProperties(source, excluded) { if (source == null) return {}; var target = _objectWithoutPropertiesLoose(source, excluded); var key, i; if (Object.getOwnPropertySymbols) { var sourceSymbolKeys = Object.getOwnPropertySymbols(source); for (i = 0; i < sourceSymbolKeys.length; i++) { key = sourceSymbolKeys[i]; if (excluded.indexOf(key) >= 0) continue; if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue; target[key] = source[key]; } } return target; }

function _objectWithoutPropertiesLoose(source, excluded) { if (source == null) return {}; var target = {}; var sourceKeys = Object.keys(source); var key, i; for (i = 0; i < sourceKeys.length; i++) { key = sourceKeys[i]; if (excluded.indexOf(key) >= 0) continue; target[key] = source[key]; } return target; }


const Button = (_ref) => {
  let {
    className = "",
    children
  } = _ref,
      rest = _objectWithoutProperties(_ref, ["className", "children"]);

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("button", _objectSpread(_objectSpread({
    className: `py-2 px-4 rounded bg-green-500 hover:bg-green-600 focus:outline-none ring-opacity-75 ring-green-400 focus:ring text-white text-lg ${className}`
  }, rest), {}, {
    children: children
  }), void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 14,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/components/cards/index.tsx":
/*!****************************************!*\
  !*** ./src/components/cards/index.tsx ***!
  \****************************************/
/*! exports provided: Cards */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Cards", function() { return Cards; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _public_meta_json__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @public/meta.json */ "./public/meta.json");
var _public_meta_json__WEBPACK_IMPORTED_MODULE_2___namespace = /*#__PURE__*/__webpack_require__.t(/*! @public/meta.json */ "./public/meta.json", 1);

var _jsxFileName = "C:\\Users\\KARTHIK\\Documents\\workspace\\matrix-cms-ui-development\\src\\components\\cards\\index.tsx";


const Cards = () => {
  var _data$plugins;

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: "flex-1 container my-8 max-w-screen-lg mx-auto p-5",
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6",
      children: ((_data$plugins = _public_meta_json__WEBPACK_IMPORTED_MODULE_2__ === null || _public_meta_json__WEBPACK_IMPORTED_MODULE_2__ === void 0 ? void 0 : _public_meta_json__WEBPACK_IMPORTED_MODULE_2__.plugins) !== null && _data$plugins !== void 0 ? _data$plugins : []).map(plugin => /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "col-span-1 rounded-md border border-gray-300 p-5",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h2", {
          className: "text-xl font-semibold mb-2",
          children: plugin.name
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 14,
          columnNumber: 13
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
          className: "m-0",
          children: plugin.description
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 15,
          columnNumber: 13
        }, undefined)]
      }, plugin.name, true, {
        fileName: _jsxFileName,
        lineNumber: 10,
        columnNumber: 11
      }, undefined))
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 8,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 7,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/components/container/index.tsx":
/*!********************************************!*\
  !*** ./src/components/container/index.tsx ***!
  \********************************************/
/*! exports provided: Container */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Container", function() { return Container; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);

var _jsxFileName = "C:\\Users\\KARTHIK\\Documents\\workspace\\matrix-cms-ui-development\\src\\components\\container\\index.tsx";
const Container = ({
  children
}) => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: "min-h-screen flex flex-col",
    children: children
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 2,
    columnNumber: 10
  }, undefined);
};

/***/ }),

/***/ "./src/components/contentItem/index.tsx":
/*!**********************************************!*\
  !*** ./src/components/contentItem/index.tsx ***!
  \**********************************************/
/*! exports provided: ContentItem */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ContentItem", function() { return ContentItem; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @components */ "./src/components/index.ts");
/* harmony import */ var _components_button_PrimaryButtonIconRight__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @components/button/PrimaryButtonIconRight */ "./src/components/button/PrimaryButtonIconRight.tsx");
/* harmony import */ var _utils_getContentTypeImageUrl__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../utils/getContentTypeImageUrl */ "./utils/getContentTypeImageUrl.ts");

var _jsxFileName = "C:\\Users\\KARTHIK\\Documents\\workspace\\matrix-cms-ui-development\\src\\components\\contentItem\\index.tsx";




const ContentItem = ({
  image_url,
  className = "",
  title,
  author,
  onClick,
  content_id,
  content_type,
  read_duration,
  style = {}
}) => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: `${className} relative mb-11 ml-0`,
    style: style,
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_2__["Image"], {
      src: image_url,
      alt: "content-image",
      className: ""
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 34,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "content-item-desc bg-secondary-light absolute top-4 p-3",
      style: {
        top: "2.5rem",
        left: "9.5rem"
      },
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h5", {
        className: "text-lg font-medium leading-6 text-primary-dark ml-2 p-0.5",
        children: title
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 39,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "flex justify-between ml-2 pl-0.5 pt-0.5",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
          className: "font-normal text-xs leading-3  text-primary-dark opacity-50",
          children: ["BY ", " " + author]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 43,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
          className: "font-normal text-xs leading-3  text-primary-dark opacity-50 mr-1",
          children: read_duration + " READ"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 46,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 42,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "flex justify-between mt-3",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_button_PrimaryButtonIconRight__WEBPACK_IMPORTED_MODULE_3__["default"], {
          title: "Read More",
          className: "h-8 w-36 text-accent",
          url: "/icons/rightArrowGray.svg"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 52,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_2__["Image"], {
          src: Object(_utils_getContentTypeImageUrl__WEBPACK_IMPORTED_MODULE_4__["default"])(content_type),
          alt: "content type image",
          className: "mr-1"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 57,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 50,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 35,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 30,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/components/contentSlider/ContentSlider.tsx":
/*!********************************************************!*\
  !*** ./src/components/contentSlider/ContentSlider.tsx ***!
  \********************************************************/
/*! exports provided: ContentSlider */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ContentSlider", function() { return ContentSlider; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components_contentItem__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @components/contentItem */ "./src/components/contentItem/index.tsx");

var _jsxFileName = "C:\\Users\\KARTHIK\\Documents\\workspace\\matrix-cms-ui-development\\src\\components\\contentSlider\\ContentSlider.tsx";


const ContentSlider = ({
  contentList,
  className,
  header,
  style = {}
}) => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: `${className}`,
    style: style,
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        children: header
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 15,
        columnNumber: 17
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 16,
        columnNumber: 17
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 14,
      columnNumber: 13
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "flex",
      children: contentList.map(contentItem => {
        return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_contentItem__WEBPACK_IMPORTED_MODULE_2__["ContentItem"], {
          image_url: contentItem.image_url,
          title: contentItem.title,
          author: contentItem.author,
          content_id: contentItem.content_id,
          content_type: contentItem.content_type,
          read_duration: contentItem.read_duration,
          onClick: id => console.log(id),
          style: {
            width: 610
          },
          className: "mr-3 mt-2 text-lg leading-6"
        }, contentItem.content_id, false, {
          fileName: _jsxFileName,
          lineNumber: 21,
          columnNumber: 25
        }, undefined);
      })
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 18,
      columnNumber: 13
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 13,
    columnNumber: 9
  }, undefined);
};

/***/ }),

/***/ "./src/components/footer/footerMenu.tsx":
/*!**********************************************!*\
  !*** ./src/components/footer/footerMenu.tsx ***!
  \**********************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _constants_footerMenu__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../constants/footerMenu */ "./constants/footerMenu.ts");

var _jsxFileName = "C:\\Users\\KARTHIK\\Documents\\workspace\\matrix-cms-ui-development\\src\\components\\footer\\footerMenu.tsx";



const FooterMenu = () => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: "sm:grid sm:grid-cols-2 sm:gap-y-0.5  bg-primary   sub-h2 laptop:flex laptop:items-center laptop:pl-56 ",
    children: _constants_footerMenu__WEBPACK_IMPORTED_MODULE_2__["default"].map((item, index) => {
      return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
        className: "p-1.5",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
          href: item.link,
          className: "text-secondary h-14 p-0.5 mr-11 leading-4.5",
          children: [" ", item.name]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 10,
          columnNumber: 11
        }, undefined)
      }, index, false, {
        fileName: _jsxFileName,
        lineNumber: 9,
        columnNumber: 17
      }, undefined);
    })
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 6,
    columnNumber: 11
  }, undefined);
};

/* harmony default export */ __webpack_exports__["default"] = (FooterMenu);

/***/ }),

/***/ "./src/components/footer/index.tsx":
/*!*****************************************!*\
  !*** ./src/components/footer/index.tsx ***!
  \*****************************************/
/*! exports provided: Footer */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Footer", function() { return Footer; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _footerMenu__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./footerMenu */ "./src/components/footer/footerMenu.tsx");
/* harmony import */ var _components_button_PrimaryButtonIconRight__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @components/button/PrimaryButtonIconRight */ "./src/components/button/PrimaryButtonIconRight.tsx");
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../constants */ "./constants/index.ts");

var _jsxFileName = "C:\\Users\\KARTHIK\\Documents\\workspace\\matrix-cms-ui-development\\src\\components\\footer\\index.tsx";




const Footer = () => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: "flex  justify-end flex-col text-secondary w-full align-bottom mt-auto",
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "bg-accent-dark footer-top flex laptop:justify-between sm:flex-col sm:pl-11 sm:pr-11 sm:pt-11",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "laptop:flex laptop:mt-16 p-0.5 laptop:ml-56",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h6", {
          className: "laptop:w-48 font-normal leading-9 text-4xl tracking-wider p-0.5",
          children: " Let's stay engaged"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 12,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
          className: "p-1 ml-4",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h6", {
            className: "sub-h2 font-medium text-lg leading-6",
            children: "Sign up for the Matrix Moments series"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 14,
            columnNumber: 13
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("input", {
            className: "mt-2 text-secondary bg-accent p-0.5 pl-3 w-full",
            style: {
              color: "#FBF9F5"
            },
            type: "email",
            placeholder: "Your email address goes here"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 15,
            columnNumber: 13
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_button_PrimaryButtonIconRight__WEBPACK_IMPORTED_MODULE_3__["default"], {
            title: "Subscribe",
            url: "/icons/arrow.svg",
            className: "p-1 text-cta",
            onClick: () => console.log("subscribe")
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 16,
            columnNumber: 13
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 13,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 11,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: " laptop:mt-16 p-0.5 laptop:mr-52 sm:flex sm:justify-between ",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h6", {
            className: "sub-h2 font-medium text-lg",
            children: " Matrix Partner Us "
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 21,
            columnNumber: 13
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h6", {
            className: " sub-h2 font-medium text-lg",
            children: " Matrix Partner China"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 22,
            columnNumber: 13
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 20,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "flex mt-2 laptop:mt-8 items-start p-0.5",
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
            className: " pl-0",
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
              src: "/icons/linkedin.svg"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 25,
              columnNumber: 34
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 25,
            columnNumber: 13
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
            className: " pl-9",
            children: [" ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
              src: "/icons/twitter.svg"
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 26,
              columnNumber: 35
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 26,
            columnNumber: 13
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 24,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 19,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 10,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: " laptop:flex justify-between footer-menu bg-primary align-middle sm:pl-11 sm:pt-6",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_footerMenu__WEBPACK_IMPORTED_MODULE_2__["default"], {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 31,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: " text-secondary flex items-center sm:mt-2 sm:grid sm:grid-cols-2 sm:gap-0",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
          className: "caption p-1 w-28 text-sm sm:mt-2",
          children: "PRIVACY POLICY"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 33,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
          className: "caption p-0.5 laptop:ml-20 laptop:mr-40 ",
          children: [_constants__WEBPACK_IMPORTED_MODULE_4__["PRIVACY_POLICY"], " "]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 34,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 32,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 30,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 9,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/components/founder/Founder.tsx":
/*!********************************************!*\
  !*** ./src/components/founder/Founder.tsx ***!
  \********************************************/
/*! exports provided: Founder */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Founder", function() { return Founder; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react-slick */ "react-slick");
/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_slick__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! slick-carousel/slick/slick.css */ "./node_modules/slick-carousel/slick/slick.css");
/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! slick-carousel/slick/slick-theme.css */ "./node_modules/slick-carousel/slick/slick-theme.css");
/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @components */ "./src/components/index.ts");

var _jsxFileName = "C:\\Users\\KARTHIK\\Documents\\workspace\\matrix-cms-ui-development\\src\\components\\founder\\Founder.tsx";

function ownKeys(object, enumerableOnly) { var keys = Object.keys(object); if (Object.getOwnPropertySymbols) { var symbols = Object.getOwnPropertySymbols(object); if (enumerableOnly) symbols = symbols.filter(function (sym) { return Object.getOwnPropertyDescriptor(object, sym).enumerable; }); keys.push.apply(keys, symbols); } return keys; }

function _objectSpread(target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i] != null ? arguments[i] : {}; if (i % 2) { ownKeys(Object(source), true).forEach(function (key) { _defineProperty(target, key, source[key]); }); } else if (Object.getOwnPropertyDescriptors) { Object.defineProperties(target, Object.getOwnPropertyDescriptors(source)); } else { ownKeys(Object(source)).forEach(function (key) { Object.defineProperty(target, key, Object.getOwnPropertyDescriptor(source, key)); }); } } return target; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }






const Founder = ({
  className,
  style = {}
}) => {
  const heros = [{
    firstName: 'Bhavish',
    lastName: 'AGGARWAL',
    firstName1: null,
    lastName1: null,
    caption: 'Mobility',
    caption1: 'Electric Cars',
    logo: '/icons/ola.svg',
    image: '/icons/Bhavish_image.svg',
    heading: ['We are', 'founders', 'first']
  }, {
    firstName: 'ROHIT',
    lastName: 'M.A.',
    firstName1: null,
    lastName1: null,
    caption: 'Healthcare',
    caption1: null,
    logo: '/icons/Cloudnine.svg',
    image: '/icons/Rohit_Treatment.svg',
    heading: ['We ', 'partner', 'closely']
  }, {
    firstName: 'ANINDYA',
    lastName: 'DUTTA',
    firstName1: 'SANDEEP',
    lastName1: 'DALMIA',
    caption: 'Student Housing Platform',
    caption1: null,
    logo: '/icons/Stanza.svg',
    image: '/icons/Anindya.svg',
    heading: ['We ', 'invest', 'early']
  }, {
    firstName: 'Asish',
    lastName: 'MOHAPATRA',
    firstName1: null,
    lastName1: null,
    caption: 'Fintech',
    caption1: 'SME Lending',
    logo: '/icons/OfBusiness.svg',
    image: '/icons/Asish.svg',
    heading: ['We', 'commit', 'personally']
  }, {
    firstName: 'Mr.',
    lastName: 'LAKSHIPATHY',
    firstName1: null,
    lastName1: null,
    caption: 'Fintech',
    caption1: 'NBFC',
    logo: '/icons/mx.svg',
    image: '/icons/Laxmipathy.svg',
    heading: ['We are', 'founders', 'first']
  }, {
    firstName: 'CHAKRADHAR',
    lastName: 'GADE',
    firstName1: 'NITIN',
    lastName1: 'KAUSHAL',
    caption: 'Fintech',
    caption1: 'NBFC',
    logo: '/icons/Country.svg',
    heading: ['We', 'commit', 'personally'],
    image: '/icons/Chakradhar.svg'
  }];
  const data = [{
    image_url: "/icons/content1.svg",
    title: "From both sides of the table : Kunal Bahl unplugged",
    author: "TARUN DAVDA",
    content_id: "abcdef",
    content_type: "blog",
    read_duration: "4 MIN"
  }, {
    image_url: "/icons/content1.svg",
    title: "From both sides of the table : Kunal Bahl unplugged",
    author: "TARUN DAVDA",
    content_id: "abcdefg",
    content_type: "blog",
    read_duration: "4 MIN"
  }];
  const settings = {
    dots: true,
    infinite: true,
    speed: 500,
    autoplaySpeed: 5000,
    slidesToShow: 1,
    slidesToScroll: 1 // autoplay: true

  };
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_slick__WEBPACK_IMPORTED_MODULE_2___default.a, _objectSpread(_objectSpread({}, settings), {}, {
    children: heros.map(hero => {
      return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: `${className}`,
          style: _objectSpread({
            width: 615.94,
            height: 863.91,
            position: "relative"
          }, style),
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "",
            style: {
              width: 571,
              height: 762,
              position: "absolute",
              background: "#083A4A",
              bottom: 50,
              left: 0
            }
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 113,
            columnNumber: 13
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "",
            style: {
              width: 594,
              height: 788,
              bottom: 65,
              left: 15,
              position: "absolute",
              display: "flex",
              flexDirection: "column"
            },
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_5__["Image"], {
              src: hero.image,
              alt: "founder image",
              style: {
                flexGrow: 1
              }
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 115,
              columnNumber: 15
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_5__["Image"], {
              src: "/icons/rectangle.svg",
              alt: "reactangle",
              className: "absolute",
              style: {
                left: 38,
                bottom: 254
              }
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 116,
              columnNumber: 15
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
              style: {
                height: 209,
                background: "#01576E"
              },
              children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "text-center flex items-center",
                style: {
                  height: 118,
                  borderBottom: "1px solid #EBEBE9"
                },
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h6", {
                  className: "font-bold text-secondary",
                  style: {
                    fontSize: 32,
                    lineHeight: "36px",
                    letterSpacing: "0.05em",
                    marginLeft: 31,
                    marginRight: 8
                  },
                  children: hero.firstName
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 120,
                  columnNumber: 19
                }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h6", {
                  className: "font-light text-secondary",
                  style: {
                    fontSize: 32,
                    lineHeight: "36px",
                    letterSpacing: "0.05em"
                  },
                  children: hero.lastName
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 123,
                  columnNumber: 19
                }, undefined)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 119,
                columnNumber: 17
              }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                className: "flex justify-between items-center",
                style: {
                  height: 88
                },
                children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
                  style: {
                    marginLeft: 31,
                    display: 'flex',
                    justifyContent: 'space-around'
                  },
                  children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                    className: "text-secondary font-medium text-lg leading-6",
                    children: [" ", hero.caption]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 130,
                    columnNumber: 21
                  }, undefined), hero.caption1 && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                    className: "text-secondary font-medium text-lg leading-6",
                    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("hr", {
                      style: {
                        width: 30,
                        transform: 'rotate(90deg)'
                      }
                    }, void 0, false, {
                      fileName: _jsxFileName,
                      lineNumber: 131,
                      columnNumber: 102
                    }, undefined)
                  }, void 0, false, {
                    fileName: _jsxFileName,
                    lineNumber: 131,
                    columnNumber: 39
                  }, undefined), hero.caption1 && /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                    className: "text-secondary font-medium text-lg leading-6",
                    children: [" ", hero.caption1]
                  }, void 0, true, {
                    fileName: _jsxFileName,
                    lineNumber: 132,
                    columnNumber: 39
                  }, undefined)]
                }, void 0, true, {
                  fileName: _jsxFileName,
                  lineNumber: 129,
                  columnNumber: 19
                }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_5__["Image"], {
                  src: hero.logo,
                  alt: "ola",
                  style: {
                    marginRight: 57
                  }
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 134,
                  columnNumber: 19
                }, undefined)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 128,
                columnNumber: 17
              }, undefined)]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 118,
              columnNumber: 15
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 114,
            columnNumber: 13
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "",
            style: {
              left: 760,
              position: "absolute"
            },
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
              className: "slide-header",
              children: [hero.heading[0], /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                style: {
                  color: '#01576E'
                },
                children: [" ", hero.heading[1], " "]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 140,
                columnNumber: 60
              }, undefined), " ", hero.heading[2]]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 140,
              columnNumber: 15
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_5__["ContentSlider"], {
              style: {
                left: -12,
                background: "#EBEBE9",
                border: "1px solid #EBEBE9",
                boxSizing: "border-box",
                fontSize: 28,
                lineHeight: "34px",
                paddingTop: 24,
                paddingLeft: 34,
                width: '155%',
                bottom: -347,
                height: 301
              },
              contentList: data,
              className: "absolute bottom-0 right-0 text-primary-dark",
              header: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                children: ["Insights from market ", /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
                  className: "text-accent",
                  children: "disruptors & investors"
                }, void 0, false, {
                  fileName: _jsxFileName,
                  lineNumber: 158,
                  columnNumber: 52
                }, undefined)]
              }, void 0, true, {
                fileName: _jsxFileName,
                lineNumber: 158,
                columnNumber: 25
              }, undefined)
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 142,
              columnNumber: 15
            }, undefined)]
          }, void 0, true, {
            fileName: _jsxFileName,
            lineNumber: 139,
            columnNumber: 13
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 112,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 111,
        columnNumber: 17
      }, undefined);
    })
  }), void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 109,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/components/founder/index.ts":
/*!*****************************************!*\
  !*** ./src/components/founder/index.ts ***!
  \*****************************************/
/*! exports provided: Founder */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _Founder__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Founder */ "./src/components/founder/Founder.tsx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Founder", function() { return _Founder__WEBPACK_IMPORTED_MODULE_0__["Founder"]; });



/***/ }),

/***/ "./src/components/header/index.tsx":
/*!*****************************************!*\
  !*** ./src/components/header/index.tsx ***!
  \*****************************************/
/*! exports provided: Header */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Header", function() { return Header; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @components */ "./src/components/index.ts");

var _jsxFileName = "C:\\Users\\KARTHIK\\Documents\\workspace\\matrix-cms-ui-development\\src\\components\\header\\index.tsx";


const Header = ({
  toggle
}) => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: "absolute flex w-full z-20 justify-between items-start laptop:pl-8 mt-11 sm:mt-0 sm:p-5",
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_2__["Logo"], {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 12,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "flex  items-center justify-start mt-2 text-accent ",
      onClick: () => toggle(),
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h6", {
        className: "sub-h1 pr-1 menu-text",
        children: "Menu"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 17,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
        src: "/icons/menu.svg",
        className: "pl-2 laptop:mr-20 text-blue"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 18,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 13,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 11,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/components/image/index.tsx":
/*!****************************************!*\
  !*** ./src/components/image/index.tsx ***!
  \****************************************/
/*! exports provided: Image */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Image", function() { return Image; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);

var _jsxFileName = "C:\\Users\\KARTHIK\\Documents\\workspace\\matrix-cms-ui-development\\src\\components\\image\\index.tsx";

const Image = ({
  src,
  alt,
  className,
  width,
  height,
  style = {}
}) => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("img", {
    src: src,
    alt: alt,
    className: className,
    height: height,
    width: width,
    style: style
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 13,
    columnNumber: 12
  }, undefined);
};

/***/ }),

/***/ "./src/components/index.ts":
/*!*********************************!*\
  !*** ./src/components/index.ts ***!
  \*********************************/
/*! exports provided: Header, Logo, Main, Button, Cards, Footer, Container, Image, Tag, NavItem, ContentItem, Founder, ContentSlider, Banner */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _header__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./header */ "./src/components/header/index.tsx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Header", function() { return _header__WEBPACK_IMPORTED_MODULE_0__["Header"]; });

/* harmony import */ var _logo__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./logo */ "./src/components/logo/index.tsx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Logo", function() { return _logo__WEBPACK_IMPORTED_MODULE_1__["Logo"]; });

/* harmony import */ var _main__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./main */ "./src/components/main/index.tsx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Main", function() { return _main__WEBPACK_IMPORTED_MODULE_2__["Main"]; });

/* harmony import */ var _button__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./button */ "./src/components/button/index.tsx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Button", function() { return _button__WEBPACK_IMPORTED_MODULE_3__["Button"]; });

/* harmony import */ var _cards__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./cards */ "./src/components/cards/index.tsx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Cards", function() { return _cards__WEBPACK_IMPORTED_MODULE_4__["Cards"]; });

/* harmony import */ var _footer__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./footer */ "./src/components/footer/index.tsx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Footer", function() { return _footer__WEBPACK_IMPORTED_MODULE_5__["Footer"]; });

/* harmony import */ var _container__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./container */ "./src/components/container/index.tsx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Container", function() { return _container__WEBPACK_IMPORTED_MODULE_6__["Container"]; });

/* harmony import */ var _image__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./image */ "./src/components/image/index.tsx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Image", function() { return _image__WEBPACK_IMPORTED_MODULE_7__["Image"]; });

/* harmony import */ var _tag__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ./tag */ "./src/components/tag/index.tsx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Tag", function() { return _tag__WEBPACK_IMPORTED_MODULE_8__["Tag"]; });

/* harmony import */ var _navItem__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! ./navItem */ "./src/components/navItem/index.tsx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "NavItem", function() { return _navItem__WEBPACK_IMPORTED_MODULE_9__["NavItem"]; });

/* harmony import */ var _contentItem__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! ./contentItem */ "./src/components/contentItem/index.tsx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ContentItem", function() { return _contentItem__WEBPACK_IMPORTED_MODULE_10__["ContentItem"]; });

/* harmony import */ var _founder__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ./founder */ "./src/components/founder/index.ts");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Founder", function() { return _founder__WEBPACK_IMPORTED_MODULE_11__["Founder"]; });

/* harmony import */ var _contentSlider_ContentSlider__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ./contentSlider/ContentSlider */ "./src/components/contentSlider/ContentSlider.tsx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "ContentSlider", function() { return _contentSlider_ContentSlider__WEBPACK_IMPORTED_MODULE_12__["ContentSlider"]; });

/* harmony import */ var _banner__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! ./banner */ "./src/components/banner/index.tsx");
/* harmony reexport (safe) */ __webpack_require__.d(__webpack_exports__, "Banner", function() { return _banner__WEBPACK_IMPORTED_MODULE_13__["Banner"]; });
















/***/ }),

/***/ "./src/components/logo/index.tsx":
/*!***************************************!*\
  !*** ./src/components/logo/index.tsx ***!
  \***************************************/
/*! exports provided: Logo */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Logo", function() { return Logo; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! next/image */ "./node_modules/next/image.js");
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);

var _jsxFileName = "C:\\Users\\KARTHIK\\Documents\\workspace\\matrix-cms-ui-development\\src\\components\\logo\\index.tsx";


const Logo = () => {
  return (
    /*#__PURE__*/
    // <Image src="/icons/matrixLogo_White.svg" alt="nextjs" width="156.19px" height="65px" className="company-logo" />
    Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(next_image__WEBPACK_IMPORTED_MODULE_2___default.a, {
      src: "/icons/matrixLogo.svg",
      alt: "nextjs",
      width: "156.19px",
      height: "65px",
      className: "company-logo"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 7,
      columnNumber: 5
    }, undefined)
  );
};

/***/ }),

/***/ "./src/components/main/index.tsx":
/*!***************************************!*\
  !*** ./src/components/main/index.tsx ***!
  \***************************************/
/*! exports provided: Main */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Main", function() { return Main; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @components */ "./src/components/index.ts");

var _jsxFileName = "C:\\Users\\KARTHIK\\Documents\\workspace\\matrix-cms-ui-development\\src\\components\\main\\index.tsx";


const Main = () => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: "text-center font-light py-5 bg-gray-700",
    children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "container mx-auto",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h1", {
        className: "text-white text-8xl mb-2",
        children: "matrix"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 9,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("p", {
        className: "text-lg text-white mb-3",
        children: "The frontend boilerplate with superpowers!"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 10,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_2__["Button"], {
        type: "button",
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
          href: "https://pankod.github.io/superplate/",
          target: "_blank",
          children: "Docs"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 14,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 13,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 8,
      columnNumber: 7
    }, undefined)
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 7,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/components/navItem/index.tsx":
/*!******************************************!*\
  !*** ./src/components/navItem/index.tsx ***!
  \******************************************/
/*! exports provided: NavItem */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "NavItem", function() { return NavItem; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @components */ "./src/components/index.ts");

var _jsxFileName = "C:\\Users\\KARTHIK\\Documents\\workspace\\matrix-cms-ui-development\\src\\components\\navItem\\index.tsx";


const NavItem = ({
  title,
  selected,
  id,
  onClick,
  className = "",
  arrow = true
}) => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: `${className} flex justify-between menu-primary-nav-text text-primary-dark`,
    style: {
      marginBottom: 25
    },
    onClick: () => onClick(id),
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
      children: title
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 28,
      columnNumber: 7
    }, undefined), selected || arrow ? !selected ? /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
      className: "menu-primary-nav-icon",
      children: [" ", ">", " "]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 32,
      columnNumber: 11
    }, undefined) : /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_2__["Image"], {
      src: "/icons/sideNavButton.svg",
      alt: "nav button",
      className: "-mr-5 opacity-100"
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 34,
      columnNumber: 11
    }, undefined) : null]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 23,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/components/tag/index.tsx":
/*!**************************************!*\
  !*** ./src/components/tag/index.tsx ***!
  \**************************************/
/*! exports provided: Tag */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Tag", function() { return Tag; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);

var _jsxFileName = "C:\\Users\\KARTHIK\\Documents\\workspace\\matrix-cms-ui-development\\src\\components\\tag\\index.tsx";

const Tag = ({
  selected,
  title,
  id,
  onClick,
  className = "",
  style = {}
}) => {
  const _className = selected ? "tag-selected" : "tag";

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
    className: className + " " + _className,
    style: style,
    onClick: () => {
      if (onClick) onClick(id);
    },
    children: title
  }, void 0, false, {
    fileName: _jsxFileName,
    lineNumber: 15,
    columnNumber: 13
  }, undefined);
};

/***/ }),

/***/ "./src/modules/content/contentList.tsx":
/*!*********************************************!*\
  !*** ./src/modules/content/contentList.tsx ***!
  \*********************************************/
/*! exports provided: ContentList */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "ContentList", function() { return ContentList; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @components */ "./src/components/index.ts");
/* harmony import */ var _components_button_SecondaryButton__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @components/button/SecondaryButton */ "./src/components/button/SecondaryButton.tsx");

var _jsxFileName = "C:\\Users\\KARTHIK\\Documents\\workspace\\matrix-cms-ui-development\\src\\modules\\content\\contentList.tsx";



const data = [{
  image_url: "/icons/content1.svg",
  title: "From both sides of the table : Kunal Bahl unplugged",
  author: "TARUN DAVDA",
  content_id: "abcdef",
  content_type: "blog",
  read_duration: "4 MIN"
}, {
  image_url: "/icons/content1.svg",
  title: "From both sides of the table : Kunal Bahl unplugged",
  author: "TARUN DAVDA",
  content_id: "abcdefg",
  content_type: "blog",
  read_duration: "4 MIN"
}];
const ContentList = () => {
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: "ml-20 mt-14 flex-grow sm:hidden",
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "flex justify-between",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "mb-3",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
          className: "font-light text-3xl leading-8 tracking-tighter text-primary",
          children: [" ", "RELEVANT CONTENT", " "]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 30,
          columnNumber: 17
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
          className: "ml-5 pl-1 text-accent",
          children: "(3200)"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 31,
          columnNumber: 17
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 29,
        columnNumber: 13
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_button_SecondaryButton__WEBPACK_IMPORTED_MODULE_3__["SecondaryButton"], {
        title: "View All RESULTS",
        className: " mr-6 text-accent-dark"
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 34,
        columnNumber: 13
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 28,
      columnNumber: 9
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "mt-4 flex-grow overflow-auto",
      children: data.map(contentItem => {
        return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_2__["ContentItem"], {
          image_url: contentItem.image_url,
          title: contentItem.title,
          author: contentItem.author,
          content_id: contentItem.content_id,
          content_type: contentItem.content_type,
          read_duration: contentItem.read_duration,
          onClick: id => console.log(id)
        }, contentItem.content_id, false, {
          fileName: _jsxFileName,
          lineNumber: 39,
          columnNumber: 29
        }, undefined);
      })
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 36,
      columnNumber: 9
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 27,
    columnNumber: 13
  }, undefined);
};

/***/ }),

/***/ "./src/modules/menu/index.tsx":
/*!************************************!*\
  !*** ./src/modules/menu/index.tsx ***!
  \************************************/
/*! exports provided: Menu */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Menu", function() { return Menu; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _sideNav__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./sideNav */ "./src/modules/menu/sideNav.tsx");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @components */ "./src/components/index.ts");
/* harmony import */ var _components_button_PrimaryButtonIconRight__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @components/button/PrimaryButtonIconRight */ "./src/components/button/PrimaryButtonIconRight.tsx");
/* harmony import */ var _content_contentList__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../content/contentList */ "./src/modules/content/contentList.tsx");
/* harmony import */ var _tagList__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./tagList */ "./src/modules/menu/tagList.tsx");
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @apollo/client */ "@apollo/client");
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _operations_appConfig__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../../../operations/appConfig */ "./operations/appConfig/index.ts");

var _jsxFileName = "C:\\Users\\KARTHIK\\Documents\\workspace\\matrix-cms-ui-development\\src\\modules\\menu\\index.tsx";








const tagList = [{
  title: "Education",
  id: "education"
}, {
  title: "Edtech",
  id: "edtech"
}, {
  title: "Consumer",
  id: "consumer"
}, {
  title: "D2C",
  id: "d2c"
}, {
  title: "Fintech",
  id: "fintech"
}, {
  title: "Gaming",
  id: "gaming"
}, {
  title: "social",
  id: "social"
}, {
  title: "Communication",
  id: "communication"
}, {
  title: "Marketplaces",
  id: "marketplaces"
}, {
  title: "Mobile",
  id: "Mobile"
}];
const Menu = () => {
  const {
    data: {
      appConfig: navMenuState
    }
  } = Object(_apollo_client__WEBPACK_IMPORTED_MODULE_7__["useQuery"])(_operations_appConfig__WEBPACK_IMPORTED_MODULE_8__["appConfiqQuery"].GET_NAV_MENU_STATE);
  console.log(navMenuState);
  const className = navMenuState.menu ? "visible" : "invisible hidden";
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: `bg-secondary z-30 overflow-hidden   flex  w-full flex-grow absolute top-0 ${className}`,
    style: {
      height: 1053
    },
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "flex justify-between bg-secondary-light flex-grow",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_3__["Image"], {
          src: "/icons/matrixLogo.svg",
          alt: "company logo",
          className: "company-logo"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 62,
          columnNumber: 11
        }, undefined)
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 61,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "sm:hidden menu-tags flex-grow pl-24",
        style: {
          marginLeft: 263
        },
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_tagList__WEBPACK_IMPORTED_MODULE_6__["TagList"], {
          title: "SECTORAL",
          tagList: tagList,
          className: "mt-28 pr-11 opacity-100",
          onItemClick: items => {
            console.log(items);
          }
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 65,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_tagList__WEBPACK_IMPORTED_MODULE_6__["TagList"], {
          title: "NON-SECTORAL",
          tagList: tagList,
          className: "pr-11 opacity-100",
          onItemClick: items => {
            console.log(items);
          }
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 69,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 64,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "flex-grow flex flex-col",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
          className: "mt-11 flex items-center self-end pt-2",
          onClick: () => _operations_appConfig__WEBPACK_IMPORTED_MODULE_8__["appConfigMutation"].toogleMenu(),
          children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h6", {
            className: "sub-h1 pr-1 menu-text text-accent ",
            children: "Close"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 75,
            columnNumber: 13
          }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_3__["Image"], {
            src: "/icons/menuClose.svg",
            className: "pl-2 laptop:mr-20 sm:mr-6 text-blue",
            alt: "close menu"
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 76,
            columnNumber: 13
          }, undefined)]
        }, void 0, true, {
          fileName: _jsxFileName,
          lineNumber: 74,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_content_contentList__WEBPACK_IMPORTED_MODULE_5__["ContentList"], {}, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 78,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_button_PrimaryButtonIconRight__WEBPACK_IMPORTED_MODULE_4__["default"], {
          title: "Visit " + "Blog Page",
          className: " sm:hidden menu-content-nav-button ml-20 mb-12 text-accent",
          url: "/icons/rightArrowGray.svg"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 79,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 73,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 60,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_sideNav__WEBPACK_IMPORTED_MODULE_2__["SideNav"], {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 82,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 59,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/modules/menu/sideNav.tsx":
/*!**************************************!*\
  !*** ./src/modules/menu/sideNav.tsx ***!
  \**************************************/
/*! exports provided: SideNav */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "SideNav", function() { return SideNav; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _constants__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../../../constants */ "./constants/index.ts");
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @components */ "./src/components/index.ts");
/* harmony import */ var _constants_socialMedia__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../constants/socialMedia */ "./constants/socialMedia.ts");
/* harmony import */ var _components_button_PrimaryButtonIconRight__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @components/button/PrimaryButtonIconRight */ "./src/components/button/PrimaryButtonIconRight.tsx");

var _jsxFileName = "C:\\Users\\KARTHIK\\Documents\\workspace\\matrix-cms-ui-development\\src\\modules\\menu\\sideNav.tsx";





const SideNav = () => {
  const [selectedIndex, setSelectedIndex] = react__WEBPACK_IMPORTED_MODULE_1___default.a.useState(0);

  const isSelected = index => {
    if (index == selectedIndex) return true;else return false;
  };

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: "side-nav z-30 absolute bg-accent-dark text-secondary  flex flex-col justify-between",
    style: {
      left: 0,
      fontSize: 54,
      lineHeight: "62px"
    },
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "block",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        children: _constants__WEBPACK_IMPORTED_MODULE_2__["navMenu"].primary.map((menuItem, index) => {
          return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_3__["NavItem"], {
            title: menuItem.name,
            className: !isSelected(index) ? " text-secondary-light opacity-50" : "text-secondary-light opacity-100",
            arrow: true,
            id: menuItem.key,
            onClick: () => setSelectedIndex(index),
            selected: isSelected(index)
          }, menuItem.key, false, {
            fileName: _jsxFileName,
            lineNumber: 24,
            columnNumber: 15
          }, undefined);
        })
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 21,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        children: _constants__WEBPACK_IMPORTED_MODULE_2__["navMenu"].secondary.map(menuItem => {
          return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
            className: "flex justify-between",
            style: {
              marginBottom: 21
            },
            children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h5", {
              className: "menu-secondary-nav-text",
              children: menuItem.name
            }, void 0, false, {
              fileName: _jsxFileName,
              lineNumber: 49,
              columnNumber: 17
            }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
              className: "menu-secondary-nav-icon",
              children: [" ", ">", " "]
            }, void 0, true, {
              fileName: _jsxFileName,
              lineNumber: 50,
              columnNumber: 17
            }, undefined)]
          }, menuItem.key, true, {
            fileName: _jsxFileName,
            lineNumber: 44,
            columnNumber: 15
          }, undefined);
        })
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 41,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 20,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: " mr-16",
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("span", {
        className: "ml-4",
        children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h6", {
          className: "mt-4 font-normal text-secondary",
          style: {
            fontSize: 28,
            lineHeight: "34px"
          },
          children: "Let's stay engaged "
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 58,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("h6", {
          className: "font-normal text-xs capitalize ",
          style: {
            marginTop: 10,
            lineHeight: "14px"
          },
          children: "SIGN UP FOR THE MATRIX MOMENTS SERIES"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 59,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("input", {
          className: "mt-2 text-secondary bg-accent w-full",
          style: {
            color: "#FBF9F5",
            marginTop: 15,
            fontSize: 15,
            lineHeight: "18px",
            opacity: 0.8,
            height: 38
          },
          type: "email",
          placeholder: "Your email address goes here"
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 62,
          columnNumber: 11
        }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_button_PrimaryButtonIconRight__WEBPACK_IMPORTED_MODULE_5__["default"], {
          title: "Subscribe",
          url: "/icons/arrow.svg",
          onClick: () => console.log("subscribe"),
          className: "text-lg leading-6",
          style: {
            color: "#0FB6B8"
          }
        }, void 0, false, {
          fileName: _jsxFileName,
          lineNumber: 68,
          columnNumber: 11
        }, undefined)]
      }, void 0, true, {
        fileName: _jsxFileName,
        lineNumber: 57,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "flex ",
        style: {
          marginTop: 60,
          marginBottom: 58
        },
        children: _constants_socialMedia__WEBPACK_IMPORTED_MODULE_4__["socialMedia"].map(item => {
          return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("a", {
            className: "p-1 mr-10",
            href: item.link,
            children: /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_3__["Image"], {
              src: item.imageUrl,
              alt: item.name,
              className: " "
            }, item.key, false, {
              fileName: _jsxFileName,
              lineNumber: 80,
              columnNumber: 17
            }, undefined)
          }, void 0, false, {
            fileName: _jsxFileName,
            lineNumber: 79,
            columnNumber: 15
          }, undefined);
        })
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 76,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 56,
      columnNumber: 7
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 16,
    columnNumber: 5
  }, undefined);
};

/***/ }),

/***/ "./src/modules/menu/tagList.tsx":
/*!**************************************!*\
  !*** ./src/modules/menu/tagList.tsx ***!
  \**************************************/
/*! exports provided: TagList */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "TagList", function() { return TagList; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @components */ "./src/components/index.ts");

var _jsxFileName = "C:\\Users\\KARTHIK\\Documents\\workspace\\matrix-cms-ui-development\\src\\modules\\menu\\tagList.tsx";


const TagList = ({
  title,
  tagList,
  onItemClick,
  className = ""
}) => {
  const [selected, setSelected] = react__WEBPACK_IMPORTED_MODULE_1___default.a.useState([]);

  const isSelected = id => {
    if (selected.indexOf(id) > -1) {
      return true;
    }

    return false;
  };

  const toggle = id => {
    if (isSelected(id) === true) {
      const index = selected.indexOf(id);
      setSelected(selected.splice(index + 1, 1));
    } else {
      setSelected([...selected, id]);
    }

    onItemClick(selected);
  };

  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
    className: `w-full ${className}`,
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: "font-light text-xs leading-3 tracking-wider p-2 text-accent-dark",
      children: title
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 35,
      columnNumber: 13
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: " flex flex-row flex-wrap text-primary-dark",
      children: tagList.map(tag => {
        return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components__WEBPACK_IMPORTED_MODULE_2__["Tag"], {
          id: title + tag.id,
          className: "ml-3 mb-3",
          title: tag.title,
          selected: isSelected(tag.id),
          onClick: () => {
            toggle(tag.id);
          }
        }, tag.id, false, {
          fileName: _jsxFileName,
          lineNumber: 39,
          columnNumber: 33
        }, undefined);
      })
    }, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 36,
      columnNumber: 13
    }, undefined)]
  }, void 0, true, {
    fileName: _jsxFileName,
    lineNumber: 34,
    columnNumber: 9
  }, undefined);
};

/***/ }),

/***/ "./src/modules/root/index.tsx":
/*!************************************!*\
  !*** ./src/modules/root/index.tsx ***!
  \************************************/
/*! exports provided: Root */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "Root", function() { return Root; });
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ "react/jsx-dev-runtime");
/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ "react");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _menu__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../menu */ "./src/modules/menu/index.tsx");
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @apollo/client */ "@apollo/client");
/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _operations_appConfig__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ../../../operations/appConfig */ "./operations/appConfig/index.ts");
/* harmony import */ var nprogress__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! nprogress */ "nprogress");
/* harmony import */ var nprogress__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(nprogress__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var nprogress_nprogress_css__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! nprogress/nprogress.css */ "./node_modules/nprogress/nprogress.css");
/* harmony import */ var nprogress_nprogress_css__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(nprogress_nprogress_css__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! next/router */ "next/router");
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _components_footer__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! @components/footer */ "./src/components/footer/index.tsx");
/* harmony import */ var _components_header__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! @components/header */ "./src/components/header/index.tsx");


var _jsxFileName = "C:\\Users\\KARTHIK\\Documents\\workspace\\matrix-cms-ui-development\\src\\modules\\root\\index.tsx";









const Root = ({
  children
}) => {
  const {
    data: {
      appConfig: navMenuState
    }
  } = Object(_apollo_client__WEBPACK_IMPORTED_MODULE_3__["useQuery"])(_operations_appConfig__WEBPACK_IMPORTED_MODULE_4__["appConfiqQuery"].GET_NAV_MENU_STATE);
  Object(react__WEBPACK_IMPORTED_MODULE_1__["useEffect"])(() => {
    next_router__WEBPACK_IMPORTED_MODULE_7___default.a.events.on("routeChangeStart", url => {
      nprogress__WEBPACK_IMPORTED_MODULE_5___default.a.start();
    });
    next_router__WEBPACK_IMPORTED_MODULE_7___default.a.events.on("routeChangeComplete", () => nprogress__WEBPACK_IMPORTED_MODULE_5___default.a.done());
    next_router__WEBPACK_IMPORTED_MODULE_7___default.a.events.on("routeChangeError", () => nprogress__WEBPACK_IMPORTED_MODULE_5___default.a.done());
    nprogress__WEBPACK_IMPORTED_MODULE_5___default.a.configure({
      showSpinner: false
    });
  }, []);
  const className = !navMenuState.menu ? "visible" : "invisible hidden ";
  return /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["Fragment"], {
    children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
      className: `flex flex-col flex-grow w-full h-full  ${className}`,
      children: [/*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_header__WEBPACK_IMPORTED_MODULE_9__["Header"], {
        toggle: _operations_appConfig__WEBPACK_IMPORTED_MODULE_4__["appConfigMutation"].toogleMenu
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 44,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])("div", {
        className: "flex-grow",
        children: children
      }, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 45,
        columnNumber: 9
      }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_components_footer__WEBPACK_IMPORTED_MODULE_8__["Footer"], {}, void 0, false, {
        fileName: _jsxFileName,
        lineNumber: 46,
        columnNumber: 9
      }, undefined)]
    }, void 0, true, {
      fileName: _jsxFileName,
      lineNumber: 43,
      columnNumber: 7
    }, undefined), /*#__PURE__*/Object(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__["jsxDEV"])(_menu__WEBPACK_IMPORTED_MODULE_2__["Menu"], {}, void 0, false, {
      fileName: _jsxFileName,
      lineNumber: 48,
      columnNumber: 7
    }, undefined)]
  }, void 0, true);
};

/***/ }),

/***/ "./src/styles/global.scss":
/*!********************************!*\
  !*** ./src/styles/global.scss ***!
  \********************************/
/*! no static exports found */
/***/ (function(module, exports) {



/***/ }),

/***/ "./utils/getContentTypeImageUrl.ts":
/*!*****************************************!*\
  !*** ./utils/getContentTypeImageUrl.ts ***!
  \*****************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = (function (type) {
  switch (type) {}

  return "/icons/video.svg";
});

/***/ }),

/***/ 0:
/*!*****************************************!*\
  !*** multi private-next-pages/_app.tsx ***!
  \*****************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

module.exports = __webpack_require__(/*! private-next-pages/_app.tsx */"./pages/_app.tsx");


/***/ }),

/***/ "@apollo/client":
/*!*********************************!*\
  !*** external "@apollo/client" ***!
  \*********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@apollo/client");

/***/ }),

/***/ "@apollo/client/link/context":
/*!**********************************************!*\
  !*** external "@apollo/client/link/context" ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("@apollo/client/link/context");

/***/ }),

/***/ "deepmerge":
/*!****************************!*\
  !*** external "deepmerge" ***!
  \****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("deepmerge");

/***/ }),

/***/ "mobile-detect":
/*!********************************!*\
  !*** external "mobile-detect" ***!
  \********************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("mobile-detect");

/***/ }),

/***/ "next/router":
/*!******************************!*\
  !*** external "next/router" ***!
  \******************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("next/router");

/***/ }),

/***/ "nprogress":
/*!****************************!*\
  !*** external "nprogress" ***!
  \****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("nprogress");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react");

/***/ }),

/***/ "react-slick":
/*!******************************!*\
  !*** external "react-slick" ***!
  \******************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react-slick");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = require("react/jsx-dev-runtime");

/***/ })

/******/ });
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vd2VicGFjay9ib290c3RyYXAiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwibmV4dC9kaXN0L25leHQtc2VydmVyL2xpYi9oZWFkLmpzXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwibmV4dC9kaXN0L25leHQtc2VydmVyL2xpYi90by1iYXNlLTY0LmpzXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwibmV4dC9kaXN0L25leHQtc2VydmVyL2xpYi91dGlscy5qc1wiIiwid2VicGFjazovLy9leHRlcm5hbCBcIm5leHQvZGlzdC9uZXh0LXNlcnZlci9zZXJ2ZXIvaW1hZ2UtY29uZmlnLmpzXCIiLCJ3ZWJwYWNrOi8vLy4vY29uc3RhbnRzL2Zvb3Rlck1lbnUudHMiLCJ3ZWJwYWNrOi8vLy4vY29uc3RhbnRzL2luZGV4LnRzIiwid2VicGFjazovLy8uL2NvbnN0YW50cy9uYXZNZW51LnRzIiwid2VicGFjazovLy8uL2NvbnN0YW50cy9zb2NpYWxNZWRpYS50cyIsIndlYnBhY2s6Ly8vLi9oZWxwZXIvYXBvbGxvLnRzeCIsIndlYnBhY2s6Ly8vLi9oZWxwZXIvdXNlRGV2aWNlVHlwZS50cyIsIndlYnBhY2s6Ly8vLi9tb2RlbHMvQXBwQ29uZmlnLnRzIiwid2VicGFjazovLy8uL25vZGVfbW9kdWxlcy9AYmFiZWwvcnVudGltZS9oZWxwZXJzL2V4dGVuZHMuanMiLCJ3ZWJwYWNrOi8vLy4vbm9kZV9tb2R1bGVzL0BiYWJlbC9ydW50aW1lL2hlbHBlcnMvaW50ZXJvcFJlcXVpcmVEZWZhdWx0LmpzIiwid2VicGFjazovLy8uL25vZGVfbW9kdWxlcy9AYmFiZWwvcnVudGltZS9oZWxwZXJzL29iamVjdFdpdGhvdXRQcm9wZXJ0aWVzTG9vc2UuanMiLCJ3ZWJwYWNrOi8vLy4vbm9kZV9tb2R1bGVzL25leHQvYXBwLmpzIiwid2VicGFjazovLy8uLi8uLi9jbGllbnQvaW1hZ2UudHN4Iiwid2VicGFjazovLy8uLi8uLi9jbGllbnQvcmVxdWVzdC1pZGxlLWNhbGxiYWNrLnRzIiwid2VicGFjazovLy8uLi8uLi9jbGllbnQvdXNlLWludGVyc2VjdGlvbi50c3giLCJ3ZWJwYWNrOi8vLy4uLy4uL3BhZ2VzL19hcHAudHN4Iiwid2VicGFjazovLy8uL25vZGVfbW9kdWxlcy9uZXh0L2ltYWdlLmpzIiwid2VicGFjazovLy8uL29wZXJhdGlvbnMvYXBwQ29uZmlnL2FwcENvbmZpZy5tdXRhdGlvbi50cyIsIndlYnBhY2s6Ly8vLi9vcGVyYXRpb25zL2FwcENvbmZpZy9hcHBDb25maWcucXVlcmllcy50cyIsIndlYnBhY2s6Ly8vLi9vcGVyYXRpb25zL2FwcENvbmZpZy9pbmRleC50cyIsIndlYnBhY2s6Ly8vLi9wYWdlcy9fYXBwLnRzeCIsIndlYnBhY2s6Ly8vLi9zcmMvY29tcG9uZW50cy9iYW5uZXIvaW5kZXgudHN4Iiwid2VicGFjazovLy8uL3NyYy9jb21wb25lbnRzL2J1dHRvbi9QcmltYXJ5QnV0dG9uSWNvblJpZ2h0LnRzeCIsIndlYnBhY2s6Ly8vLi9zcmMvY29tcG9uZW50cy9idXR0b24vU2Vjb25kYXJ5QnV0dG9uLnRzeCIsIndlYnBhY2s6Ly8vLi9zcmMvY29tcG9uZW50cy9idXR0b24vaW5kZXgudHN4Iiwid2VicGFjazovLy8uL3NyYy9jb21wb25lbnRzL2NhcmRzL2luZGV4LnRzeCIsIndlYnBhY2s6Ly8vLi9zcmMvY29tcG9uZW50cy9jb250YWluZXIvaW5kZXgudHN4Iiwid2VicGFjazovLy8uL3NyYy9jb21wb25lbnRzL2NvbnRlbnRJdGVtL2luZGV4LnRzeCIsIndlYnBhY2s6Ly8vLi9zcmMvY29tcG9uZW50cy9jb250ZW50U2xpZGVyL0NvbnRlbnRTbGlkZXIudHN4Iiwid2VicGFjazovLy8uL3NyYy9jb21wb25lbnRzL2Zvb3Rlci9mb290ZXJNZW51LnRzeCIsIndlYnBhY2s6Ly8vLi9zcmMvY29tcG9uZW50cy9mb290ZXIvaW5kZXgudHN4Iiwid2VicGFjazovLy8uL3NyYy9jb21wb25lbnRzL2ZvdW5kZXIvRm91bmRlci50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL2NvbXBvbmVudHMvZm91bmRlci9pbmRleC50cyIsIndlYnBhY2s6Ly8vLi9zcmMvY29tcG9uZW50cy9oZWFkZXIvaW5kZXgudHN4Iiwid2VicGFjazovLy8uL3NyYy9jb21wb25lbnRzL2ltYWdlL2luZGV4LnRzeCIsIndlYnBhY2s6Ly8vLi9zcmMvY29tcG9uZW50cy9pbmRleC50cyIsIndlYnBhY2s6Ly8vLi9zcmMvY29tcG9uZW50cy9sb2dvL2luZGV4LnRzeCIsIndlYnBhY2s6Ly8vLi9zcmMvY29tcG9uZW50cy9tYWluL2luZGV4LnRzeCIsIndlYnBhY2s6Ly8vLi9zcmMvY29tcG9uZW50cy9uYXZJdGVtL2luZGV4LnRzeCIsIndlYnBhY2s6Ly8vLi9zcmMvY29tcG9uZW50cy90YWcvaW5kZXgudHN4Iiwid2VicGFjazovLy8uL3NyYy9tb2R1bGVzL2NvbnRlbnQvY29udGVudExpc3QudHN4Iiwid2VicGFjazovLy8uL3NyYy9tb2R1bGVzL21lbnUvaW5kZXgudHN4Iiwid2VicGFjazovLy8uL3NyYy9tb2R1bGVzL21lbnUvc2lkZU5hdi50c3giLCJ3ZWJwYWNrOi8vLy4vc3JjL21vZHVsZXMvbWVudS90YWdMaXN0LnRzeCIsIndlYnBhY2s6Ly8vLi9zcmMvbW9kdWxlcy9yb290L2luZGV4LnRzeCIsIndlYnBhY2s6Ly8vLi91dGlscy9nZXRDb250ZW50VHlwZUltYWdlVXJsLnRzIiwid2VicGFjazovLy9leHRlcm5hbCBcIkBhcG9sbG8vY2xpZW50XCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwiQGFwb2xsby9jbGllbnQvbGluay9jb250ZXh0XCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwiZGVlcG1lcmdlXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwibW9iaWxlLWRldGVjdFwiIiwid2VicGFjazovLy9leHRlcm5hbCBcIm5leHQvcm91dGVyXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwibnByb2dyZXNzXCIiLCJ3ZWJwYWNrOi8vL2V4dGVybmFsIFwicmVhY3RcIiIsIndlYnBhY2s6Ly8vZXh0ZXJuYWwgXCJyZWFjdC1zbGlja1wiIiwid2VicGFjazovLy9leHRlcm5hbCBcInJlYWN0L2pzeC1kZXYtcnVudGltZVwiIl0sIm5hbWVzIjpbImZvb3Rlcm1lbnUiLCJrZXkiLCJuYW1lIiwibGluayIsIlBSSVZBQ1lfUE9MSUNZIiwibmF2TWVudSIsInByaW1hcnkiLCJzZWNvbmRhcnkiLCJzb2NpYWxNZWRpYSIsImltYWdlVXJsIiwiQVBPTExPX1NUQVRFX1BST1BFUlRZX05BTUUiLCJDT09LSUVTX1RPS0VOX05BTUUiLCJnZXRUb2tlbiIsInJlcSIsImFwb2xsb0NsaWVudCIsImNyZWF0ZUFwb2xsb0NsaWVudCIsImN0eCIsImh0dHBMaW5rIiwiSHR0cExpbmsiLCJ1cmkiLCJwcm9jZXNzIiwiZW52IiwiTkVYVF9QVUJMSUNfR1JBUEhRTF9VUkkiLCJjcmVkZW50aWFscyIsImF1dGhMaW5rIiwic2V0Q29udGV4dCIsIl8iLCJoZWFkZXJzIiwidG9rZW4iLCJhdXRob3JpemF0aW9uIiwiQXBvbGxvQ2xpZW50Iiwic3NyTW9kZSIsImNvbmNhdCIsImNhY2hlIiwiSW5NZW1vcnlDYWNoZSIsInR5cGVQb2xpY2llcyIsIlF1ZXJ5IiwiZmllbGRzIiwiYXBwQ29uZmlnIiwicmVhZCIsImFwcENvbmZpZ1ZhciIsImluaXRpYWxpemVBcG9sbG8iLCJpbml0aWFsU3RhdGUiLCJjbGllbnQiLCJleGlzdGluZ0NhY2hlIiwiZXh0cmFjdCIsImRhdGEiLCJtZXJnZSIsInJlc3RvcmUiLCJhZGRBcG9sbG9TdGF0ZSIsInBhZ2VQcm9wcyIsInByb3BzIiwidXNlQXBvbGxvIiwic3RhdGUiLCJzdG9yZSIsInVzZU1lbW8iLCJ1c2VEZXZpY2VUeXBlIiwidXNlckFnZW50IiwibWQiLCJNb2JpbGVEZXRlY3QiLCJtb2JpbGUiLCJ0YWJsZXQiLCJkZXNrdG9wIiwiaW50aWFsQXBwY29uZmlnIiwibWVudSIsIm5hdk1lbnVTZWxlY3RlZCIsIm1ha2VWYXIiLCJnbG9iYWwiLCJWQUxJRF9MT0FESU5HX1ZBTFVFUyIsImxvYWRlcnMiLCJWQUxJRF9MQVlPVVRfVkFMVUVTIiwiZGV2aWNlU2l6ZXMiLCJpbWFnZVNpemVzIiwibG9hZGVyIiwicGF0aCIsImRvbWFpbnMiLCJpbWFnZUNvbmZpZ0RlZmF1bHQiLCJhbGxTaXplcyIsImNvbmZpZ0RldmljZVNpemVzIiwiYSIsInNpemVzIiwibGF5b3V0IiwicGVyY2VudFNpemVzIiwibSIsInBhcnNlSW50Iiwic21hbGxlc3RSYXRpbyIsIk1hdGgiLCJ3aWR0aHMiLCJzIiwia2luZCIsIndpZHRoIiwidyIsInAiLCJzcmNTZXQiLCJnZXRXaWR0aHMiLCJsYXN0IiwiaSIsInNyYyIsImxvYWQiLCJyb290IiwiVkFMSURfTE9BREVSUyIsImNvbmZpZ0xvYWRlciIsInVub3B0aW1pemVkIiwicHJpb3JpdHkiLCJhbGwiLCJyZXN0IiwidW5zaXplZCIsIkJvb2xlYW4iLCJKU09OIiwibG9hZGluZyIsImlzTGF6eSIsInJvb3RNYXJnaW4iLCJkaXNhYmxlZCIsImlzVmlzaWJsZSIsIndpZHRoSW50IiwiZ2V0SW50IiwiaGVpZ2h0SW50IiwicXVhbGl0eUludCIsImltZ1N0eWxlIiwicG9zaXRpb24iLCJ0b3AiLCJsZWZ0IiwiYm90dG9tIiwicmlnaHQiLCJib3hTaXppbmciLCJwYWRkaW5nIiwiYm9yZGVyIiwibWFyZ2luIiwiZGlzcGxheSIsImhlaWdodCIsIm1pbldpZHRoIiwibWF4V2lkdGgiLCJtaW5IZWlnaHQiLCJtYXhIZWlnaHQiLCJxdW90aWVudCIsInBhZGRpbmdUb3AiLCJpc05hTiIsIndyYXBwZXJTdHlsZSIsIm92ZXJmbG93Iiwic2l6ZXJTdHlsZSIsInNpemVyU3ZnIiwiaW1nQXR0cmlidXRlcyIsImdlbmVyYXRlSW1nQXR0cnMiLCJxdWFsaXR5IiwicGFyYW1zIiwicGFyYW1zU3RyaW5nIiwibm9ybWFsaXplU3JjIiwibWlzc2luZ1ZhbHVlcyIsInBhcnNlZFNyYyIsImNvbnNvbGUiLCJjb25maWdEb21haW5zIiwiaG9zdG5hbWUiLCJlbmNvZGVVUklDb21wb25lbnQiLCJyZXF1ZXN0SWRsZUNhbGxiYWNrIiwic2VsZiIsInN0YXJ0IiwiRGF0ZSIsInNldFRpbWVvdXQiLCJjYiIsImRpZFRpbWVvdXQiLCJ0aW1lUmVtYWluaW5nIiwiY2FuY2VsSWRsZUNhbGxiYWNrIiwiY2xlYXJUaW1lb3V0IiwiaGFzSW50ZXJzZWN0aW9uT2JzZXJ2ZXIiLCJpc0Rpc2FibGVkIiwidW5vYnNlcnZlIiwic2V0UmVmIiwiZWwiLCJvYnNlcnZlIiwic2V0VmlzaWJsZSIsImlkbGVDYWxsYmFjayIsImNyZWF0ZU9ic2VydmVyIiwiZWxlbWVudHMiLCJvYnNlcnZlciIsIm9ic2VydmVycyIsImlkIiwib3B0aW9ucyIsImluc3RhbmNlIiwiZW50cmllcyIsImVudHJ5IiwiY2FsbGJhY2siLCJSZWFjdCIsIkNvbXBvbmVudCIsImNvbXBvbmVudERpZENhdGNoIiwicmVuZGVyIiwiX19OX1NTRyIsInVybCIsImNyZWF0ZVVybCIsIkFwcCIsIm9yaWdHZXRJbml0aWFsUHJvcHMiLCJhcHBHZXRJbml0aWFsUHJvcHMiLCJnZXRJbml0aWFsUHJvcHMiLCJ3YXJuQ29udGFpbmVyIiwid2FyblVybCIsImJhY2siLCJyb3V0ZXIiLCJwdXNoIiwicHVzaFRvIiwicHVzaFJvdXRlIiwiYXMiLCJwdXNoVXJsIiwicmVwbGFjZSIsInJlcGxhY2VUbyIsInJlcGxhY2VSb3V0ZSIsInJlcGxhY2VVcmwiLCJ0b29nbGVNZW51IiwiX2FwcENvbmZpZyIsInNldFNlbGVjdGVkTmF2TWVudSIsIm5hdk1lbnVJZCIsImFwcENvbmZpZ011dGF0aW9ucyIsIkdFVF9OQVZfTUVOVV9TVEFURSIsImdxbCIsImFwcENvbmZpcVF1ZXJ5IiwiRXh0ZW5kZWRBcHAiLCJkZXZpY2VUeXBlIiwiYXBwQ29udGV4dCIsImFwcFByb3BzIiwicXVlcnkiLCJuYXZpZ2F0b3IiLCJCYW5uZXIiLCJ0aXRsZSIsInN1YlRpdGxlIiwiYmFubmVySW1nIiwibW9iaWxlQmFubmVySW1nIiwiYmFja2dyb3VuZEltYWdlIiwiQnV0dG9uIiwib25DbGljayIsImNsYXNzTmFtZSIsInN0eWxlIiwiU2Vjb25kYXJ5QnV0dG9uIiwiY2hpbGRyZW4iLCJDYXJkcyIsInBsdWdpbnMiLCJtYXAiLCJwbHVnaW4iLCJkZXNjcmlwdGlvbiIsIkNvbnRhaW5lciIsIkNvbnRlbnRJdGVtIiwiaW1hZ2VfdXJsIiwiYXV0aG9yIiwiY29udGVudF9pZCIsImNvbnRlbnRfdHlwZSIsInJlYWRfZHVyYXRpb24iLCJnZXRDb250ZW50VHlwZUltYWdlVXJsIiwiQ29udGVudFNsaWRlciIsImNvbnRlbnRMaXN0IiwiaGVhZGVyIiwiY29udGVudEl0ZW0iLCJsb2ciLCJGb290ZXJNZW51IiwiaXRlbSIsImluZGV4IiwiRm9vdGVyIiwiY29sb3IiLCJGb3VuZGVyIiwiaGVyb3MiLCJmaXJzdE5hbWUiLCJsYXN0TmFtZSIsImZpcnN0TmFtZTEiLCJsYXN0TmFtZTEiLCJjYXB0aW9uIiwiY2FwdGlvbjEiLCJsb2dvIiwiaW1hZ2UiLCJoZWFkaW5nIiwic2V0dGluZ3MiLCJkb3RzIiwiaW5maW5pdGUiLCJzcGVlZCIsImF1dG9wbGF5U3BlZWQiLCJzbGlkZXNUb1Nob3ciLCJzbGlkZXNUb1Njcm9sbCIsImhlcm8iLCJiYWNrZ3JvdW5kIiwiZmxleERpcmVjdGlvbiIsImZsZXhHcm93IiwiYm9yZGVyQm90dG9tIiwiZm9udFNpemUiLCJsaW5lSGVpZ2h0IiwibGV0dGVyU3BhY2luZyIsIm1hcmdpbkxlZnQiLCJtYXJnaW5SaWdodCIsImp1c3RpZnlDb250ZW50IiwidHJhbnNmb3JtIiwicGFkZGluZ0xlZnQiLCJIZWFkZXIiLCJ0b2dnbGUiLCJJbWFnZSIsImFsdCIsIkxvZ28iLCJNYWluIiwiTmF2SXRlbSIsInNlbGVjdGVkIiwiYXJyb3ciLCJtYXJnaW5Cb3R0b20iLCJUYWciLCJfY2xhc3NOYW1lIiwiQ29udGVudExpc3QiLCJ0YWdMaXN0IiwiTWVudSIsIm5hdk1lbnVTdGF0ZSIsInVzZVF1ZXJ5IiwiaXRlbXMiLCJhcHBDb25maWdNdXRhdGlvbiIsIlNpZGVOYXYiLCJzZWxlY3RlZEluZGV4Iiwic2V0U2VsZWN0ZWRJbmRleCIsInVzZVN0YXRlIiwiaXNTZWxlY3RlZCIsIm1lbnVJdGVtIiwibWFyZ2luVG9wIiwib3BhY2l0eSIsIlRhZ0xpc3QiLCJvbkl0ZW1DbGljayIsInNldFNlbGVjdGVkIiwiaW5kZXhPZiIsInNwbGljZSIsInRhZyIsIlJvb3QiLCJ1c2VFZmZlY3QiLCJSb3V0ZXIiLCJldmVudHMiLCJvbiIsIk5Qcm9ncmVzcyIsImRvbmUiLCJjb25maWd1cmUiLCJzaG93U3Bpbm5lciIsInR5cGUiXSwibWFwcGluZ3MiOiI7O1FBQUE7UUFDQTs7UUFFQTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQSxJQUFJO1FBQ0o7UUFDQTs7UUFFQTtRQUNBOztRQUVBO1FBQ0E7UUFDQTs7O1FBR0E7UUFDQTs7UUFFQTtRQUNBOztRQUVBO1FBQ0E7UUFDQTtRQUNBLDBDQUEwQyxnQ0FBZ0M7UUFDMUU7UUFDQTs7UUFFQTtRQUNBO1FBQ0E7UUFDQSx3REFBd0Qsa0JBQWtCO1FBQzFFO1FBQ0EsaURBQWlELGNBQWM7UUFDL0Q7O1FBRUE7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBO1FBQ0E7UUFDQTtRQUNBLHlDQUF5QyxpQ0FBaUM7UUFDMUUsZ0hBQWdILG1CQUFtQixFQUFFO1FBQ3JJO1FBQ0E7O1FBRUE7UUFDQTtRQUNBO1FBQ0EsMkJBQTJCLDBCQUEwQixFQUFFO1FBQ3ZELGlDQUFpQyxlQUFlO1FBQ2hEO1FBQ0E7UUFDQTs7UUFFQTtRQUNBLHNEQUFzRCwrREFBK0Q7O1FBRXJIO1FBQ0E7OztRQUdBO1FBQ0E7Ozs7Ozs7Ozs7OztBQ3hGQSw4RDs7Ozs7Ozs7Ozs7QUNBQSxvRTs7Ozs7Ozs7Ozs7QUNBQSwrRDs7Ozs7Ozs7Ozs7QUNBQSx5RTs7Ozs7Ozs7Ozs7O0FDQUE7QUFBQSxNQUFNQSxVQUFVLEdBQUcsQ0FDakI7QUFDRUMsS0FBRyxFQUFFLGNBRFA7QUFFRUMsTUFBSSxFQUFFLE9BRlI7QUFHRUMsTUFBSSxFQUFFO0FBSFIsQ0FEaUIsRUFNakI7QUFDRUYsS0FBRyxFQUFFLGtCQURQO0FBRUVDLE1BQUksRUFBRSxXQUZSO0FBR0VDLE1BQUksRUFBRTtBQUhSLENBTmlCLEVBV2pCO0FBQ0VGLEtBQUcsRUFBRSxhQURQO0FBRUVDLE1BQUksRUFBRSxNQUZSO0FBR0VDLE1BQUksRUFBRTtBQUhSLENBWGlCLEVBZ0JqQjtBQUNFRixLQUFHLEVBQUUsc0JBRFA7QUFFRUMsTUFBSSxFQUFFLGVBRlI7QUFHRUMsTUFBSSxFQUFFO0FBSFIsQ0FoQmlCLEVBcUJqQjtBQUNFRixLQUFHLEVBQUUsZ0JBRFA7QUFFRUMsTUFBSSxFQUFFLFNBRlI7QUFHRUMsTUFBSSxFQUFFO0FBSFIsQ0FyQmlCLEVBMEJqQjtBQUNFRixLQUFHLEVBQUUsZ0JBRFA7QUFFRUMsTUFBSSxFQUFFLFNBRlI7QUFHRUMsTUFBSSxFQUFFO0FBSFIsQ0ExQmlCLENBQW5CO0FBaUNlSCx5RUFBZixFOzs7Ozs7Ozs7Ozs7QUNqQ0E7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUNPLE1BQU1JLGNBQWMsR0FBRywrQkFBdkIsQzs7Ozs7Ozs7Ozs7O0FDRlA7QUFBQTtBQUFPLE1BQU1DLE9BQU8sR0FBRztBQUNyQkMsU0FBTyxFQUFFLENBQ1A7QUFDRUwsT0FBRyxFQUFFLGNBRFA7QUFFRUMsUUFBSSxFQUFFLE9BRlI7QUFHRUMsUUFBSSxFQUFFO0FBSFIsR0FETyxFQU1QO0FBQ0VGLE9BQUcsRUFBRSxrQkFEUDtBQUVFQyxRQUFJLEVBQUUsV0FGUjtBQUdFQyxRQUFJLEVBQUU7QUFIUixHQU5PLEVBV1A7QUFDRUYsT0FBRyxFQUFFLGFBRFA7QUFFRUMsUUFBSSxFQUFFLE1BRlI7QUFHRUMsUUFBSSxFQUFFO0FBSFIsR0FYTyxDQURZO0FBa0JyQkksV0FBUyxFQUFFLENBQ1Q7QUFDRU4sT0FBRyxFQUFFLHNCQURQO0FBRUVDLFFBQUksRUFBRSxlQUZSO0FBR0VDLFFBQUksRUFBRTtBQUhSLEdBRFMsRUFNVDtBQUNFRixPQUFHLEVBQUUsZ0JBRFA7QUFFRUMsUUFBSSxFQUFFLFNBRlI7QUFHRUMsUUFBSSxFQUFFO0FBSFIsR0FOUyxFQVdUO0FBQ0VGLE9BQUcsRUFBRSxnQkFEUDtBQUVFQyxRQUFJLEVBQUUsU0FGUjtBQUdFQyxRQUFJLEVBQUU7QUFIUixHQVhTO0FBbEJVLENBQWhCO0FBcUNRRSxzRUFBZixFOzs7Ozs7Ozs7Ozs7QUNyQ0E7QUFBQTtBQUFPLE1BQU1HLFdBQVcsR0FBRyxDQUN6QjtBQUNFTixNQUFJLEVBQUUsVUFEUjtBQUVFQyxNQUFJLEVBQUUsRUFGUjtBQUdFRixLQUFHLEVBQUUsVUFIUDtBQUlFUSxVQUFRLEVBQUU7QUFKWixDQUR5QixFQU96QjtBQUNFUCxNQUFJLEVBQUUsU0FEUjtBQUVFQyxNQUFJLEVBQUUsRUFGUjtBQUdFRixLQUFHLEVBQUUsU0FIUDtBQUlFUSxVQUFRLEVBQUU7QUFKWixDQVB5QixDQUFwQixDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNBUDtBQUNBO0FBR0E7QUFDQTtBQUNBO0FBTU8sTUFBTUMsMEJBQTBCLEdBQUcsa0JBQW5DO0FBQ0EsTUFBTUMsa0JBQWtCLEdBQUcsS0FBM0I7O0FBRVAsTUFBTUMsUUFBUSxHQUFJQyxHQUFELElBQTJCO0FBQzFDLFNBQU8sRUFBUCxDQUQwQyxDQUMvQjtBQUNaLENBRkQ7O0FBSUEsSUFBSUMsWUFBaUQsR0FBRyxJQUF4RDs7QUFFQSxNQUFNQyxrQkFBa0IsR0FBSUMsR0FBRCxJQUFxQztBQUM5RCxRQUFNQyxRQUFRLEdBQUcsSUFBSUMsdURBQUosQ0FBYTtBQUM1QkMsT0FBRyxFQUFFQyxPQUFPLENBQUNDLEdBQVIsQ0FBWUMsdUJBRFc7QUFFNUJDLGVBQVcsRUFBRTtBQUZlLEdBQWIsQ0FBakI7QUFLQSxRQUFNQyxRQUFRLEdBQUdDLDhFQUFVLENBQUMsQ0FBQ0MsQ0FBRCxFQUFJO0FBQUVDO0FBQUYsR0FBSixLQUFvQjtBQUM5QztBQUNBLFVBQU1DLEtBQUssR0FBR2hCLFFBQVEsQ0FBQ0ksR0FBRCxhQUFDQSxHQUFELHVCQUFDQSxHQUFHLENBQUVILEdBQU4sQ0FBdEI7QUFFQSxXQUFPO0FBQ0xjLGFBQU8sa0NBQ0ZBLE9BREU7QUFFTEUscUJBQWEsRUFBRUQsS0FBSyxHQUFJLFVBQVNBLEtBQU0sRUFBbkIsR0FBdUI7QUFGdEM7QUFERixLQUFQO0FBTUQsR0FWMEIsQ0FBM0I7QUFZQSxTQUFPLElBQUlFLDJEQUFKLENBQWlCO0FBQ3RCQyxXQUFPLE1BRGU7QUFFdEI1QixRQUFJLEVBQUVxQixRQUFRLENBQUNRLE1BQVQsQ0FBZ0JmLFFBQWhCLENBRmdCO0FBR3RCZ0IsU0FBSyxFQUFFLElBQUlDLDREQUFKLENBQWtCO0FBQ3ZCQyxrQkFBWSxFQUFFO0FBQ1pDLGFBQUssRUFBRTtBQUNMQyxnQkFBTSxFQUFFO0FBQ05DLHFCQUFTLEVBQUU7QUFDVEMsa0JBQUksR0FBRztBQUNMLHVCQUFPQyxzRUFBWSxFQUFuQjtBQUNEOztBQUhRO0FBREw7QUFESDtBQURLO0FBRFMsS0FBbEI7QUFIZSxHQUFqQixDQUFQO0FBa0JELENBcENEOztBQXNDTyxTQUFTQyxnQkFBVCxDQUEwQkMsWUFBWSxHQUFHLElBQXpDLEVBQStDMUIsR0FBRyxHQUFHLElBQXJELEVBQTJEO0FBQUE7O0FBQ2hFLFFBQU0yQixNQUFNLG9CQUFHN0IsWUFBSCx5REFBbUJDLGtCQUFrQixDQUFDQyxHQUFELENBQWpELENBRGdFLENBR2hFO0FBQ0E7O0FBQ0EsTUFBSTBCLFlBQUosRUFBa0I7QUFDaEI7QUFDQSxVQUFNRSxhQUFhLEdBQUdELE1BQU0sQ0FBQ0UsT0FBUCxFQUF0QixDQUZnQixDQUloQjtBQUNBOztBQUNBLFVBQU1DLElBQUksR0FBR0MsZ0RBQUssQ0FBQ0wsWUFBRCxFQUFlRSxhQUFmLENBQWxCLENBTmdCLENBUWhCOztBQUNBRCxVQUFNLENBQUNWLEtBQVAsQ0FBYWUsT0FBYixDQUFxQkYsSUFBckI7QUFDRCxHQWYrRCxDQWlCaEU7OztBQUNBLFlBQW1DO0FBQ2pDLFdBQU9ILE1BQVA7QUFDRCxHQXBCK0QsQ0FzQmhFOzs7QUFDQSxNQUFJLENBQUM3QixZQUFMLEVBQW1CO0FBQ2pCQSxnQkFBWSxHQUFHNkIsTUFBZjtBQUNEOztBQUVELFNBQU9BLE1BQVA7QUFDRDtBQUVNLFNBQVNNLGNBQVQsQ0FDTE4sTUFESyxFQUVMTyxTQUZLLEVBR0w7QUFDQSxNQUFJQSxTQUFKLGFBQUlBLFNBQUosZUFBSUEsU0FBUyxDQUFFQyxLQUFmLEVBQXNCO0FBQ3BCRCxhQUFTLENBQUNDLEtBQVYsQ0FBZ0J6QywwQkFBaEIsSUFBOENpQyxNQUFNLENBQUNWLEtBQVAsQ0FBYVksT0FBYixFQUE5QztBQUNEOztBQUVELFNBQU9LLFNBQVA7QUFDRDtBQUVNLFNBQVNFLFNBQVQsQ0FBbUJGLFNBQW5CLEVBQXlDO0FBQzlDLFFBQU1HLEtBQUssR0FBR0gsU0FBUyxDQUFDeEMsMEJBQUQsQ0FBdkI7QUFDQSxRQUFNNEMsS0FBSyxHQUFHQyxxREFBTyxDQUFDLE1BQU1kLGdCQUFnQixDQUFDWSxLQUFELENBQXZCLEVBQWdDLENBQUNBLEtBQUQsQ0FBaEMsQ0FBckI7QUFFQSxTQUFPQyxLQUFQO0FBQ0QsQzs7Ozs7Ozs7Ozs7O0FDekdEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFFTyxTQUFTRSxhQUFULENBQXVCQyxTQUF2QixFQUFrQztBQUN2QyxRQUFNQyxFQUFFLEdBQUcsSUFBSUMsb0RBQUosQ0FBaUJGLFNBQWpCLENBQVg7QUFDQSxNQUFJRyxNQUFNLEdBQUcsS0FBYjtBQUFBLE1BQ0VDLE1BQU0sR0FBRyxLQURYO0FBQUEsTUFFRUMsT0FBTyxHQUFHLEtBRlo7O0FBR0EsTUFBSUosRUFBRSxDQUFDRyxNQUFILEVBQUosRUFBaUI7QUFDZkEsVUFBTSxHQUFHLElBQVQ7QUFDRCxHQUZELE1BRU8sSUFBSUgsRUFBRSxDQUFDRSxNQUFILEVBQUosRUFBaUI7QUFDdEJBLFVBQU0sR0FBRyxJQUFUO0FBQ0QsR0FGTSxNQUVBO0FBQ0xFLFdBQU8sR0FBRyxJQUFWO0FBQ0Q7O0FBQ0QsU0FBTztBQUNMRixVQURLO0FBRUxDLFVBRks7QUFHTEM7QUFISyxHQUFQO0FBS0QsQzs7Ozs7Ozs7Ozs7O0FDbkJEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFPQSxNQUFNQyxlQUEwQixHQUFHO0FBQ2pDQyxNQUFJLEVBQUUsS0FEMkI7QUFFakNDLGlCQUFlLEVBQUU7QUFGZ0IsQ0FBbkM7QUFLTyxNQUFNekIsWUFBb0MsR0FBRzBCLDhEQUFPLENBQ3pESCxlQUR5RCxDQUFwRCxDOzs7Ozs7Ozs7OztBQ1pQO0FBQ0E7QUFDQSxtQkFBbUIsc0JBQXNCO0FBQ3pDOztBQUVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBO0FBQ0E7O0FBRUEsMEI7Ozs7Ozs7Ozs7O0FDbEJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsd0M7Ozs7Ozs7Ozs7O0FDTkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxhQUFhLHVCQUF1QjtBQUNwQztBQUNBO0FBQ0E7QUFDQTs7QUFFQTtBQUNBOztBQUVBLCtDOzs7Ozs7Ozs7OztBQ2ZBLGlCQUFpQixtQkFBTyxDQUFDLGlFQUFtQjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDQTVDOztBQUNBOztBQUNBOztBQUNBOztBQU1BOztBQUVBLFVBQW1DO0FBQ2pDO0FBQUVJLFFBQUQsc0JBQUNBLEdBQUQsSUFBQ0E7QUFHSjs7QUFBQSxNQUFNQyxvQkFBb0IsR0FBRyxrQkFBN0IsU0FBNkIsQ0FBN0I7QUFhQSxNQUFNQyxPQUFPLEdBQUcsUUFHZCxDQUNBLFVBREEsV0FDQSxDQURBLEVBRUEsZUFGQSxnQkFFQSxDQUZBLEVBR0EsV0FIQSxZQUdBLENBSEEsRUFJQSxZQVBGLGFBT0UsQ0FKQSxDQUhjLENBQWhCO0FBVUEsTUFBTUMsbUJBQW1CLEdBQUcsNkNBQTVCLFNBQTRCLENBQTVCO0FBc0NBLE1BQU07QUFDSkMsYUFBVyxFQURQO0FBRUpDLFlBQVUsRUFGTjtBQUdKQyxRQUFNLEVBSEY7QUFJSkMsTUFBSSxFQUpBO0FBS0pDLFNBQU8sRUFMSDtBQUFBLElBT0Z2RCwwSkFBeUR3RCxhQVA3RCxtQixDQVFBOztBQUNBLE1BQU1DLFFBQVEsR0FBRyxDQUFDLEdBQUQsbUJBQXVCLEdBQXhDLGdCQUFpQixDQUFqQjtBQUNBQyxpQkFBaUIsQ0FBakJBLEtBQXVCLFVBQVVDLENBQUMsR0FBbENEO0FBQ0FELFFBQVEsQ0FBUkEsS0FBYyxVQUFVRSxDQUFDLEdBQXpCRjs7QUFFQSx5Q0FJeUM7QUFDdkMsTUFBSUcsS0FBSyxLQUFLQyxNQUFNLEtBQU5BLFVBQXFCQSxNQUFNLEtBQXpDLFlBQVMsQ0FBVCxFQUE2RDtBQUMzRDtBQUNBLFVBQU1DLFlBQVksR0FBRyxDQUFDLEdBQUdGLEtBQUssQ0FBTEEsU0FBSixvQkFBSUEsQ0FBSixNQUErQ0csQ0FBRCxJQUNqRUMsUUFBUSxDQUFDRCxDQUFDLENBRFosQ0FDWSxDQUFGLENBRFcsQ0FBckI7O0FBR0EsUUFBSUQsWUFBWSxDQUFoQixRQUF5QjtBQUN2QixZQUFNRyxhQUFhLEdBQUdDLElBQUksQ0FBSkEsSUFBUyxHQUFUQSxnQkFBdEI7QUFDQSxhQUFPO0FBQ0xDLGNBQU0sRUFBRVYsUUFBUSxDQUFSQSxPQUNMVyxDQUFELElBQU9BLENBQUMsSUFBSVYsaUJBQWlCLENBQWpCQSxDQUFpQixDQUFqQkEsR0FGVCxhQUNHRCxDQURIO0FBSUxZLFlBQUksRUFKTjtBQUFPLE9BQVA7QUFPRjs7QUFBQSxXQUFPO0FBQUVGLFlBQU0sRUFBUjtBQUFvQkUsVUFBSSxFQUEvQjtBQUFPLEtBQVA7QUFFRjs7QUFBQSxNQUNFLDZCQUNBUixNQUFNLEtBRE4sVUFFQUEsTUFBTSxLQUhSLGNBSUU7QUFDQSxXQUFPO0FBQUVNLFlBQU0sRUFBUjtBQUE2QkUsVUFBSSxFQUF4QztBQUFPLEtBQVA7QUFHRjs7QUFBQSxRQUFNRixNQUFNLEdBQUcsQ0FDYixHQUFHLFNBQ0Q7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLFVBQVFHLEtBQUssR0FBRztBQUFoQjtBQUFBLFFBQ0dDLENBQUQsSUFBT2QsUUFBUSxDQUFSQSxLQUFlZSxDQUFELElBQU9BLENBQUMsSUFBdEJmLE1BQWdDQSxRQUFRLENBQUNBLFFBQVEsQ0FBUkEsU0FYdEQsQ0FXcUQsQ0FEakQsQ0FUQyxDQURVLENBQWY7QUFlQSxTQUFPO0FBQUE7QUFBVVksUUFBSSxFQUFyQjtBQUFPLEdBQVA7QUFtQkY7O0FBQUEsMEJBQTBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQTFCO0FBQTBCLENBQTFCLEVBUXVDO0FBQ3JDLG1CQUFpQjtBQUNmLFdBQU87QUFBQTtBQUFPSSxZQUFNLEVBQWI7QUFBMEJiLFdBQUssRUFBdEM7QUFBTyxLQUFQO0FBR0Y7O0FBQUEsUUFBTTtBQUFBO0FBQUE7QUFBQSxNQUFtQmMsU0FBUyxnQkFBbEMsS0FBa0MsQ0FBbEM7QUFDQSxRQUFNQyxJQUFJLEdBQUdSLE1BQU0sQ0FBTkEsU0FBYjtBQUVBLFNBQU87QUFDTFAsU0FBSyxFQUFFLFVBQVVTLElBQUksS0FBZCxnQkFERjtBQUVMSSxVQUFNLEVBQUVOLE1BQU0sQ0FBTkEsSUFFSixVQUNHLEdBQUVkLE1BQU0sQ0FBQztBQUFBO0FBQUE7QUFBZ0JpQixXQUFLLEVBQXRCO0FBQUMsS0FBRCxDQUE2QixJQUNwQ0QsSUFBSSxLQUFKQSxVQUFtQk8sQ0FBQyxHQUFHLENBQ3hCLEdBQUVQLElBTERGLFNBRkgsSUFFR0EsQ0FGSDtBQVdMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBVSxPQUFHLEVBQUV4QixNQUFNLENBQUM7QUFBQTtBQUFBO0FBQWdCaUIsV0FBSyxFQUFFSCxNQUFNLENBakIzQyxJQWlCMkM7QUFBN0IsS0FBRDtBQWpCTixHQUFQO0FBcUJGOztBQUFBLG1CQUFnRDtBQUM5QyxNQUFJLGFBQUosVUFBMkI7QUFDekI7QUFFRjs7QUFBQSxNQUFJLGFBQUosVUFBMkI7QUFDekIsV0FBT0gsUUFBUSxJQUFmLEVBQWUsQ0FBZjtBQUVGOztBQUFBO0FBR0Y7O0FBQUEseUNBQTJEO0FBQ3pELFFBQU1jLElBQUksR0FBRzdCLE9BQU8sQ0FBUEEsSUFBYixZQUFhQSxDQUFiOztBQUNBLFlBQVU7QUFDUixXQUFPNkIsSUFBSTtBQUFHQyxVQUFJLEVBQVA7QUFBQSxPQUFYLFdBQVcsRUFBWDtBQUVGOztBQUFBLFFBQU0sVUFDSCx5REFBd0RDLHFDQUV2RCxlQUFjQyxZQUhsQixFQUFNLENBQU47QUFPYTs7QUFBQSxxQkFjQTtBQUFBLE1BZGU7QUFBQTtBQUFBO0FBRzVCQyxlQUFXLEdBSGlCO0FBSTVCQyxZQUFRLEdBSm9CO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFZNUI5QixVQUFNLEdBWnNCO0FBQUEsTUFjZjtBQUFBLE1BRFYrQixHQUNVO0FBQ2IsTUFBSUMsSUFBeUIsR0FBN0I7QUFDQSxNQUFJeEIsTUFBZ0MsR0FBR0QsS0FBSyxrQkFBNUM7QUFDQSxNQUFJMEIsT0FBTyxHQUFYOztBQUNBLE1BQUksYUFBSixNQUF1QjtBQUNyQkEsV0FBTyxHQUFHQyxPQUFPLENBQUNGLElBQUksQ0FBdEJDLE9BQWlCLENBQWpCQSxDQURxQixDQUVyQjs7QUFDQSxXQUFPRCxJQUFJLENBQVgsU0FBVyxDQUFYO0FBSEYsU0FJTyxJQUFJLFlBQUosTUFBc0I7QUFDM0I7QUFDQSxRQUFJQSxJQUFJLENBQVIsUUFBaUJ4QixNQUFNLEdBQUd3QixJQUFJLENBQWJ4QixPQUZVLENBSTNCOztBQUNBLFdBQU93QixJQUFJLENBQVgsUUFBVyxDQUFYO0FBR0Y7O0FBQUEsWUFBMkM7QUFDekMsUUFBSSxDQUFKLEtBQVU7QUFDUixZQUFNLFVBQ0gsMEhBQXlIRyxJQUFJLENBQUpBLFVBQ3hIO0FBQUE7QUFBQTtBQUR3SEE7QUFDeEgsT0FEd0hBLENBRDVILEVBQU0sQ0FBTjtBQU1GOztBQUFBLFFBQUksQ0FBQ3RDLG1CQUFtQixDQUFuQkEsU0FBTCxNQUFLQSxDQUFMLEVBQTJDO0FBQ3pDLFlBQU0sVUFDSCxtQkFBa0IyQixHQUFJLDhDQUE2Q2hCLE1BQU8sc0JBQXFCWCxtQkFBbUIsQ0FBbkJBLHFCQURsRyxHQUFNLENBQU47QUFNRjs7QUFBQSxRQUFJLENBQUNGLG9CQUFvQixDQUFwQkEsU0FBTCxPQUFLQSxDQUFMLEVBQTZDO0FBQzNDLFlBQU0sVUFDSCxtQkFBa0I2QixHQUFJLCtDQUE4Q1ksT0FBUSxzQkFBcUJ6QyxvQkFBb0IsQ0FBcEJBLHFCQURwRyxHQUFNLENBQU47QUFNRjs7QUFBQSxRQUFJbUMsUUFBUSxJQUFJTSxPQUFPLEtBQXZCLFFBQW9DO0FBQ2xDLFlBQU0sVUFDSCxtQkFBa0JaLEdBRHJCLGlGQUFNLENBQU47QUFJRjs7QUFBQSxpQkFBYTtBQUNYLFlBQU0sVUFDSCxtQkFBa0JBLEdBRHJCLGlHQUFNLENBQU47QUFJSDtBQUVEOztBQUFBLE1BQUlhLE1BQU0sR0FDUixjQUFjRCxPQUFPLEtBQVBBLFVBQXNCLG1CQUR0QyxXQUNFLENBREY7O0FBRUEsTUFBSVosR0FBRyxJQUFJQSxHQUFHLENBQUhBLFdBQVgsT0FBV0EsQ0FBWCxFQUFvQztBQUNsQztBQUNBSyxlQUFXLEdBQVhBO0FBQ0FRLFVBQU0sR0FBTkE7QUFHRjs7QUFBQSxRQUFNLDBCQUEwQixzQ0FBa0M7QUFDaEVDLGNBQVUsRUFEc0Q7QUFFaEVDLFlBQVEsRUFBRSxDQUZaO0FBQWtFLEdBQWxDLENBQWhDO0FBSUEsUUFBTUMsU0FBUyxHQUFHLFdBQWxCO0FBRUEsUUFBTUMsUUFBUSxHQUFHQyxNQUFNLENBQXZCLEtBQXVCLENBQXZCO0FBQ0EsUUFBTUMsU0FBUyxHQUFHRCxNQUFNLENBQXhCLE1BQXdCLENBQXhCO0FBQ0EsUUFBTUUsVUFBVSxHQUFHRixNQUFNLENBQXpCLE9BQXlCLENBQXpCO0FBRUE7QUFDQTtBQUNBO0FBQ0EsTUFBSUcsUUFBcUMsR0FBRztBQUMxQ0MsWUFBUSxFQURrQztBQUUxQ0MsT0FBRyxFQUZ1QztBQUcxQ0MsUUFBSSxFQUhzQztBQUkxQ0MsVUFBTSxFQUpvQztBQUsxQ0MsU0FBSyxFQUxxQztBQU8xQ0MsYUFBUyxFQVBpQztBQVExQ0MsV0FBTyxFQVJtQztBQVMxQ0MsVUFBTSxFQVRvQztBQVUxQ0MsVUFBTSxFQVZvQztBQVkxQ0MsV0FBTyxFQVptQztBQWExQ3RDLFNBQUssRUFicUM7QUFjMUN1QyxVQUFNLEVBZG9DO0FBZTFDQyxZQUFRLEVBZmtDO0FBZ0IxQ0MsWUFBUSxFQWhCa0M7QUFpQjFDQyxhQUFTLEVBakJpQztBQWtCMUNDLGFBQVMsRUFsQmlDO0FBQUE7QUFBNUM7QUFBNEMsR0FBNUM7O0FBdUJBLE1BQ0UsbUNBQ0EscUJBREEsZUFFQXBELE1BQU0sS0FIUixRQUlFO0FBQ0E7QUFDQSxVQUFNcUQsUUFBUSxHQUFHbEIsU0FBUyxHQUExQjtBQUNBLFVBQU1tQixVQUFVLEdBQUdDLEtBQUssQ0FBTEEsUUFBSyxDQUFMQSxZQUE0QixHQUFFRixRQUFRLEdBQUcsR0FBNUQ7O0FBQ0EsUUFBSXJELE1BQU0sS0FBVixjQUE2QjtBQUMzQjtBQUNBd0Qsa0JBQVksR0FBRztBQUNiVCxlQUFPLEVBRE07QUFFYlUsZ0JBQVEsRUFGSztBQUdibkIsZ0JBQVEsRUFISztBQUtiSyxpQkFBUyxFQUxJO0FBTWJHLGNBQU0sRUFOUlU7QUFBZSxPQUFmQTtBQVFBRSxnQkFBVSxHQUFHO0FBQUVYLGVBQU8sRUFBVDtBQUFvQkosaUJBQVMsRUFBN0I7QUFBYmU7QUFBYSxPQUFiQTtBQVZGLFdBV08sSUFBSTFELE1BQU0sS0FBVixhQUE0QjtBQUNqQztBQUNBd0Qsa0JBQVksR0FBRztBQUNiVCxlQUFPLEVBRE07QUFFYkcsZ0JBQVEsRUFGSztBQUdiTyxnQkFBUSxFQUhLO0FBSWJuQixnQkFBUSxFQUpLO0FBS2JLLGlCQUFTLEVBTEk7QUFNYkcsY0FBTSxFQU5SVTtBQUFlLE9BQWZBO0FBUUFFLGdCQUFVLEdBQUc7QUFDWGYsaUJBQVMsRUFERTtBQUVYSSxlQUFPLEVBRkk7QUFHWEcsZ0JBQVEsRUFIVlE7QUFBYSxPQUFiQTtBQUtBQyxjQUFRLEdBQUksZUFBYzFCLFFBQVMsYUFBWUUsU0FBL0N3QjtBQWZLLFdBZ0JBLElBQUkzRCxNQUFNLEtBQVYsU0FBd0I7QUFDN0I7QUFDQXdELGtCQUFZLEdBQUc7QUFDYkMsZ0JBQVEsRUFESztBQUViZCxpQkFBUyxFQUZJO0FBR2JJLGVBQU8sRUFITTtBQUliVCxnQkFBUSxFQUpLO0FBS2I3QixhQUFLLEVBTFE7QUFNYnVDLGNBQU0sRUFOUlE7QUFBZSxPQUFmQTtBQVNIO0FBOUNELFNBOENPLElBQ0wsbUNBQ0EscUJBREEsZUFFQXhELE1BQU0sS0FIRCxRQUlMO0FBQ0E7QUFDQXdELGdCQUFZLEdBQUc7QUFDYlQsYUFBTyxFQURNO0FBRWJVLGNBQVEsRUFGSztBQUlibkIsY0FBUSxFQUpLO0FBS2JDLFNBQUcsRUFMVTtBQU1iQyxVQUFJLEVBTlM7QUFPYkMsWUFBTSxFQVBPO0FBUWJDLFdBQUssRUFSUTtBQVViQyxlQUFTLEVBVkk7QUFXYkcsWUFBTSxFQVhSVTtBQUFlLEtBQWZBO0FBTkssU0FtQkE7QUFDTDtBQUNBLGNBQTJDO0FBQ3pDLFlBQU0sVUFDSCxtQkFBa0J4QyxHQURyQix5RUFBTSxDQUFOO0FBSUg7QUFFRDs7QUFBQSxNQUFJNEMsYUFBZ0MsR0FBRztBQUNyQzVDLE9BQUcsRUFEa0M7QUFHckNKLFVBQU0sRUFIK0I7QUFJckNiLFNBQUssRUFKUDtBQUF1QyxHQUF2Qzs7QUFPQSxpQkFBZTtBQUNiNkQsaUJBQWEsR0FBR0MsZ0JBQWdCLENBQUM7QUFBQTtBQUFBO0FBQUE7QUFJL0JwRCxXQUFLLEVBSjBCO0FBSy9CcUQsYUFBTyxFQUx3QjtBQUFBO0FBQWpDRjtBQUFpQyxLQUFELENBQWhDQTtBQVdGOztBQUFBLGVBQWE7QUFDWEosZ0JBQVksR0FBWkE7QUFDQUUsY0FBVSxHQUFWQTtBQUNBckIsWUFBUSxHQUFSQTtBQUVGOztBQUFBLHNCQUNFO0FBQUssU0FBSyxFQUFWO0FBQUEsS0FDR3FCLFVBQVUsZ0JBQ1Q7QUFBSyxTQUFLLEVBQVY7QUFBQSxLQUNHQyxRQUFRLGdCQUNQO0FBQ0UsU0FBSyxFQUFFO0FBQ0xULGNBQVEsRUFESDtBQUVMSCxhQUFPLEVBRkY7QUFHTEQsWUFBTSxFQUhEO0FBSUxELFlBQU0sRUFKRDtBQUtMRCxhQUFPLEVBTlg7QUFDUyxLQURUO0FBUUUsT0FBRyxFQVJMO0FBU0UsbUJBVEY7QUFVRSxRQUFJLEVBVk47QUFXRSxPQUFHLEVBQUcsNkJBQTRCLCtCQVo3QjtBQUNQLElBRE8sR0FGRixJQUNULENBRFMsR0FEYixNQW9CRywyQkFDQyw0REFDRSw0REFFTWlCLGdCQUFnQixDQUFDO0FBQUE7QUFBQTtBQUFBO0FBSW5CcEQsU0FBSyxFQUpjO0FBS25CcUQsV0FBTyxFQUxZO0FBQUE7QUFGdkI7QUFFdUIsR0FBRCxDQUZ0QjtBQVdFLE9BQUcsRUFYTDtBQVlFLFlBQVEsRUFaVjtBQWFFLFNBQUssRUFiUDtBQWNFLFNBQUssRUFkUDtBQWVFLGFBQVMsRUFyQ2pCO0FBc0JNLEtBREYsQ0FyQkosZUF5Q0U7QUFHRSxZQUFRLEVBSFY7QUFJRSxhQUFTLEVBSlg7QUFLRSxPQUFHLEVBTEw7QUFNRSxTQUFLLEVBL0NUO0FBeUNFLEtBekNGLEVBaURHeEMsUUFBUTtBQUFBO0FBQ1A7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLCtCQUFDLE1BQUQsNEJBQ0U7QUFDRSxPQUFHLEVBQ0QsWUFDQXNDLGFBQWEsQ0FEYixNQUVBQSxhQUFhLENBRmIsU0FHQUEsYUFBYSxDQUxqQjtBQU9FLE9BQUcsRUFQTDtBQVFFLE1BQUUsRUFSSjtBQVNFLFFBQUksRUFBRUEsYUFBYSxDQUFiQSxxQkFBbUNBLGFBQWEsQ0FBQzVDLEdBVHpELENBVUU7QUFWRjtBQVdFLGVBQVcsRUFBRTRDLGFBQWEsQ0FBQ2hELE1BWDdCLENBWUU7QUFaRjtBQWFFLGNBQVUsRUFBRWdELGFBQWEsQ0FwQnRCO0FBT0wsSUFERixDQU5PLEdBbERiLElBQ0UsQ0FERjtBQThFRixDLENBQUE7OztBQUVBLDJCQUEyQztBQUN6QyxTQUFPNUMsR0FBRyxDQUFIQSxDQUFHLENBQUhBLFdBQWlCQSxHQUFHLENBQUhBLE1BQWpCQSxDQUFpQkEsQ0FBakJBLEdBQVA7QUFHRjs7QUFBQSxxQkFBcUI7QUFBQTtBQUFBO0FBQUE7QUFBckI7QUFBcUIsQ0FBckIsRUFLb0M7QUFDbEM7QUFDQSxRQUFNK0MsTUFBTSxHQUFHLDJCQUEyQixPQUExQyxLQUFlLENBQWY7QUFDQSxNQUFJQyxZQUFZLEdBQWhCOztBQUNBLGVBQWE7QUFDWEQsVUFBTSxDQUFOQSxLQUFZLE9BQVpBO0FBR0Y7O0FBQUEsTUFBSUEsTUFBTSxDQUFWLFFBQW1CO0FBQ2pCQyxnQkFBWSxHQUFHLE1BQU1ELE1BQU0sQ0FBTkEsS0FBckJDLEdBQXFCRCxDQUFyQkM7QUFFRjs7QUFBQSxTQUFRLEdBQUU5QyxJQUFLLEdBQUUrQyxZQUFZLEtBQU0sR0FBRUQsWUFBckM7QUFHRjs7QUFBQSxzQkFBc0I7QUFBQTtBQUFBO0FBQXRCO0FBQXNCLENBQXRCLEVBQTZFO0FBQzNFLFNBQVEsR0FBRTlDLElBQUssR0FBRStDLFlBQVksS0FBTSxZQUFXeEQsS0FBOUM7QUFHRjs7QUFBQSwwQkFBMEI7QUFBQTtBQUFBO0FBQUE7QUFBMUI7QUFBMEIsQ0FBMUIsRUFLb0M7QUFDbEM7QUFDQSxRQUFNc0QsTUFBTSxHQUFHLHNCQUFzQixPQUF0QixPQUFvQyxRQUFRRCxPQUFPLElBQWxFLE1BQW1ELENBQXBDLENBQWY7QUFDQSxNQUFJRSxZQUFZLEdBQUdELE1BQU0sQ0FBTkEsWUFBbkI7QUFDQSxTQUFRLEdBQUU3QyxJQUFLLEdBQUU4QyxZQUFhLEdBQUVDLFlBQVksS0FBNUM7QUFHRjs7QUFBQSx1QkFBdUI7QUFBQTtBQUFBO0FBQUE7QUFBdkI7QUFBdUIsQ0FBdkIsRUFLb0M7QUFDbEMsWUFBMkM7QUFDekMsVUFBTUMsYUFBYSxHQUFuQixHQUR5QyxDQUd6Qzs7QUFDQSxRQUFJLENBQUosS0FBVUEsYUFBYSxDQUFiQTtBQUNWLFFBQUksQ0FBSixPQUFZQSxhQUFhLENBQWJBOztBQUVaLFFBQUlBLGFBQWEsQ0FBYkEsU0FBSixHQUE4QjtBQUM1QixZQUFNLFVBQ0gsb0NBQW1DQSxhQUFhLENBQWJBLFVBRWxDLGdHQUErRnZDLElBQUksQ0FBSkEsVUFDL0Y7QUFBQTtBQUFBO0FBRCtGQTtBQUMvRixPQUQrRkEsQ0FIbkcsRUFBTSxDQUFOO0FBU0Y7O0FBQUEsUUFBSVgsR0FBRyxDQUFIQSxXQUFKLElBQUlBLENBQUosRUFBMEI7QUFDeEIsWUFBTSxVQUNILHdCQUF1QkEsR0FEMUIsMEdBQU0sQ0FBTjtBQUtGOztBQUFBLFFBQUksQ0FBQ0EsR0FBRyxDQUFIQSxXQUFELEdBQUNBLENBQUQsSUFBSixlQUEyQztBQUN6Qzs7QUFDQSxVQUFJO0FBQ0ZtRCxpQkFBUyxHQUFHLFFBQVpBLEdBQVksQ0FBWkE7QUFDQSxPQUZGLENBRUUsWUFBWTtBQUNaQyxlQUFPLENBQVBBO0FBQ0EsY0FBTSxVQUNILHdCQUF1QnBELEdBRDFCLGlJQUFNLENBQU47QUFLRjs7QUFBQSxVQUFJLENBQUNxRCxhQUFhLENBQWJBLFNBQXVCRixTQUFTLENBQXJDLFFBQUtFLENBQUwsRUFBaUQ7QUFDL0MsY0FBTSxVQUNILHFCQUFvQnJELEdBQUksa0NBQWlDbUQsU0FBUyxDQUFDRyxRQUFwRSwrREFBQyxHQURILDhFQUFNLENBQU47QUFLSDtBQUNGO0FBRUQ7O0FBQUEsU0FBUSxHQUFFcEQsSUFBSyxRQUFPcUQsa0JBQWtCLEtBQU0sTUFBSzlELEtBQU0sTUFBS3FELE9BQU8sSUFBSSxFQUF6RTtBQUNELEM7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDdmpCTSxNQUFNVSxtQkFBbUIsR0FDN0IsK0JBQStCQyxJQUFJLENBQXBDLG1CQUFDLElBQ0QsY0FFa0I7QUFDaEIsTUFBSUMsS0FBSyxHQUFHQyxJQUFJLENBQWhCLEdBQVlBLEVBQVo7QUFDQSxTQUFPQyxVQUFVLENBQUMsWUFBWTtBQUM1QkMsTUFBRSxDQUFDO0FBQ0RDLGdCQUFVLEVBRFQ7QUFFREMsbUJBQWEsRUFBRSxZQUFZO0FBQ3pCLGVBQU8xRSxJQUFJLENBQUpBLE9BQVksTUFBTXNFLElBQUksQ0FBSkEsUUFBekIsS0FBbUIsQ0FBWnRFLENBQVA7QUFISndFO0FBQUcsS0FBRCxDQUFGQTtBQURlLEtBQWpCLENBQWlCLENBQWpCO0FBTkc7Ozs7QUFnQkEsTUFBTUcsa0JBQWtCLEdBQzVCLCtCQUErQlAsSUFBSSxDQUFwQyxrQkFBQyxJQUNELGNBQXlDO0FBQ3ZDLFNBQU9RLFlBQVksQ0FBbkIsRUFBbUIsQ0FBbkI7QUFIRzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ25DUDs7QUFDQTs7QUFjQSxNQUFNQyx1QkFBdUIsR0FBRyxnQ0FBaEM7O0FBRU8seUJBQTRDO0FBQUE7QUFBNUM7QUFBNEMsQ0FBNUMsRUFHcUQ7QUFDMUQsUUFBTUMsVUFBbUIsR0FBR3BELFFBQVEsSUFBSSxDQUF4QztBQUVBLFFBQU1xRCxTQUFTLEdBQUcsV0FBbEIsTUFBa0IsR0FBbEI7QUFDQSxRQUFNLHdCQUF3QixxQkFBOUIsS0FBOEIsQ0FBOUI7QUFFQSxRQUFNQyxNQUFNLEdBQUcsd0JBQ1pDLEVBQUQsSUFBa0I7QUFDaEIsUUFBSUYsU0FBUyxDQUFiLFNBQXVCO0FBQ3JCQSxlQUFTLENBQVRBO0FBQ0FBLGVBQVMsQ0FBVEE7QUFHRjs7QUFBQSxRQUFJRCxVQUFVLElBQWQsU0FBMkI7O0FBRTNCLFFBQUlHLEVBQUUsSUFBSUEsRUFBRSxDQUFaLFNBQXNCO0FBQ3BCRixlQUFTLENBQVRBLFVBQW9CRyxPQUFPLEtBRXhCdkQsU0FBRCxJQUFlQSxTQUFTLElBQUl3RCxVQUFVLENBRmIsU0FFYSxDQUZiLEVBR3pCO0FBSEZKO0FBR0UsT0FIeUIsQ0FBM0JBO0FBTUg7QUFoQlksS0FpQmIseUJBakJGLE9BaUJFLENBakJhLENBQWY7QUFvQkEsd0JBQVUsTUFBTTtBQUNkLFFBQUksQ0FBSix5QkFBOEI7QUFDNUIsVUFBSSxDQUFKLFNBQWM7QUFDWixjQUFNSyxZQUFZLEdBQUcsOENBQW9CLE1BQU1ELFVBQVUsQ0FBekQsSUFBeUQsQ0FBcEMsQ0FBckI7QUFDQSxlQUFPLE1BQU0sNkNBQWIsWUFBYSxDQUFiO0FBRUg7QUFDRjtBQVBELEtBT0csQ0FQSCxPQU9HLENBUEg7QUFTQSxTQUFPLFNBQVAsT0FBTyxDQUFQO0FBR0Y7O0FBQUEsNkNBSWM7QUFDWixRQUFNO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFBNkJFLGNBQWMsQ0FBakQsT0FBaUQsQ0FBakQ7QUFDQUMsVUFBUSxDQUFSQTtBQUVBQyxVQUFRLENBQVJBO0FBQ0EsU0FBTyxxQkFBMkI7QUFDaENELFlBQVEsQ0FBUkE7QUFDQUMsWUFBUSxDQUFSQSxtQkFGZ0MsQ0FJaEM7O0FBQ0EsUUFBSUQsUUFBUSxDQUFSQSxTQUFKLEdBQXlCO0FBQ3ZCQyxjQUFRLENBQVJBO0FBQ0FDLGVBQVMsQ0FBVEE7QUFFSDtBQVREO0FBWUY7O0FBQUEsTUFBTUEsU0FBUyxHQUFHLElBQWxCLEdBQWtCLEVBQWxCOztBQUNBLGlDQUF3RTtBQUN0RSxRQUFNQyxFQUFFLEdBQUdDLE9BQU8sQ0FBUEEsY0FBWDtBQUNBLE1BQUlDLFFBQVEsR0FBR0gsU0FBUyxDQUFUQSxJQUFmLEVBQWVBLENBQWY7O0FBQ0EsZ0JBQWM7QUFDWjtBQUdGOztBQUFBLFFBQU1GLFFBQVEsR0FBRyxJQUFqQixHQUFpQixFQUFqQjtBQUNBLFFBQU1DLFFBQVEsR0FBRyx5QkFBMEJLLE9BQUQsSUFBYTtBQUNyREEsV0FBTyxDQUFQQSxRQUFpQkMsS0FBRCxJQUFXO0FBQ3pCLFlBQU1DLFFBQVEsR0FBR1IsUUFBUSxDQUFSQSxJQUFhTyxLQUFLLENBQW5DLE1BQWlCUCxDQUFqQjtBQUNBLFlBQU0zRCxTQUFTLEdBQUdrRSxLQUFLLENBQUxBLGtCQUF3QkEsS0FBSyxDQUFMQSxvQkFBMUM7O0FBQ0EsVUFBSUMsUUFBUSxJQUFaLFdBQTJCO0FBQ3pCQSxnQkFBUSxDQUFSQSxTQUFRLENBQVJBO0FBRUg7QUFOREY7QUFEZSxLQUFqQixPQUFpQixDQUFqQjtBQVVBSixXQUFTLENBQVRBLFFBRUdHLFFBQVEsR0FBRztBQUFBO0FBQUE7QUFGZEg7QUFFYyxHQUZkQTtBQVFBO0FBQ0QsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDM0dEOztBQUNBOzs7O0FBa0JBO0FBQ0E7QUFDQTtBQUNBOztBQUNBLGtDQUFrQztBQUFBO0FBQWxDO0FBQWtDLENBQWxDLEVBR3lDO0FBQ3ZDLFFBQU01SCxTQUFTLEdBQUcsTUFBTSwyQ0FBeEIsR0FBd0IsQ0FBeEI7QUFDQSxTQUFPO0FBQVA7QUFBTyxHQUFQO0FBR2E7O0FBQUEsa0JBQTJDbUksZUFBTUMsU0FBakQsQ0FHYjtBQUlBO0FBQ0E7QUFDQTtBQUNBQyxtQkFBaUIsb0JBQTRDO0FBQzNEO0FBR0ZDOztBQUFBQSxRQUFNLEdBQUc7QUFDUCxVQUFNO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLFFBQXFELEtBQTNEO0FBR0Esd0JBQ0UscUVBR0k7QUFDQTtBQUNJLE1BQUVDLE9BQU8sSUFBVCxXQUF3QjtBQUFFQyxTQUFHLEVBQUVDLFNBQVMsQ0FBeEMsTUFBd0M7QUFBaEIsS0FBeEIsR0FOVixFQUNFLEVBREY7QUFmRjs7QUFBQTs7O0FBSG1CQyxHLENBSVpDLG1CQUpZRCxHQUlVRSxrQkFKVkY7QUFBQUEsRyxDQUtaRyxlQUxZSCxHQUtNRSxrQkFMTkY7QUErQnJCO0FBQ0E7O0FBRUEsVUFBMkM7QUFDekNJLGVBQWEsR0FBRyxxQkFBUyxNQUFNO0FBQzdCM0MsV0FBTyxDQUFQQTtBQURGMkMsR0FBZ0IsQ0FBaEJBO0FBTUFDLFNBQU8sR0FBRyxxQkFBUyxNQUFNO0FBQ3ZCNUMsV0FBTyxDQUFQQTtBQURGNEMsR0FBVSxDQUFWQTtBQU9GLEMsQ0FBQTs7O0FBQ08sc0JBQTJCO0FBQ2hDLFlBQTJDRCxhQUFhO0FBQ3hELFNBQU9wRyxDQUFDLENBQVI7QUFHSzs7QUFBQSwyQkFBbUM7QUFDeEM7QUFDQSxRQUFNO0FBQUE7QUFBQTtBQUFBO0FBQUEsTUFBTjtBQUNBLFNBQU87QUFDTCxnQkFBWTtBQUNWLGdCQUEyQ3FHLE9BQU87QUFDbEQ7QUFIRzs7QUFLTCxtQkFBZTtBQUNiLGdCQUEyQ0EsT0FBTztBQUNsRDtBQVBHOztBQVNMLGlCQUFhO0FBQ1gsZ0JBQTJDQSxPQUFPO0FBQ2xEO0FBWEc7O0FBYUxDLFFBQUksRUFBRSxNQUFNO0FBQ1YsZ0JBQTJDRCxPQUFPO0FBQ2xERSxZQUFNLENBQU5BO0FBZkc7QUFpQkxDLFFBQUksRUFBRSxhQUE4QjtBQUNsQyxnQkFBMkNILE9BQU87QUFDbEQsYUFBT0UsTUFBTSxDQUFOQSxVQUFQLEVBQU9BLENBQVA7QUFuQkc7QUFxQkxFLFVBQU0sRUFBRSxjQUErQjtBQUNyQyxnQkFBMkNKLE9BQU87QUFDbEQsWUFBTUssU0FBUyxHQUFHQyxFQUFFLFVBQXBCO0FBQ0EsWUFBTUMsT0FBTyxHQUFHRCxFQUFFLElBQWxCO0FBRUEsYUFBT0osTUFBTSxDQUFOQSxnQkFBUCxPQUFPQSxDQUFQO0FBMUJHO0FBNEJMTSxXQUFPLEVBQUUsYUFBOEI7QUFDckMsZ0JBQTJDUixPQUFPO0FBQ2xELGFBQU9FLE1BQU0sQ0FBTkEsYUFBUCxFQUFPQSxDQUFQO0FBOUJHO0FBZ0NMTyxhQUFTLEVBQUUsY0FBK0I7QUFDeEMsZ0JBQTJDVCxPQUFPO0FBQ2xELFlBQU1VLFlBQVksR0FBR0osRUFBRSxVQUF2QjtBQUNBLFlBQU1LLFVBQVUsR0FBR0wsRUFBRSxJQUFyQjtBQUVBLGFBQU9KLE1BQU0sQ0FBTkEsc0JBQVAsVUFBT0EsQ0FBUDtBQXJDSjtBQUFPLEdBQVA7QUF3Q0QsQzs7Ozs7Ozs7Ozs7QUNoSUQsaUJBQWlCLG1CQUFPLENBQUMscUVBQXFCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDQTlDOztBQUdBLE1BQU1VLFVBQVUsR0FBRyxVQUFVdkssU0FBVixFQUE2QztBQUM5RCxTQUFPLE1BQU07QUFDWCxVQUFNd0ssVUFBVSxxQkFBUXhLLFNBQVMsRUFBakIsQ0FBaEI7O0FBQ0F3SyxjQUFVLENBQUM5SSxJQUFYLEdBQWtCLENBQUM4SSxVQUFVLENBQUM5SSxJQUE5QjtBQUNBMUIsYUFBUyxDQUFDd0ssVUFBRCxDQUFUO0FBQ0QsR0FKRDtBQUtELENBTkQ7O0FBUUEsTUFBTUMsa0JBQWtCLEdBQUcsVUFBVXpLLFNBQVYsRUFBNkM7QUFDdEUsU0FBUTBLLFNBQUQsSUFBOEI7QUFDbkMsVUFBTUYsVUFBVSxxQkFBUXhLLFNBQVMsRUFBakIsQ0FBaEI7O0FBQ0F3SyxjQUFVLENBQUM3SSxlQUFYLEdBQTZCK0ksU0FBN0I7QUFDQTFLLGFBQVMsQ0FBQ3dLLFVBQUQsQ0FBVDtBQUNELEdBSkQ7QUFLRCxDQU5EOztBQVFBLE1BQU1HLGtCQUFrQixHQUFHO0FBQ3pCSixZQUFVLEVBQUVBLFVBQVUsQ0FBQ3JLLDhEQUFELENBREc7QUFFekJ1SyxvQkFBa0IsRUFBRUEsa0JBQWtCLENBQUN2Syw4REFBRDtBQUZiLENBQTNCO0FBS2V5SyxpRkFBZixFOzs7Ozs7Ozs7Ozs7QUN4QkE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUVPLE1BQU1DLGtCQUFrQixHQUFHQyxrREFBSTtBQUN0QztBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSxDQVBPLEM7Ozs7Ozs7Ozs7OztBQ0ZQO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQ0E7QUFFQSxNQUFNQyxjQUFjLEdBQUc7QUFDckJGLDJGQUFrQkE7QUFERyxDQUF2Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDSEE7QUFDQTtBQUNBO0FBQ0E7Q0FDZ0U7O0FBQ2hFO0FBQ0E7QUFDQTtDQUVBO0FBQ0E7O0FBR2UsU0FBU0csV0FBVCxDQUFxQjtBQUNsQy9CLFdBRGtDO0FBRWxDcEksV0FGa0M7QUFHbENPO0FBSGtDLENBQXJCLEVBSUM7QUFDZCxRQUFNM0MsWUFBWSxHQUFHc0MsK0RBQVMsQ0FBQ0YsU0FBRCxDQUE5QjtBQUNBLFFBQU1vSyxVQUFVLEdBQUc5SiwwRUFBYSxDQUFDQyxTQUFELENBQWhDO0FBRUEsc0JBQ0U7QUFBQSwyQkFJRSxxRUFBQyw2REFBRDtBQUFnQixZQUFNLEVBQUUzQyxZQUF4QjtBQUFBLDZCQUNFLHFFQUFDLHNEQUFEO0FBQU0sa0JBQVUsRUFBRXdNLFVBQWxCO0FBQUEsK0JBQ0UscUVBQUMsU0FBRCxrQ0FBZXBLLFNBQWY7QUFBMEIsb0JBQVUsRUFBRW9LO0FBQXRDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUpGLG1CQURGO0FBWUQ7O0FBRURELFdBQVcsQ0FBQ3RCLGVBQVosR0FBOEIsTUFBT3dCLFVBQVAsSUFBc0I7QUFDbEQsUUFBTUMsUUFBUSxHQUFHLE1BQU01QiwrQ0FBRyxDQUFDRyxlQUFKLENBQW9Cd0IsVUFBcEIsQ0FBdkI7QUFDQSxRQUFNO0FBQUUxTSxPQUFGO0FBQU80TTtBQUFQLE1BQWlCRixVQUFVLENBQUN2TSxHQUFsQztBQUNBLFFBQU15QyxTQUFTLEdBQUc1QyxHQUFHLEdBQUdBLEdBQUcsQ0FBQ2MsT0FBSixDQUFZLFlBQVosQ0FBSCxHQUErQitMLFNBQVMsQ0FBQ2pLLFNBQTlEO0FBRUEseUNBQVkrSixRQUFaO0FBQXNCL0osYUFBdEI7QUFBaUNnSztBQUFqQztBQUNELENBTkQsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNuQ0E7QUFTTyxNQUFNRSxNQUF1QixHQUFHLENBQUM7QUFBRUMsT0FBRjtBQUFTQyxVQUFUO0FBQW1CQyxXQUFuQjtBQUE4QkM7QUFBOUIsQ0FBRCxLQUFxRDtBQUUxRixzQkFDRTtBQUFBLDRCQUNFO0FBQUssZUFBUyxFQUFDLG1EQUFmO0FBQW1FLFdBQUssRUFBRTtBQUFFQyx1QkFBZSxFQUFHLE9BQU1GLFNBQVU7QUFBcEMsT0FBMUU7QUFBQSw2QkFDRTtBQUFLLGlCQUFTLEVBQUMsMEVBQWY7QUFBQSwrQkFDRTtBQUFLLG1CQUFTLEVBQUMsYUFBZjtBQUFBLGtDQUNFO0FBQUkscUJBQVMsRUFBQyxxRUFBZDtBQUFBLHNCQUFxRkY7QUFBckY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFERixlQUVFO0FBQUcscUJBQVMsRUFBQyxnQ0FBYjtBQUFBLHNCQUErQ0M7QUFBL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFGRixlQUdFO0FBQUsscUJBQVMsRUFBQztBQUFmO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBREYsZUFxQkU7QUFBSyxlQUFTLEVBQUMseURBQWY7QUFBeUUsV0FBSyxFQUFFO0FBQUVHLHVCQUFlLEVBQUcsK0RBQThERCxlQUFnQjtBQUFsRyxPQUFoRjtBQUFBLDZCQUNFO0FBQUssaUJBQVMsRUFBQywwRUFBZjtBQUFBLCtCQUNFO0FBQUssbUJBQVMsRUFBQyxLQUFmO0FBQUEsa0NBQ0U7QUFBSSxxQkFBUyxFQUFDLDREQUFkO0FBQUEsc0JBQTRFSDtBQUE1RTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQURGLGVBRUU7QUFBRyxxQkFBUyxFQUFDLGlDQUFiO0FBQUEsc0JBQWdEQztBQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUZGLGVBR0U7QUFBSyxxQkFBUyxFQUFDO0FBQWY7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFIRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFyQkY7QUFBQSxrQkFERjtBQWtDRCxDQXBDTSxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDVFA7O0FBVUEsTUFBTUksTUFBdUIsR0FBRyxDQUFDO0FBQy9CTCxPQUQrQjtBQUUvQmxDLEtBRitCO0FBRy9Cd0MsU0FIK0I7QUFJL0JDLFdBQVMsR0FBRyxFQUptQjtBQUsvQkMsT0FBSyxHQUFHO0FBTHVCLENBQUQsS0FNMUI7QUFDSixzQkFDRTtBQUNFLFdBQU8sRUFBRUYsT0FEWDtBQUVFLFNBQUssRUFBRUUsS0FGVDtBQUdFLGFBQVMsRUFBRyxxQ0FBb0NELFNBQVUsRUFINUQ7QUFBQSxlQUtHLEdBTEgsRUFNR1AsS0FOSCxvQkFNVTtBQUFLLGVBQVMsRUFBQyxNQUFmO0FBQXNCLFNBQUcsRUFBRWxDO0FBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBTlY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUFVRCxDQWpCRDs7QUFtQmV1QyxxRUFBZixFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzdCQTtBQVNPLE1BQU1JLGVBQWdDLEdBQUcsQ0FBQztBQUFFVCxPQUFGO0FBQVNNLFNBQVQ7QUFBa0JDO0FBQWxCLENBQUQsS0FBbUM7QUFDL0Usc0JBQVE7QUFBUSxhQUFTLEVBQUcsNkRBQTREQSxTQUFVLEVBQTFGO0FBQUEsb0JBQWdHUCxLQUFoRztBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBUjtBQUNILENBRk0sQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ1RQO0FBT08sTUFBTUssTUFBeUIsR0FBRyxVQUluQztBQUFBLE1BSm9DO0FBQ3hDRSxhQUFTLEdBQUcsRUFENEI7QUFFeENHO0FBRndDLEdBSXBDO0FBQUEsTUFERDdILElBQ0M7O0FBQ0osc0JBQ0U7QUFDRSxhQUFTLEVBQUcscUlBQW9JMEgsU0FBVTtBQUQ1SixLQUVNMUgsSUFGTjtBQUFBLGNBSUc2SDtBQUpIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQVFELENBYk0sQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ1BQO0FBRUE7QUFFTyxNQUFNQyxLQUFlLEdBQUcsTUFBTTtBQUFBOztBQUNuQyxzQkFDRTtBQUFLLGFBQVMsRUFBQyxtREFBZjtBQUFBLDJCQUNFO0FBQUssZUFBUyxFQUFDLHNEQUFmO0FBQUEsZ0JBQ0csa0JBQUN6TCw4Q0FBRCxhQUFDQSw4Q0FBRCx1QkFBQ0EsOENBQUksQ0FBRTBMLE9BQVAseURBQWtCLEVBQWxCLEVBQXNCQyxHQUF0QixDQUEyQkMsTUFBRCxpQkFDekI7QUFFRSxpQkFBUyxFQUFDLGtEQUZaO0FBQUEsZ0NBSUU7QUFBSSxtQkFBUyxFQUFDLDRCQUFkO0FBQUEsb0JBQTRDQSxNQUFNLENBQUN4TztBQUFuRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUpGLGVBS0U7QUFBRyxtQkFBUyxFQUFDLEtBQWI7QUFBQSxvQkFBb0J3TyxNQUFNLENBQUNDO0FBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBTEY7QUFBQSxTQUNPRCxNQUFNLENBQUN4TyxJQURkO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREQ7QUFESDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBZUQsQ0FoQk0sQzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDSkEsTUFBTTBPLFNBQVMsR0FBRyxDQUFDO0FBQUVOO0FBQUYsQ0FBRCxLQUFrQjtBQUN6QyxzQkFBTztBQUFLLGFBQVMsRUFBQyw0QkFBZjtBQUFBLGNBQTZDQTtBQUE3QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQVA7QUFDRCxDQUZNLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDQVA7QUFDQTtBQUNBO0FBQ0E7QUFjTyxNQUFNTyxXQUE0QixHQUFHLENBQUM7QUFDM0NDLFdBRDJDO0FBRTNDWCxXQUFTLEdBQUcsRUFGK0I7QUFHM0NQLE9BSDJDO0FBSTNDbUIsUUFKMkM7QUFLM0NiLFNBTDJDO0FBTTNDYyxZQU4yQztBQU8zQ0MsY0FQMkM7QUFRM0NDLGVBUjJDO0FBUzNDZCxPQUFLLEdBQUc7QUFUbUMsQ0FBRCxLQVV0QztBQUNKLHNCQUNFO0FBQ0UsYUFBUyxFQUFHLEdBQUVELFNBQVUsc0JBRDFCO0FBRUUsU0FBSyxFQUFFQyxLQUZUO0FBQUEsNEJBSUUscUVBQUMsaURBQUQ7QUFBTyxTQUFHLEVBQUVVLFNBQVo7QUFBdUIsU0FBRyxFQUFDLGVBQTNCO0FBQTJDLGVBQVMsRUFBQztBQUFyRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQUpGLGVBS0U7QUFDRSxlQUFTLEVBQUMseURBRFo7QUFFRSxXQUFLLEVBQUU7QUFBRXRILFdBQUcsRUFBRSxRQUFQO0FBQWlCQyxZQUFJLEVBQUU7QUFBdkIsT0FGVDtBQUFBLDhCQUlFO0FBQUksaUJBQVMsRUFBQyw0REFBZDtBQUFBLGtCQUNHbUc7QUFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUpGLGVBT0U7QUFBSyxpQkFBUyxFQUFDLHlDQUFmO0FBQUEsZ0NBQ0U7QUFBTSxtQkFBUyxFQUFDLDZEQUFoQjtBQUFBLDRCQUNNLE1BQU1tQixNQURaO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFERixlQUlFO0FBQU0sbUJBQVMsRUFBQyxrRUFBaEI7QUFBQSxvQkFDR0csYUFBYSxHQUFHO0FBRG5CO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVBGLGVBZUU7QUFBSyxpQkFBUyxFQUFDLDJCQUFmO0FBQUEsZ0NBRUUscUVBQUMsaUZBQUQ7QUFDRSxlQUFLLEVBQUUsV0FEVDtBQUVFLG1CQUFTLEVBQUMsc0JBRlo7QUFHRSxhQUFHLEVBQUM7QUFITjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUZGLGVBT0UscUVBQUMsaURBQUQ7QUFDRSxhQUFHLEVBQUVDLDZFQUFzQixDQUFDRixZQUFELENBRDdCO0FBRUUsYUFBRyxFQUFDLG9CQUZOO0FBR0UsbUJBQVMsRUFBQztBQUhaO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQXFDRCxDQWhETSxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNqQlA7QUFDQTtBQVNPLE1BQU1HLGFBQThCLEdBQUcsQ0FBQztBQUFFQyxhQUFGO0FBQWVsQixXQUFmO0FBQTJCbUIsUUFBM0I7QUFBbUNsQixPQUFLLEdBQUM7QUFBekMsQ0FBRCxLQUFrRDtBQUM1RixzQkFDSTtBQUFLLGFBQVMsRUFBRyxHQUFFRCxTQUFVLEVBQTdCO0FBQWdDLFNBQUssRUFBRUMsS0FBdkM7QUFBQSw0QkFDSTtBQUFBLDhCQUNJO0FBQUEsa0JBQU1rQjtBQUFOO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREosZUFFSTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFESixlQUtJO0FBQUssZUFBUyxFQUFDLE1BQWY7QUFBQSxnQkFDS0QsV0FBVyxDQUFDWixHQUFaLENBQWlCYyxXQUFELElBQWlCO0FBQzlCLDRCQUNJLHFFQUFDLG1FQUFEO0FBRUksbUJBQVMsRUFBRUEsV0FBVyxDQUFDVCxTQUYzQjtBQUdJLGVBQUssRUFBRVMsV0FBVyxDQUFDM0IsS0FIdkI7QUFJSSxnQkFBTSxFQUFFMkIsV0FBVyxDQUFDUixNQUp4QjtBQUtJLG9CQUFVLEVBQUVRLFdBQVcsQ0FBQ1AsVUFMNUI7QUFNSSxzQkFBWSxFQUFFTyxXQUFXLENBQUNOLFlBTjlCO0FBT0ksdUJBQWEsRUFBRU0sV0FBVyxDQUFDTCxhQVAvQjtBQVFJLGlCQUFPLEVBQUduRSxFQUFELElBQVExQixPQUFPLENBQUNtRyxHQUFSLENBQVl6RSxFQUFaLENBUnJCO0FBU0ksZUFBSyxFQUFFO0FBQUNyRixpQkFBSyxFQUFDO0FBQVAsV0FUWDtBQVVJLG1CQUFTLEVBQUM7QUFWZCxXQUNTNkosV0FBVyxDQUFDUCxVQURyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQURKO0FBY0gsT0FmQTtBQURMO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBTEo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREo7QUEwQkgsQ0EzQk0sQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNWUDtBQUNBOztBQUdBLE1BQU1TLFVBQW9CLEdBQUcsTUFBTTtBQUNqQyxzQkFBUTtBQUFLLGFBQVMsRUFBQyx3R0FBZjtBQUFBLGNBRUp6TCw2REFBSSxDQUFDeUssR0FBTCxDQUFTLENBQUNpQixJQUFELEVBQVlDLEtBQVosS0FBOEI7QUFDckMsMEJBQVE7QUFBa0IsaUJBQVMsRUFBQyxPQUE1QjtBQUFBLCtCQUNOO0FBQUcsY0FBSSxFQUFFRCxJQUFJLENBQUN2UCxJQUFkO0FBQW9CLG1CQUFTLEVBQUMsNkNBQTlCO0FBQUEsMEJBQThFdVAsSUFBSSxDQUFDeFAsSUFBbkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRE0sU0FBV3lQLEtBQVg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBUjtBQUdELEtBSkQ7QUFGSTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQVI7QUFTRCxDQVZEOztBQVllRix5RUFBZixFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2ZBO0FBQ0E7QUFDQTtBQUNBO0FBRU8sTUFBTUcsTUFBZ0IsR0FBRyxNQUFNO0FBQ3BDLHNCQUNFO0FBQUssYUFBUyxFQUFDLHVFQUFmO0FBQUEsNEJBQ0U7QUFBSyxlQUFTLEVBQUMsOEZBQWY7QUFBQSw4QkFDRTtBQUFLLGlCQUFTLEVBQUMsNkNBQWY7QUFBQSxnQ0FDRTtBQUFJLG1CQUFTLEVBQUMsaUVBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREYsZUFFRTtBQUFNLG1CQUFTLEVBQUMsVUFBaEI7QUFBQSxrQ0FDRTtBQUFJLHFCQUFTLEVBQUMsc0NBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBREYsZUFFRTtBQUFPLHFCQUFTLEVBQUMsaURBQWpCO0FBQW1FLGlCQUFLLEVBQUU7QUFBRUMsbUJBQUssRUFBRTtBQUFULGFBQTFFO0FBQWdHLGdCQUFJLEVBQUMsT0FBckc7QUFBNkcsdUJBQVcsRUFBQztBQUF6SDtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUZGLGVBR0UscUVBQUMsaUZBQUQ7QUFBUSxpQkFBSyxFQUFDLFdBQWQ7QUFBMEIsZUFBRyxFQUFDLGtCQUE5QjtBQUFpRCxxQkFBUyxFQUFFLGNBQTVEO0FBQTRFLG1CQUFPLEVBQUUsTUFBTXhHLE9BQU8sQ0FBQ21HLEdBQVIsQ0FBWSxXQUFaO0FBQTNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFERixlQVNFO0FBQUssaUJBQVMsRUFBQyw4REFBZjtBQUFBLGdDQUNFO0FBQUEsa0NBQ0U7QUFBSSxxQkFBUyxFQUFDLDRCQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQURGLGVBRUU7QUFBSSxxQkFBUyxFQUFDLDZCQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUZGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFERixlQUtFO0FBQUssbUJBQVMsRUFBQyx5Q0FBZjtBQUFBLGtDQUNFO0FBQUcscUJBQVMsRUFBQyxPQUFiO0FBQUEsbUNBQXFCO0FBQUssaUJBQUcsRUFBQztBQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBckI7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFERixlQUVFO0FBQUcscUJBQVMsRUFBQyxPQUFiO0FBQUEseUNBQXNCO0FBQUssaUJBQUcsRUFBQztBQUFUO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBQXRCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFERixlQXFCRTtBQUFLLGVBQVMsRUFBQyxtRkFBZjtBQUFBLDhCQUNFLHFFQUFDLG1EQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBREYsZUFFRTtBQUFLLGlCQUFTLEVBQUMsMkVBQWY7QUFBQSxnQ0FDRTtBQUFNLG1CQUFTLEVBQUMsa0NBQWhCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQURGLGVBRUU7QUFBRyxtQkFBUyxFQUFDLDBDQUFiO0FBQUEscUJBQXlEcFAseURBQXpEO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFGRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXJCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQWdDRCxDQWpDTSxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDTlA7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQVdPLE1BQU0wUCxPQUF3QixHQUFHLENBQUM7QUFBRTNCLFdBQUY7QUFBYUMsT0FBSyxHQUFHO0FBQXJCLENBQUQsS0FBK0I7QUFDckUsUUFBTTJCLEtBQUssR0FBRyxDQUFDO0FBQ2JDLGFBQVMsRUFBRSxTQURFO0FBRWJDLFlBQVEsRUFBRSxVQUZHO0FBR2JDLGNBQVUsRUFBRSxJQUhDO0FBSWJDLGFBQVMsRUFBRSxJQUpFO0FBS2JDLFdBQU8sRUFBRSxVQUxJO0FBTWJDLFlBQVEsRUFBRSxlQU5HO0FBT2JDLFFBQUksRUFBRSxnQkFQTztBQVFiQyxTQUFLLEVBQUUsMEJBUk07QUFTYkMsV0FBTyxFQUFFLENBQUMsUUFBRCxFQUFXLFVBQVgsRUFBdUIsT0FBdkI7QUFUSSxHQUFELEVBVVg7QUFDRFIsYUFBUyxFQUFFLE9BRFY7QUFFREMsWUFBUSxFQUFFLE1BRlQ7QUFHREMsY0FBVSxFQUFFLElBSFg7QUFJREMsYUFBUyxFQUFFLElBSlY7QUFLREMsV0FBTyxFQUFFLFlBTFI7QUFNREMsWUFBUSxFQUFFLElBTlQ7QUFPREMsUUFBSSxFQUFFLHNCQVBMO0FBUURDLFNBQUssRUFBRSw0QkFSTjtBQVNEQyxXQUFPLEVBQUUsQ0FBQyxLQUFELEVBQVEsU0FBUixFQUFtQixTQUFuQjtBQVRSLEdBVlcsRUFvQlg7QUFDRFIsYUFBUyxFQUFFLFNBRFY7QUFFREMsWUFBUSxFQUFFLE9BRlQ7QUFHREMsY0FBVSxFQUFFLFNBSFg7QUFJREMsYUFBUyxFQUFFLFFBSlY7QUFLREMsV0FBTyxFQUFFLDBCQUxSO0FBTURDLFlBQVEsRUFBRSxJQU5UO0FBT0RDLFFBQUksRUFBRSxtQkFQTDtBQVFEQyxTQUFLLEVBQUUsb0JBUk47QUFTREMsV0FBTyxFQUFFLENBQUMsS0FBRCxFQUFRLFFBQVIsRUFBa0IsT0FBbEI7QUFUUixHQXBCVyxFQThCWDtBQUNEUixhQUFTLEVBQUUsT0FEVjtBQUVEQyxZQUFRLEVBQUUsV0FGVDtBQUdEQyxjQUFVLEVBQUUsSUFIWDtBQUlEQyxhQUFTLEVBQUUsSUFKVjtBQUtEQyxXQUFPLEVBQUUsU0FMUjtBQU1EQyxZQUFRLEVBQUUsYUFOVDtBQU9EQyxRQUFJLEVBQUUsdUJBUEw7QUFRREMsU0FBSyxFQUFFLGtCQVJOO0FBU0RDLFdBQU8sRUFBRSxDQUFDLElBQUQsRUFBTyxRQUFQLEVBQWlCLFlBQWpCO0FBVFIsR0E5QlcsRUF3Q1g7QUFDRFIsYUFBUyxFQUFFLEtBRFY7QUFFREMsWUFBUSxFQUFFLGFBRlQ7QUFHREMsY0FBVSxFQUFFLElBSFg7QUFJREMsYUFBUyxFQUFFLElBSlY7QUFLREMsV0FBTyxFQUFFLFNBTFI7QUFNREMsWUFBUSxFQUFFLE1BTlQ7QUFPREMsUUFBSSxFQUFFLGVBUEw7QUFRREMsU0FBSyxFQUFFLHVCQVJOO0FBU0RDLFdBQU8sRUFBRSxDQUFDLFFBQUQsRUFBVyxVQUFYLEVBQXVCLE9BQXZCO0FBVFIsR0F4Q1csRUFrRFg7QUFDRFIsYUFBUyxFQUFFLFlBRFY7QUFFREMsWUFBUSxFQUFFLE1BRlQ7QUFHREMsY0FBVSxFQUFFLE9BSFg7QUFJREMsYUFBUyxFQUFFLFNBSlY7QUFLREMsV0FBTyxFQUFFLFNBTFI7QUFNREMsWUFBUSxFQUFFLE1BTlQ7QUFPREMsUUFBSSxFQUFFLG9CQVBMO0FBUURFLFdBQU8sRUFBRSxDQUFDLElBQUQsRUFBTyxRQUFQLEVBQWlCLFlBQWpCLENBUlI7QUFTREQsU0FBSyxFQUFFO0FBVE4sR0FsRFcsQ0FBZDtBQThEQSxRQUFNek4sSUFBSSxHQUFHLENBQ1g7QUFDRWdNLGFBQVMsRUFBRSxxQkFEYjtBQUVFbEIsU0FBSyxFQUFFLHFEQUZUO0FBR0VtQixVQUFNLEVBQUUsYUFIVjtBQUlFQyxjQUFVLEVBQUUsUUFKZDtBQUtFQyxnQkFBWSxFQUFFLE1BTGhCO0FBTUVDLGlCQUFhLEVBQUU7QUFOakIsR0FEVyxFQVNYO0FBQ0VKLGFBQVMsRUFBRSxxQkFEYjtBQUVFbEIsU0FBSyxFQUFFLHFEQUZUO0FBR0VtQixVQUFNLEVBQUUsYUFIVjtBQUlFQyxjQUFVLEVBQUUsU0FKZDtBQUtFQyxnQkFBWSxFQUFFLE1BTGhCO0FBTUVDLGlCQUFhLEVBQUU7QUFOakIsR0FUVyxDQUFiO0FBb0JBLFFBQU11QixRQUFRLEdBQUc7QUFDZkMsUUFBSSxFQUFFLElBRFM7QUFFZkMsWUFBUSxFQUFFLElBRks7QUFHZkMsU0FBSyxFQUFFLEdBSFE7QUFJZkMsaUJBQWEsRUFBRSxJQUpBO0FBS2ZDLGdCQUFZLEVBQUUsQ0FMQztBQU1mQyxrQkFBYyxFQUFFLENBTkQsQ0FPZjs7QUFQZSxHQUFqQjtBQVNBLHNCQUNFLHFFQUFDLGtEQUFELGtDQUFZTixRQUFaO0FBQUEsY0FDR1YsS0FBSyxDQUFDdEIsR0FBTixDQUFVdUMsSUFBSSxJQUFJO0FBQ2pCLDBCQUFRO0FBQUEsK0JBQ047QUFBSyxtQkFBUyxFQUFHLEdBQUU3QyxTQUFVLEVBQTdCO0FBQWdDLGVBQUs7QUFBSXpJLGlCQUFLLEVBQUUsTUFBWDtBQUFtQnVDLGtCQUFNLEVBQUUsTUFBM0I7QUFBbUNWLG9CQUFRLEVBQUU7QUFBN0MsYUFBNEQ2RyxLQUE1RCxDQUFyQztBQUFBLGtDQUNFO0FBQUsscUJBQVMsRUFBQyxFQUFmO0FBQWtCLGlCQUFLLEVBQUU7QUFBRTFJLG1CQUFLLEVBQUUsR0FBVDtBQUFjdUMsb0JBQU0sRUFBRSxHQUF0QjtBQUEyQlYsc0JBQVEsRUFBRSxVQUFyQztBQUFpRDBKLHdCQUFVLEVBQUUsU0FBN0Q7QUFBd0V2SixvQkFBTSxFQUFFLEVBQWhGO0FBQW9GRCxrQkFBSSxFQUFFO0FBQTFGO0FBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBREYsZUFFRTtBQUFLLHFCQUFTLEVBQUMsRUFBZjtBQUFrQixpQkFBSyxFQUFFO0FBQUUvQixtQkFBSyxFQUFFLEdBQVQ7QUFBY3VDLG9CQUFNLEVBQUUsR0FBdEI7QUFBMkJQLG9CQUFNLEVBQUUsRUFBbkM7QUFBdUNELGtCQUFJLEVBQUUsRUFBN0M7QUFBaURGLHNCQUFRLEVBQUUsVUFBM0Q7QUFBdUVTLHFCQUFPLEVBQUUsTUFBaEY7QUFBd0ZrSiwyQkFBYSxFQUFFO0FBQXZHLGFBQXpCO0FBQUEsb0NBQ0UscUVBQUMsaURBQUQ7QUFBTyxpQkFBRyxFQUFFRixJQUFJLENBQUNULEtBQWpCO0FBQXdCLGlCQUFHLEVBQUMsZUFBNUI7QUFBNEMsbUJBQUssRUFBRTtBQUFFWSx3QkFBUSxFQUFFO0FBQVo7QUFBbkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFERixlQUVFLHFFQUFDLGlEQUFEO0FBQU8saUJBQUcsRUFBQyxzQkFBWDtBQUFrQyxpQkFBRyxFQUFFLFlBQXZDO0FBQXFELHVCQUFTLEVBQUMsVUFBL0Q7QUFBMEUsbUJBQUssRUFBRTtBQUFFMUosb0JBQUksRUFBRSxFQUFSO0FBQVlDLHNCQUFNLEVBQUU7QUFBcEI7QUFBakY7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFGRixlQUlFO0FBQUssbUJBQUssRUFBRTtBQUFFTyxzQkFBTSxFQUFFLEdBQVY7QUFBZWdKLDBCQUFVLEVBQUU7QUFBM0IsZUFBWjtBQUFBLHNDQUNFO0FBQUsseUJBQVMsRUFBQywrQkFBZjtBQUErQyxxQkFBSyxFQUFFO0FBQUVoSix3QkFBTSxFQUFFLEdBQVY7QUFBZW1KLDhCQUFZLEVBQUU7QUFBN0IsaUJBQXREO0FBQUEsd0NBQ0U7QUFBSSwyQkFBUyxFQUFDLDBCQUFkO0FBQXlDLHVCQUFLLEVBQUU7QUFBRUMsNEJBQVEsRUFBRSxFQUFaO0FBQWdCQyw4QkFBVSxFQUFFLE1BQTVCO0FBQW9DQyxpQ0FBYSxFQUFFLFFBQW5EO0FBQTZEQyw4QkFBVSxFQUFFLEVBQXpFO0FBQTZFQywrQkFBVyxFQUFFO0FBQTFGLG1CQUFoRDtBQUFBLDRCQUNHVCxJQUFJLENBQUNoQjtBQURSO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBREYsZUFJRTtBQUFJLDJCQUFTLEVBQUMsMkJBQWQ7QUFBMEMsdUJBQUssRUFBRTtBQUFFcUIsNEJBQVEsRUFBRSxFQUFaO0FBQWdCQyw4QkFBVSxFQUFFLE1BQTVCO0FBQW9DQyxpQ0FBYSxFQUFFO0FBQW5ELG1CQUFqRDtBQUFBLDRCQUNHUCxJQUFJLENBQUNmO0FBRFI7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFKRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsMkJBREYsZUFVRTtBQUFLLHlCQUFTLEVBQUMsbUNBQWY7QUFBbUQscUJBQUssRUFBRTtBQUFFaEksd0JBQU0sRUFBRTtBQUFWLGlCQUExRDtBQUFBLHdDQUNFO0FBQUssdUJBQUssRUFBRTtBQUFFdUosOEJBQVUsRUFBRSxFQUFkO0FBQWtCeEosMkJBQU8sRUFBRSxNQUEzQjtBQUFtQzBKLGtDQUFjLEVBQUU7QUFBbkQsbUJBQVo7QUFBQSwwQ0FDRTtBQUFNLDZCQUFTLEVBQUMsOENBQWhCO0FBQUEsb0NBQWlFVixJQUFJLENBQUNaLE9BQXRFO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwrQkFERixFQUVHWSxJQUFJLENBQUNYLFFBQUwsaUJBQWlCO0FBQU0sNkJBQVMsRUFBQyw4Q0FBaEI7QUFBQSwyQ0FBK0Q7QUFBSSwyQkFBSyxFQUFFO0FBQUUzSyw2QkFBSyxFQUFFLEVBQVQ7QUFBYWlNLGlDQUFTLEVBQUU7QUFBeEI7QUFBWDtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQS9EO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBRnBCLEVBR0dYLElBQUksQ0FBQ1gsUUFBTCxpQkFBaUI7QUFBTSw2QkFBUyxFQUFDLDhDQUFoQjtBQUFBLG9DQUFpRVcsSUFBSSxDQUFDWCxRQUF0RTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsK0JBSHBCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSw2QkFERixlQU1FLHFFQUFDLGlEQUFEO0FBQU8scUJBQUcsRUFBRVcsSUFBSSxDQUFDVixJQUFqQjtBQUF1QixxQkFBRyxFQUFFLEtBQTVCO0FBQW1DLHVCQUFLLEVBQUU7QUFBRW1CLCtCQUFXLEVBQUU7QUFBZjtBQUExQztBQUFBO0FBQUE7QUFBQTtBQUFBLDZCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFWRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBSkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQUZGLGVBMkJFO0FBQUsscUJBQVMsRUFBQyxFQUFmO0FBQWtCLGlCQUFLLEVBQUU7QUFBRWhLLGtCQUFJLEVBQUUsR0FBUjtBQUFhRixzQkFBUSxFQUFFO0FBQXZCLGFBQXpCO0FBQUEsb0NBQ0U7QUFBRyx1QkFBUyxFQUFDLGNBQWI7QUFBQSx5QkFBNkJ5SixJQUFJLENBQUNSLE9BQUwsQ0FBYSxDQUFiLENBQTdCLGVBQTZDO0FBQU0scUJBQUssRUFBRTtBQUFFWCx1QkFBSyxFQUFFO0FBQVQsaUJBQWI7QUFBQSxnQ0FBcUNtQixJQUFJLENBQUNSLE9BQUwsQ0FBYSxDQUFiLENBQXJDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSwyQkFBN0MsT0FBNEdRLElBQUksQ0FBQ1IsT0FBTCxDQUFhLENBQWIsQ0FBNUc7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQURGLGVBR0UscUVBQUMseURBQUQ7QUFDRSxtQkFBSyxFQUFFO0FBQ0wvSSxvQkFBSSxFQUFFLENBQUMsRUFERjtBQUVMd0osMEJBQVUsRUFBRSxTQUZQO0FBR0xuSixzQkFBTSxFQUFFLG1CQUhIO0FBSUxGLHlCQUFTLEVBQUUsWUFKTjtBQUtMeUosd0JBQVEsRUFBRSxFQUxMO0FBTUxDLDBCQUFVLEVBQUUsTUFOUDtBQU9ML0ksMEJBQVUsRUFBRSxFQVBQO0FBUUxxSiwyQkFBVyxFQUFFLEVBUlI7QUFTTGxNLHFCQUFLLEVBQUUsTUFURjtBQVVMZ0Msc0JBQU0sRUFBRSxDQUFDLEdBVko7QUFXTE8sc0JBQU0sRUFBRTtBQVhILGVBRFQ7QUFjRSx5QkFBVyxFQUFFbkYsSUFkZjtBQWVFLHVCQUFTLEVBQUMsNkNBZlo7QUFnQkUsb0JBQU0sZUFBRTtBQUFBLGlFQUEyQjtBQUFNLDJCQUFTLEVBQUMsYUFBaEI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsNkJBQTNCO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQWhCVjtBQUFBO0FBQUE7QUFBQTtBQUFBLHlCQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx1QkEzQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRE07QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBUjtBQW9ERCxLQXJEQTtBQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQThERCxDQTFKTSxDOzs7Ozs7Ozs7Ozs7QUNmUDtBQUFBO0FBQUE7QUFBQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0FBO0FBRUE7QUFNTyxNQUFNK08sTUFBdUIsR0FBRyxDQUFDO0FBQUVDO0FBQUYsQ0FBRCxLQUFnQjtBQUNyRCxzQkFDRTtBQUFLLGFBQVMsRUFBQyx3RkFBZjtBQUFBLDRCQUNFLHFFQUFDLGdEQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBREYsZUFFRTtBQUNFLGVBQVMsRUFBQyxvREFEWjtBQUVFLGFBQU8sRUFBRSxNQUFNQSxNQUFNLEVBRnZCO0FBQUEsOEJBSUU7QUFBSSxpQkFBUyxFQUFDLHVCQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUpGLGVBS0U7QUFDRSxXQUFHLEVBQUMsaUJBRE47QUFFRSxpQkFBUyxFQUFDO0FBRlo7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREY7QUFlRCxDQWhCTSxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ1JQO0FBV08sTUFBTUMsS0FBc0IsR0FBRyxDQUFDO0FBQUU5TCxLQUFGO0FBQU8rTCxLQUFQO0FBQVk3RCxXQUFaO0FBQXdCekksT0FBeEI7QUFBK0J1QyxRQUEvQjtBQUF3Q21HLE9BQUssR0FBQztBQUE5QyxDQUFELEtBQXdEO0FBQzFGLHNCQUFPO0FBQUssT0FBRyxFQUFFbkksR0FBVjtBQUFlLE9BQUcsRUFBRStMLEdBQXBCO0FBQXlCLGFBQVMsRUFBRTdELFNBQXBDO0FBQStDLFVBQU0sRUFBRWxHLE1BQXZEO0FBQStELFNBQUssRUFBRXZDLEtBQXRFO0FBQTZFLFNBQUssRUFBRTBJO0FBQXBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBUDtBQUNILENBRk0sQzs7Ozs7Ozs7Ozs7O0FDWFA7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNaQTtBQUNBO0FBRU8sTUFBTTZELElBQWMsR0FBRyxNQUFNO0FBQ2xDO0FBQUE7QUFDRTtBQUNBLHlFQUFDLGlEQUFEO0FBQU8sU0FBRyxFQUFDLHVCQUFYO0FBQW1DLFNBQUcsRUFBQyxRQUF2QztBQUFnRCxXQUFLLEVBQUMsVUFBdEQ7QUFBaUUsWUFBTSxFQUFDLE1BQXhFO0FBQStFLGVBQVMsRUFBQztBQUF6RjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRkY7QUFJRCxDQUxNLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0hQO0FBRUE7QUFFTyxNQUFNQyxJQUFjLEdBQUcsTUFBTTtBQUNsQyxzQkFDRTtBQUFLLGFBQVMsRUFBQyx5Q0FBZjtBQUFBLDJCQUNFO0FBQUssZUFBUyxFQUFDLG1CQUFmO0FBQUEsOEJBQ0U7QUFBSSxpQkFBUyxFQUFDLDBCQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURGLGVBRUU7QUFBRyxpQkFBUyxFQUFDLHlCQUFiO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUZGLGVBS0UscUVBQUMsa0RBQUQ7QUFBUSxZQUFJLEVBQUMsUUFBYjtBQUFBLCtCQUNFO0FBQUcsY0FBSSxFQUFDLHNDQUFSO0FBQStDLGdCQUFNLEVBQUMsUUFBdEQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFERjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUxGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQWVELENBaEJNLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0hQO0FBQ0E7QUFXTyxNQUFNQyxPQUF3QixHQUFHLENBQUM7QUFDdkN2RSxPQUR1QztBQUV2Q3dFLFVBRnVDO0FBR3ZDckgsSUFIdUM7QUFJdkNtRCxTQUp1QztBQUt2Q0MsV0FBUyxHQUFHLEVBTDJCO0FBTXZDa0UsT0FBSyxHQUFHO0FBTitCLENBQUQsS0FPbEM7QUFDSixzQkFDRTtBQUNFLGFBQVMsRUFBRyxHQUFFbEUsU0FBVSwrREFEMUI7QUFFRSxTQUFLLEVBQUU7QUFBRW1FLGtCQUFZLEVBQUU7QUFBaEIsS0FGVDtBQUdFLFdBQU8sRUFBRSxNQUFNcEUsT0FBTyxDQUFDbkQsRUFBRCxDQUh4QjtBQUFBLDRCQUtFO0FBQUEsZ0JBQU82QztBQUFQO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBTEYsRUFPS3dFLFFBQVEsSUFBSUMsS0FBYixHQUNDLENBQUNELFFBQUYsZ0JBQ0U7QUFBTSxlQUFTLEVBQUMsdUJBQWhCO0FBQUEsc0JBQTBDLEdBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFERixnQkFHRSxxRUFBQyxpREFBRDtBQUNFLFNBQUcsRUFBRSwwQkFEUDtBQUVFLFNBQUcsRUFBQyxZQUZOO0FBR0UsZUFBUyxFQUFDO0FBSFo7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFKRixHQVVFLElBakJOO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQURGO0FBcUJELENBN0JNLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDYlA7QUFZTyxNQUFNRyxHQUFvQixHQUFHLENBQUM7QUFBRUgsVUFBRjtBQUFZeEUsT0FBWjtBQUFtQjdDLElBQW5CO0FBQXVCbUQsU0FBdkI7QUFBZ0NDLFdBQVMsR0FBRyxFQUE1QztBQUFnREMsT0FBSyxHQUFHO0FBQXhELENBQUQsS0FBeUU7QUFDekcsUUFBTW9FLFVBQVUsR0FBR0osUUFBUSxHQUFHLGNBQUgsR0FBb0IsS0FBL0M7O0FBQ0Esc0JBQVE7QUFBTSxhQUFTLEVBQUVqRSxTQUFTLEdBQUcsR0FBWixHQUFrQnFFLFVBQW5DO0FBQStDLFNBQUssRUFBRXBFLEtBQXREO0FBQTZELFdBQU8sRUFBRSxNQUFNO0FBQUUsVUFBSUYsT0FBSixFQUFhQSxPQUFPLENBQUNuRCxFQUFELENBQVA7QUFBYSxLQUF4RztBQUFBLGNBQ0g2QztBQURHO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBUjtBQUdILENBTE0sQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ1pQO0FBQ0E7QUFDQTtBQUdBLE1BQU05SyxJQUFJLEdBQUcsQ0FDVDtBQUNJZ00sV0FBUyxFQUFFLHFCQURmO0FBRUlsQixPQUFLLEVBQUUscURBRlg7QUFHSW1CLFFBQU0sRUFBRSxhQUhaO0FBSUlDLFlBQVUsRUFBRSxRQUpoQjtBQUtJQyxjQUFZLEVBQUUsTUFMbEI7QUFNSUMsZUFBYSxFQUFFO0FBTm5CLENBRFMsRUFTVDtBQUNJSixXQUFTLEVBQUUscUJBRGY7QUFFSWxCLE9BQUssRUFBRSxxREFGWDtBQUdJbUIsUUFBTSxFQUFFLGFBSFo7QUFJSUMsWUFBVSxFQUFFLFNBSmhCO0FBS0lDLGNBQVksRUFBRSxNQUxsQjtBQU1JQyxlQUFhLEVBQUU7QUFObkIsQ0FUUyxDQUFiO0FBbUJPLE1BQU11RCxXQUFxQixHQUFHLE1BQU07QUFFdkMsc0JBQVE7QUFBSyxhQUFTLEVBQUMsaUNBQWY7QUFBQSw0QkFDSjtBQUFLLGVBQVMsRUFBQyxzQkFBZjtBQUFBLDhCQUNJO0FBQUssaUJBQVMsRUFBQyxNQUFmO0FBQUEsZ0NBQ0k7QUFBTSxtQkFBUyxFQUFDLDZEQUFoQjtBQUFBLDBCQUFnRixrQkFBaEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQURKLGVBRUk7QUFBTSxtQkFBUyxFQUFDLHVCQUFoQjtBQUFBLG9CQUF5QztBQUF6QztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUZKO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFESixlQU1JLHFFQUFDLGtGQUFEO0FBQWlCLGFBQUssRUFBQyxrQkFBdkI7QUFBMEMsaUJBQVMsRUFBQztBQUFwRDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU5KO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFESSxlQVNKO0FBQUssZUFBUyxFQUFDLDhCQUFmO0FBQUEsZ0JBRVEzUCxJQUFJLENBQUMyTCxHQUFMLENBQVVjLFdBQUQsSUFBaUI7QUFDdEIsNEJBQVEscUVBQUMsdURBQUQ7QUFFSixtQkFBUyxFQUFFQSxXQUFXLENBQUNULFNBRm5CO0FBR0osZUFBSyxFQUFFUyxXQUFXLENBQUMzQixLQUhmO0FBSUosZ0JBQU0sRUFBRTJCLFdBQVcsQ0FBQ1IsTUFKaEI7QUFLSixvQkFBVSxFQUFFUSxXQUFXLENBQUNQLFVBTHBCO0FBTUosc0JBQVksRUFBRU8sV0FBVyxDQUFDTixZQU50QjtBQU9KLHVCQUFhLEVBQUVNLFdBQVcsQ0FBQ0wsYUFQdkI7QUFRSixpQkFBTyxFQUFHbkUsRUFBRCxJQUFRMUIsT0FBTyxDQUFDbUcsR0FBUixDQUFZekUsRUFBWjtBQVJiLFdBQ0N3RSxXQUFXLENBQUNQLFVBRGI7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFBUjtBQVVILE9BWEQ7QUFGUjtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQVRJO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFSO0FBMkJILENBN0JNLEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN4QlA7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUdBLE1BQU0wRCxPQUFPLEdBQUcsQ0FBQztBQUNmOUUsT0FBSyxFQUFFLFdBRFE7QUFFZjdDLElBQUUsRUFBRTtBQUZXLENBQUQsRUFLaEI7QUFDRTZDLE9BQUssRUFBRSxRQURUO0FBRUU3QyxJQUFFLEVBQUU7QUFGTixDQUxnQixFQVNoQjtBQUNFNkMsT0FBSyxFQUFFLFVBRFQ7QUFFRTdDLElBQUUsRUFBRTtBQUZOLENBVGdCLEVBYWhCO0FBQ0U2QyxPQUFLLEVBQUUsS0FEVDtBQUVFN0MsSUFBRSxFQUFFO0FBRk4sQ0FiZ0IsRUFpQmhCO0FBQ0U2QyxPQUFLLEVBQUUsU0FEVDtBQUVFN0MsSUFBRSxFQUFFO0FBRk4sQ0FqQmdCLEVBcUJaO0FBQ0Y2QyxPQUFLLEVBQUUsUUFETDtBQUVGN0MsSUFBRSxFQUFFO0FBRkYsQ0FyQlksRUF3QmI7QUFDRDZDLE9BQUssRUFBRSxRQUROO0FBRUQ3QyxJQUFFLEVBQUU7QUFGSCxDQXhCYSxFQTJCYjtBQUNENkMsT0FBSyxFQUFFLGVBRE47QUFFRDdDLElBQUUsRUFBRTtBQUZILENBM0JhLEVBOEJiO0FBQ0Q2QyxPQUFLLEVBQUUsY0FETjtBQUVEN0MsSUFBRSxFQUFFO0FBRkgsQ0E5QmEsRUFpQ2I7QUFDRDZDLE9BQUssRUFBRSxRQUROO0FBRUQ3QyxJQUFFLEVBQUU7QUFGSCxDQWpDYSxDQUFoQjtBQXdDTyxNQUFNNEgsSUFBYyxHQUFHLE1BQU07QUFFbEMsUUFBTTtBQUFFN1AsUUFBSSxFQUFFO0FBQUVSLGVBQVMsRUFBRXNRO0FBQWI7QUFBUixNQUF3Q0MsK0RBQVEsQ0FBQ3pGLG9FQUFjLENBQUNGLGtCQUFoQixDQUF0RDtBQUVBN0QsU0FBTyxDQUFDbUcsR0FBUixDQUFZb0QsWUFBWjtBQUVBLFFBQU16RSxTQUFTLEdBQUd5RSxZQUFZLENBQUM1TyxJQUFiLEdBQW9CLFNBQXBCLEdBQWdDLGtCQUFsRDtBQUNBLHNCQUNFO0FBQUssYUFBUyxFQUFHLDZFQUE0RW1LLFNBQVUsRUFBdkc7QUFBMEcsU0FBSyxFQUFFO0FBQUNsRyxZQUFNLEVBQUM7QUFBUixLQUFqSDtBQUFBLDRCQUNFO0FBQUssZUFBUyxFQUFDLG1EQUFmO0FBQUEsOEJBQ0U7QUFBQSwrQkFDRSxxRUFBQyxpREFBRDtBQUFPLGFBQUcsRUFBQyx1QkFBWDtBQUFtQyxhQUFHLEVBQUMsY0FBdkM7QUFBc0QsbUJBQVMsRUFBQztBQUFoRTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFERixlQUlFO0FBQUssaUJBQVMsRUFBQyxxQ0FBZjtBQUFxRCxhQUFLLEVBQUU7QUFBRXVKLG9CQUFVLEVBQUU7QUFBZCxTQUE1RDtBQUFBLGdDQUNFLHFFQUFDLGdEQUFEO0FBQVMsZUFBSyxFQUFDLFVBQWY7QUFBMEIsaUJBQU8sRUFBRWtCLE9BQW5DO0FBQTRDLG1CQUFTLEVBQUMseUJBQXREO0FBQWdGLHFCQUFXLEVBQUdJLEtBQUQsSUFBVztBQUN0R3pKLG1CQUFPLENBQUNtRyxHQUFSLENBQVlzRCxLQUFaO0FBQ0Q7QUFGRDtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQURGLGVBS0UscUVBQUMsZ0RBQUQ7QUFBUyxlQUFLLEVBQUMsY0FBZjtBQUE4QixpQkFBTyxFQUFFSixPQUF2QztBQUFnRCxtQkFBUyxFQUFDLG1CQUExRDtBQUE4RSxxQkFBVyxFQUFHSSxLQUFELElBQVc7QUFDcEd6SixtQkFBTyxDQUFDbUcsR0FBUixDQUFZc0QsS0FBWjtBQUNEO0FBRkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSkYsZUFhRTtBQUFLLGlCQUFTLEVBQUMseUJBQWY7QUFBQSxnQ0FDRTtBQUFLLG1CQUFTLEVBQUMsdUNBQWY7QUFBdUQsaUJBQU8sRUFBRSxNQUFNQyx1RUFBaUIsQ0FBQ2xHLFVBQWxCLEVBQXRFO0FBQUEsa0NBQ0U7QUFBSSxxQkFBUyxFQUFDLG9DQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQURGLGVBRUUscUVBQUMsaURBQUQ7QUFBTyxlQUFHLEVBQUMsc0JBQVg7QUFBa0MscUJBQVMsRUFBQyxxQ0FBNUM7QUFBa0YsZUFBRyxFQUFDO0FBQXRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBRkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQURGLGVBS0UscUVBQUMsZ0VBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxxQkFMRixlQU1FLHFFQUFDLGlGQUFEO0FBQVEsZUFBSyxFQUFFLFdBQVcsV0FBMUI7QUFBdUMsbUJBQVMsRUFBQyw0REFBakQ7QUFBOEcsYUFBRyxFQUFDO0FBQWxIO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBTkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQWJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFERixlQXVCRSxxRUFBQyxnREFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXZCRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQTJCRCxDQWxDTSxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNsRFA7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVPLE1BQU1tRyxPQUFpQixHQUFHLE1BQU07QUFDckMsUUFBTSxDQUFDQyxhQUFELEVBQWdCQyxnQkFBaEIsSUFBb0M3SCw0Q0FBSyxDQUFDOEgsUUFBTixDQUFlLENBQWYsQ0FBMUM7O0FBRUEsUUFBTUMsVUFBVSxHQUFJekQsS0FBRCxJQUFtQjtBQUNwQyxRQUFJQSxLQUFLLElBQUlzRCxhQUFiLEVBQTRCLE9BQU8sSUFBUCxDQUE1QixLQUNLLE9BQU8sS0FBUDtBQUNOLEdBSEQ7O0FBS0Esc0JBQ0U7QUFDRSxhQUFTLEVBQUMscUZBRFo7QUFFRSxTQUFLLEVBQUU7QUFBRXhMLFVBQUksRUFBRSxDQUFSO0FBQVc0SixjQUFRLEVBQUUsRUFBckI7QUFBeUJDLGdCQUFVLEVBQUU7QUFBckMsS0FGVDtBQUFBLDRCQUlFO0FBQUssZUFBUyxFQUFDLE9BQWY7QUFBQSw4QkFDRTtBQUFBLGtCQUNHalIsa0RBQU8sQ0FBQ0MsT0FBUixDQUFnQm1PLEdBQWhCLENBQW9CLENBQUM0RSxRQUFELEVBQWdCMUQsS0FBaEIsS0FBMEI7QUFDN0MsOEJBQ0UscUVBQUMsbURBQUQ7QUFDRSxpQkFBSyxFQUFFMEQsUUFBUSxDQUFDblQsSUFEbEI7QUFFRSxxQkFBUyxFQUNQLENBQUNrVCxVQUFVLENBQUN6RCxLQUFELENBQVgsR0FDSSxrQ0FESixHQUVJLGtDQUxSO0FBT0UsaUJBQUssRUFBRSxJQVBUO0FBU0UsY0FBRSxFQUFFMEQsUUFBUSxDQUFDcFQsR0FUZjtBQVVFLG1CQUFPLEVBQUUsTUFBTWlULGdCQUFnQixDQUFDdkQsS0FBRCxDQVZqQztBQVdFLG9CQUFRLEVBQUV5RCxVQUFVLENBQUN6RCxLQUFEO0FBWHRCLGFBUU8wRCxRQUFRLENBQUNwVCxHQVJoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQURGO0FBZUQsU0FoQkE7QUFESDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURGLGVBcUJFO0FBQUEsa0JBQ0dJLGtEQUFPLENBQUNFLFNBQVIsQ0FBa0JrTyxHQUFsQixDQUF1QjRFLFFBQUQsSUFBbUI7QUFDeEMsOEJBQ0U7QUFFRSxxQkFBUyxFQUFDLHNCQUZaO0FBR0UsaUJBQUssRUFBRTtBQUFFZiwwQkFBWSxFQUFFO0FBQWhCLGFBSFQ7QUFBQSxvQ0FLRTtBQUFJLHVCQUFTLEVBQUMseUJBQWQ7QUFBQSx3QkFBeUNlLFFBQVEsQ0FBQ25UO0FBQWxEO0FBQUE7QUFBQTtBQUFBO0FBQUEseUJBTEYsZUFNRTtBQUFNLHVCQUFTLEVBQUMseUJBQWhCO0FBQUEsOEJBQTRDLEdBQTVDO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSx5QkFORjtBQUFBLGFBQ09tVCxRQUFRLENBQUNwVCxHQURoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLHVCQURGO0FBVUQsU0FYQTtBQURIO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBckJGO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFKRixlQXdDRTtBQUFLLGVBQVMsRUFBQyxRQUFmO0FBQUEsOEJBQ0U7QUFBTSxpQkFBUyxFQUFDLE1BQWhCO0FBQUEsZ0NBQ0U7QUFBSSxtQkFBUyxFQUFDLGlDQUFkO0FBQWdELGVBQUssRUFBRTtBQUFFb1Isb0JBQVEsRUFBQyxFQUFYO0FBQWVDLHNCQUFVLEVBQUM7QUFBMUIsV0FBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBREYsZUFFRTtBQUFJLG1CQUFTLEVBQUMsaUNBQWQ7QUFBZ0QsZUFBSyxFQUFFO0FBQUNnQyxxQkFBUyxFQUFDLEVBQVg7QUFBY2hDLHNCQUFVLEVBQUM7QUFBekIsV0FBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBRkYsZUFLRTtBQUNFLG1CQUFTLEVBQUMsc0NBRFo7QUFFRSxlQUFLLEVBQUU7QUFBRXpCLGlCQUFLLEVBQUUsU0FBVDtBQUFxQnlELHFCQUFTLEVBQUMsRUFBL0I7QUFBa0NqQyxvQkFBUSxFQUFDLEVBQTNDO0FBQStDQyxzQkFBVSxFQUFDLE1BQTFEO0FBQWlFaUMsbUJBQU8sRUFBQyxHQUF6RTtBQUE4RXRMLGtCQUFNLEVBQUM7QUFBckYsV0FGVDtBQUdFLGNBQUksRUFBQyxPQUhQO0FBSUUscUJBQVcsRUFBQztBQUpkO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBTEYsZUFXRSxxRUFBQyxpRkFBRDtBQUNFLGVBQUssRUFBQyxXQURSO0FBRUUsYUFBRyxFQUFDLGtCQUZOO0FBR0UsaUJBQU8sRUFBRSxNQUFNb0IsT0FBTyxDQUFDbUcsR0FBUixDQUFZLFdBQVosQ0FIakI7QUFJRSxtQkFBUyxFQUFDLG1CQUpaO0FBS0UsZUFBSyxFQUFFO0FBQUNLLGlCQUFLLEVBQUU7QUFBUjtBQUxUO0FBQUE7QUFBQTtBQUFBO0FBQUEscUJBWEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQURGLGVBb0JFO0FBQUssaUJBQVMsRUFBQyxPQUFmO0FBQXVCLGFBQUssRUFBRTtBQUFDeUQsbUJBQVMsRUFBQyxFQUFYO0FBQWdCaEIsc0JBQVksRUFBQztBQUE3QixTQUE5QjtBQUFBLGtCQUNHOVIsa0VBQVcsQ0FBQ2lPLEdBQVosQ0FBaUJpQixJQUFELElBQVU7QUFDekIsOEJBQ0U7QUFBRyxxQkFBUyxFQUFDLFdBQWI7QUFBeUIsZ0JBQUksRUFBRUEsSUFBSSxDQUFDdlAsSUFBcEM7QUFBQSxtQ0FDRSxxRUFBQyxpREFBRDtBQUNFLGlCQUFHLEVBQUV1UCxJQUFJLENBQUNqUCxRQURaO0FBRUUsaUJBQUcsRUFBRWlQLElBQUksQ0FBQ3hQLElBRlo7QUFHRSx1QkFBUyxFQUFDO0FBSFosZUFJT3dQLElBQUksQ0FBQ3pQLEdBSlo7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsdUJBREY7QUFVRCxTQVhBO0FBREg7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFwQkY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQXhDRjtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFERjtBQThFRCxDQXRGTSxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNOUDtBQUNBO0FBVU8sTUFBTXVULE9BQXdCLEdBQUcsQ0FBQztBQUFFNUYsT0FBRjtBQUFTOEUsU0FBVDtBQUFrQmUsYUFBbEI7QUFBOEJ0RixXQUFTLEdBQUM7QUFBeEMsQ0FBRCxLQUF5RDtBQUM3RixRQUFNLENBQUNpRSxRQUFELEVBQVdzQixXQUFYLElBQTBCckksNENBQUssQ0FBQzhILFFBQU4sQ0FBZSxFQUFmLENBQWhDOztBQUVBLFFBQU1DLFVBQVUsR0FBSXJJLEVBQUQsSUFBUTtBQUN2QixRQUFJcUgsUUFBUSxDQUFDdUIsT0FBVCxDQUFpQjVJLEVBQWpCLElBQXVCLENBQUMsQ0FBNUIsRUFBK0I7QUFDM0IsYUFBTyxJQUFQO0FBQ0g7O0FBRUQsV0FBTyxLQUFQO0FBRUgsR0FQRDs7QUFTQSxRQUFNK0csTUFBTSxHQUFJL0csRUFBRCxJQUFRO0FBQ25CLFFBQUlxSSxVQUFVLENBQUNySSxFQUFELENBQVYsS0FBbUIsSUFBdkIsRUFBNkI7QUFDekIsWUFBTTRFLEtBQUssR0FBR3lDLFFBQVEsQ0FBQ3VCLE9BQVQsQ0FBaUI1SSxFQUFqQixDQUFkO0FBQ0EySSxpQkFBVyxDQUFDdEIsUUFBUSxDQUFDd0IsTUFBVCxDQUFnQmpFLEtBQUssR0FBQyxDQUF0QixFQUF5QixDQUF6QixDQUFELENBQVg7QUFDSCxLQUhELE1BR087QUFDSCtELGlCQUFXLENBQUMsQ0FBQyxHQUFHdEIsUUFBSixFQUFjckgsRUFBZCxDQUFELENBQVg7QUFDSDs7QUFDRDBJLGVBQVcsQ0FBQ3JCLFFBQUQsQ0FBWDtBQUNILEdBUkQ7O0FBU0Esc0JBQ0k7QUFBSyxhQUFTLEVBQUcsVUFBU2pFLFNBQVUsRUFBcEM7QUFBQSw0QkFDSTtBQUFLLGVBQVMsRUFBQyxrRUFBZjtBQUFBLGdCQUFtRlA7QUFBbkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFESixlQUVJO0FBQUssZUFBUyxFQUFDLDRDQUFmO0FBQUEsZ0JBRVE4RSxPQUFPLENBQUNqRSxHQUFSLENBQWFvRixHQUFELElBQVM7QUFDakIsNEJBQVEscUVBQUMsK0NBQUQ7QUFBSyxZQUFFLEVBQUVqRyxLQUFLLEdBQUNpRyxHQUFHLENBQUM5SSxFQUFuQjtBQUFvQyxtQkFBUyxFQUFDLFdBQTlDO0FBQTBELGVBQUssRUFBRThJLEdBQUcsQ0FBQ2pHLEtBQXJFO0FBQTRFLGtCQUFRLEVBQUV3RixVQUFVLENBQUNTLEdBQUcsQ0FBQzlJLEVBQUwsQ0FBaEc7QUFBMEcsaUJBQU8sRUFBRSxNQUFNO0FBQzdIK0csa0JBQU0sQ0FBQytCLEdBQUcsQ0FBQzlJLEVBQUwsQ0FBTjtBQUNIO0FBRk8sV0FBNEI4SSxHQUFHLENBQUM5SSxFQUFoQztBQUFBO0FBQUE7QUFBQTtBQUFBLHFCQUFSO0FBR0gsT0FKRDtBQUZSO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRko7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBREo7QUFjSCxDQW5DTSxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNYUDtBQUVBO0FBQ0E7QUFDQTtBQUlBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFZTyxNQUFNK0ksSUFBcUIsR0FBRyxDQUFDO0FBQUV4RjtBQUFGLENBQUQsS0FBa0I7QUFDckQsUUFBTTtBQUNKeEwsUUFBSSxFQUFFO0FBQUVSLGVBQVMsRUFBRXNRO0FBQWI7QUFERixNQUVGQywrREFBUSxDQUFDekYsb0VBQWMsQ0FBQ0Ysa0JBQWhCLENBRlo7QUFHQTZHLHlEQUFTLENBQUMsTUFBTTtBQUNkQyxzREFBTSxDQUFDQyxNQUFQLENBQWNDLEVBQWQsQ0FBaUIsa0JBQWpCLEVBQXNDeEksR0FBRCxJQUFTO0FBQzVDeUksc0RBQVMsQ0FBQ3hLLEtBQVY7QUFDRCxLQUZEO0FBR0FxSyxzREFBTSxDQUFDQyxNQUFQLENBQWNDLEVBQWQsQ0FBaUIscUJBQWpCLEVBQXdDLE1BQU1DLGdEQUFTLENBQUNDLElBQVYsRUFBOUM7QUFDQUosc0RBQU0sQ0FBQ0MsTUFBUCxDQUFjQyxFQUFkLENBQWlCLGtCQUFqQixFQUFxQyxNQUFNQyxnREFBUyxDQUFDQyxJQUFWLEVBQTNDO0FBQ0FELG9EQUFTLENBQUNFLFNBQVYsQ0FBb0I7QUFBRUMsaUJBQVcsRUFBRTtBQUFmLEtBQXBCO0FBQ0QsR0FQUSxFQU9OLEVBUE0sQ0FBVDtBQVFBLFFBQU1uRyxTQUFTLEdBQUcsQ0FBQ3lFLFlBQVksQ0FBQzVPLElBQWQsR0FDZCxTQURjLEdBRWQsbUJBRko7QUFJQSxzQkFDRTtBQUFBLDRCQUNFO0FBQUssZUFBUyxFQUFHLDBDQUF5Q21LLFNBQVUsRUFBcEU7QUFBQSw4QkFDRSxxRUFBQyx5REFBRDtBQUFRLGNBQU0sRUFBRTRFLHVFQUFpQixDQUFDbEc7QUFBbEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFERixlQUVFO0FBQUssaUJBQVMsRUFBQyxXQUFmO0FBQUEsa0JBQTRCeUI7QUFBNUI7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFGRixlQUdFLHFFQUFDLHlEQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBSEY7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQURGLGVBTUUscUVBQUMsMENBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxpQkFORjtBQUFBLGtCQURGO0FBVUQsQ0ExQk0sQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUN0QlA7QUFBZSx5RUFBVWlHLElBQVYsRUFBZTtBQUMxQixVQUFRQSxJQUFSOztBQUdBLFNBQU8sa0JBQVA7QUFDSCxDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ1BELDJDOzs7Ozs7Ozs7OztBQ0FBLHdEOzs7Ozs7Ozs7OztBQ0FBLHNDOzs7Ozs7Ozs7OztBQ0FBLDBDOzs7Ozs7Ozs7OztBQ0FBLHdDOzs7Ozs7Ozs7OztBQ0FBLHNDOzs7Ozs7Ozs7OztBQ0FBLGtDOzs7Ozs7Ozs7OztBQ0FBLHdDOzs7Ozs7Ozs7OztBQ0FBLGtEIiwiZmlsZSI6InBhZ2VzL19hcHAuanMiLCJzb3VyY2VzQ29udGVudCI6WyIgXHQvLyBUaGUgbW9kdWxlIGNhY2hlXG4gXHR2YXIgaW5zdGFsbGVkTW9kdWxlcyA9IHJlcXVpcmUoJy4uL3Nzci1tb2R1bGUtY2FjaGUuanMnKTtcblxuIFx0Ly8gVGhlIHJlcXVpcmUgZnVuY3Rpb25cbiBcdGZ1bmN0aW9uIF9fd2VicGFja19yZXF1aXJlX18obW9kdWxlSWQpIHtcblxuIFx0XHQvLyBDaGVjayBpZiBtb2R1bGUgaXMgaW4gY2FjaGVcbiBcdFx0aWYoaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF0pIHtcbiBcdFx0XHRyZXR1cm4gaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF0uZXhwb3J0cztcbiBcdFx0fVxuIFx0XHQvLyBDcmVhdGUgYSBuZXcgbW9kdWxlIChhbmQgcHV0IGl0IGludG8gdGhlIGNhY2hlKVxuIFx0XHR2YXIgbW9kdWxlID0gaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF0gPSB7XG4gXHRcdFx0aTogbW9kdWxlSWQsXG4gXHRcdFx0bDogZmFsc2UsXG4gXHRcdFx0ZXhwb3J0czoge31cbiBcdFx0fTtcblxuIFx0XHQvLyBFeGVjdXRlIHRoZSBtb2R1bGUgZnVuY3Rpb25cbiBcdFx0dmFyIHRocmV3ID0gdHJ1ZTtcbiBcdFx0dHJ5IHtcbiBcdFx0XHRtb2R1bGVzW21vZHVsZUlkXS5jYWxsKG1vZHVsZS5leHBvcnRzLCBtb2R1bGUsIG1vZHVsZS5leHBvcnRzLCBfX3dlYnBhY2tfcmVxdWlyZV9fKTtcbiBcdFx0XHR0aHJldyA9IGZhbHNlO1xuIFx0XHR9IGZpbmFsbHkge1xuIFx0XHRcdGlmKHRocmV3KSBkZWxldGUgaW5zdGFsbGVkTW9kdWxlc1ttb2R1bGVJZF07XG4gXHRcdH1cblxuIFx0XHQvLyBGbGFnIHRoZSBtb2R1bGUgYXMgbG9hZGVkXG4gXHRcdG1vZHVsZS5sID0gdHJ1ZTtcblxuIFx0XHQvLyBSZXR1cm4gdGhlIGV4cG9ydHMgb2YgdGhlIG1vZHVsZVxuIFx0XHRyZXR1cm4gbW9kdWxlLmV4cG9ydHM7XG4gXHR9XG5cblxuIFx0Ly8gZXhwb3NlIHRoZSBtb2R1bGVzIG9iamVjdCAoX193ZWJwYWNrX21vZHVsZXNfXylcbiBcdF9fd2VicGFja19yZXF1aXJlX18ubSA9IG1vZHVsZXM7XG5cbiBcdC8vIGV4cG9zZSB0aGUgbW9kdWxlIGNhY2hlXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLmMgPSBpbnN0YWxsZWRNb2R1bGVzO1xuXG4gXHQvLyBkZWZpbmUgZ2V0dGVyIGZ1bmN0aW9uIGZvciBoYXJtb255IGV4cG9ydHNcbiBcdF9fd2VicGFja19yZXF1aXJlX18uZCA9IGZ1bmN0aW9uKGV4cG9ydHMsIG5hbWUsIGdldHRlcikge1xuIFx0XHRpZighX193ZWJwYWNrX3JlcXVpcmVfXy5vKGV4cG9ydHMsIG5hbWUpKSB7XG4gXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIG5hbWUsIHsgZW51bWVyYWJsZTogdHJ1ZSwgZ2V0OiBnZXR0ZXIgfSk7XG4gXHRcdH1cbiBcdH07XG5cbiBcdC8vIGRlZmluZSBfX2VzTW9kdWxlIG9uIGV4cG9ydHNcbiBcdF9fd2VicGFja19yZXF1aXJlX18uciA9IGZ1bmN0aW9uKGV4cG9ydHMpIHtcbiBcdFx0aWYodHlwZW9mIFN5bWJvbCAhPT0gJ3VuZGVmaW5lZCcgJiYgU3ltYm9sLnRvU3RyaW5nVGFnKSB7XG4gXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFN5bWJvbC50b1N0cmluZ1RhZywgeyB2YWx1ZTogJ01vZHVsZScgfSk7XG4gXHRcdH1cbiBcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsICdfX2VzTW9kdWxlJywgeyB2YWx1ZTogdHJ1ZSB9KTtcbiBcdH07XG5cbiBcdC8vIGNyZWF0ZSBhIGZha2UgbmFtZXNwYWNlIG9iamVjdFxuIFx0Ly8gbW9kZSAmIDE6IHZhbHVlIGlzIGEgbW9kdWxlIGlkLCByZXF1aXJlIGl0XG4gXHQvLyBtb2RlICYgMjogbWVyZ2UgYWxsIHByb3BlcnRpZXMgb2YgdmFsdWUgaW50byB0aGUgbnNcbiBcdC8vIG1vZGUgJiA0OiByZXR1cm4gdmFsdWUgd2hlbiBhbHJlYWR5IG5zIG9iamVjdFxuIFx0Ly8gbW9kZSAmIDh8MTogYmVoYXZlIGxpa2UgcmVxdWlyZVxuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy50ID0gZnVuY3Rpb24odmFsdWUsIG1vZGUpIHtcbiBcdFx0aWYobW9kZSAmIDEpIHZhbHVlID0gX193ZWJwYWNrX3JlcXVpcmVfXyh2YWx1ZSk7XG4gXHRcdGlmKG1vZGUgJiA4KSByZXR1cm4gdmFsdWU7XG4gXHRcdGlmKChtb2RlICYgNCkgJiYgdHlwZW9mIHZhbHVlID09PSAnb2JqZWN0JyAmJiB2YWx1ZSAmJiB2YWx1ZS5fX2VzTW9kdWxlKSByZXR1cm4gdmFsdWU7XG4gXHRcdHZhciBucyA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG4gXHRcdF9fd2VicGFja19yZXF1aXJlX18ucihucyk7XG4gXHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShucywgJ2RlZmF1bHQnLCB7IGVudW1lcmFibGU6IHRydWUsIHZhbHVlOiB2YWx1ZSB9KTtcbiBcdFx0aWYobW9kZSAmIDIgJiYgdHlwZW9mIHZhbHVlICE9ICdzdHJpbmcnKSBmb3IodmFyIGtleSBpbiB2YWx1ZSkgX193ZWJwYWNrX3JlcXVpcmVfXy5kKG5zLCBrZXksIGZ1bmN0aW9uKGtleSkgeyByZXR1cm4gdmFsdWVba2V5XTsgfS5iaW5kKG51bGwsIGtleSkpO1xuIFx0XHRyZXR1cm4gbnM7XG4gXHR9O1xuXG4gXHQvLyBnZXREZWZhdWx0RXhwb3J0IGZ1bmN0aW9uIGZvciBjb21wYXRpYmlsaXR5IHdpdGggbm9uLWhhcm1vbnkgbW9kdWxlc1xuIFx0X193ZWJwYWNrX3JlcXVpcmVfXy5uID0gZnVuY3Rpb24obW9kdWxlKSB7XG4gXHRcdHZhciBnZXR0ZXIgPSBtb2R1bGUgJiYgbW9kdWxlLl9fZXNNb2R1bGUgP1xuIFx0XHRcdGZ1bmN0aW9uIGdldERlZmF1bHQoKSB7IHJldHVybiBtb2R1bGVbJ2RlZmF1bHQnXTsgfSA6XG4gXHRcdFx0ZnVuY3Rpb24gZ2V0TW9kdWxlRXhwb3J0cygpIHsgcmV0dXJuIG1vZHVsZTsgfTtcbiBcdFx0X193ZWJwYWNrX3JlcXVpcmVfXy5kKGdldHRlciwgJ2EnLCBnZXR0ZXIpO1xuIFx0XHRyZXR1cm4gZ2V0dGVyO1xuIFx0fTtcblxuIFx0Ly8gT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLm8gPSBmdW5jdGlvbihvYmplY3QsIHByb3BlcnR5KSB7IHJldHVybiBPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob2JqZWN0LCBwcm9wZXJ0eSk7IH07XG5cbiBcdC8vIF9fd2VicGFja19wdWJsaWNfcGF0aF9fXG4gXHRfX3dlYnBhY2tfcmVxdWlyZV9fLnAgPSBcIlwiO1xuXG5cbiBcdC8vIExvYWQgZW50cnkgbW9kdWxlIGFuZCByZXR1cm4gZXhwb3J0c1xuIFx0cmV0dXJuIF9fd2VicGFja19yZXF1aXJlX18oX193ZWJwYWNrX3JlcXVpcmVfXy5zID0gMCk7XG4iLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJuZXh0L2Rpc3QvbmV4dC1zZXJ2ZXIvbGliL2hlYWQuanNcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwibmV4dC9kaXN0L25leHQtc2VydmVyL2xpYi90by1iYXNlLTY0LmpzXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIm5leHQvZGlzdC9uZXh0LXNlcnZlci9saWIvdXRpbHMuanNcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwibmV4dC9kaXN0L25leHQtc2VydmVyL3NlcnZlci9pbWFnZS1jb25maWcuanNcIik7IiwiY29uc3QgZm9vdGVybWVudSA9IFtcbiAge1xuICAgIGtleTogXCJmb290ZXJfYWJvdXRcIixcbiAgICBuYW1lOiBcIkFib3V0XCIsXG4gICAgbGluazogXCJcIixcbiAgfSxcbiAge1xuICAgIGtleTogXCJmb290ZXJfcG9ydGZvbGlvXCIsXG4gICAgbmFtZTogXCJQb3J0Zm9saW9cIixcbiAgICBsaW5rOiBcIi9wb3J0Zm9saW9cIixcbiAgfSxcbiAge1xuICAgIGtleTogXCJmb290ZXJfYmxvZ1wiLFxuICAgIG5hbWU6IFwiQmxvZ1wiLFxuICAgIGxpbms6IFwiXCIsXG4gIH0sXG4gIHtcbiAgICBrZXk6IFwiZm9vdGVyX2Fkdmlzb3J5X3RlYW1cIixcbiAgICBuYW1lOiBcIkFkdmlzb3J5IFRlYW1cIixcbiAgICBsaW5rOiBcIi9hZHZpc29yeVRlYW1cIixcbiAgfSxcbiAge1xuICAgIGtleTogXCJmb290ZXJfY29udGFjdFwiLFxuICAgIG5hbWU6IFwiQ29udGFjdFwiLFxuICAgIGxpbms6IFwiXCIsXG4gIH0sXG4gIHtcbiAgICBrZXk6IFwiZm9vdGVyX2NhcmVlcnNcIixcbiAgICBuYW1lOiBcIkNhcmVlcnNcIixcbiAgICBsaW5rOiBcIlwiLFxuICB9LFxuXTtcblxuZXhwb3J0IGRlZmF1bHQgZm9vdGVybWVudTtcbiIsImV4cG9ydCAqIGZyb20gXCIuL2Zvb3Rlck1lbnVcIjtcbmV4cG9ydCAqIGZyb20gXCIuL25hdk1lbnVcIjtcbmV4cG9ydCBjb25zdCBQUklWQUNZX1BPTElDWSA9IFwiTUFERSBXSVRIIExPVkUgQlkgUExFQVNFIFNFRSBcIlxuIiwiZXhwb3J0IGNvbnN0IG5hdk1lbnUgPSB7XG4gIHByaW1hcnk6IFtcbiAgICB7XG4gICAgICBrZXk6IFwiZm9vdGVyX2Fib3V0XCIsXG4gICAgICBuYW1lOiBcIkFib3V0XCIsXG4gICAgICBsaW5rOiBcIlwiLFxuICAgIH0sXG4gICAge1xuICAgICAga2V5OiBcImZvb3Rlcl9wb3J0Zm9saW9cIixcbiAgICAgIG5hbWU6IFwiUG9ydGZvbGlvXCIsXG4gICAgICBsaW5rOiBcIlwiLFxuICAgIH0sXG4gICAge1xuICAgICAga2V5OiBcImZvb3Rlcl9ibG9nXCIsXG4gICAgICBuYW1lOiBcIkJsb2dcIixcbiAgICAgIGxpbms6IFwiXCIsXG4gICAgfSxcbiAgXSxcbiAgc2Vjb25kYXJ5OiBbXG4gICAge1xuICAgICAga2V5OiBcImZvb3Rlcl9hZHZpc29yeV90ZWFtXCIsXG4gICAgICBuYW1lOiBcIkFkdmlzb3J5IFRlYW1cIixcbiAgICAgIGxpbms6IFwiXCIsXG4gICAgfSxcbiAgICB7XG4gICAgICBrZXk6IFwiZm9vdGVyX2NvbnRhY3RcIixcbiAgICAgIG5hbWU6IFwiQ29udGFjdFwiLFxuICAgICAgbGluazogXCJcIixcbiAgICB9LFxuICAgIHtcbiAgICAgIGtleTogXCJmb290ZXJfY2FyZWVyc1wiLFxuICAgICAgbmFtZTogXCJDYXJlZXJzXCIsXG4gICAgICBsaW5rOiBcIlwiLFxuICAgIH0sXG4gIF0sXG59O1xuXG5leHBvcnQgZGVmYXVsdCBuYXZNZW51O1xuIiwiZXhwb3J0IGNvbnN0IHNvY2lhbE1lZGlhID0gW1xuICB7XG4gICAgbmFtZTogXCJMaW5rZWRJblwiLFxuICAgIGxpbms6IFwiXCIsXG4gICAga2V5OiBcImxpbmtlZGluXCIsXG4gICAgaW1hZ2VVcmw6IFwiL2ljb25zL2xpbmtlZGluLnN2Z1wiLFxuICB9LFxuICB7XG4gICAgbmFtZTogXCJUd2l0dGVyXCIsXG4gICAgbGluazogXCJcIixcbiAgICBrZXk6IFwidHdpdHRlclwiLFxuICAgIGltYWdlVXJsOiBcIi9pY29ucy90d2l0dGVyLnN2Z1wiLFxuICB9LFxuXTtcbiIsImltcG9ydCB7IHVzZU1lbW8gfSBmcm9tICdyZWFjdCc7XG5pbXBvcnQgbWVyZ2UgZnJvbSAnZGVlcG1lcmdlJztcbmltcG9ydCB0eXBlIHsgR2V0U2VydmVyU2lkZVByb3BzQ29udGV4dCB9IGZyb20gJ25leHQnO1xuaW1wb3J0IHR5cGUgeyBJbmNvbWluZ01lc3NhZ2UgfSBmcm9tICdodHRwJztcbmltcG9ydCB7IEFwb2xsb0NsaWVudCwgSHR0cExpbmssIEluTWVtb3J5Q2FjaGUsIE5vcm1hbGl6ZWRDYWNoZU9iamVjdCB9IGZyb20gJ0BhcG9sbG8vY2xpZW50JztcbmltcG9ydCB7IHNldENvbnRleHQgfSBmcm9tICdAYXBvbGxvL2NsaWVudC9saW5rL2NvbnRleHQnO1xuaW1wb3J0IHthcHBDb25maWdWYXJ9IGZyb20gXCIuLi9tb2RlbHMvQXBwQ29uZmlnXCI7XG5cbmludGVyZmFjZSBQYWdlUHJvcHMge1xuICBwcm9wcz86IFJlY29yZDxzdHJpbmcsIGFueT47XG59XG5cbmV4cG9ydCBjb25zdCBBUE9MTE9fU1RBVEVfUFJPUEVSVFlfTkFNRSA9ICdfX0FQT0xMT19TVEFURV9fJztcbmV4cG9ydCBjb25zdCBDT09LSUVTX1RPS0VOX05BTUUgPSAnand0JztcblxuY29uc3QgZ2V0VG9rZW4gPSAocmVxPzogSW5jb21pbmdNZXNzYWdlKSA9PiB7XG4gIHJldHVybiAnJzsgLy8gdG9kbzogaW1wbGVtZW50IHRoZSBsb2dpYyBpZiByZXF1aXJlZFxufTtcblxubGV0IGFwb2xsb0NsaWVudDogQXBvbGxvQ2xpZW50PE5vcm1hbGl6ZWRDYWNoZU9iamVjdD4gPSBudWxsO1xuXG5jb25zdCBjcmVhdGVBcG9sbG9DbGllbnQgPSAoY3R4PzogR2V0U2VydmVyU2lkZVByb3BzQ29udGV4dCkgPT4ge1xuICBjb25zdCBodHRwTGluayA9IG5ldyBIdHRwTGluayh7XG4gICAgdXJpOiBwcm9jZXNzLmVudi5ORVhUX1BVQkxJQ19HUkFQSFFMX1VSSSxcbiAgICBjcmVkZW50aWFsczogJ3NhbWUtb3JpZ2luJyxcbiAgfSk7XG5cbiAgY29uc3QgYXV0aExpbmsgPSBzZXRDb250ZXh0KChfLCB7IGhlYWRlcnMgfSkgPT4ge1xuICAgIC8vIEdldCB0aGUgYXV0aGVudGljYXRpb24gdG9rZW4gZnJvbSBjb29raWVzXG4gICAgY29uc3QgdG9rZW4gPSBnZXRUb2tlbihjdHg/LnJlcSk7XG5cbiAgICByZXR1cm4ge1xuICAgICAgaGVhZGVyczoge1xuICAgICAgICAuLi5oZWFkZXJzLFxuICAgICAgICBhdXRob3JpemF0aW9uOiB0b2tlbiA/IGBCZWFyZXIgJHt0b2tlbn1gIDogJycsXG4gICAgICB9LFxuICAgIH07XG4gIH0pO1xuXG4gIHJldHVybiBuZXcgQXBvbGxvQ2xpZW50KHtcbiAgICBzc3JNb2RlOiB0eXBlb2Ygd2luZG93ID09PSAndW5kZWZpbmVkJyxcbiAgICBsaW5rOiBhdXRoTGluay5jb25jYXQoaHR0cExpbmspLFxuICAgIGNhY2hlOiBuZXcgSW5NZW1vcnlDYWNoZSh7XG4gICAgICB0eXBlUG9saWNpZXM6IHtcbiAgICAgICAgUXVlcnk6IHtcbiAgICAgICAgICBmaWVsZHM6IHtcbiAgICAgICAgICAgIGFwcENvbmZpZzoge1xuICAgICAgICAgICAgICByZWFkKCkge1xuICAgICAgICAgICAgICAgIHJldHVybiBhcHBDb25maWdWYXIoKTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfSksXG4gIH0pO1xufTtcblxuZXhwb3J0IGZ1bmN0aW9uIGluaXRpYWxpemVBcG9sbG8oaW5pdGlhbFN0YXRlID0gbnVsbCwgY3R4ID0gbnVsbCkge1xuICBjb25zdCBjbGllbnQgPSBhcG9sbG9DbGllbnQgPz8gY3JlYXRlQXBvbGxvQ2xpZW50KGN0eCk7XG5cbiAgLy8gSWYgeW91ciBwYWdlIGhhcyBOZXh0LmpzIGRhdGEgZmV0Y2hpbmcgbWV0aG9kcyB0aGF0IHVzZSBBcG9sbG8gQ2xpZW50LFxuICAvLyB0aGUgaW5pdGlhbCBzdGF0ZSBnZXRzIGh5ZHJhdGVkIGhlcmVcbiAgaWYgKGluaXRpYWxTdGF0ZSkge1xuICAgIC8vIEdldCBleGlzdGluZyBjYWNoZSwgbG9hZGVkIGR1cmluZyBjbGllbnQgc2lkZSBkYXRhIGZldGNoaW5nXG4gICAgY29uc3QgZXhpc3RpbmdDYWNoZSA9IGNsaWVudC5leHRyYWN0KCk7XG5cbiAgICAvLyBNZXJnZSB0aGUgZXhpc3RpbmcgY2FjaGUgaW50byBkYXRhIHBhc3NlZCBmcm9tXG4gICAgLy8gZ2V0U3RhdGljUHJvcHMvZ2V0U2VydmVyU2lkZVByb3BzXG4gICAgY29uc3QgZGF0YSA9IG1lcmdlKGluaXRpYWxTdGF0ZSwgZXhpc3RpbmdDYWNoZSk7XG5cbiAgICAvLyBSZXN0b3JlIHRoZSBjYWNoZSB3aXRoIHRoZSBtZXJnZWQgZGF0YVxuICAgIGNsaWVudC5jYWNoZS5yZXN0b3JlKGRhdGEpO1xuICB9XG5cbiAgLy8gRm9yIFNTRyBhbmQgU1NSIGFsd2F5cyBjcmVhdGUgYSBuZXcgQXBvbGxvIENsaWVudFxuICBpZiAodHlwZW9mIHdpbmRvdyA9PT0gJ3VuZGVmaW5lZCcpIHtcbiAgICByZXR1cm4gY2xpZW50O1xuICB9XG5cbiAgLy8gQ3JlYXRlIHRoZSBBcG9sbG8gQ2xpZW50IG9uY2UgaW4gdGhlIGNsaWVudFxuICBpZiAoIWFwb2xsb0NsaWVudCkge1xuICAgIGFwb2xsb0NsaWVudCA9IGNsaWVudDtcbiAgfVxuXG4gIHJldHVybiBjbGllbnQ7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiBhZGRBcG9sbG9TdGF0ZShcbiAgY2xpZW50OiBBcG9sbG9DbGllbnQ8Tm9ybWFsaXplZENhY2hlT2JqZWN0PixcbiAgcGFnZVByb3BzOiBQYWdlUHJvcHMsXG4pIHtcbiAgaWYgKHBhZ2VQcm9wcz8ucHJvcHMpIHtcbiAgICBwYWdlUHJvcHMucHJvcHNbQVBPTExPX1NUQVRFX1BST1BFUlRZX05BTUVdID0gY2xpZW50LmNhY2hlLmV4dHJhY3QoKTtcbiAgfVxuXG4gIHJldHVybiBwYWdlUHJvcHM7XG59XG5cbmV4cG9ydCBmdW5jdGlvbiB1c2VBcG9sbG8ocGFnZVByb3BzOiBQYWdlUHJvcHMpIHtcbiAgY29uc3Qgc3RhdGUgPSBwYWdlUHJvcHNbQVBPTExPX1NUQVRFX1BST1BFUlRZX05BTUVdO1xuICBjb25zdCBzdG9yZSA9IHVzZU1lbW8oKCkgPT4gaW5pdGlhbGl6ZUFwb2xsbyhzdGF0ZSksIFtzdGF0ZV0pO1xuXG4gIHJldHVybiBzdG9yZTtcbn1cbiIsImltcG9ydCBNb2JpbGVEZXRlY3QgZnJvbSBcIm1vYmlsZS1kZXRlY3RcIjtcblxuZXhwb3J0IGZ1bmN0aW9uIHVzZURldmljZVR5cGUodXNlckFnZW50KSB7XG4gIGNvbnN0IG1kID0gbmV3IE1vYmlsZURldGVjdCh1c2VyQWdlbnQpO1xuICBsZXQgbW9iaWxlID0gZmFsc2UsXG4gICAgdGFibGV0ID0gZmFsc2UsXG4gICAgZGVza3RvcCA9IGZhbHNlO1xuICBpZiAobWQudGFibGV0KCkpIHtcbiAgICB0YWJsZXQgPSB0cnVlO1xuICB9IGVsc2UgaWYgKG1kLm1vYmlsZSgpKSB7XG4gICAgbW9iaWxlID0gdHJ1ZTtcbiAgfSBlbHNlIHtcbiAgICBkZXNrdG9wID0gdHJ1ZTtcbiAgfVxuICByZXR1cm4ge1xuICAgIG1vYmlsZSxcbiAgICB0YWJsZXQsXG4gICAgZGVza3RvcFxuICB9O1xufVxuIiwiaW1wb3J0IHsgbWFrZVZhciwgUmVhY3RpdmVWYXIgfSBmcm9tIFwiQGFwb2xsby9jbGllbnRcIjtcblxuZXhwb3J0IGludGVyZmFjZSBBcHBDb25maWcge1xuICBtZW51OiBib29sZWFuO1xuICBuYXZNZW51U2VsZWN0ZWQ6IHN0cmluZyB8IG51bGw7XG59XG5cbmNvbnN0IGludGlhbEFwcGNvbmZpZzogQXBwQ29uZmlnID0ge1xuICBtZW51OiBmYWxzZSxcbiAgbmF2TWVudVNlbGVjdGVkOiBudWxsLFxufTtcblxuZXhwb3J0IGNvbnN0IGFwcENvbmZpZ1ZhcjogUmVhY3RpdmVWYXI8QXBwQ29uZmlnPiA9IG1ha2VWYXI8QXBwQ29uZmlnPihcbiAgaW50aWFsQXBwY29uZmlnXG4pO1xuIiwiZnVuY3Rpb24gX2V4dGVuZHMoKSB7XG4gIG1vZHVsZS5leHBvcnRzID0gX2V4dGVuZHMgPSBPYmplY3QuYXNzaWduIHx8IGZ1bmN0aW9uICh0YXJnZXQpIHtcbiAgICBmb3IgKHZhciBpID0gMTsgaSA8IGFyZ3VtZW50cy5sZW5ndGg7IGkrKykge1xuICAgICAgdmFyIHNvdXJjZSA9IGFyZ3VtZW50c1tpXTtcblxuICAgICAgZm9yICh2YXIga2V5IGluIHNvdXJjZSkge1xuICAgICAgICBpZiAoT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKHNvdXJjZSwga2V5KSkge1xuICAgICAgICAgIHRhcmdldFtrZXldID0gc291cmNlW2tleV07XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG5cbiAgICByZXR1cm4gdGFyZ2V0O1xuICB9O1xuXG4gIHJldHVybiBfZXh0ZW5kcy5hcHBseSh0aGlzLCBhcmd1bWVudHMpO1xufVxuXG5tb2R1bGUuZXhwb3J0cyA9IF9leHRlbmRzOyIsImZ1bmN0aW9uIF9pbnRlcm9wUmVxdWlyZURlZmF1bHQob2JqKSB7XG4gIHJldHVybiBvYmogJiYgb2JqLl9fZXNNb2R1bGUgPyBvYmogOiB7XG4gICAgXCJkZWZhdWx0XCI6IG9ialxuICB9O1xufVxuXG5tb2R1bGUuZXhwb3J0cyA9IF9pbnRlcm9wUmVxdWlyZURlZmF1bHQ7IiwiZnVuY3Rpb24gX29iamVjdFdpdGhvdXRQcm9wZXJ0aWVzTG9vc2Uoc291cmNlLCBleGNsdWRlZCkge1xuICBpZiAoc291cmNlID09IG51bGwpIHJldHVybiB7fTtcbiAgdmFyIHRhcmdldCA9IHt9O1xuICB2YXIgc291cmNlS2V5cyA9IE9iamVjdC5rZXlzKHNvdXJjZSk7XG4gIHZhciBrZXksIGk7XG5cbiAgZm9yIChpID0gMDsgaSA8IHNvdXJjZUtleXMubGVuZ3RoOyBpKyspIHtcbiAgICBrZXkgPSBzb3VyY2VLZXlzW2ldO1xuICAgIGlmIChleGNsdWRlZC5pbmRleE9mKGtleSkgPj0gMCkgY29udGludWU7XG4gICAgdGFyZ2V0W2tleV0gPSBzb3VyY2Vba2V5XTtcbiAgfVxuXG4gIHJldHVybiB0YXJnZXQ7XG59XG5cbm1vZHVsZS5leHBvcnRzID0gX29iamVjdFdpdGhvdXRQcm9wZXJ0aWVzTG9vc2U7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKCcuL2Rpc3QvcGFnZXMvX2FwcCcpXG4iLCJpbXBvcnQgUmVhY3QgZnJvbSAncmVhY3QnXG5pbXBvcnQgSGVhZCBmcm9tICcuLi9uZXh0LXNlcnZlci9saWIvaGVhZCdcbmltcG9ydCB7IHRvQmFzZTY0IH0gZnJvbSAnLi4vbmV4dC1zZXJ2ZXIvbGliL3RvLWJhc2UtNjQnXG5pbXBvcnQge1xuICBJbWFnZUNvbmZpZyxcbiAgaW1hZ2VDb25maWdEZWZhdWx0LFxuICBMb2FkZXJWYWx1ZSxcbiAgVkFMSURfTE9BREVSUyxcbn0gZnJvbSAnLi4vbmV4dC1zZXJ2ZXIvc2VydmVyL2ltYWdlLWNvbmZpZydcbmltcG9ydCB7IHVzZUludGVyc2VjdGlvbiB9IGZyb20gJy4vdXNlLWludGVyc2VjdGlvbidcblxuaWYgKHR5cGVvZiB3aW5kb3cgPT09ICd1bmRlZmluZWQnKSB7XG4gIDsoZ2xvYmFsIGFzIGFueSkuX19ORVhUX0lNQUdFX0lNUE9SVEVEID0gdHJ1ZVxufVxuXG5jb25zdCBWQUxJRF9MT0FESU5HX1ZBTFVFUyA9IFsnbGF6eScsICdlYWdlcicsIHVuZGVmaW5lZF0gYXMgY29uc3RcbnR5cGUgTG9hZGluZ1ZhbHVlID0gdHlwZW9mIFZBTElEX0xPQURJTkdfVkFMVUVTW251bWJlcl1cblxuZXhwb3J0IHR5cGUgSW1hZ2VMb2FkZXIgPSAocmVzb2x2ZXJQcm9wczogSW1hZ2VMb2FkZXJQcm9wcykgPT4gc3RyaW5nXG5cbmV4cG9ydCB0eXBlIEltYWdlTG9hZGVyUHJvcHMgPSB7XG4gIHNyYzogc3RyaW5nXG4gIHdpZHRoOiBudW1iZXJcbiAgcXVhbGl0eT86IG51bWJlclxufVxuXG50eXBlIERlZmF1bHRJbWFnZUxvYWRlclByb3BzID0gSW1hZ2VMb2FkZXJQcm9wcyAmIHsgcm9vdDogc3RyaW5nIH1cblxuY29uc3QgbG9hZGVycyA9IG5ldyBNYXA8XG4gIExvYWRlclZhbHVlLFxuICAocHJvcHM6IERlZmF1bHRJbWFnZUxvYWRlclByb3BzKSA9PiBzdHJpbmdcbj4oW1xuICBbJ2ltZ2l4JywgaW1naXhMb2FkZXJdLFxuICBbJ2Nsb3VkaW5hcnknLCBjbG91ZGluYXJ5TG9hZGVyXSxcbiAgWydha2FtYWknLCBha2FtYWlMb2FkZXJdLFxuICBbJ2RlZmF1bHQnLCBkZWZhdWx0TG9hZGVyXSxcbl0pXG5cbmNvbnN0IFZBTElEX0xBWU9VVF9WQUxVRVMgPSBbXG4gICdmaWxsJyxcbiAgJ2ZpeGVkJyxcbiAgJ2ludHJpbnNpYycsXG4gICdyZXNwb25zaXZlJyxcbiAgdW5kZWZpbmVkLFxuXSBhcyBjb25zdFxudHlwZSBMYXlvdXRWYWx1ZSA9IHR5cGVvZiBWQUxJRF9MQVlPVVRfVkFMVUVTW251bWJlcl1cblxudHlwZSBJbWdFbGVtZW50U3R5bGUgPSBOb25OdWxsYWJsZTxKU1guSW50cmluc2ljRWxlbWVudHNbJ2ltZyddWydzdHlsZSddPlxuXG5leHBvcnQgdHlwZSBJbWFnZVByb3BzID0gT21pdDxcbiAgSlNYLkludHJpbnNpY0VsZW1lbnRzWydpbWcnXSxcbiAgJ3NyYycgfCAnc3JjU2V0JyB8ICdyZWYnIHwgJ3dpZHRoJyB8ICdoZWlnaHQnIHwgJ2xvYWRpbmcnIHwgJ3N0eWxlJ1xuPiAmIHtcbiAgc3JjOiBzdHJpbmdcbiAgbG9hZGVyPzogSW1hZ2VMb2FkZXJcbiAgcXVhbGl0eT86IG51bWJlciB8IHN0cmluZ1xuICBwcmlvcml0eT86IGJvb2xlYW5cbiAgbG9hZGluZz86IExvYWRpbmdWYWx1ZVxuICB1bm9wdGltaXplZD86IGJvb2xlYW5cbiAgb2JqZWN0Rml0PzogSW1nRWxlbWVudFN0eWxlWydvYmplY3RGaXQnXVxuICBvYmplY3RQb3NpdGlvbj86IEltZ0VsZW1lbnRTdHlsZVsnb2JqZWN0UG9zaXRpb24nXVxufSAmIChcbiAgICB8IHtcbiAgICAgICAgd2lkdGg/OiBuZXZlclxuICAgICAgICBoZWlnaHQ/OiBuZXZlclxuICAgICAgICAvKiogQGRlcHJlY2F0ZWQgVXNlIGBsYXlvdXQ9XCJmaWxsXCJgIGluc3RlYWQgKi9cbiAgICAgICAgdW5zaXplZDogdHJ1ZVxuICAgICAgfVxuICAgIHwgeyB3aWR0aD86IG5ldmVyOyBoZWlnaHQ/OiBuZXZlcjsgbGF5b3V0OiAnZmlsbCcgfVxuICAgIHwge1xuICAgICAgICB3aWR0aDogbnVtYmVyIHwgc3RyaW5nXG4gICAgICAgIGhlaWdodDogbnVtYmVyIHwgc3RyaW5nXG4gICAgICAgIGxheW91dD86IEV4Y2x1ZGU8TGF5b3V0VmFsdWUsICdmaWxsJz5cbiAgICAgIH1cbiAgKVxuXG5jb25zdCB7XG4gIGRldmljZVNpemVzOiBjb25maWdEZXZpY2VTaXplcyxcbiAgaW1hZ2VTaXplczogY29uZmlnSW1hZ2VTaXplcyxcbiAgbG9hZGVyOiBjb25maWdMb2FkZXIsXG4gIHBhdGg6IGNvbmZpZ1BhdGgsXG4gIGRvbWFpbnM6IGNvbmZpZ0RvbWFpbnMsXG59ID1cbiAgKChwcm9jZXNzLmVudi5fX05FWFRfSU1BR0VfT1BUUyBhcyBhbnkpIGFzIEltYWdlQ29uZmlnKSB8fCBpbWFnZUNvbmZpZ0RlZmF1bHRcbi8vIHNvcnQgc21hbGxlc3QgdG8gbGFyZ2VzdFxuY29uc3QgYWxsU2l6ZXMgPSBbLi4uY29uZmlnRGV2aWNlU2l6ZXMsIC4uLmNvbmZpZ0ltYWdlU2l6ZXNdXG5jb25maWdEZXZpY2VTaXplcy5zb3J0KChhLCBiKSA9PiBhIC0gYilcbmFsbFNpemVzLnNvcnQoKGEsIGIpID0+IGEgLSBiKVxuXG5mdW5jdGlvbiBnZXRXaWR0aHMoXG4gIHdpZHRoOiBudW1iZXIgfCB1bmRlZmluZWQsXG4gIGxheW91dDogTGF5b3V0VmFsdWUsXG4gIHNpemVzOiBzdHJpbmcgfCB1bmRlZmluZWRcbik6IHsgd2lkdGhzOiBudW1iZXJbXTsga2luZDogJ3cnIHwgJ3gnIH0ge1xuICBpZiAoc2l6ZXMgJiYgKGxheW91dCA9PT0gJ2ZpbGwnIHx8IGxheW91dCA9PT0gJ3Jlc3BvbnNpdmUnKSkge1xuICAgIC8vIEZpbmQgYWxsIHRoZSBcInZ3XCIgcGVyY2VudCBzaXplcyB1c2VkIGluIHRoZSBzaXplcyBwcm9wXG4gICAgY29uc3QgcGVyY2VudFNpemVzID0gWy4uLnNpemVzLm1hdGNoQWxsKC8oXnxcXHMpKDE/XFxkP1xcZCl2dy9nKV0ubWFwKChtKSA9PlxuICAgICAgcGFyc2VJbnQobVsyXSlcbiAgICApXG4gICAgaWYgKHBlcmNlbnRTaXplcy5sZW5ndGgpIHtcbiAgICAgIGNvbnN0IHNtYWxsZXN0UmF0aW8gPSBNYXRoLm1pbiguLi5wZXJjZW50U2l6ZXMpICogMC4wMVxuICAgICAgcmV0dXJuIHtcbiAgICAgICAgd2lkdGhzOiBhbGxTaXplcy5maWx0ZXIoXG4gICAgICAgICAgKHMpID0+IHMgPj0gY29uZmlnRGV2aWNlU2l6ZXNbMF0gKiBzbWFsbGVzdFJhdGlvXG4gICAgICAgICksXG4gICAgICAgIGtpbmQ6ICd3JyxcbiAgICAgIH1cbiAgICB9XG4gICAgcmV0dXJuIHsgd2lkdGhzOiBhbGxTaXplcywga2luZDogJ3cnIH1cbiAgfVxuICBpZiAoXG4gICAgdHlwZW9mIHdpZHRoICE9PSAnbnVtYmVyJyB8fFxuICAgIGxheW91dCA9PT0gJ2ZpbGwnIHx8XG4gICAgbGF5b3V0ID09PSAncmVzcG9uc2l2ZSdcbiAgKSB7XG4gICAgcmV0dXJuIHsgd2lkdGhzOiBjb25maWdEZXZpY2VTaXplcywga2luZDogJ3cnIH1cbiAgfVxuXG4gIGNvbnN0IHdpZHRocyA9IFtcbiAgICAuLi5uZXcgU2V0KFxuICAgICAgLy8gPiBUaGlzIG1lYW5zIHRoYXQgbW9zdCBPTEVEIHNjcmVlbnMgdGhhdCBzYXkgdGhleSBhcmUgM3ggcmVzb2x1dGlvbixcbiAgICAgIC8vID4gYXJlIGFjdHVhbGx5IDN4IGluIHRoZSBncmVlbiBjb2xvciwgYnV0IG9ubHkgMS41eCBpbiB0aGUgcmVkIGFuZFxuICAgICAgLy8gPiBibHVlIGNvbG9ycy4gU2hvd2luZyBhIDN4IHJlc29sdXRpb24gaW1hZ2UgaW4gdGhlIGFwcCB2cyBhIDJ4XG4gICAgICAvLyA+IHJlc29sdXRpb24gaW1hZ2Ugd2lsbCBiZSB2aXN1YWxseSB0aGUgc2FtZSwgdGhvdWdoIHRoZSAzeCBpbWFnZVxuICAgICAgLy8gPiB0YWtlcyBzaWduaWZpY2FudGx5IG1vcmUgZGF0YS4gRXZlbiB0cnVlIDN4IHJlc29sdXRpb24gc2NyZWVucyBhcmVcbiAgICAgIC8vID4gd2FzdGVmdWwgYXMgdGhlIGh1bWFuIGV5ZSBjYW5ub3Qgc2VlIHRoYXQgbGV2ZWwgb2YgZGV0YWlsIHdpdGhvdXRcbiAgICAgIC8vID4gc29tZXRoaW5nIGxpa2UgYSBtYWduaWZ5aW5nIGdsYXNzLlxuICAgICAgLy8gaHR0cHM6Ly9ibG9nLnR3aXR0ZXIuY29tL2VuZ2luZWVyaW5nL2VuX3VzL3RvcGljcy9pbmZyYXN0cnVjdHVyZS8yMDE5L2NhcHBpbmctaW1hZ2UtZmlkZWxpdHktb24tdWx0cmEtaGlnaC1yZXNvbHV0aW9uLWRldmljZXMuaHRtbFxuICAgICAgW3dpZHRoLCB3aWR0aCAqIDIgLyosIHdpZHRoICogMyovXS5tYXAoXG4gICAgICAgICh3KSA9PiBhbGxTaXplcy5maW5kKChwKSA9PiBwID49IHcpIHx8IGFsbFNpemVzW2FsbFNpemVzLmxlbmd0aCAtIDFdXG4gICAgICApXG4gICAgKSxcbiAgXVxuICByZXR1cm4geyB3aWR0aHMsIGtpbmQ6ICd4JyB9XG59XG5cbnR5cGUgR2VuSW1nQXR0cnNEYXRhID0ge1xuICBzcmM6IHN0cmluZ1xuICB1bm9wdGltaXplZDogYm9vbGVhblxuICBsYXlvdXQ6IExheW91dFZhbHVlXG4gIGxvYWRlcjogSW1hZ2VMb2FkZXJcbiAgd2lkdGg/OiBudW1iZXJcbiAgcXVhbGl0eT86IG51bWJlclxuICBzaXplcz86IHN0cmluZ1xufVxuXG50eXBlIEdlbkltZ0F0dHJzUmVzdWx0ID0ge1xuICBzcmM6IHN0cmluZ1xuICBzcmNTZXQ6IHN0cmluZyB8IHVuZGVmaW5lZFxuICBzaXplczogc3RyaW5nIHwgdW5kZWZpbmVkXG59XG5cbmZ1bmN0aW9uIGdlbmVyYXRlSW1nQXR0cnMoe1xuICBzcmMsXG4gIHVub3B0aW1pemVkLFxuICBsYXlvdXQsXG4gIHdpZHRoLFxuICBxdWFsaXR5LFxuICBzaXplcyxcbiAgbG9hZGVyLFxufTogR2VuSW1nQXR0cnNEYXRhKTogR2VuSW1nQXR0cnNSZXN1bHQge1xuICBpZiAodW5vcHRpbWl6ZWQpIHtcbiAgICByZXR1cm4geyBzcmMsIHNyY1NldDogdW5kZWZpbmVkLCBzaXplczogdW5kZWZpbmVkIH1cbiAgfVxuXG4gIGNvbnN0IHsgd2lkdGhzLCBraW5kIH0gPSBnZXRXaWR0aHMod2lkdGgsIGxheW91dCwgc2l6ZXMpXG4gIGNvbnN0IGxhc3QgPSB3aWR0aHMubGVuZ3RoIC0gMVxuXG4gIHJldHVybiB7XG4gICAgc2l6ZXM6ICFzaXplcyAmJiBraW5kID09PSAndycgPyAnMTAwdncnIDogc2l6ZXMsXG4gICAgc3JjU2V0OiB3aWR0aHNcbiAgICAgIC5tYXAoXG4gICAgICAgICh3LCBpKSA9PlxuICAgICAgICAgIGAke2xvYWRlcih7IHNyYywgcXVhbGl0eSwgd2lkdGg6IHcgfSl9ICR7XG4gICAgICAgICAgICBraW5kID09PSAndycgPyB3IDogaSArIDFcbiAgICAgICAgICB9JHtraW5kfWBcbiAgICAgIClcbiAgICAgIC5qb2luKCcsICcpLFxuXG4gICAgLy8gSXQncyBpbnRlbmRlZCB0byBrZWVwIGBzcmNgIHRoZSBsYXN0IGF0dHJpYnV0ZSBiZWNhdXNlIFJlYWN0IHVwZGF0ZXNcbiAgICAvLyBhdHRyaWJ1dGVzIGluIG9yZGVyLiBJZiB3ZSBrZWVwIGBzcmNgIHRoZSBmaXJzdCBvbmUsIFNhZmFyaSB3aWxsXG4gICAgLy8gaW1tZWRpYXRlbHkgc3RhcnQgdG8gZmV0Y2ggYHNyY2AsIGJlZm9yZSBgc2l6ZXNgIGFuZCBgc3JjU2V0YCBhcmUgZXZlblxuICAgIC8vIHVwZGF0ZWQgYnkgUmVhY3QuIFRoYXQgY2F1c2VzIG11bHRpcGxlIHVubmVjZXNzYXJ5IHJlcXVlc3RzIGlmIGBzcmNTZXRgXG4gICAgLy8gYW5kIGBzaXplc2AgYXJlIGRlZmluZWQuXG4gICAgLy8gVGhpcyBidWcgY2Fubm90IGJlIHJlcHJvZHVjZWQgaW4gQ2hyb21lIG9yIEZpcmVmb3guXG4gICAgc3JjOiBsb2FkZXIoeyBzcmMsIHF1YWxpdHksIHdpZHRoOiB3aWR0aHNbbGFzdF0gfSksXG4gIH1cbn1cblxuZnVuY3Rpb24gZ2V0SW50KHg6IHVua25vd24pOiBudW1iZXIgfCB1bmRlZmluZWQge1xuICBpZiAodHlwZW9mIHggPT09ICdudW1iZXInKSB7XG4gICAgcmV0dXJuIHhcbiAgfVxuICBpZiAodHlwZW9mIHggPT09ICdzdHJpbmcnKSB7XG4gICAgcmV0dXJuIHBhcnNlSW50KHgsIDEwKVxuICB9XG4gIHJldHVybiB1bmRlZmluZWRcbn1cblxuZnVuY3Rpb24gZGVmYXVsdEltYWdlTG9hZGVyKGxvYWRlclByb3BzOiBJbWFnZUxvYWRlclByb3BzKSB7XG4gIGNvbnN0IGxvYWQgPSBsb2FkZXJzLmdldChjb25maWdMb2FkZXIpXG4gIGlmIChsb2FkKSB7XG4gICAgcmV0dXJuIGxvYWQoeyByb290OiBjb25maWdQYXRoLCAuLi5sb2FkZXJQcm9wcyB9KVxuICB9XG4gIHRocm93IG5ldyBFcnJvcihcbiAgICBgVW5rbm93biBcImxvYWRlclwiIGZvdW5kIGluIFwibmV4dC5jb25maWcuanNcIi4gRXhwZWN0ZWQ6ICR7VkFMSURfTE9BREVSUy5qb2luKFxuICAgICAgJywgJ1xuICAgICl9LiBSZWNlaXZlZDogJHtjb25maWdMb2FkZXJ9YFxuICApXG59XG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEltYWdlKHtcbiAgc3JjLFxuICBzaXplcyxcbiAgdW5vcHRpbWl6ZWQgPSBmYWxzZSxcbiAgcHJpb3JpdHkgPSBmYWxzZSxcbiAgbG9hZGluZyxcbiAgY2xhc3NOYW1lLFxuICBxdWFsaXR5LFxuICB3aWR0aCxcbiAgaGVpZ2h0LFxuICBvYmplY3RGaXQsXG4gIG9iamVjdFBvc2l0aW9uLFxuICBsb2FkZXIgPSBkZWZhdWx0SW1hZ2VMb2FkZXIsXG4gIC4uLmFsbFxufTogSW1hZ2VQcm9wcykge1xuICBsZXQgcmVzdDogUGFydGlhbDxJbWFnZVByb3BzPiA9IGFsbFxuICBsZXQgbGF5b3V0OiBOb25OdWxsYWJsZTxMYXlvdXRWYWx1ZT4gPSBzaXplcyA/ICdyZXNwb25zaXZlJyA6ICdpbnRyaW5zaWMnXG4gIGxldCB1bnNpemVkID0gZmFsc2VcbiAgaWYgKCd1bnNpemVkJyBpbiByZXN0KSB7XG4gICAgdW5zaXplZCA9IEJvb2xlYW4ocmVzdC51bnNpemVkKVxuICAgIC8vIFJlbW92ZSBwcm9wZXJ0eSBzbyBpdCdzIG5vdCBzcHJlYWQgaW50byBpbWFnZTpcbiAgICBkZWxldGUgcmVzdFsndW5zaXplZCddXG4gIH0gZWxzZSBpZiAoJ2xheW91dCcgaW4gcmVzdCkge1xuICAgIC8vIE92ZXJyaWRlIGRlZmF1bHQgbGF5b3V0IGlmIHRoZSB1c2VyIHNwZWNpZmllZCBvbmU6XG4gICAgaWYgKHJlc3QubGF5b3V0KSBsYXlvdXQgPSByZXN0LmxheW91dFxuXG4gICAgLy8gUmVtb3ZlIHByb3BlcnR5IHNvIGl0J3Mgbm90IHNwcmVhZCBpbnRvIGltYWdlOlxuICAgIGRlbGV0ZSByZXN0WydsYXlvdXQnXVxuICB9XG5cbiAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHtcbiAgICBpZiAoIXNyYykge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICBgSW1hZ2UgaXMgbWlzc2luZyByZXF1aXJlZCBcInNyY1wiIHByb3BlcnR5LiBNYWtlIHN1cmUgeW91IHBhc3MgXCJzcmNcIiBpbiBwcm9wcyB0byB0aGUgXFxgbmV4dC9pbWFnZVxcYCBjb21wb25lbnQuIFJlY2VpdmVkOiAke0pTT04uc3RyaW5naWZ5KFxuICAgICAgICAgIHsgd2lkdGgsIGhlaWdodCwgcXVhbGl0eSB9XG4gICAgICAgICl9YFxuICAgICAgKVxuICAgIH1cbiAgICBpZiAoIVZBTElEX0xBWU9VVF9WQUxVRVMuaW5jbHVkZXMobGF5b3V0KSkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICBgSW1hZ2Ugd2l0aCBzcmMgXCIke3NyY31cIiBoYXMgaW52YWxpZCBcImxheW91dFwiIHByb3BlcnR5LiBQcm92aWRlZCBcIiR7bGF5b3V0fVwiIHNob3VsZCBiZSBvbmUgb2YgJHtWQUxJRF9MQVlPVVRfVkFMVUVTLm1hcChcbiAgICAgICAgICBTdHJpbmdcbiAgICAgICAgKS5qb2luKCcsJyl9LmBcbiAgICAgIClcbiAgICB9XG4gICAgaWYgKCFWQUxJRF9MT0FESU5HX1ZBTFVFUy5pbmNsdWRlcyhsb2FkaW5nKSkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICBgSW1hZ2Ugd2l0aCBzcmMgXCIke3NyY31cIiBoYXMgaW52YWxpZCBcImxvYWRpbmdcIiBwcm9wZXJ0eS4gUHJvdmlkZWQgXCIke2xvYWRpbmd9XCIgc2hvdWxkIGJlIG9uZSBvZiAke1ZBTElEX0xPQURJTkdfVkFMVUVTLm1hcChcbiAgICAgICAgICBTdHJpbmdcbiAgICAgICAgKS5qb2luKCcsJyl9LmBcbiAgICAgIClcbiAgICB9XG4gICAgaWYgKHByaW9yaXR5ICYmIGxvYWRpbmcgPT09ICdsYXp5Jykge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICBgSW1hZ2Ugd2l0aCBzcmMgXCIke3NyY31cIiBoYXMgYm90aCBcInByaW9yaXR5XCIgYW5kIFwibG9hZGluZz0nbGF6eSdcIiBwcm9wZXJ0aWVzLiBPbmx5IG9uZSBzaG91bGQgYmUgdXNlZC5gXG4gICAgICApXG4gICAgfVxuICAgIGlmICh1bnNpemVkKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgIGBJbWFnZSB3aXRoIHNyYyBcIiR7c3JjfVwiIGhhcyBkZXByZWNhdGVkIFwidW5zaXplZFwiIHByb3BlcnR5LCB3aGljaCB3YXMgcmVtb3ZlZCBpbiBmYXZvciBvZiB0aGUgXCJsYXlvdXQ9J2ZpbGwnXCIgcHJvcGVydHlgXG4gICAgICApXG4gICAgfVxuICB9XG5cbiAgbGV0IGlzTGF6eSA9XG4gICAgIXByaW9yaXR5ICYmIChsb2FkaW5nID09PSAnbGF6eScgfHwgdHlwZW9mIGxvYWRpbmcgPT09ICd1bmRlZmluZWQnKVxuICBpZiAoc3JjICYmIHNyYy5zdGFydHNXaXRoKCdkYXRhOicpKSB7XG4gICAgLy8gaHR0cHM6Ly9kZXZlbG9wZXIubW96aWxsYS5vcmcvZW4tVVMvZG9jcy9XZWIvSFRUUC9CYXNpY3Nfb2ZfSFRUUC9EYXRhX1VSSXNcbiAgICB1bm9wdGltaXplZCA9IHRydWVcbiAgICBpc0xhenkgPSBmYWxzZVxuICB9XG5cbiAgY29uc3QgW3NldFJlZiwgaXNJbnRlcnNlY3RlZF0gPSB1c2VJbnRlcnNlY3Rpb248SFRNTEltYWdlRWxlbWVudD4oe1xuICAgIHJvb3RNYXJnaW46ICcyMDBweCcsXG4gICAgZGlzYWJsZWQ6ICFpc0xhenksXG4gIH0pXG4gIGNvbnN0IGlzVmlzaWJsZSA9ICFpc0xhenkgfHwgaXNJbnRlcnNlY3RlZFxuXG4gIGNvbnN0IHdpZHRoSW50ID0gZ2V0SW50KHdpZHRoKVxuICBjb25zdCBoZWlnaHRJbnQgPSBnZXRJbnQoaGVpZ2h0KVxuICBjb25zdCBxdWFsaXR5SW50ID0gZ2V0SW50KHF1YWxpdHkpXG5cbiAgbGV0IHdyYXBwZXJTdHlsZTogSlNYLkludHJpbnNpY0VsZW1lbnRzWydkaXYnXVsnc3R5bGUnXSB8IHVuZGVmaW5lZFxuICBsZXQgc2l6ZXJTdHlsZTogSlNYLkludHJpbnNpY0VsZW1lbnRzWydkaXYnXVsnc3R5bGUnXSB8IHVuZGVmaW5lZFxuICBsZXQgc2l6ZXJTdmc6IHN0cmluZyB8IHVuZGVmaW5lZFxuICBsZXQgaW1nU3R5bGU6IEltZ0VsZW1lbnRTdHlsZSB8IHVuZGVmaW5lZCA9IHtcbiAgICBwb3NpdGlvbjogJ2Fic29sdXRlJyxcbiAgICB0b3A6IDAsXG4gICAgbGVmdDogMCxcbiAgICBib3R0b206IDAsXG4gICAgcmlnaHQ6IDAsXG5cbiAgICBib3hTaXppbmc6ICdib3JkZXItYm94JyxcbiAgICBwYWRkaW5nOiAwLFxuICAgIGJvcmRlcjogJ25vbmUnLFxuICAgIG1hcmdpbjogJ2F1dG8nLFxuXG4gICAgZGlzcGxheTogJ2Jsb2NrJyxcbiAgICB3aWR0aDogMCxcbiAgICBoZWlnaHQ6IDAsXG4gICAgbWluV2lkdGg6ICcxMDAlJyxcbiAgICBtYXhXaWR0aDogJzEwMCUnLFxuICAgIG1pbkhlaWdodDogJzEwMCUnLFxuICAgIG1heEhlaWdodDogJzEwMCUnLFxuXG4gICAgb2JqZWN0Rml0LFxuICAgIG9iamVjdFBvc2l0aW9uLFxuICB9XG4gIGlmIChcbiAgICB0eXBlb2Ygd2lkdGhJbnQgIT09ICd1bmRlZmluZWQnICYmXG4gICAgdHlwZW9mIGhlaWdodEludCAhPT0gJ3VuZGVmaW5lZCcgJiZcbiAgICBsYXlvdXQgIT09ICdmaWxsJ1xuICApIHtcbiAgICAvLyA8SW1hZ2Ugc3JjPVwiaS5wbmdcIiB3aWR0aD1cIjEwMFwiIGhlaWdodD1cIjEwMFwiIC8+XG4gICAgY29uc3QgcXVvdGllbnQgPSBoZWlnaHRJbnQgLyB3aWR0aEludFxuICAgIGNvbnN0IHBhZGRpbmdUb3AgPSBpc05hTihxdW90aWVudCkgPyAnMTAwJScgOiBgJHtxdW90aWVudCAqIDEwMH0lYFxuICAgIGlmIChsYXlvdXQgPT09ICdyZXNwb25zaXZlJykge1xuICAgICAgLy8gPEltYWdlIHNyYz1cImkucG5nXCIgd2lkdGg9XCIxMDBcIiBoZWlnaHQ9XCIxMDBcIiBsYXlvdXQ9XCJyZXNwb25zaXZlXCIgLz5cbiAgICAgIHdyYXBwZXJTdHlsZSA9IHtcbiAgICAgICAgZGlzcGxheTogJ2Jsb2NrJyxcbiAgICAgICAgb3ZlcmZsb3c6ICdoaWRkZW4nLFxuICAgICAgICBwb3NpdGlvbjogJ3JlbGF0aXZlJyxcblxuICAgICAgICBib3hTaXppbmc6ICdib3JkZXItYm94JyxcbiAgICAgICAgbWFyZ2luOiAwLFxuICAgICAgfVxuICAgICAgc2l6ZXJTdHlsZSA9IHsgZGlzcGxheTogJ2Jsb2NrJywgYm94U2l6aW5nOiAnYm9yZGVyLWJveCcsIHBhZGRpbmdUb3AgfVxuICAgIH0gZWxzZSBpZiAobGF5b3V0ID09PSAnaW50cmluc2ljJykge1xuICAgICAgLy8gPEltYWdlIHNyYz1cImkucG5nXCIgd2lkdGg9XCIxMDBcIiBoZWlnaHQ9XCIxMDBcIiBsYXlvdXQ9XCJpbnRyaW5zaWNcIiAvPlxuICAgICAgd3JhcHBlclN0eWxlID0ge1xuICAgICAgICBkaXNwbGF5OiAnaW5saW5lLWJsb2NrJyxcbiAgICAgICAgbWF4V2lkdGg6ICcxMDAlJyxcbiAgICAgICAgb3ZlcmZsb3c6ICdoaWRkZW4nLFxuICAgICAgICBwb3NpdGlvbjogJ3JlbGF0aXZlJyxcbiAgICAgICAgYm94U2l6aW5nOiAnYm9yZGVyLWJveCcsXG4gICAgICAgIG1hcmdpbjogMCxcbiAgICAgIH1cbiAgICAgIHNpemVyU3R5bGUgPSB7XG4gICAgICAgIGJveFNpemluZzogJ2JvcmRlci1ib3gnLFxuICAgICAgICBkaXNwbGF5OiAnYmxvY2snLFxuICAgICAgICBtYXhXaWR0aDogJzEwMCUnLFxuICAgICAgfVxuICAgICAgc2l6ZXJTdmcgPSBgPHN2ZyB3aWR0aD1cIiR7d2lkdGhJbnR9XCIgaGVpZ2h0PVwiJHtoZWlnaHRJbnR9XCIgeG1sbnM9XCJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2Z1wiIHZlcnNpb249XCIxLjFcIi8+YFxuICAgIH0gZWxzZSBpZiAobGF5b3V0ID09PSAnZml4ZWQnKSB7XG4gICAgICAvLyA8SW1hZ2Ugc3JjPVwiaS5wbmdcIiB3aWR0aD1cIjEwMFwiIGhlaWdodD1cIjEwMFwiIGxheW91dD1cImZpeGVkXCIgLz5cbiAgICAgIHdyYXBwZXJTdHlsZSA9IHtcbiAgICAgICAgb3ZlcmZsb3c6ICdoaWRkZW4nLFxuICAgICAgICBib3hTaXppbmc6ICdib3JkZXItYm94JyxcbiAgICAgICAgZGlzcGxheTogJ2lubGluZS1ibG9jaycsXG4gICAgICAgIHBvc2l0aW9uOiAncmVsYXRpdmUnLFxuICAgICAgICB3aWR0aDogd2lkdGhJbnQsXG4gICAgICAgIGhlaWdodDogaGVpZ2h0SW50LFxuICAgICAgfVxuICAgIH1cbiAgfSBlbHNlIGlmIChcbiAgICB0eXBlb2Ygd2lkdGhJbnQgPT09ICd1bmRlZmluZWQnICYmXG4gICAgdHlwZW9mIGhlaWdodEludCA9PT0gJ3VuZGVmaW5lZCcgJiZcbiAgICBsYXlvdXQgPT09ICdmaWxsJ1xuICApIHtcbiAgICAvLyA8SW1hZ2Ugc3JjPVwiaS5wbmdcIiBsYXlvdXQ9XCJmaWxsXCIgLz5cbiAgICB3cmFwcGVyU3R5bGUgPSB7XG4gICAgICBkaXNwbGF5OiAnYmxvY2snLFxuICAgICAgb3ZlcmZsb3c6ICdoaWRkZW4nLFxuXG4gICAgICBwb3NpdGlvbjogJ2Fic29sdXRlJyxcbiAgICAgIHRvcDogMCxcbiAgICAgIGxlZnQ6IDAsXG4gICAgICBib3R0b206IDAsXG4gICAgICByaWdodDogMCxcblxuICAgICAgYm94U2l6aW5nOiAnYm9yZGVyLWJveCcsXG4gICAgICBtYXJnaW46IDAsXG4gICAgfVxuICB9IGVsc2Uge1xuICAgIC8vIDxJbWFnZSBzcmM9XCJpLnBuZ1wiIC8+XG4gICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihcbiAgICAgICAgYEltYWdlIHdpdGggc3JjIFwiJHtzcmN9XCIgbXVzdCB1c2UgXCJ3aWR0aFwiIGFuZCBcImhlaWdodFwiIHByb3BlcnRpZXMgb3IgXCJsYXlvdXQ9J2ZpbGwnXCIgcHJvcGVydHkuYFxuICAgICAgKVxuICAgIH1cbiAgfVxuXG4gIGxldCBpbWdBdHRyaWJ1dGVzOiBHZW5JbWdBdHRyc1Jlc3VsdCA9IHtcbiAgICBzcmM6XG4gICAgICAnZGF0YTppbWFnZS9naWY7YmFzZTY0LFIwbEdPRGxoQVFBQkFJQUFBQUFBQVAvLy95SDVCQUVBQUFBQUxBQUFBQUFCQUFFQUFBSUJSQUE3JyxcbiAgICBzcmNTZXQ6IHVuZGVmaW5lZCxcbiAgICBzaXplczogdW5kZWZpbmVkLFxuICB9XG5cbiAgaWYgKGlzVmlzaWJsZSkge1xuICAgIGltZ0F0dHJpYnV0ZXMgPSBnZW5lcmF0ZUltZ0F0dHJzKHtcbiAgICAgIHNyYyxcbiAgICAgIHVub3B0aW1pemVkLFxuICAgICAgbGF5b3V0LFxuICAgICAgd2lkdGg6IHdpZHRoSW50LFxuICAgICAgcXVhbGl0eTogcXVhbGl0eUludCxcbiAgICAgIHNpemVzLFxuICAgICAgbG9hZGVyLFxuICAgIH0pXG4gIH1cblxuICBpZiAodW5zaXplZCkge1xuICAgIHdyYXBwZXJTdHlsZSA9IHVuZGVmaW5lZFxuICAgIHNpemVyU3R5bGUgPSB1bmRlZmluZWRcbiAgICBpbWdTdHlsZSA9IHVuZGVmaW5lZFxuICB9XG4gIHJldHVybiAoXG4gICAgPGRpdiBzdHlsZT17d3JhcHBlclN0eWxlfT5cbiAgICAgIHtzaXplclN0eWxlID8gKFxuICAgICAgICA8ZGl2IHN0eWxlPXtzaXplclN0eWxlfT5cbiAgICAgICAgICB7c2l6ZXJTdmcgPyAoXG4gICAgICAgICAgICA8aW1nXG4gICAgICAgICAgICAgIHN0eWxlPXt7XG4gICAgICAgICAgICAgICAgbWF4V2lkdGg6ICcxMDAlJyxcbiAgICAgICAgICAgICAgICBkaXNwbGF5OiAnYmxvY2snLFxuICAgICAgICAgICAgICAgIG1hcmdpbjogMCxcbiAgICAgICAgICAgICAgICBib3JkZXI6ICdub25lJyxcbiAgICAgICAgICAgICAgICBwYWRkaW5nOiAwLFxuICAgICAgICAgICAgICB9fVxuICAgICAgICAgICAgICBhbHQ9XCJcIlxuICAgICAgICAgICAgICBhcmlhLWhpZGRlbj17dHJ1ZX1cbiAgICAgICAgICAgICAgcm9sZT1cInByZXNlbnRhdGlvblwiXG4gICAgICAgICAgICAgIHNyYz17YGRhdGE6aW1hZ2Uvc3ZnK3htbDtiYXNlNjQsJHt0b0Jhc2U2NChzaXplclN2Zyl9YH1cbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgKSA6IG51bGx9XG4gICAgICAgIDwvZGl2PlxuICAgICAgKSA6IG51bGx9XG4gICAgICB7IWlzVmlzaWJsZSAmJiAoXG4gICAgICAgIDxub3NjcmlwdD5cbiAgICAgICAgICA8aW1nXG4gICAgICAgICAgICB7Li4ucmVzdH1cbiAgICAgICAgICAgIHsuLi5nZW5lcmF0ZUltZ0F0dHJzKHtcbiAgICAgICAgICAgICAgc3JjLFxuICAgICAgICAgICAgICB1bm9wdGltaXplZCxcbiAgICAgICAgICAgICAgbGF5b3V0LFxuICAgICAgICAgICAgICB3aWR0aDogd2lkdGhJbnQsXG4gICAgICAgICAgICAgIHF1YWxpdHk6IHF1YWxpdHlJbnQsXG4gICAgICAgICAgICAgIHNpemVzLFxuICAgICAgICAgICAgICBsb2FkZXIsXG4gICAgICAgICAgICB9KX1cbiAgICAgICAgICAgIHNyYz17c3JjfVxuICAgICAgICAgICAgZGVjb2Rpbmc9XCJhc3luY1wiXG4gICAgICAgICAgICBzaXplcz17c2l6ZXN9XG4gICAgICAgICAgICBzdHlsZT17aW1nU3R5bGV9XG4gICAgICAgICAgICBjbGFzc05hbWU9e2NsYXNzTmFtZX1cbiAgICAgICAgICAvPlxuICAgICAgICA8L25vc2NyaXB0PlxuICAgICAgKX1cbiAgICAgIDxpbWdcbiAgICAgICAgey4uLnJlc3R9XG4gICAgICAgIHsuLi5pbWdBdHRyaWJ1dGVzfVxuICAgICAgICBkZWNvZGluZz1cImFzeW5jXCJcbiAgICAgICAgY2xhc3NOYW1lPXtjbGFzc05hbWV9XG4gICAgICAgIHJlZj17c2V0UmVmfVxuICAgICAgICBzdHlsZT17aW1nU3R5bGV9XG4gICAgICAvPlxuICAgICAge3ByaW9yaXR5ID8gKFxuICAgICAgICAvLyBOb3RlIGhvdyB3ZSBvbWl0IHRoZSBgaHJlZmAgYXR0cmlidXRlLCBhcyBpdCB3b3VsZCBvbmx5IGJlIHJlbGV2YW50XG4gICAgICAgIC8vIGZvciBicm93c2VycyB0aGF0IGRvIG5vdCBzdXBwb3J0IGBpbWFnZXNyY3NldGAsIGFuZCBpbiB0aG9zZSBjYXNlc1xuICAgICAgICAvLyBpdCB3b3VsZCBsaWtlbHkgY2F1c2UgdGhlIGluY29ycmVjdCBpbWFnZSB0byBiZSBwcmVsb2FkZWQuXG4gICAgICAgIC8vXG4gICAgICAgIC8vIGh0dHBzOi8vaHRtbC5zcGVjLndoYXR3Zy5vcmcvbXVsdGlwYWdlL3NlbWFudGljcy5odG1sI2F0dHItbGluay1pbWFnZXNyY3NldFxuICAgICAgICA8SGVhZD5cbiAgICAgICAgICA8bGlua1xuICAgICAgICAgICAga2V5PXtcbiAgICAgICAgICAgICAgJ19fbmltZy0nICtcbiAgICAgICAgICAgICAgaW1nQXR0cmlidXRlcy5zcmMgK1xuICAgICAgICAgICAgICBpbWdBdHRyaWJ1dGVzLnNyY1NldCArXG4gICAgICAgICAgICAgIGltZ0F0dHJpYnV0ZXMuc2l6ZXNcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJlbD1cInByZWxvYWRcIlxuICAgICAgICAgICAgYXM9XCJpbWFnZVwiXG4gICAgICAgICAgICBocmVmPXtpbWdBdHRyaWJ1dGVzLnNyY1NldCA/IHVuZGVmaW5lZCA6IGltZ0F0dHJpYnV0ZXMuc3JjfVxuICAgICAgICAgICAgLy8gQHRzLWlnbm9yZTogaW1hZ2VzcmNzZXQgaXMgbm90IHlldCBpbiB0aGUgbGluayBlbGVtZW50IHR5cGVcbiAgICAgICAgICAgIGltYWdlc3Jjc2V0PXtpbWdBdHRyaWJ1dGVzLnNyY1NldH1cbiAgICAgICAgICAgIC8vIEB0cy1pZ25vcmU6IGltYWdlc2l6ZXMgaXMgbm90IHlldCBpbiB0aGUgbGluayBlbGVtZW50IHR5cGVcbiAgICAgICAgICAgIGltYWdlc2l6ZXM9e2ltZ0F0dHJpYnV0ZXMuc2l6ZXN9XG4gICAgICAgICAgPjwvbGluaz5cbiAgICAgICAgPC9IZWFkPlxuICAgICAgKSA6IG51bGx9XG4gICAgPC9kaXY+XG4gIClcbn1cblxuLy9CVUlMVCBJTiBMT0FERVJTXG5cbmZ1bmN0aW9uIG5vcm1hbGl6ZVNyYyhzcmM6IHN0cmluZyk6IHN0cmluZyB7XG4gIHJldHVybiBzcmNbMF0gPT09ICcvJyA/IHNyYy5zbGljZSgxKSA6IHNyY1xufVxuXG5mdW5jdGlvbiBpbWdpeExvYWRlcih7XG4gIHJvb3QsXG4gIHNyYyxcbiAgd2lkdGgsXG4gIHF1YWxpdHksXG59OiBEZWZhdWx0SW1hZ2VMb2FkZXJQcm9wcyk6IHN0cmluZyB7XG4gIC8vIERlbW86IGh0dHBzOi8vc3RhdGljLmltZ2l4Lm5ldC9kYWlzeS5wbmc/Zm9ybWF0PWF1dG8mZml0PW1heCZ3PTMwMFxuICBjb25zdCBwYXJhbXMgPSBbJ2F1dG89Zm9ybWF0JywgJ2ZpdD1tYXgnLCAndz0nICsgd2lkdGhdXG4gIGxldCBwYXJhbXNTdHJpbmcgPSAnJ1xuICBpZiAocXVhbGl0eSkge1xuICAgIHBhcmFtcy5wdXNoKCdxPScgKyBxdWFsaXR5KVxuICB9XG5cbiAgaWYgKHBhcmFtcy5sZW5ndGgpIHtcbiAgICBwYXJhbXNTdHJpbmcgPSAnPycgKyBwYXJhbXMuam9pbignJicpXG4gIH1cbiAgcmV0dXJuIGAke3Jvb3R9JHtub3JtYWxpemVTcmMoc3JjKX0ke3BhcmFtc1N0cmluZ31gXG59XG5cbmZ1bmN0aW9uIGFrYW1haUxvYWRlcih7IHJvb3QsIHNyYywgd2lkdGggfTogRGVmYXVsdEltYWdlTG9hZGVyUHJvcHMpOiBzdHJpbmcge1xuICByZXR1cm4gYCR7cm9vdH0ke25vcm1hbGl6ZVNyYyhzcmMpfT9pbXdpZHRoPSR7d2lkdGh9YFxufVxuXG5mdW5jdGlvbiBjbG91ZGluYXJ5TG9hZGVyKHtcbiAgcm9vdCxcbiAgc3JjLFxuICB3aWR0aCxcbiAgcXVhbGl0eSxcbn06IERlZmF1bHRJbWFnZUxvYWRlclByb3BzKTogc3RyaW5nIHtcbiAgLy8gRGVtbzogaHR0cHM6Ly9yZXMuY2xvdWRpbmFyeS5jb20vZGVtby9pbWFnZS91cGxvYWQvd18zMDAsY19saW1pdCxxX2F1dG8vdHVydGxlcy5qcGdcbiAgY29uc3QgcGFyYW1zID0gWydmX2F1dG8nLCAnY19saW1pdCcsICd3XycgKyB3aWR0aCwgJ3FfJyArIChxdWFsaXR5IHx8ICdhdXRvJyldXG4gIGxldCBwYXJhbXNTdHJpbmcgPSBwYXJhbXMuam9pbignLCcpICsgJy8nXG4gIHJldHVybiBgJHtyb290fSR7cGFyYW1zU3RyaW5nfSR7bm9ybWFsaXplU3JjKHNyYyl9YFxufVxuXG5mdW5jdGlvbiBkZWZhdWx0TG9hZGVyKHtcbiAgcm9vdCxcbiAgc3JjLFxuICB3aWR0aCxcbiAgcXVhbGl0eSxcbn06IERlZmF1bHRJbWFnZUxvYWRlclByb3BzKTogc3RyaW5nIHtcbiAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHtcbiAgICBjb25zdCBtaXNzaW5nVmFsdWVzID0gW11cblxuICAgIC8vIHRoZXNlIHNob3VsZCBhbHdheXMgYmUgcHJvdmlkZWQgYnV0IG1ha2Ugc3VyZSB0aGV5IGFyZVxuICAgIGlmICghc3JjKSBtaXNzaW5nVmFsdWVzLnB1c2goJ3NyYycpXG4gICAgaWYgKCF3aWR0aCkgbWlzc2luZ1ZhbHVlcy5wdXNoKCd3aWR0aCcpXG5cbiAgICBpZiAobWlzc2luZ1ZhbHVlcy5sZW5ndGggPiAwKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgIGBOZXh0IEltYWdlIE9wdGltaXphdGlvbiByZXF1aXJlcyAke21pc3NpbmdWYWx1ZXMuam9pbihcbiAgICAgICAgICAnLCAnXG4gICAgICAgICl9IHRvIGJlIHByb3ZpZGVkLiBNYWtlIHN1cmUgeW91IHBhc3MgdGhlbSBhcyBwcm9wcyB0byB0aGUgXFxgbmV4dC9pbWFnZVxcYCBjb21wb25lbnQuIFJlY2VpdmVkOiAke0pTT04uc3RyaW5naWZ5KFxuICAgICAgICAgIHsgc3JjLCB3aWR0aCwgcXVhbGl0eSB9XG4gICAgICAgICl9YFxuICAgICAgKVxuICAgIH1cblxuICAgIGlmIChzcmMuc3RhcnRzV2l0aCgnLy8nKSkge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICBgRmFpbGVkIHRvIHBhcnNlIHNyYyBcIiR7c3JjfVwiIG9uIFxcYG5leHQvaW1hZ2VcXGAsIHByb3RvY29sLXJlbGF0aXZlIFVSTCAoLy8pIG11c3QgYmUgY2hhbmdlZCB0byBhbiBhYnNvbHV0ZSBVUkwgKGh0dHA6Ly8gb3IgaHR0cHM6Ly8pYFxuICAgICAgKVxuICAgIH1cblxuICAgIGlmICghc3JjLnN0YXJ0c1dpdGgoJy8nKSAmJiBjb25maWdEb21haW5zKSB7XG4gICAgICBsZXQgcGFyc2VkU3JjOiBVUkxcbiAgICAgIHRyeSB7XG4gICAgICAgIHBhcnNlZFNyYyA9IG5ldyBVUkwoc3JjKVxuICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoZXJyKVxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXG4gICAgICAgICAgYEZhaWxlZCB0byBwYXJzZSBzcmMgXCIke3NyY31cIiBvbiBcXGBuZXh0L2ltYWdlXFxgLCBpZiB1c2luZyByZWxhdGl2ZSBpbWFnZSBpdCBtdXN0IHN0YXJ0IHdpdGggYSBsZWFkaW5nIHNsYXNoIFwiL1wiIG9yIGJlIGFuIGFic29sdXRlIFVSTCAoaHR0cDovLyBvciBodHRwczovLylgXG4gICAgICAgIClcbiAgICAgIH1cblxuICAgICAgaWYgKCFjb25maWdEb21haW5zLmluY2x1ZGVzKHBhcnNlZFNyYy5ob3N0bmFtZSkpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFxuICAgICAgICAgIGBJbnZhbGlkIHNyYyBwcm9wICgke3NyY30pIG9uIFxcYG5leHQvaW1hZ2VcXGAsIGhvc3RuYW1lIFwiJHtwYXJzZWRTcmMuaG9zdG5hbWV9XCIgaXMgbm90IGNvbmZpZ3VyZWQgdW5kZXIgaW1hZ2VzIGluIHlvdXIgXFxgbmV4dC5jb25maWcuanNcXGBcXG5gICtcbiAgICAgICAgICAgIGBTZWUgbW9yZSBpbmZvOiBodHRwczovL25leHRqcy5vcmcvZG9jcy9tZXNzYWdlcy9uZXh0LWltYWdlLXVuY29uZmlndXJlZC1ob3N0YFxuICAgICAgICApXG4gICAgICB9XG4gICAgfVxuICB9XG5cbiAgcmV0dXJuIGAke3Jvb3R9P3VybD0ke2VuY29kZVVSSUNvbXBvbmVudChzcmMpfSZ3PSR7d2lkdGh9JnE9JHtxdWFsaXR5IHx8IDc1fWBcbn1cbiIsInR5cGUgUmVxdWVzdElkbGVDYWxsYmFja0hhbmRsZSA9IGFueVxudHlwZSBSZXF1ZXN0SWRsZUNhbGxiYWNrT3B0aW9ucyA9IHtcbiAgdGltZW91dDogbnVtYmVyXG59XG50eXBlIFJlcXVlc3RJZGxlQ2FsbGJhY2tEZWFkbGluZSA9IHtcbiAgcmVhZG9ubHkgZGlkVGltZW91dDogYm9vbGVhblxuICB0aW1lUmVtYWluaW5nOiAoKSA9PiBudW1iZXJcbn1cblxuZGVjbGFyZSBnbG9iYWwge1xuICBpbnRlcmZhY2UgV2luZG93IHtcbiAgICByZXF1ZXN0SWRsZUNhbGxiYWNrOiAoXG4gICAgICBjYWxsYmFjazogKGRlYWRsaW5lOiBSZXF1ZXN0SWRsZUNhbGxiYWNrRGVhZGxpbmUpID0+IHZvaWQsXG4gICAgICBvcHRzPzogUmVxdWVzdElkbGVDYWxsYmFja09wdGlvbnNcbiAgICApID0+IFJlcXVlc3RJZGxlQ2FsbGJhY2tIYW5kbGVcbiAgICBjYW5jZWxJZGxlQ2FsbGJhY2s6IChpZDogUmVxdWVzdElkbGVDYWxsYmFja0hhbmRsZSkgPT4gdm9pZFxuICB9XG59XG5cbmV4cG9ydCBjb25zdCByZXF1ZXN0SWRsZUNhbGxiYWNrID1cbiAgKHR5cGVvZiBzZWxmICE9PSAndW5kZWZpbmVkJyAmJiBzZWxmLnJlcXVlc3RJZGxlQ2FsbGJhY2spIHx8XG4gIGZ1bmN0aW9uIChcbiAgICBjYjogKGRlYWRsaW5lOiBSZXF1ZXN0SWRsZUNhbGxiYWNrRGVhZGxpbmUpID0+IHZvaWRcbiAgKTogTm9kZUpTLlRpbWVvdXQge1xuICAgIGxldCBzdGFydCA9IERhdGUubm93KClcbiAgICByZXR1cm4gc2V0VGltZW91dChmdW5jdGlvbiAoKSB7XG4gICAgICBjYih7XG4gICAgICAgIGRpZFRpbWVvdXQ6IGZhbHNlLFxuICAgICAgICB0aW1lUmVtYWluaW5nOiBmdW5jdGlvbiAoKSB7XG4gICAgICAgICAgcmV0dXJuIE1hdGgubWF4KDAsIDUwIC0gKERhdGUubm93KCkgLSBzdGFydCkpXG4gICAgICAgIH0sXG4gICAgICB9KVxuICAgIH0sIDEpXG4gIH1cblxuZXhwb3J0IGNvbnN0IGNhbmNlbElkbGVDYWxsYmFjayA9XG4gICh0eXBlb2Ygc2VsZiAhPT0gJ3VuZGVmaW5lZCcgJiYgc2VsZi5jYW5jZWxJZGxlQ2FsbGJhY2spIHx8XG4gIGZ1bmN0aW9uIChpZDogUmVxdWVzdElkbGVDYWxsYmFja0hhbmRsZSkge1xuICAgIHJldHVybiBjbGVhclRpbWVvdXQoaWQpXG4gIH1cbiIsImltcG9ydCB7IHVzZUNhbGxiYWNrLCB1c2VFZmZlY3QsIHVzZVJlZiwgdXNlU3RhdGUgfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7XG4gIHJlcXVlc3RJZGxlQ2FsbGJhY2ssXG4gIGNhbmNlbElkbGVDYWxsYmFjayxcbn0gZnJvbSAnLi9yZXF1ZXN0LWlkbGUtY2FsbGJhY2snXG5cbnR5cGUgVXNlSW50ZXJzZWN0aW9uT2JzZXJ2ZXJJbml0ID0gUGljazxJbnRlcnNlY3Rpb25PYnNlcnZlckluaXQsICdyb290TWFyZ2luJz5cbnR5cGUgVXNlSW50ZXJzZWN0aW9uID0geyBkaXNhYmxlZD86IGJvb2xlYW4gfSAmIFVzZUludGVyc2VjdGlvbk9ic2VydmVySW5pdFxudHlwZSBPYnNlcnZlQ2FsbGJhY2sgPSAoaXNWaXNpYmxlOiBib29sZWFuKSA9PiB2b2lkXG50eXBlIE9ic2VydmVyID0ge1xuICBpZDogc3RyaW5nXG4gIG9ic2VydmVyOiBJbnRlcnNlY3Rpb25PYnNlcnZlclxuICBlbGVtZW50czogTWFwPEVsZW1lbnQsIE9ic2VydmVDYWxsYmFjaz5cbn1cblxuY29uc3QgaGFzSW50ZXJzZWN0aW9uT2JzZXJ2ZXIgPSB0eXBlb2YgSW50ZXJzZWN0aW9uT2JzZXJ2ZXIgIT09ICd1bmRlZmluZWQnXG5cbmV4cG9ydCBmdW5jdGlvbiB1c2VJbnRlcnNlY3Rpb248VCBleHRlbmRzIEVsZW1lbnQ+KHtcbiAgcm9vdE1hcmdpbixcbiAgZGlzYWJsZWQsXG59OiBVc2VJbnRlcnNlY3Rpb24pOiBbKGVsZW1lbnQ6IFQgfCBudWxsKSA9PiB2b2lkLCBib29sZWFuXSB7XG4gIGNvbnN0IGlzRGlzYWJsZWQ6IGJvb2xlYW4gPSBkaXNhYmxlZCB8fCAhaGFzSW50ZXJzZWN0aW9uT2JzZXJ2ZXJcblxuICBjb25zdCB1bm9ic2VydmUgPSB1c2VSZWY8RnVuY3Rpb24+KClcbiAgY29uc3QgW3Zpc2libGUsIHNldFZpc2libGVdID0gdXNlU3RhdGUoZmFsc2UpXG5cbiAgY29uc3Qgc2V0UmVmID0gdXNlQ2FsbGJhY2soXG4gICAgKGVsOiBUIHwgbnVsbCkgPT4ge1xuICAgICAgaWYgKHVub2JzZXJ2ZS5jdXJyZW50KSB7XG4gICAgICAgIHVub2JzZXJ2ZS5jdXJyZW50KClcbiAgICAgICAgdW5vYnNlcnZlLmN1cnJlbnQgPSB1bmRlZmluZWRcbiAgICAgIH1cblxuICAgICAgaWYgKGlzRGlzYWJsZWQgfHwgdmlzaWJsZSkgcmV0dXJuXG5cbiAgICAgIGlmIChlbCAmJiBlbC50YWdOYW1lKSB7XG4gICAgICAgIHVub2JzZXJ2ZS5jdXJyZW50ID0gb2JzZXJ2ZShcbiAgICAgICAgICBlbCxcbiAgICAgICAgICAoaXNWaXNpYmxlKSA9PiBpc1Zpc2libGUgJiYgc2V0VmlzaWJsZShpc1Zpc2libGUpLFxuICAgICAgICAgIHsgcm9vdE1hcmdpbiB9XG4gICAgICAgIClcbiAgICAgIH1cbiAgICB9LFxuICAgIFtpc0Rpc2FibGVkLCByb290TWFyZ2luLCB2aXNpYmxlXVxuICApXG5cbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBpZiAoIWhhc0ludGVyc2VjdGlvbk9ic2VydmVyKSB7XG4gICAgICBpZiAoIXZpc2libGUpIHtcbiAgICAgICAgY29uc3QgaWRsZUNhbGxiYWNrID0gcmVxdWVzdElkbGVDYWxsYmFjaygoKSA9PiBzZXRWaXNpYmxlKHRydWUpKVxuICAgICAgICByZXR1cm4gKCkgPT4gY2FuY2VsSWRsZUNhbGxiYWNrKGlkbGVDYWxsYmFjaylcbiAgICAgIH1cbiAgICB9XG4gIH0sIFt2aXNpYmxlXSlcblxuICByZXR1cm4gW3NldFJlZiwgdmlzaWJsZV1cbn1cblxuZnVuY3Rpb24gb2JzZXJ2ZShcbiAgZWxlbWVudDogRWxlbWVudCxcbiAgY2FsbGJhY2s6IE9ic2VydmVDYWxsYmFjayxcbiAgb3B0aW9uczogVXNlSW50ZXJzZWN0aW9uT2JzZXJ2ZXJJbml0XG4pOiAoKSA9PiB2b2lkIHtcbiAgY29uc3QgeyBpZCwgb2JzZXJ2ZXIsIGVsZW1lbnRzIH0gPSBjcmVhdGVPYnNlcnZlcihvcHRpb25zKVxuICBlbGVtZW50cy5zZXQoZWxlbWVudCwgY2FsbGJhY2spXG5cbiAgb2JzZXJ2ZXIub2JzZXJ2ZShlbGVtZW50KVxuICByZXR1cm4gZnVuY3Rpb24gdW5vYnNlcnZlKCk6IHZvaWQge1xuICAgIGVsZW1lbnRzLmRlbGV0ZShlbGVtZW50KVxuICAgIG9ic2VydmVyLnVub2JzZXJ2ZShlbGVtZW50KVxuXG4gICAgLy8gRGVzdHJveSBvYnNlcnZlciB3aGVuIHRoZXJlJ3Mgbm90aGluZyBsZWZ0IHRvIHdhdGNoOlxuICAgIGlmIChlbGVtZW50cy5zaXplID09PSAwKSB7XG4gICAgICBvYnNlcnZlci5kaXNjb25uZWN0KClcbiAgICAgIG9ic2VydmVycy5kZWxldGUoaWQpXG4gICAgfVxuICB9XG59XG5cbmNvbnN0IG9ic2VydmVycyA9IG5ldyBNYXA8c3RyaW5nLCBPYnNlcnZlcj4oKVxuZnVuY3Rpb24gY3JlYXRlT2JzZXJ2ZXIob3B0aW9uczogVXNlSW50ZXJzZWN0aW9uT2JzZXJ2ZXJJbml0KTogT2JzZXJ2ZXIge1xuICBjb25zdCBpZCA9IG9wdGlvbnMucm9vdE1hcmdpbiB8fCAnJ1xuICBsZXQgaW5zdGFuY2UgPSBvYnNlcnZlcnMuZ2V0KGlkKVxuICBpZiAoaW5zdGFuY2UpIHtcbiAgICByZXR1cm4gaW5zdGFuY2VcbiAgfVxuXG4gIGNvbnN0IGVsZW1lbnRzID0gbmV3IE1hcDxFbGVtZW50LCBPYnNlcnZlQ2FsbGJhY2s+KClcbiAgY29uc3Qgb2JzZXJ2ZXIgPSBuZXcgSW50ZXJzZWN0aW9uT2JzZXJ2ZXIoKGVudHJpZXMpID0+IHtcbiAgICBlbnRyaWVzLmZvckVhY2goKGVudHJ5KSA9PiB7XG4gICAgICBjb25zdCBjYWxsYmFjayA9IGVsZW1lbnRzLmdldChlbnRyeS50YXJnZXQpXG4gICAgICBjb25zdCBpc1Zpc2libGUgPSBlbnRyeS5pc0ludGVyc2VjdGluZyB8fCBlbnRyeS5pbnRlcnNlY3Rpb25SYXRpbyA+IDBcbiAgICAgIGlmIChjYWxsYmFjayAmJiBpc1Zpc2libGUpIHtcbiAgICAgICAgY2FsbGJhY2soaXNWaXNpYmxlKVxuICAgICAgfVxuICAgIH0pXG4gIH0sIG9wdGlvbnMpXG5cbiAgb2JzZXJ2ZXJzLnNldChcbiAgICBpZCxcbiAgICAoaW5zdGFuY2UgPSB7XG4gICAgICBpZCxcbiAgICAgIG9ic2VydmVyLFxuICAgICAgZWxlbWVudHMsXG4gICAgfSlcbiAgKVxuICByZXR1cm4gaW5zdGFuY2Vcbn1cbiIsImltcG9ydCBSZWFjdCwgeyBFcnJvckluZm8gfSBmcm9tICdyZWFjdCdcbmltcG9ydCB7XG4gIGV4ZWNPbmNlLFxuICBsb2FkR2V0SW5pdGlhbFByb3BzLFxuICBBcHBDb250ZXh0VHlwZSxcbiAgQXBwSW5pdGlhbFByb3BzLFxuICBBcHBQcm9wc1R5cGUsXG4gIE5leHRXZWJWaXRhbHNNZXRyaWMsXG59IGZyb20gJy4uL25leHQtc2VydmVyL2xpYi91dGlscydcbmltcG9ydCB7IFJvdXRlciB9IGZyb20gJy4uL2NsaWVudC9yb3V0ZXInXG5cbmV4cG9ydCB7IEFwcEluaXRpYWxQcm9wcyB9XG5cbmV4cG9ydCB7IE5leHRXZWJWaXRhbHNNZXRyaWMgfVxuXG5leHBvcnQgdHlwZSBBcHBDb250ZXh0ID0gQXBwQ29udGV4dFR5cGU8Um91dGVyPlxuXG5leHBvcnQgdHlwZSBBcHBQcm9wczxQID0ge30+ID0gQXBwUHJvcHNUeXBlPFJvdXRlciwgUD5cblxuLyoqXG4gKiBgQXBwYCBjb21wb25lbnQgaXMgdXNlZCBmb3IgaW5pdGlhbGl6ZSBvZiBwYWdlcy4gSXQgYWxsb3dzIGZvciBvdmVyd3JpdGluZyBhbmQgZnVsbCBjb250cm9sIG9mIHRoZSBgcGFnZWAgaW5pdGlhbGl6YXRpb24uXG4gKiBUaGlzIGFsbG93cyBmb3Iga2VlcGluZyBzdGF0ZSBiZXR3ZWVuIG5hdmlnYXRpb24sIGN1c3RvbSBlcnJvciBoYW5kbGluZywgaW5qZWN0aW5nIGFkZGl0aW9uYWwgZGF0YS5cbiAqL1xuYXN5bmMgZnVuY3Rpb24gYXBwR2V0SW5pdGlhbFByb3BzKHtcbiAgQ29tcG9uZW50LFxuICBjdHgsXG59OiBBcHBDb250ZXh0KTogUHJvbWlzZTxBcHBJbml0aWFsUHJvcHM+IHtcbiAgY29uc3QgcGFnZVByb3BzID0gYXdhaXQgbG9hZEdldEluaXRpYWxQcm9wcyhDb21wb25lbnQsIGN0eClcbiAgcmV0dXJuIHsgcGFnZVByb3BzIH1cbn1cblxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgQXBwPFAgPSB7fSwgQ1AgPSB7fSwgUyA9IHt9PiBleHRlbmRzIFJlYWN0LkNvbXBvbmVudDxcbiAgUCAmIEFwcFByb3BzPENQPixcbiAgU1xuPiB7XG4gIHN0YXRpYyBvcmlnR2V0SW5pdGlhbFByb3BzID0gYXBwR2V0SW5pdGlhbFByb3BzXG4gIHN0YXRpYyBnZXRJbml0aWFsUHJvcHMgPSBhcHBHZXRJbml0aWFsUHJvcHNcblxuICAvLyBLZXB0IGhlcmUgZm9yIGJhY2t3YXJkcyBjb21wYXRpYmlsaXR5LlxuICAvLyBXaGVuIHNvbWVvbmUgZW5kZWQgQXBwIHRoZXkgY291bGQgY2FsbCBgc3VwZXIuY29tcG9uZW50RGlkQ2F0Y2hgLlxuICAvLyBAZGVwcmVjYXRlZCBUaGlzIG1ldGhvZCBpcyBubyBsb25nZXIgbmVlZGVkLiBFcnJvcnMgYXJlIGNhdWdodCBhdCB0aGUgdG9wIGxldmVsXG4gIGNvbXBvbmVudERpZENhdGNoKGVycm9yOiBFcnJvciwgX2Vycm9ySW5mbzogRXJyb3JJbmZvKTogdm9pZCB7XG4gICAgdGhyb3cgZXJyb3JcbiAgfVxuXG4gIHJlbmRlcigpIHtcbiAgICBjb25zdCB7IHJvdXRlciwgQ29tcG9uZW50LCBwYWdlUHJvcHMsIF9fTl9TU0csIF9fTl9TU1AgfSA9IHRoaXNcbiAgICAgIC5wcm9wcyBhcyBBcHBQcm9wczxDUD5cblxuICAgIHJldHVybiAoXG4gICAgICA8Q29tcG9uZW50XG4gICAgICAgIHsuLi5wYWdlUHJvcHN9XG4gICAgICAgIHtcbiAgICAgICAgICAvLyB3ZSBkb24ndCBhZGQgdGhlIGxlZ2FjeSBVUkwgcHJvcCBpZiBpdCdzIHVzaW5nIG5vbi1sZWdhY3lcbiAgICAgICAgICAvLyBtZXRob2RzIGxpa2UgZ2V0U3RhdGljUHJvcHMgYW5kIGdldFNlcnZlclNpZGVQcm9wc1xuICAgICAgICAgIC4uLighKF9fTl9TU0cgfHwgX19OX1NTUCkgPyB7IHVybDogY3JlYXRlVXJsKHJvdXRlcikgfSA6IHt9KVxuICAgICAgICB9XG4gICAgICAvPlxuICAgIClcbiAgfVxufVxuXG5sZXQgd2FybkNvbnRhaW5lcjogKCkgPT4gdm9pZFxubGV0IHdhcm5Vcmw6ICgpID0+IHZvaWRcblxuaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHtcbiAgd2FybkNvbnRhaW5lciA9IGV4ZWNPbmNlKCgpID0+IHtcbiAgICBjb25zb2xlLndhcm4oXG4gICAgICBgV2FybmluZzogdGhlIFxcYENvbnRhaW5lclxcYCBpbiBcXGBfYXBwXFxgIGhhcyBiZWVuIGRlcHJlY2F0ZWQgYW5kIHNob3VsZCBiZSByZW1vdmVkLiBodHRwczovL25leHRqcy5vcmcvZG9jcy9tZXNzYWdlcy9hcHAtY29udGFpbmVyLWRlcHJlY2F0ZWRgXG4gICAgKVxuICB9KVxuXG4gIHdhcm5VcmwgPSBleGVjT25jZSgoKSA9PiB7XG4gICAgY29uc29sZS5lcnJvcihcbiAgICAgIGBXYXJuaW5nOiB0aGUgJ3VybCcgcHJvcGVydHkgaXMgZGVwcmVjYXRlZC4gaHR0cHM6Ly9uZXh0anMub3JnL2RvY3MvbWVzc2FnZXMvdXJsLWRlcHJlY2F0ZWRgXG4gICAgKVxuICB9KVxufVxuXG4vLyBAZGVwcmVjYXRlZCBub29wIGZvciBub3cgdW50aWwgcmVtb3ZhbFxuZXhwb3J0IGZ1bmN0aW9uIENvbnRhaW5lcihwOiBhbnkpIHtcbiAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHdhcm5Db250YWluZXIoKVxuICByZXR1cm4gcC5jaGlsZHJlblxufVxuXG5leHBvcnQgZnVuY3Rpb24gY3JlYXRlVXJsKHJvdXRlcjogUm91dGVyKSB7XG4gIC8vIFRoaXMgaXMgdG8gbWFrZSBzdXJlIHdlIGRvbid0IHJlZmVyZW5jZXMgdGhlIHJvdXRlciBvYmplY3QgYXQgY2FsbCB0aW1lXG4gIGNvbnN0IHsgcGF0aG5hbWUsIGFzUGF0aCwgcXVlcnkgfSA9IHJvdXRlclxuICByZXR1cm4ge1xuICAgIGdldCBxdWVyeSgpIHtcbiAgICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB3YXJuVXJsKClcbiAgICAgIHJldHVybiBxdWVyeVxuICAgIH0sXG4gICAgZ2V0IHBhdGhuYW1lKCkge1xuICAgICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHdhcm5VcmwoKVxuICAgICAgcmV0dXJuIHBhdGhuYW1lXG4gICAgfSxcbiAgICBnZXQgYXNQYXRoKCkge1xuICAgICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHdhcm5VcmwoKVxuICAgICAgcmV0dXJuIGFzUGF0aFxuICAgIH0sXG4gICAgYmFjazogKCkgPT4ge1xuICAgICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHdhcm5VcmwoKVxuICAgICAgcm91dGVyLmJhY2soKVxuICAgIH0sXG4gICAgcHVzaDogKHVybDogc3RyaW5nLCBhcz86IHN0cmluZykgPT4ge1xuICAgICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHdhcm5VcmwoKVxuICAgICAgcmV0dXJuIHJvdXRlci5wdXNoKHVybCwgYXMpXG4gICAgfSxcbiAgICBwdXNoVG86IChocmVmOiBzdHJpbmcsIGFzPzogc3RyaW5nKSA9PiB7XG4gICAgICBpZiAocHJvY2Vzcy5lbnYuTk9ERV9FTlYgIT09ICdwcm9kdWN0aW9uJykgd2FyblVybCgpXG4gICAgICBjb25zdCBwdXNoUm91dGUgPSBhcyA/IGhyZWYgOiAnJ1xuICAgICAgY29uc3QgcHVzaFVybCA9IGFzIHx8IGhyZWZcblxuICAgICAgcmV0dXJuIHJvdXRlci5wdXNoKHB1c2hSb3V0ZSwgcHVzaFVybClcbiAgICB9LFxuICAgIHJlcGxhY2U6ICh1cmw6IHN0cmluZywgYXM/OiBzdHJpbmcpID0+IHtcbiAgICAgIGlmIChwcm9jZXNzLmVudi5OT0RFX0VOViAhPT0gJ3Byb2R1Y3Rpb24nKSB3YXJuVXJsKClcbiAgICAgIHJldHVybiByb3V0ZXIucmVwbGFjZSh1cmwsIGFzKVxuICAgIH0sXG4gICAgcmVwbGFjZVRvOiAoaHJlZjogc3RyaW5nLCBhcz86IHN0cmluZykgPT4ge1xuICAgICAgaWYgKHByb2Nlc3MuZW52Lk5PREVfRU5WICE9PSAncHJvZHVjdGlvbicpIHdhcm5VcmwoKVxuICAgICAgY29uc3QgcmVwbGFjZVJvdXRlID0gYXMgPyBocmVmIDogJydcbiAgICAgIGNvbnN0IHJlcGxhY2VVcmwgPSBhcyB8fCBocmVmXG5cbiAgICAgIHJldHVybiByb3V0ZXIucmVwbGFjZShyZXBsYWNlUm91dGUsIHJlcGxhY2VVcmwpXG4gICAgfSxcbiAgfVxufVxuIiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKCcuL2Rpc3QvY2xpZW50L2ltYWdlJylcbiIsImltcG9ydCB7IEFwcENvbmZpZywgYXBwQ29uZmlnVmFyIH0gZnJvbSBcIi4uLy4uL21vZGVscy9BcHBDb25maWdcIjtcbmltcG9ydCB7IFJlYWN0aXZlVmFyIH0gZnJvbSBcIkBhcG9sbG8vY2xpZW50XCI7XG5cbmNvbnN0IHRvb2dsZU1lbnUgPSBmdW5jdGlvbiAoYXBwQ29uZmlnOiBSZWFjdGl2ZVZhcjxBcHBDb25maWc+KSB7XG4gIHJldHVybiAoKSA9PiB7XG4gICAgY29uc3QgX2FwcENvbmZpZyA9IHsgLi4uYXBwQ29uZmlnKCkgfTtcbiAgICBfYXBwQ29uZmlnLm1lbnUgPSAhX2FwcENvbmZpZy5tZW51O1xuICAgIGFwcENvbmZpZyhfYXBwQ29uZmlnKTtcbiAgfTtcbn07XG5cbmNvbnN0IHNldFNlbGVjdGVkTmF2TWVudSA9IGZ1bmN0aW9uIChhcHBDb25maWc6IFJlYWN0aXZlVmFyPEFwcENvbmZpZz4pIHtcbiAgcmV0dXJuIChuYXZNZW51SWQ6IHN0cmluZyB8IG51bGwpID0+IHtcbiAgICBjb25zdCBfYXBwQ29uZmlnID0geyAuLi5hcHBDb25maWcoKSB9O1xuICAgIF9hcHBDb25maWcubmF2TWVudVNlbGVjdGVkID0gbmF2TWVudUlkO1xuICAgIGFwcENvbmZpZyhfYXBwQ29uZmlnKTtcbiAgfTtcbn07XG5cbmNvbnN0IGFwcENvbmZpZ011dGF0aW9ucyA9IHtcbiAgdG9vZ2xlTWVudTogdG9vZ2xlTWVudShhcHBDb25maWdWYXIpLFxuICBzZXRTZWxlY3RlZE5hdk1lbnU6IHNldFNlbGVjdGVkTmF2TWVudShhcHBDb25maWdWYXIpLFxufTtcblxuZXhwb3J0IGRlZmF1bHQgYXBwQ29uZmlnTXV0YXRpb25zO1xuIiwiaW1wb3J0IHsgZ3FsIH0gZnJvbSBcIkBhcG9sbG8vY2xpZW50XCI7XG5cbmV4cG9ydCBjb25zdCBHRVRfTkFWX01FTlVfU1RBVEUgPSBncWxgXG4gIHF1ZXJ5IEdldE5hdk1lbnVTdGF0ZSB7XG4gICAgYXBwQ29uZmlnIEBjbGllbnQge1xuICAgICAgbWVudVxuICAgICAgbmF2TWVudVNlbGVjdGVkXG4gICAgfVxuICB9XG5gO1xuIiwiaW1wb3J0IHsgR0VUX05BVl9NRU5VX1NUQVRFIH0gZnJvbSBcIi4vYXBwQ29uZmlnLnF1ZXJpZXNcIjtcbmltcG9ydCBhcHBDb25maWdNdXRhdGlvbiBmcm9tIFwiLi9hcHBDb25maWcubXV0YXRpb25cIjtcblxuY29uc3QgYXBwQ29uZmlxUXVlcnkgPSB7XG4gIEdFVF9OQVZfTUVOVV9TVEFURSxcbn07XG5cbmV4cG9ydCB7IGFwcENvbmZpZ011dGF0aW9uLCBhcHBDb25maXFRdWVyeSB9O1xuIiwiaW1wb3J0IFJlYWN0IGZyb20gJ3JlYWN0JztcbmltcG9ydCBBcHAsIHsgQXBwUHJvcHMgfSBmcm9tICduZXh0L2FwcCc7XG5pbXBvcnQgJ3RhaWx3aW5kY3NzL3RhaWx3aW5kLmNzcyc7XG5pbXBvcnQgJ0BzdHlsZXMvZ2xvYmFsLnNjc3MnO1xuaW1wb3J0IFwicmVhY3QtcmVzcG9uc2l2ZS1jYXJvdXNlbC9saWIvc3R5bGVzL2Nhcm91c2VsLm1pbi5jc3NcIjsgLy8gcmVxdWlyZXMgYSBsb2FkZXJcbmltcG9ydCB7IEFwb2xsb1Byb3ZpZGVyIH0gZnJvbSAnQGFwb2xsby9jbGllbnQnO1xuaW1wb3J0IHsgdXNlQXBvbGxvIH0gZnJvbSAnaGVscGVyL2Fwb2xsbyc7XG5pbXBvcnQgeyB1c2VEZXZpY2VUeXBlIH0gZnJvbSAnaGVscGVyL3VzZURldmljZVR5cGUnO1xuaW1wb3J0IHsgUm9vdCB9IGZyb20gJy4uL3NyYy9tb2R1bGVzL3Jvb3QnO1xuLy8gaW1wb3J0ICdib290c3RyYXAvZGlzdC9jc3MvYm9vdHN0cmFwLmNzcydcbi8vIGltcG9ydCBIZWFkIGZyb20gXCJuZXh0L2hlYWRcIjtcblxuXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBFeHRlbmRlZEFwcCh7XG4gIENvbXBvbmVudCxcbiAgcGFnZVByb3BzLFxuICB1c2VyQWdlbnQsXG59KTogSlNYLkVsZW1lbnQge1xuICBjb25zdCBhcG9sbG9DbGllbnQgPSB1c2VBcG9sbG8ocGFnZVByb3BzKTtcbiAgY29uc3QgZGV2aWNlVHlwZSA9IHVzZURldmljZVR5cGUodXNlckFnZW50KTtcblxuICByZXR1cm4gKFxuICAgIDw+XG4gICAgICB7LyogPEhlYWQ+XG4gICAgICAgIDxtZXRhIG5hbWU9XCJ2aWV3cG9ydFwiIGNvbnRlbnQ9XCJ3aWR0aD1kZXZpY2Utd2lkdGgsIGluaXRpYWwtc2NhbGU9MVwiIC8+XG4gICAgICA8L0hlYWQ+ICovfVxuICAgICAgPEFwb2xsb1Byb3ZpZGVyIGNsaWVudD17YXBvbGxvQ2xpZW50fT5cbiAgICAgICAgPFJvb3QgZGV2aWNlVHlwZT17ZGV2aWNlVHlwZX0+XG4gICAgICAgICAgPENvbXBvbmVudCB7Li4ucGFnZVByb3BzfSBkZXZpY2VUeXBlPXtkZXZpY2VUeXBlfSAvPlxuICAgICAgICA8L1Jvb3Q+XG4gICAgICA8L0Fwb2xsb1Byb3ZpZGVyPlxuICAgIDwvPlxuICApO1xufVxuXG5FeHRlbmRlZEFwcC5nZXRJbml0aWFsUHJvcHMgPSBhc3luYyAoYXBwQ29udGV4dCkgPT4ge1xuICBjb25zdCBhcHBQcm9wcyA9IGF3YWl0IEFwcC5nZXRJbml0aWFsUHJvcHMoYXBwQ29udGV4dCk7XG4gIGNvbnN0IHsgcmVxLCBxdWVyeSB9ID0gYXBwQ29udGV4dC5jdHg7XG4gIGNvbnN0IHVzZXJBZ2VudCA9IHJlcSA/IHJlcS5oZWFkZXJzWyd1c2VyLWFnZW50J10gOiBuYXZpZ2F0b3IudXNlckFnZW50O1xuXG4gIHJldHVybiB7IC4uLmFwcFByb3BzLCB1c2VyQWdlbnQsIHF1ZXJ5IH07XG59O1xuIiwiaW1wb3J0IFJlYWN0LCB7IHVzZVN0YXRlIH0gZnJvbSBcInJlYWN0XCI7XG5cbmV4cG9ydCB0eXBlIFByb3BzID0ge1xuICB0aXRsZT86IHN0cmluZztcbiAgc3ViVGl0bGU/OiBzdHJpbmc7XG4gIGJhbm5lckltZz86IGFueTtcbiAgbW9iaWxlQmFubmVySW1nPzogYW55O1xufTtcblxuZXhwb3J0IGNvbnN0IEJhbm5lcjogUmVhY3QuRkM8UHJvcHM+ID0gKHsgdGl0bGUsIHN1YlRpdGxlLCBiYW5uZXJJbWcsIG1vYmlsZUJhbm5lckltZyB9KSA9PiB7XG5cbiAgcmV0dXJuIChcbiAgICA8PlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJzbTpoaWRkZW4gdy1mdWxsIGJnLWNvdmVyIGJnLWNlbnRlciBjLWJnIHJlbGF0aXZlXCIgc3R5bGU9e3sgYmFja2dyb3VuZEltYWdlOiBgdXJsKCR7YmFubmVySW1nfSlgIH19PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGgtZnVsbCB3LWZ1bGwgYmctZ3JheS05MDAgYmctb3BhY2l0eS01MFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXJcIj5cbiAgICAgICAgICAgIDxoMSBjbGFzc05hbWU9XCJ0ZXh0LXdoaXRlIHRleHQtN2xnIG1kOmxlYWRpbmctMTAgZm9udC1ib2xkIHhsOnRleHQtNHhsIHNtOnRleHQtMnhsXCI+e3RpdGxlfTwvaDE+XG4gICAgICAgICAgICA8cCBjbGFzc05hbWU9XCJ0ZXh0LXdoaXRlIHRleHQtM21kIG1kOnRleHQteGxcIj57c3ViVGl0bGV9PC9wPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IHctZnVsbCByZWxhdGl2ZSBwb3NpdGlvbi1ib3R0b21cIj5cblxuICAgICAgICAgICAgICB7LyogPGRpdiBjbGFzc05hbWU9XCJjb250ZW50LWNlbnRlciBtLWF1dG9cIj5cbiAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJ0ZXh0LXdoaXRlIHB0LTE5cCBwbC0zcCBidG4tYWN0aXZlLWJnIHB5LTIgdGV4dC0zeGwgXCI+XG4gICAgICAgICAgICAgICAgQ1VSUkVOVCBJTlZFU1RNRU5UU1xuICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgPGJ1dHRvbiBjbGFzc05hbWU9XCJ0eHQtd2hpdGUgcGwtM3AgcHQtMTlwIHB5LTIgdGV4dC0zeGxcIj5cbiAgICAgICAgICAgICAgICBQQVNUIElOVkVTVE1FTlRTXG4gICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgPC9kaXY+ICovfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwic206YmxvY2sgaGlkZGVuIHctZnVsbCBiZy1jb3ZlciBiZy1jZW50ZXIgYy1iZyByZWxhdGl2ZVwiIHN0eWxlPXt7IGJhY2tncm91bmRJbWFnZTogYGxpbmVhci1ncmFkaWVudChyZ2JhKDAsIDAsIDAsIDAuNSksIHJnYmEoMCwgMCwgMCwgMC41KSksdXJsKCR7bW9iaWxlQmFubmVySW1nfSlgIH19PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggaXRlbXMtY2VudGVyIGp1c3RpZnktY2VudGVyIGgtZnVsbCB3LWZ1bGwgYmctZ3JheS05MDAgYmctb3BhY2l0eS01MFwiPlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicC04XCI+XG4gICAgICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC13aGl0ZSBsZWFkaW5nLXRpZ2h0IHRleHQtNXNtIGZvbnQtbWVkaXVtIHNtOnRleHQtbGVmdFwiPnt0aXRsZX08L2gxPlxuICAgICAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC13aGl0ZSB0ZXh0LXhsIHNtOnRleHQtbGVmdFwiPntzdWJUaXRsZX08L3A+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggdy1mdWxsIHJlbGF0aXZlIHBvc2l0aW9uLWJvdHRvbVwiPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC8+XG4gICk7XG59O1xuIiwiaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuXG5leHBvcnQgdHlwZSBQcm9wcyA9IHtcbiAgdGl0bGU6IHN0cmluZztcbiAgdXJsOiBzdHJpbmc7XG4gIG9uQ2xpY2s/OiAoKSA9PiB2b2lkO1xuICBjbGFzc05hbWU/OiBzdHJpbmc7XG4gIHN0eWxlPzogYW55O1xufTtcblxuY29uc3QgQnV0dG9uOiBSZWFjdC5GQzxQcm9wcz4gPSAoe1xuICB0aXRsZSxcbiAgdXJsLFxuICBvbkNsaWNrLFxuICBjbGFzc05hbWUgPSBcIlwiLFxuICBzdHlsZSA9IHt9LFxufSkgPT4ge1xuICByZXR1cm4gKFxuICAgIDxidXR0b25cbiAgICAgIG9uQ2xpY2s9e29uQ2xpY2t9XG4gICAgICBzdHlsZT17c3R5bGV9XG4gICAgICBjbGFzc05hbWU9e2BmbGV4IHAtMC41IHBsLTAgaXRlbXMtY2VudGVyIG10LTIgJHtjbGFzc05hbWV9YH1cbiAgICA+XG4gICAgICB7XCIgXCJ9XG4gICAgICB7dGl0bGV9IDxpbWcgY2xhc3NOYW1lPVwicGwtMlwiIHNyYz17dXJsfT48L2ltZz5cbiAgICA8L2J1dHRvbj5cbiAgKTtcbn07XG5cbmV4cG9ydCBkZWZhdWx0IEJ1dHRvbjtcbiIsImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcblxuXG5leHBvcnQgdHlwZSBQcm9wcyA9IHtcbiAgICB0aXRsZTogc3RyaW5nO1xuICAgIG9uQ2xpY2s/OiAoKSA9PiB2b2lkO1xuICAgIGNsYXNzTmFtZT86IHN0cmluZ1xufVxuXG5leHBvcnQgY29uc3QgU2Vjb25kYXJ5QnV0dG9uOiBSZWFjdC5GQzxQcm9wcz4gPSAoeyB0aXRsZSwgb25DbGljaywgY2xhc3NOYW1lIH0pID0+IHtcbiAgICByZXR1cm4gKDxidXR0b24gY2xhc3NOYW1lPXtgdGV4dC1sZyBsZWFkaW5nLTYgZm9udC1tZWRpdW0gdW5kZXJsaW5lIHRleHQtYWNjZW50LWRhcmsgICR7Y2xhc3NOYW1lfWB9ID4ge3RpdGxlfTwvYnV0dG9uPik7XG59IiwiaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuXG5leHBvcnQgdHlwZSBJQnV0dG9uID0gUmVhY3QuRGV0YWlsZWRIVE1MUHJvcHM8XG4gIFJlYWN0LkJ1dHRvbkhUTUxBdHRyaWJ1dGVzPEhUTUxCdXR0b25FbGVtZW50PixcbiAgSFRNTEJ1dHRvbkVsZW1lbnRcbj47XG5cbmV4cG9ydCBjb25zdCBCdXR0b246IFJlYWN0LkZDPElCdXR0b24+ID0gKHtcbiAgY2xhc3NOYW1lID0gXCJcIixcbiAgY2hpbGRyZW4sXG4gIC4uLnJlc3Rcbn0pID0+IHtcbiAgcmV0dXJuIChcbiAgICA8YnV0dG9uXG4gICAgICBjbGFzc05hbWU9e2BweS0yIHB4LTQgcm91bmRlZCBiZy1ncmVlbi01MDAgaG92ZXI6YmctZ3JlZW4tNjAwIGZvY3VzOm91dGxpbmUtbm9uZSByaW5nLW9wYWNpdHktNzUgcmluZy1ncmVlbi00MDAgZm9jdXM6cmluZyB0ZXh0LXdoaXRlIHRleHQtbGcgJHtjbGFzc05hbWV9YH1cbiAgICAgIHsuLi5yZXN0fVxuICAgID5cbiAgICAgIHtjaGlsZHJlbn1cbiAgICA8L2J1dHRvbj5cbiAgKTtcbn07XG4iLCJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5cbmltcG9ydCBkYXRhIGZyb20gXCJAcHVibGljL21ldGEuanNvblwiO1xuXG5leHBvcnQgY29uc3QgQ2FyZHM6IFJlYWN0LkZDID0gKCkgPT4ge1xuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC0xIGNvbnRhaW5lciBteS04IG1heC13LXNjcmVlbi1sZyBteC1hdXRvIHAtNVwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJncmlkIGdyaWQtY29scy0xIG1kOmdyaWQtY29scy0yIGxnOmdyaWQtY29scy0zIGdhcC02XCI+XG4gICAgICAgIHsoZGF0YT8ucGx1Z2lucyA/PyBbXSkubWFwKChwbHVnaW4pID0+IChcbiAgICAgICAgICA8ZGl2XG4gICAgICAgICAgICBrZXk9e3BsdWdpbi5uYW1lfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiY29sLXNwYW4tMSByb3VuZGVkLW1kIGJvcmRlciBib3JkZXItZ3JheS0zMDAgcC01XCJcbiAgICAgICAgICA+XG4gICAgICAgICAgICA8aDIgY2xhc3NOYW1lPVwidGV4dC14bCBmb250LXNlbWlib2xkIG1iLTJcIj57cGx1Z2luLm5hbWV9PC9oMj5cbiAgICAgICAgICAgIDxwIGNsYXNzTmFtZT1cIm0tMFwiPntwbHVnaW4uZGVzY3JpcHRpb259PC9wPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICApKX1cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufTtcbiIsImV4cG9ydCBjb25zdCBDb250YWluZXIgPSAoeyBjaGlsZHJlbiB9KSA9PiB7XG4gIHJldHVybiA8ZGl2IGNsYXNzTmFtZT1cIm1pbi1oLXNjcmVlbiBmbGV4IGZsZXgtY29sXCI+e2NoaWxkcmVufTwvZGl2Pjtcbn07XG4iLCJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBJbWFnZSB9IGZyb20gXCJAY29tcG9uZW50c1wiO1xuaW1wb3J0IEJ1dHRvbiBmcm9tIFwiQGNvbXBvbmVudHMvYnV0dG9uL1ByaW1hcnlCdXR0b25JY29uUmlnaHRcIjtcbmltcG9ydCBnZXRDb250ZW50VHlwZUltYWdlVXJsIGZyb20gXCIuLi8uLi8uLi91dGlscy9nZXRDb250ZW50VHlwZUltYWdlVXJsXCI7XG5cbmV4cG9ydCB0eXBlIFByb3BzID0ge1xuICBpbWFnZV91cmw6IHN0cmluZztcbiAgdGl0bGU6IHN0cmluZztcbiAgYXV0aG9yOiBzdHJpbmc7XG4gIG9uQ2xpY2s6IChpZDogc3RyaW5nKSA9PiB2b2lkO1xuICBjb250ZW50X2lkOiBzdHJpbmc7XG4gIGNvbnRlbnRfdHlwZTogc3RyaW5nO1xuICByZWFkX2R1cmF0aW9uOiBzdHJpbmc7XG4gIHN0eWxlPzogYW55O1xuICBjbGFzc05hbWU/OiBzdHJpbmc7XG59O1xuXG5leHBvcnQgY29uc3QgQ29udGVudEl0ZW06IFJlYWN0LkZDPFByb3BzPiA9ICh7XG4gIGltYWdlX3VybCxcbiAgY2xhc3NOYW1lID0gXCJcIixcbiAgdGl0bGUsXG4gIGF1dGhvcixcbiAgb25DbGljayxcbiAgY29udGVudF9pZCxcbiAgY29udGVudF90eXBlLFxuICByZWFkX2R1cmF0aW9uLFxuICBzdHlsZSA9IHt9LFxufSkgPT4ge1xuICByZXR1cm4gKFxuICAgIDxkaXZcbiAgICAgIGNsYXNzTmFtZT17YCR7Y2xhc3NOYW1lfSByZWxhdGl2ZSBtYi0xMSBtbC0wYH1cbiAgICAgIHN0eWxlPXtzdHlsZX1cbiAgICA+XG4gICAgICA8SW1hZ2Ugc3JjPXtpbWFnZV91cmx9IGFsdD1cImNvbnRlbnQtaW1hZ2VcIiBjbGFzc05hbWU9XCJcIiAvPlxuICAgICAgPGRpdlxuICAgICAgICBjbGFzc05hbWU9XCJjb250ZW50LWl0ZW0tZGVzYyBiZy1zZWNvbmRhcnktbGlnaHQgYWJzb2x1dGUgdG9wLTQgcC0zXCJcbiAgICAgICAgc3R5bGU9e3sgdG9wOiBcIjIuNXJlbVwiLCBsZWZ0OiBcIjkuNXJlbVwiIH19XG4gICAgICA+XG4gICAgICAgIDxoNSBjbGFzc05hbWU9XCJ0ZXh0LWxnIGZvbnQtbWVkaXVtIGxlYWRpbmctNiB0ZXh0LXByaW1hcnktZGFyayBtbC0yIHAtMC41XCI+XG4gICAgICAgICAge3RpdGxlfVxuICAgICAgICA8L2g1PlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuIG1sLTIgcGwtMC41IHB0LTAuNVwiPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbm9ybWFsIHRleHQteHMgbGVhZGluZy0zICB0ZXh0LXByaW1hcnktZGFyayBvcGFjaXR5LTUwXCI+XG4gICAgICAgICAgICBCWSB7XCIgXCIgKyBhdXRob3J9XG4gICAgICAgICAgPC9zcGFuPlxuICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cImZvbnQtbm9ybWFsIHRleHQteHMgbGVhZGluZy0zICB0ZXh0LXByaW1hcnktZGFyayBvcGFjaXR5LTUwIG1yLTFcIj5cbiAgICAgICAgICAgIHtyZWFkX2R1cmF0aW9uICsgXCIgUkVBRFwifVxuICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gbXQtM1wiPlxuICAgICAgICAgIHsvKiA8YnV0dG9uIG9uQ2xpY2s9eygpID0+IG9uQ2xpY2soY29udGVudF9pZCl9IC8+ICovfVxuICAgICAgICAgIDxCdXR0b25cbiAgICAgICAgICAgIHRpdGxlPXtcIlJlYWQgTW9yZVwifVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwiaC04IHctMzYgdGV4dC1hY2NlbnRcIlxuICAgICAgICAgICAgdXJsPVwiL2ljb25zL3JpZ2h0QXJyb3dHcmF5LnN2Z1wiXG4gICAgICAgICAgLz5cbiAgICAgICAgICA8SW1hZ2VcbiAgICAgICAgICAgIHNyYz17Z2V0Q29udGVudFR5cGVJbWFnZVVybChjb250ZW50X3R5cGUpfVxuICAgICAgICAgICAgYWx0PVwiY29udGVudCB0eXBlIGltYWdlXCJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cIm1yLTFcIlxuICAgICAgICAgIC8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59O1xuIiwiaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgQ29udGVudEl0ZW0gfSBmcm9tIFwiQGNvbXBvbmVudHMvY29udGVudEl0ZW1cIjtcblxuZXhwb3J0IHR5cGUgUHJvcHMgPSB7XG4gICAgY2xhc3NOYW1lPzogc3RyaW5nXG4gICAgY29udGVudExpc3Q6IEFycmF5PGFueT47XG4gICAgc3R5bGU6IGFueSxcbiAgICBoZWFkZXIgOiBhbnk7XG59O1xuXG5leHBvcnQgY29uc3QgQ29udGVudFNsaWRlcjogUmVhY3QuRkM8UHJvcHM+ID0gKHsgY29udGVudExpc3QsIGNsYXNzTmFtZSAsIGhlYWRlciwgc3R5bGU9e319KSA9PiB7XG4gICAgcmV0dXJuIChcbiAgICAgICAgPGRpdiBjbGFzc05hbWU9e2Ake2NsYXNzTmFtZX1gfSBzdHlsZT17c3R5bGV9PlxuICAgICAgICAgICAgPGRpdiA+XG4gICAgICAgICAgICAgICAgPGRpdj57aGVhZGVyfTwvZGl2PlxuICAgICAgICAgICAgICAgIDxkaXY+PC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleFwiPlxuICAgICAgICAgICAgICAgIHtjb250ZW50TGlzdC5tYXAoKGNvbnRlbnRJdGVtKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgICAgICAgICAgICA8Q29udGVudEl0ZW1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBrZXk9e2NvbnRlbnRJdGVtLmNvbnRlbnRfaWR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgaW1hZ2VfdXJsPXtjb250ZW50SXRlbS5pbWFnZV91cmx9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGl0bGU9e2NvbnRlbnRJdGVtLnRpdGxlfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGF1dGhvcj17Y29udGVudEl0ZW0uYXV0aG9yfVxuICAgICAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRlbnRfaWQ9e2NvbnRlbnRJdGVtLmNvbnRlbnRfaWR9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY29udGVudF90eXBlPXtjb250ZW50SXRlbS5jb250ZW50X3R5cGV9XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgcmVhZF9kdXJhdGlvbj17Y29udGVudEl0ZW0ucmVhZF9kdXJhdGlvbn1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoaWQpID0+IGNvbnNvbGUubG9nKGlkKX1cbiAgICAgICAgICAgICAgICAgICAgICAgICAgICBzdHlsZT17e3dpZHRoOjYxMH19XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwibXItMyBtdC0yIHRleHQtbGcgbGVhZGluZy02XCJcbiAgICAgICAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgICAgICk7XG4gICAgICAgICAgICAgICAgfSl9XG4gICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgPC9kaXY+XG4gICAgKTtcbn07XG4iLCJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgbWVudSBmcm9tIFwiLi4vLi4vLi4vY29uc3RhbnRzL2Zvb3Rlck1lbnVcIjtcblxuXG5jb25zdCBGb290ZXJNZW51OiBSZWFjdC5GQyA9ICgpID0+IHtcbiAgcmV0dXJuICg8ZGl2IGNsYXNzTmFtZT1cInNtOmdyaWQgc206Z3JpZC1jb2xzLTIgc206Z2FwLXktMC41ICBiZy1wcmltYXJ5ICAgc3ViLWgyIGxhcHRvcDpmbGV4IGxhcHRvcDppdGVtcy1jZW50ZXIgbGFwdG9wOnBsLTU2IFwiPlxuICAgIHtcbiAgICAgIG1lbnUubWFwKChpdGVtOiBhbnksIGluZGV4OiBudW1iZXIpID0+IHtcbiAgICAgICAgcmV0dXJuICg8c3BhbiBrZXk9e2luZGV4fSBjbGFzc05hbWU9XCJwLTEuNVwiPlxuICAgICAgICAgIDxhIGhyZWY9e2l0ZW0ubGlua30gY2xhc3NOYW1lPVwidGV4dC1zZWNvbmRhcnkgaC0xNCBwLTAuNSBtci0xMSBsZWFkaW5nLTQuNVwiPiB7aXRlbS5uYW1lfTwvYT5cbiAgICAgICAgPC9zcGFuPilcbiAgICAgIH0pXG4gICAgfVxuICA8L2Rpdj4pXG59XG5cbmV4cG9ydCBkZWZhdWx0IEZvb3Rlck1lbnU7XG4iLCJcbmltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCBGb290ZXJNZW51IGZyb20gXCIuL2Zvb3Rlck1lbnVcIjtcbmltcG9ydCBCdXR0b24gZnJvbSBcIkBjb21wb25lbnRzL2J1dHRvbi9QcmltYXJ5QnV0dG9uSWNvblJpZ2h0XCI7XG5pbXBvcnQgeyBQUklWQUNZX1BPTElDWSB9IGZyb20gXCIuLi8uLi8uLi9jb25zdGFudHNcIlxuXG5leHBvcnQgY29uc3QgRm9vdGVyOiBSZWFjdC5GQyA9ICgpID0+IHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXggIGp1c3RpZnktZW5kIGZsZXgtY29sIHRleHQtc2Vjb25kYXJ5IHctZnVsbCBhbGlnbi1ib3R0b20gbXQtYXV0b1wiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJiZy1hY2NlbnQtZGFyayBmb290ZXItdG9wIGZsZXggbGFwdG9wOmp1c3RpZnktYmV0d2VlbiBzbTpmbGV4LWNvbCBzbTpwbC0xMSBzbTpwci0xMSBzbTpwdC0xMVwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImxhcHRvcDpmbGV4IGxhcHRvcDptdC0xNiBwLTAuNSBsYXB0b3A6bWwtNTZcIj5cbiAgICAgICAgICA8aDYgY2xhc3NOYW1lPVwibGFwdG9wOnctNDggZm9udC1ub3JtYWwgbGVhZGluZy05IHRleHQtNHhsIHRyYWNraW5nLXdpZGVyIHAtMC41XCI+IExldCdzIHN0YXkgZW5nYWdlZDwvaDY+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwicC0xIG1sLTRcIj5cbiAgICAgICAgICAgIDxoNiBjbGFzc05hbWU9XCJzdWItaDIgZm9udC1tZWRpdW0gdGV4dC1sZyBsZWFkaW5nLTZcIj5TaWduIHVwIGZvciB0aGUgTWF0cml4IE1vbWVudHMgc2VyaWVzPC9oNj5cbiAgICAgICAgICAgIDxpbnB1dCBjbGFzc05hbWU9XCJtdC0yIHRleHQtc2Vjb25kYXJ5IGJnLWFjY2VudCBwLTAuNSBwbC0zIHctZnVsbFwiIHN0eWxlPXt7IGNvbG9yOiBcIiNGQkY5RjVcIiB9fSB0eXBlPVwiZW1haWxcIiBwbGFjZWhvbGRlcj1cIllvdXIgZW1haWwgYWRkcmVzcyBnb2VzIGhlcmVcIiAvPlxuICAgICAgICAgICAgPEJ1dHRvbiB0aXRsZT1cIlN1YnNjcmliZVwiIHVybD1cIi9pY29ucy9hcnJvdy5zdmdcIiBjbGFzc05hbWU9e1wicC0xIHRleHQtY3RhXCJ9IG9uQ2xpY2s9eygpID0+IGNvbnNvbGUubG9nKFwic3Vic2NyaWJlXCIpfSAvPlxuICAgICAgICAgIDwvc3Bhbj5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiIGxhcHRvcDptdC0xNiBwLTAuNSBsYXB0b3A6bXItNTIgc206ZmxleCBzbTpqdXN0aWZ5LWJldHdlZW4gXCI+XG4gICAgICAgICAgPGRpdj5cbiAgICAgICAgICAgIDxoNiBjbGFzc05hbWU9XCJzdWItaDIgZm9udC1tZWRpdW0gdGV4dC1sZ1wiPiBNYXRyaXggUGFydG5lciBVcyA8L2g2PlxuICAgICAgICAgICAgPGg2IGNsYXNzTmFtZT1cIiBzdWItaDIgZm9udC1tZWRpdW0gdGV4dC1sZ1wiPiBNYXRyaXggUGFydG5lciBDaGluYTwvaDY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IG10LTIgbGFwdG9wOm10LTggaXRlbXMtc3RhcnQgcC0wLjVcIj5cbiAgICAgICAgICAgIDxhIGNsYXNzTmFtZT1cIiBwbC0wXCI+PGltZyBzcmM9XCIvaWNvbnMvbGlua2VkaW4uc3ZnXCIgLz48L2E+XG4gICAgICAgICAgICA8YSBjbGFzc05hbWU9XCIgcGwtOVwiPiA8aW1nIHNyYz1cIi9pY29ucy90d2l0dGVyLnN2Z1wiIC8+PC9hPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCIgbGFwdG9wOmZsZXgganVzdGlmeS1iZXR3ZWVuIGZvb3Rlci1tZW51IGJnLXByaW1hcnkgYWxpZ24tbWlkZGxlIHNtOnBsLTExIHNtOnB0LTZcIj5cbiAgICAgICAgPEZvb3Rlck1lbnUgLz5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCIgdGV4dC1zZWNvbmRhcnkgZmxleCBpdGVtcy1jZW50ZXIgc206bXQtMiBzbTpncmlkIHNtOmdyaWQtY29scy0yIHNtOmdhcC0wXCI+XG4gICAgICAgICAgPHNwYW4gY2xhc3NOYW1lPVwiY2FwdGlvbiBwLTEgdy0yOCB0ZXh0LXNtIHNtOm10LTJcIiA+UFJJVkFDWSBQT0xJQ1k8L3NwYW4+XG4gICAgICAgICAgPHAgY2xhc3NOYW1lPVwiY2FwdGlvbiBwLTAuNSBsYXB0b3A6bWwtMjAgbGFwdG9wOm1yLTQwIFwiPntQUklWQUNZX1BPTElDWX0gPC9wPlxuICAgICAgICA8L2Rpdj5cbiAgICAgIDwvZGl2PlxuXG4gICAgPC9kaXY+XG4gICk7XG59O1xuIiwiaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IFNsaWRlciBmcm9tIFwicmVhY3Qtc2xpY2tcIjtcbmltcG9ydCBcInNsaWNrLWNhcm91c2VsL3NsaWNrL3NsaWNrLmNzc1wiO1xuaW1wb3J0IFwic2xpY2stY2Fyb3VzZWwvc2xpY2svc2xpY2stdGhlbWUuY3NzXCI7XG5pbXBvcnQgeyBJbWFnZSwgQ29udGVudFNsaWRlciB9IGZyb20gXCJAY29tcG9uZW50c1wiO1xuXG5leHBvcnQgdHlwZSBQcm9wcyA9IHtcbiAgbmFtZXM/OiBBcnJheTxzdHJpbmc+O1xuICBiYWNrZ3JvdW5kX3VybD86IHN0cmluZztcbiAgdGFncz86IEFycmF5PHN0cmluZz47XG4gIGxvZ28/OiBzdHJpbmc7XG4gIGNsYXNzTmFtZT86IHN0cmluZztcbiAgc3R5bGU/OiBhbnk7XG59O1xuXG5leHBvcnQgY29uc3QgRm91bmRlcjogUmVhY3QuRkM8UHJvcHM+ID0gKHsgY2xhc3NOYW1lLCBzdHlsZSA9IHt9IH0pID0+IHtcbiAgY29uc3QgaGVyb3MgPSBbe1xuICAgIGZpcnN0TmFtZTogJ0JoYXZpc2gnLFxuICAgIGxhc3ROYW1lOiAnQUdHQVJXQUwnLFxuICAgIGZpcnN0TmFtZTE6IG51bGwsXG4gICAgbGFzdE5hbWUxOiBudWxsLFxuICAgIGNhcHRpb246ICdNb2JpbGl0eScsXG4gICAgY2FwdGlvbjE6ICdFbGVjdHJpYyBDYXJzJyxcbiAgICBsb2dvOiAnL2ljb25zL29sYS5zdmcnLFxuICAgIGltYWdlOiAnL2ljb25zL0JoYXZpc2hfaW1hZ2Uuc3ZnJyxcbiAgICBoZWFkaW5nOiBbJ1dlIGFyZScsICdmb3VuZGVycycsICdmaXJzdCddXG4gIH0sIHtcbiAgICBmaXJzdE5hbWU6ICdST0hJVCcsXG4gICAgbGFzdE5hbWU6ICdNLkEuJyxcbiAgICBmaXJzdE5hbWUxOiBudWxsLFxuICAgIGxhc3ROYW1lMTogbnVsbCxcbiAgICBjYXB0aW9uOiAnSGVhbHRoY2FyZScsXG4gICAgY2FwdGlvbjE6IG51bGwsXG4gICAgbG9nbzogJy9pY29ucy9DbG91ZG5pbmUuc3ZnJyxcbiAgICBpbWFnZTogJy9pY29ucy9Sb2hpdF9UcmVhdG1lbnQuc3ZnJyxcbiAgICBoZWFkaW5nOiBbJ1dlICcsICdwYXJ0bmVyJywgJ2Nsb3NlbHknXVxuICB9LCB7XG4gICAgZmlyc3ROYW1lOiAnQU5JTkRZQScsXG4gICAgbGFzdE5hbWU6ICdEVVRUQScsXG4gICAgZmlyc3ROYW1lMTogJ1NBTkRFRVAnLFxuICAgIGxhc3ROYW1lMTogJ0RBTE1JQScsXG4gICAgY2FwdGlvbjogJ1N0dWRlbnQgSG91c2luZyBQbGF0Zm9ybScsXG4gICAgY2FwdGlvbjE6IG51bGwsXG4gICAgbG9nbzogJy9pY29ucy9TdGFuemEuc3ZnJyxcbiAgICBpbWFnZTogJy9pY29ucy9BbmluZHlhLnN2ZycsXG4gICAgaGVhZGluZzogWydXZSAnLCAnaW52ZXN0JywgJ2Vhcmx5J11cbiAgfSwge1xuICAgIGZpcnN0TmFtZTogJ0FzaXNoJyxcbiAgICBsYXN0TmFtZTogJ01PSEFQQVRSQScsXG4gICAgZmlyc3ROYW1lMTogbnVsbCxcbiAgICBsYXN0TmFtZTE6IG51bGwsXG4gICAgY2FwdGlvbjogJ0ZpbnRlY2gnLFxuICAgIGNhcHRpb24xOiAnU01FIExlbmRpbmcnLFxuICAgIGxvZ286ICcvaWNvbnMvT2ZCdXNpbmVzcy5zdmcnLFxuICAgIGltYWdlOiAnL2ljb25zL0FzaXNoLnN2ZycsXG4gICAgaGVhZGluZzogWydXZScsICdjb21taXQnLCAncGVyc29uYWxseSddXG4gIH0sIHtcbiAgICBmaXJzdE5hbWU6ICdNci4nLFxuICAgIGxhc3ROYW1lOiAnTEFLU0hJUEFUSFknLFxuICAgIGZpcnN0TmFtZTE6IG51bGwsXG4gICAgbGFzdE5hbWUxOiBudWxsLFxuICAgIGNhcHRpb246ICdGaW50ZWNoJyxcbiAgICBjYXB0aW9uMTogJ05CRkMnLFxuICAgIGxvZ286ICcvaWNvbnMvbXguc3ZnJyxcbiAgICBpbWFnZTogJy9pY29ucy9MYXhtaXBhdGh5LnN2ZycsXG4gICAgaGVhZGluZzogWydXZSBhcmUnLCAnZm91bmRlcnMnLCAnZmlyc3QnXVxuICB9LCB7XG4gICAgZmlyc3ROYW1lOiAnQ0hBS1JBREhBUicsXG4gICAgbGFzdE5hbWU6ICdHQURFJyxcbiAgICBmaXJzdE5hbWUxOiAnTklUSU4nLFxuICAgIGxhc3ROYW1lMTogJ0tBVVNIQUwnLFxuICAgIGNhcHRpb246ICdGaW50ZWNoJyxcbiAgICBjYXB0aW9uMTogJ05CRkMnLFxuICAgIGxvZ286ICcvaWNvbnMvQ291bnRyeS5zdmcnLFxuICAgIGhlYWRpbmc6IFsnV2UnLCAnY29tbWl0JywgJ3BlcnNvbmFsbHknXSxcbiAgICBpbWFnZTogJy9pY29ucy9DaGFrcmFkaGFyLnN2ZydcbiAgfV1cblxuICBjb25zdCBkYXRhID0gW1xuICAgIHtcbiAgICAgIGltYWdlX3VybDogXCIvaWNvbnMvY29udGVudDEuc3ZnXCIsXG4gICAgICB0aXRsZTogXCJGcm9tIGJvdGggc2lkZXMgb2YgdGhlIHRhYmxlIDogS3VuYWwgQmFobCB1bnBsdWdnZWRcIixcbiAgICAgIGF1dGhvcjogXCJUQVJVTiBEQVZEQVwiLFxuICAgICAgY29udGVudF9pZDogXCJhYmNkZWZcIixcbiAgICAgIGNvbnRlbnRfdHlwZTogXCJibG9nXCIsXG4gICAgICByZWFkX2R1cmF0aW9uOiBcIjQgTUlOXCIsXG4gICAgfSxcbiAgICB7XG4gICAgICBpbWFnZV91cmw6IFwiL2ljb25zL2NvbnRlbnQxLnN2Z1wiLFxuICAgICAgdGl0bGU6IFwiRnJvbSBib3RoIHNpZGVzIG9mIHRoZSB0YWJsZSA6IEt1bmFsIEJhaGwgdW5wbHVnZ2VkXCIsXG4gICAgICBhdXRob3I6IFwiVEFSVU4gREFWREFcIixcbiAgICAgIGNvbnRlbnRfaWQ6IFwiYWJjZGVmZ1wiLFxuICAgICAgY29udGVudF90eXBlOiBcImJsb2dcIixcbiAgICAgIHJlYWRfZHVyYXRpb246IFwiNCBNSU5cIixcbiAgICB9LFxuXG4gIF07XG5cbiAgY29uc3Qgc2V0dGluZ3MgPSB7XG4gICAgZG90czogdHJ1ZSxcbiAgICBpbmZpbml0ZTogdHJ1ZSxcbiAgICBzcGVlZDogNTAwLFxuICAgIGF1dG9wbGF5U3BlZWQ6IDUwMDAsXG4gICAgc2xpZGVzVG9TaG93OiAxLFxuICAgIHNsaWRlc1RvU2Nyb2xsOiAxLFxuICAgIC8vIGF1dG9wbGF5OiB0cnVlXG4gIH07XG4gIHJldHVybiAoXG4gICAgPFNsaWRlciB7Li4uc2V0dGluZ3N9PlxuICAgICAge2hlcm9zLm1hcChoZXJvID0+IHtcbiAgICAgICAgcmV0dXJuICg8ZGl2PlxuICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPXtgJHtjbGFzc05hbWV9YH0gc3R5bGU9e3sgd2lkdGg6IDYxNS45NCwgaGVpZ2h0OiA4NjMuOTEsIHBvc2l0aW9uOiBcInJlbGF0aXZlXCIsIC4uLnN0eWxlLCB9fT5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiXCIgc3R5bGU9e3sgd2lkdGg6IDU3MSwgaGVpZ2h0OiA3NjIsIHBvc2l0aW9uOiBcImFic29sdXRlXCIsIGJhY2tncm91bmQ6IFwiIzA4M0E0QVwiLCBib3R0b206IDUwLCBsZWZ0OiAwLCB9fT48L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiXCIgc3R5bGU9e3sgd2lkdGg6IDU5NCwgaGVpZ2h0OiA3ODgsIGJvdHRvbTogNjUsIGxlZnQ6IDE1LCBwb3NpdGlvbjogXCJhYnNvbHV0ZVwiLCBkaXNwbGF5OiBcImZsZXhcIiwgZmxleERpcmVjdGlvbjogXCJjb2x1bW5cIiwgfX0+XG4gICAgICAgICAgICAgIDxJbWFnZSBzcmM9e2hlcm8uaW1hZ2V9IGFsdD1cImZvdW5kZXIgaW1hZ2VcIiBzdHlsZT17eyBmbGV4R3JvdzogMSB9fT48L0ltYWdlPlxuICAgICAgICAgICAgICA8SW1hZ2Ugc3JjPVwiL2ljb25zL3JlY3RhbmdsZS5zdmdcIiBhbHQ9e1wicmVhY3RhbmdsZVwifSBjbGFzc05hbWU9XCJhYnNvbHV0ZVwiIHN0eWxlPXt7IGxlZnQ6IDM4LCBib3R0b206IDI1NCB9fSAvPlxuXG4gICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgaGVpZ2h0OiAyMDksIGJhY2tncm91bmQ6IFwiIzAxNTc2RVwiIH19PlxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwidGV4dC1jZW50ZXIgZmxleCBpdGVtcy1jZW50ZXJcIiBzdHlsZT17eyBoZWlnaHQ6IDExOCwgYm9yZGVyQm90dG9tOiBcIjFweCBzb2xpZCAjRUJFQkU5XCIgfX0+XG4gICAgICAgICAgICAgICAgICA8aDYgY2xhc3NOYW1lPVwiZm9udC1ib2xkIHRleHQtc2Vjb25kYXJ5XCIgc3R5bGU9e3sgZm9udFNpemU6IDMyLCBsaW5lSGVpZ2h0OiBcIjM2cHhcIiwgbGV0dGVyU3BhY2luZzogXCIwLjA1ZW1cIiwgbWFyZ2luTGVmdDogMzEsIG1hcmdpblJpZ2h0OiA4LCB9fT5cbiAgICAgICAgICAgICAgICAgICAge2hlcm8uZmlyc3ROYW1lfVxuICAgICAgICAgICAgICAgICAgPC9oNj5cbiAgICAgICAgICAgICAgICAgIDxoNiBjbGFzc05hbWU9XCJmb250LWxpZ2h0IHRleHQtc2Vjb25kYXJ5XCIgc3R5bGU9e3sgZm9udFNpemU6IDMyLCBsaW5lSGVpZ2h0OiBcIjM2cHhcIiwgbGV0dGVyU3BhY2luZzogXCIwLjA1ZW1cIiwgfX0+XG4gICAgICAgICAgICAgICAgICAgIHtoZXJvLmxhc3ROYW1lfVxuICAgICAgICAgICAgICAgICAgPC9oNj5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gaXRlbXMtY2VudGVyXCIgc3R5bGU9e3sgaGVpZ2h0OiA4OCB9fT5cbiAgICAgICAgICAgICAgICAgIDxkaXYgc3R5bGU9e3sgbWFyZ2luTGVmdDogMzEsIGRpc3BsYXk6ICdmbGV4JywganVzdGlmeUNvbnRlbnQ6ICdzcGFjZS1hcm91bmQnIH19PlxuICAgICAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJ0ZXh0LXNlY29uZGFyeSBmb250LW1lZGl1bSB0ZXh0LWxnIGxlYWRpbmctNlwiPiB7aGVyby5jYXB0aW9ufTwvc3Bhbj5cbiAgICAgICAgICAgICAgICAgICAge2hlcm8uY2FwdGlvbjEgJiYgPHNwYW4gY2xhc3NOYW1lPVwidGV4dC1zZWNvbmRhcnkgZm9udC1tZWRpdW0gdGV4dC1sZyBsZWFkaW5nLTZcIj48aHIgc3R5bGU9e3sgd2lkdGg6IDMwLCB0cmFuc2Zvcm06ICdyb3RhdGUoOTBkZWcpJyB9fSAvPjwvc3Bhbj59XG4gICAgICAgICAgICAgICAgICAgIHtoZXJvLmNhcHRpb24xICYmIDxzcGFuIGNsYXNzTmFtZT1cInRleHQtc2Vjb25kYXJ5IGZvbnQtbWVkaXVtIHRleHQtbGcgbGVhZGluZy02XCI+IHtoZXJvLmNhcHRpb24xfTwvc3Bhbj59XG4gICAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgICAgIDxJbWFnZSBzcmM9e2hlcm8ubG9nb30gYWx0PXtcIm9sYVwifSBzdHlsZT17eyBtYXJnaW5SaWdodDogNTcgfX0gLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJcIiBzdHlsZT17eyBsZWZ0OiA3NjAsIHBvc2l0aW9uOiBcImFic29sdXRlXCIgfX0+XG4gICAgICAgICAgICAgIDxwIGNsYXNzTmFtZT0nc2xpZGUtaGVhZGVyJz57aGVyby5oZWFkaW5nWzBdfTxzcGFuIHN0eWxlPXt7IGNvbG9yOiAnIzAxNTc2RScgfX0+IHtoZXJvLmhlYWRpbmdbMV19IDwvc3Bhbj4ge2hlcm8uaGVhZGluZ1syXX08L3A+XG5cbiAgICAgICAgICAgICAgPENvbnRlbnRTbGlkZXJcbiAgICAgICAgICAgICAgICBzdHlsZT17e1xuICAgICAgICAgICAgICAgICAgbGVmdDogLTEyLFxuICAgICAgICAgICAgICAgICAgYmFja2dyb3VuZDogXCIjRUJFQkU5XCIsXG4gICAgICAgICAgICAgICAgICBib3JkZXI6IFwiMXB4IHNvbGlkICNFQkVCRTlcIixcbiAgICAgICAgICAgICAgICAgIGJveFNpemluZzogXCJib3JkZXItYm94XCIsXG4gICAgICAgICAgICAgICAgICBmb250U2l6ZTogMjgsXG4gICAgICAgICAgICAgICAgICBsaW5lSGVpZ2h0OiBcIjM0cHhcIixcbiAgICAgICAgICAgICAgICAgIHBhZGRpbmdUb3A6IDI0LFxuICAgICAgICAgICAgICAgICAgcGFkZGluZ0xlZnQ6IDM0LFxuICAgICAgICAgICAgICAgICAgd2lkdGg6ICcxNTUlJyxcbiAgICAgICAgICAgICAgICAgIGJvdHRvbTogLTM0NyxcbiAgICAgICAgICAgICAgICAgIGhlaWdodDogMzAxXG4gICAgICAgICAgICAgICAgfX1cbiAgICAgICAgICAgICAgICBjb250ZW50TGlzdD17ZGF0YX1cbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJhYnNvbHV0ZSBib3R0b20tMCByaWdodC0wIHRleHQtcHJpbWFyeS1kYXJrXCJcbiAgICAgICAgICAgICAgICBoZWFkZXI9ezxzcGFuPkluc2lnaHRzIGZyb20gbWFya2V0IDxzcGFuIGNsYXNzTmFtZT1cInRleHQtYWNjZW50XCI+ZGlzcnVwdG9ycyAmIGludmVzdG9yczwvc3Bhbj48L3NwYW4+fVxuICAgICAgICAgICAgICAvPlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PilcbiAgICAgIH0pfVxuXG5cblxuXG4gICAgPC9TbGlkZXI+XG4gICk7XG59O1xuIiwiZXhwb3J0IHsgRm91bmRlciB9IGZyb20gXCIuL0ZvdW5kZXJcIjsiLCJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5cbmltcG9ydCB7IExvZ28gfSBmcm9tICdAY29tcG9uZW50cyc7XG5cbmV4cG9ydCB0eXBlIFByb3BzID0ge1xuICB0b2dnbGU6ICgpID0+IHZvaWQ7XG59XG5cbmV4cG9ydCBjb25zdCBIZWFkZXI6IFJlYWN0LkZDPFByb3BzPiA9ICh7IHRvZ2dsZSB9KSA9PiB7XG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJhYnNvbHV0ZSBmbGV4IHctZnVsbCB6LTIwIGp1c3RpZnktYmV0d2VlbiBpdGVtcy1zdGFydCBsYXB0b3A6cGwtOCBtdC0xMSBzbTptdC0wIHNtOnAtNVwiPlxuICAgICAgPExvZ28gLz5cbiAgICAgIDxkaXZcbiAgICAgICAgY2xhc3NOYW1lPVwiZmxleCAgaXRlbXMtY2VudGVyIGp1c3RpZnktc3RhcnQgbXQtMiB0ZXh0LWFjY2VudCBcIlxuICAgICAgICBvbkNsaWNrPXsoKSA9PiB0b2dnbGUoKX1cbiAgICAgID5cbiAgICAgICAgPGg2IGNsYXNzTmFtZT1cInN1Yi1oMSBwci0xIG1lbnUtdGV4dFwiPk1lbnU8L2g2PlxuICAgICAgICA8aW1nXG4gICAgICAgICAgc3JjPVwiL2ljb25zL21lbnUuc3ZnXCJcbiAgICAgICAgICBjbGFzc05hbWU9XCJwbC0yIGxhcHRvcDptci0yMCB0ZXh0LWJsdWVcIlxuICAgICAgICA+PC9pbWc+XG4gICAgICA8L2Rpdj5cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG4iLCJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5cbmV4cG9ydCB0eXBlIFByb3BzID0ge1xuICAgIHNyYzogc3RyaW5nO1xuICAgIGFsdDogc3RyaW5nO1xuICAgIGNsYXNzTmFtZT86IHN0cmluZztcbiAgICBoZWlnaHQ/OiBudW1iZXI7XG4gICAgd2lkdGg/OiBudW1iZXI7XG4gICAgc3R5bGU/OiBhbnlcbn1cblxuZXhwb3J0IGNvbnN0IEltYWdlOiBSZWFjdC5GQzxQcm9wcz4gPSAoeyBzcmMsIGFsdCwgY2xhc3NOYW1lICwgd2lkdGgsIGhlaWdodCAsIHN0eWxlPXt9IH0pID0+IHtcbiAgICByZXR1cm4gPGltZyBzcmM9e3NyY30gYWx0PXthbHR9IGNsYXNzTmFtZT17Y2xhc3NOYW1lfSBoZWlnaHQ9e2hlaWdodH0gd2lkdGg9e3dpZHRofSBzdHlsZT17c3R5bGV9ID48L2ltZz5cbn1cbiIsImV4cG9ydCB7IEhlYWRlciB9IGZyb20gXCIuL2hlYWRlclwiO1xuZXhwb3J0IHsgTG9nbyB9IGZyb20gXCIuL2xvZ29cIjtcbmV4cG9ydCB7IE1haW4gfSBmcm9tIFwiLi9tYWluXCI7XG5leHBvcnQgeyBCdXR0b24gfSBmcm9tIFwiLi9idXR0b25cIjtcbmV4cG9ydCB7IENhcmRzIH0gZnJvbSBcIi4vY2FyZHNcIjtcbmV4cG9ydCB7IEZvb3RlciB9IGZyb20gXCIuL2Zvb3RlclwiO1xuZXhwb3J0IHsgQ29udGFpbmVyIH0gZnJvbSBcIi4vY29udGFpbmVyXCI7XG5leHBvcnQgeyBJbWFnZSB9IGZyb20gXCIuL2ltYWdlXCI7XG5leHBvcnQgeyBUYWcgfSBmcm9tIFwiLi90YWdcIjtcbmV4cG9ydCB7IE5hdkl0ZW0gfSBmcm9tIFwiLi9uYXZJdGVtXCI7XG5leHBvcnQgeyBDb250ZW50SXRlbSB9IGZyb20gXCIuL2NvbnRlbnRJdGVtXCI7XG5leHBvcnQgeyBGb3VuZGVyIH0gZnJvbSBcIi4vZm91bmRlclwiO1xuZXhwb3J0IHsgQ29udGVudFNsaWRlciB9IGZyb20gXCIuL2NvbnRlbnRTbGlkZXIvQ29udGVudFNsaWRlclwiO1xuZXhwb3J0IHsgQmFubmVyIH0gZnJvbSBcIi4vYmFubmVyXCJcbiIsImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCBJbWFnZSBmcm9tIFwibmV4dC9pbWFnZVwiO1xuXG5leHBvcnQgY29uc3QgTG9nbzogUmVhY3QuRkMgPSAoKSA9PiB7XG4gIHJldHVybiAoXG4gICAgLy8gPEltYWdlIHNyYz1cIi9pY29ucy9tYXRyaXhMb2dvX1doaXRlLnN2Z1wiIGFsdD1cIm5leHRqc1wiIHdpZHRoPVwiMTU2LjE5cHhcIiBoZWlnaHQ9XCI2NXB4XCIgY2xhc3NOYW1lPVwiY29tcGFueS1sb2dvXCIgLz5cbiAgICA8SW1hZ2Ugc3JjPVwiL2ljb25zL21hdHJpeExvZ28uc3ZnXCIgYWx0PVwibmV4dGpzXCIgd2lkdGg9XCIxNTYuMTlweFwiIGhlaWdodD1cIjY1cHhcIiBjbGFzc05hbWU9XCJjb21wYW55LWxvZ29cIiAvPlxuICApO1xufTtcbiIsImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcblxuaW1wb3J0IHsgQnV0dG9uIH0gZnJvbSBcIkBjb21wb25lbnRzXCI7XG5cbmV4cG9ydCBjb25zdCBNYWluOiBSZWFjdC5GQyA9ICgpID0+IHtcbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInRleHQtY2VudGVyIGZvbnQtbGlnaHQgcHktNSBiZy1ncmF5LTcwMFwiPlxuICAgICAgPGRpdiBjbGFzc05hbWU9XCJjb250YWluZXIgbXgtYXV0b1wiPlxuICAgICAgICA8aDEgY2xhc3NOYW1lPVwidGV4dC13aGl0ZSB0ZXh0LTh4bCBtYi0yXCI+bWF0cml4PC9oMT5cbiAgICAgICAgPHAgY2xhc3NOYW1lPVwidGV4dC1sZyB0ZXh0LXdoaXRlIG1iLTNcIj5cbiAgICAgICAgICBUaGUgZnJvbnRlbmQgYm9pbGVycGxhdGUgd2l0aCBzdXBlcnBvd2VycyFcbiAgICAgICAgPC9wPlxuICAgICAgICA8QnV0dG9uIHR5cGU9XCJidXR0b25cIj5cbiAgICAgICAgICA8YSBocmVmPVwiaHR0cHM6Ly9wYW5rb2QuZ2l0aHViLmlvL3N1cGVycGxhdGUvXCIgdGFyZ2V0PVwiX2JsYW5rXCI+XG4gICAgICAgICAgICBEb2NzXG4gICAgICAgICAgPC9hPlxuICAgICAgICA8L0J1dHRvbj5cbiAgICAgIDwvZGl2PlxuICAgIDwvZGl2PlxuICApO1xufTtcbiIsImltcG9ydCB7IHRpdGxlIH0gZnJvbSBcInByb2Nlc3NcIjtcbmltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IEltYWdlIH0gZnJvbSBcIkBjb21wb25lbnRzXCI7XG5cbmV4cG9ydCB0eXBlIFByb3BzID0ge1xuICB0aXRsZTogc3RyaW5nO1xuICBpZDogc3RyaW5nO1xuICBvbkNsaWNrOiAoaWQ6IHN0cmluZykgPT4gdm9pZDtcbiAgc2VsZWN0ZWQ6IGJvb2xlYW47XG4gIGNsYXNzTmFtZT86IHN0cmluZztcbiAgYXJyb3c6IGJvb2xlYW47XG59O1xuXG5leHBvcnQgY29uc3QgTmF2SXRlbTogUmVhY3QuRkM8UHJvcHM+ID0gKHtcbiAgdGl0bGUsXG4gIHNlbGVjdGVkLFxuICBpZCxcbiAgb25DbGljayxcbiAgY2xhc3NOYW1lID0gXCJcIixcbiAgYXJyb3cgPSB0cnVlLFxufSkgPT4ge1xuICByZXR1cm4gKFxuICAgIDxkaXZcbiAgICAgIGNsYXNzTmFtZT17YCR7Y2xhc3NOYW1lfSBmbGV4IGp1c3RpZnktYmV0d2VlbiBtZW51LXByaW1hcnktbmF2LXRleHQgdGV4dC1wcmltYXJ5LWRhcmtgfVxuICAgICAgc3R5bGU9e3sgbWFyZ2luQm90dG9tOiAyNSB9fVxuICAgICAgb25DbGljaz17KCkgPT4gb25DbGljayhpZCl9XG4gICAgPlxuICAgICAgPHNwYW4+e3RpdGxlfTwvc3Bhbj5cbiAgICAgIHsvKiA8SW1hZ2Ugc3JjPVwiL2ljb25zL3JpZ2h0QXJyb3cubGFyZ2Uuc3ZnXCIgYWx0PVwiaW1hZ2VcIiBjbGFzc05hbWU9XCJtZW51X3ByaW1hcnlfbmF2X2ljb25cIiAgLz4gKi99XG4gICAgICB7IChzZWxlY3RlZCB8fCBhcnJvdyApID8gKFxuICAgICAgICAoIXNlbGVjdGVkKSA/IChcbiAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtZW51LXByaW1hcnktbmF2LWljb25cIj4ge1wiPlwifSA8L3NwYW4+XG4gICAgICAgICkgOiAoXG4gICAgICAgICAgPEltYWdlXG4gICAgICAgICAgICBzcmM9e1wiL2ljb25zL3NpZGVOYXZCdXR0b24uc3ZnXCJ9XG4gICAgICAgICAgICBhbHQ9XCJuYXYgYnV0dG9uXCJcbiAgICAgICAgICAgIGNsYXNzTmFtZT1cIi1tci01IG9wYWNpdHktMTAwXCJcbiAgICAgICAgICAvPlxuICAgICAgICApXG4gICAgICApIDogbnVsbH1cbiAgICA8L2Rpdj5cbiAgKTtcbn07XG4iLCJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5cbmV4cG9ydCB0eXBlIFByb3BzID0ge1xuICAgIHNlbGVjdGVkOiBib29sZWFuO1xuICAgIHRpdGxlOiBzdHJpbmc7XG4gICAgaWQ6IHN0cmluZztcbiAgICBvbkNsaWNrPzogKHN0cmluZykgPT4gdm9pZDtcbiAgICBjbGFzc05hbWU/OiBzdHJpbmc7XG4gICAgc3R5bGU/OiBhbnk7XG59XG5cblxuZXhwb3J0IGNvbnN0IFRhZzogUmVhY3QuRkM8UHJvcHM+ID0gKHsgc2VsZWN0ZWQsIHRpdGxlLCBpZCwgb25DbGljaywgY2xhc3NOYW1lID0gXCJcIiwgc3R5bGUgPSB7fSB9OiBQcm9wcykgPT4ge1xuICAgIGNvbnN0IF9jbGFzc05hbWUgPSBzZWxlY3RlZCA/IFwidGFnLXNlbGVjdGVkXCIgOiBcInRhZ1wiO1xuICAgIHJldHVybiAoPHNwYW4gY2xhc3NOYW1lPXtjbGFzc05hbWUgKyBcIiBcIiArIF9jbGFzc05hbWV9IHN0eWxlPXtzdHlsZX0gb25DbGljaz17KCkgPT4geyBpZiAob25DbGljaykgb25DbGljayhpZCkgfX0+XG4gICAgICAgIHt0aXRsZX1cbiAgICA8L3NwYW4+KVxufSIsImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IENvbnRlbnRJdGVtIH0gZnJvbSBcIkBjb21wb25lbnRzXCI7XG5pbXBvcnQgeyBTZWNvbmRhcnlCdXR0b24gfSBmcm9tIFwiQGNvbXBvbmVudHMvYnV0dG9uL1NlY29uZGFyeUJ1dHRvblwiO1xuXG5cbmNvbnN0IGRhdGEgPSBbXG4gICAge1xuICAgICAgICBpbWFnZV91cmw6IFwiL2ljb25zL2NvbnRlbnQxLnN2Z1wiLFxuICAgICAgICB0aXRsZTogXCJGcm9tIGJvdGggc2lkZXMgb2YgdGhlIHRhYmxlIDogS3VuYWwgQmFobCB1bnBsdWdnZWRcIixcbiAgICAgICAgYXV0aG9yOiBcIlRBUlVOIERBVkRBXCIsXG4gICAgICAgIGNvbnRlbnRfaWQ6IFwiYWJjZGVmXCIsXG4gICAgICAgIGNvbnRlbnRfdHlwZTogXCJibG9nXCIsXG4gICAgICAgIHJlYWRfZHVyYXRpb246IFwiNCBNSU5cIlxuICAgIH0sXG4gICAge1xuICAgICAgICBpbWFnZV91cmw6IFwiL2ljb25zL2NvbnRlbnQxLnN2Z1wiLFxuICAgICAgICB0aXRsZTogXCJGcm9tIGJvdGggc2lkZXMgb2YgdGhlIHRhYmxlIDogS3VuYWwgQmFobCB1bnBsdWdnZWRcIixcbiAgICAgICAgYXV0aG9yOiBcIlRBUlVOIERBVkRBXCIsXG4gICAgICAgIGNvbnRlbnRfaWQ6IFwiYWJjZGVmZ1wiLFxuICAgICAgICBjb250ZW50X3R5cGU6IFwiYmxvZ1wiLFxuICAgICAgICByZWFkX2R1cmF0aW9uOiBcIjQgTUlOXCJcbiAgICB9XG5dXG5cbmV4cG9ydCBjb25zdCBDb250ZW50TGlzdDogUmVhY3QuRkMgPSAoKSA9PiB7XG5cbiAgICByZXR1cm4gKDxkaXYgY2xhc3NOYW1lPVwibWwtMjAgbXQtMTQgZmxleC1ncm93IHNtOmhpZGRlblwiPlxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuXCI+XG4gICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm1iLTNcIj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJmb250LWxpZ2h0IHRleHQtM3hsIGxlYWRpbmctOCB0cmFja2luZy10aWdodGVyIHRleHQtcHJpbWFyeVwiPiB7XCJSRUxFVkFOVCBDT05URU5UXCJ9IDwvc3Bhbj5cbiAgICAgICAgICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC01IHBsLTEgdGV4dC1hY2NlbnRcIj57XCIoMzIwMClcIn08L3NwYW4+XG4gICAgICAgICAgICA8L2Rpdj5cblxuICAgICAgICAgICAgPFNlY29uZGFyeUJ1dHRvbiB0aXRsZT1cIlZpZXcgQWxsIFJFU1VMVFNcIiBjbGFzc05hbWU9XCIgbXItNiB0ZXh0LWFjY2VudC1kYXJrXCIgLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwibXQtNCBmbGV4LWdyb3cgb3ZlcmZsb3ctYXV0b1wiPlxuICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgIGRhdGEubWFwKChjb250ZW50SXRlbSkgPT4ge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gKDxDb250ZW50SXRlbVxuICAgICAgICAgICAgICAgICAgICAgICAga2V5PXtjb250ZW50SXRlbS5jb250ZW50X2lkfVxuICAgICAgICAgICAgICAgICAgICAgICAgaW1hZ2VfdXJsPXtjb250ZW50SXRlbS5pbWFnZV91cmx9XG4gICAgICAgICAgICAgICAgICAgICAgICB0aXRsZT17Y29udGVudEl0ZW0udGl0bGV9XG4gICAgICAgICAgICAgICAgICAgICAgICBhdXRob3I9e2NvbnRlbnRJdGVtLmF1dGhvcn1cbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnRlbnRfaWQ9e2NvbnRlbnRJdGVtLmNvbnRlbnRfaWR9XG4gICAgICAgICAgICAgICAgICAgICAgICBjb250ZW50X3R5cGU9e2NvbnRlbnRJdGVtLmNvbnRlbnRfdHlwZX1cbiAgICAgICAgICAgICAgICAgICAgICAgIHJlYWRfZHVyYXRpb249e2NvbnRlbnRJdGVtLnJlYWRfZHVyYXRpb259XG4gICAgICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoaWQpID0+IGNvbnNvbGUubG9nKGlkKX1cbiAgICAgICAgICAgICAgICAgICAgLz4pXG4gICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgIH1cbiAgICAgICAgPC9kaXY+XG5cbiAgICA8L2Rpdj4pXG59XG4iLCJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBTaWRlTmF2IH0gZnJvbSBcIi4vc2lkZU5hdlwiO1xuaW1wb3J0IHsgVGFnLCBJbWFnZSB9IGZyb20gXCJAY29tcG9uZW50c1wiO1xuaW1wb3J0IEJ1dHRvbiBmcm9tIFwiQGNvbXBvbmVudHMvYnV0dG9uL1ByaW1hcnlCdXR0b25JY29uUmlnaHRcIjtcbmltcG9ydCB7IENvbnRlbnRMaXN0IH0gZnJvbSBcIi4uL2NvbnRlbnQvY29udGVudExpc3RcIjtcbmltcG9ydCB7IFRhZ0xpc3QgfSBmcm9tIFwiLi90YWdMaXN0XCI7XG5pbXBvcnQgeyB1c2VRdWVyeSwgdXNlUmVhY3RpdmVWYXIgfSBmcm9tIFwiQGFwb2xsby9jbGllbnRcIjtcbmltcG9ydCB7IGFwcENvbmZpZ011dGF0aW9uLCBhcHBDb25maXFRdWVyeSB9IGZyb20gXCIuLi8uLi8uLi9vcGVyYXRpb25zL2FwcENvbmZpZ1wiO1xuaW1wb3J0IHsgYXBwQ29uZmlnVmFyIH0gZnJvbSBcIi4uLy4uLy4uL21vZGVscy9BcHBDb25maWdcIlxuXG5jb25zdCB0YWdMaXN0ID0gW3tcbiAgdGl0bGU6IFwiRWR1Y2F0aW9uXCIsXG4gIGlkOiBcImVkdWNhdGlvblwiXG5cbn0sXG57XG4gIHRpdGxlOiBcIkVkdGVjaFwiLFxuICBpZDogXCJlZHRlY2hcIlxufSxcbntcbiAgdGl0bGU6IFwiQ29uc3VtZXJcIixcbiAgaWQ6IFwiY29uc3VtZXJcIlxufSxcbntcbiAgdGl0bGU6IFwiRDJDXCIsXG4gIGlkOiBcImQyY1wiXG59LFxue1xuICB0aXRsZTogXCJGaW50ZWNoXCIsXG4gIGlkOiBcImZpbnRlY2hcIlxufVxuICAsIHtcbiAgdGl0bGU6IFwiR2FtaW5nXCIsXG4gIGlkOiBcImdhbWluZ1wiXG59LCB7XG4gIHRpdGxlOiBcInNvY2lhbFwiLFxuICBpZDogXCJzb2NpYWxcIlxufSwge1xuICB0aXRsZTogXCJDb21tdW5pY2F0aW9uXCIsXG4gIGlkOiBcImNvbW11bmljYXRpb25cIlxufSwge1xuICB0aXRsZTogXCJNYXJrZXRwbGFjZXNcIixcbiAgaWQ6IFwibWFya2V0cGxhY2VzXCJcbn0sIHtcbiAgdGl0bGU6IFwiTW9iaWxlXCIsXG4gIGlkOiBcIk1vYmlsZVwiXG59XG5dXG5cblxuZXhwb3J0IGNvbnN0IE1lbnU6IFJlYWN0LkZDID0gKCkgPT4ge1xuXG4gIGNvbnN0IHsgZGF0YTogeyBhcHBDb25maWc6IG5hdk1lbnVTdGF0ZSB9IH0gPSB1c2VRdWVyeShhcHBDb25maXFRdWVyeS5HRVRfTkFWX01FTlVfU1RBVEUpO1xuXG4gIGNvbnNvbGUubG9nKG5hdk1lbnVTdGF0ZSk7XG5cbiAgY29uc3QgY2xhc3NOYW1lID0gbmF2TWVudVN0YXRlLm1lbnUgPyBcInZpc2libGVcIiA6IFwiaW52aXNpYmxlIGhpZGRlblwiXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9e2BiZy1zZWNvbmRhcnkgei0zMCBvdmVyZmxvdy1oaWRkZW4gICBmbGV4ICB3LWZ1bGwgZmxleC1ncm93IGFic29sdXRlIHRvcC0wICR7Y2xhc3NOYW1lfWB9IHN0eWxlPXt7aGVpZ2h0OjEwNTN9fT5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleCBqdXN0aWZ5LWJldHdlZW4gYmctc2Vjb25kYXJ5LWxpZ2h0IGZsZXgtZ3Jvd1wiPlxuICAgICAgICA8ZGl2PlxuICAgICAgICAgIDxJbWFnZSBzcmM9XCIvaWNvbnMvbWF0cml4TG9nby5zdmdcIiBhbHQ9XCJjb21wYW55IGxvZ29cIiBjbGFzc05hbWU9XCJjb21wYW55LWxvZ29cIiAvPlxuICAgICAgICA8L2Rpdj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzbTpoaWRkZW4gbWVudS10YWdzIGZsZXgtZ3JvdyBwbC0yNFwiIHN0eWxlPXt7IG1hcmdpbkxlZnQ6IDI2MyB9fT5cbiAgICAgICAgICA8VGFnTGlzdCB0aXRsZT1cIlNFQ1RPUkFMXCIgdGFnTGlzdD17dGFnTGlzdH0gY2xhc3NOYW1lPVwibXQtMjggcHItMTEgb3BhY2l0eS0xMDBcIiBvbkl0ZW1DbGljaz17KGl0ZW1zKSA9PiB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhpdGVtcyk7XG4gICAgICAgICAgfX0gLz5cblxuICAgICAgICAgIDxUYWdMaXN0IHRpdGxlPVwiTk9OLVNFQ1RPUkFMXCIgdGFnTGlzdD17dGFnTGlzdH0gY2xhc3NOYW1lPVwicHItMTEgb3BhY2l0eS0xMDBcIiBvbkl0ZW1DbGljaz17KGl0ZW1zKSA9PiB7XG4gICAgICAgICAgICBjb25zb2xlLmxvZyhpdGVtcyk7XG4gICAgICAgICAgfX0gLz5cbiAgICAgICAgPC9kaXY+XG4gICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZmxleC1ncm93IGZsZXggZmxleC1jb2xcIj5cbiAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cIm10LTExIGZsZXggaXRlbXMtY2VudGVyIHNlbGYtZW5kIHB0LTJcIiBvbkNsaWNrPXsoKSA9PiBhcHBDb25maWdNdXRhdGlvbi50b29nbGVNZW51KCl9PlxuICAgICAgICAgICAgPGg2IGNsYXNzTmFtZT1cInN1Yi1oMSBwci0xIG1lbnUtdGV4dCB0ZXh0LWFjY2VudCBcIj5DbG9zZTwvaDY+XG4gICAgICAgICAgICA8SW1hZ2Ugc3JjPVwiL2ljb25zL21lbnVDbG9zZS5zdmdcIiBjbGFzc05hbWU9XCJwbC0yIGxhcHRvcDptci0yMCBzbTptci02IHRleHQtYmx1ZVwiIGFsdD1cImNsb3NlIG1lbnVcIj48L0ltYWdlPlxuICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgIDxDb250ZW50TGlzdCAvPlxuICAgICAgICAgIDxCdXR0b24gdGl0bGU9e1wiVmlzaXQgXCIgKyBcIkJsb2cgUGFnZVwifSBjbGFzc05hbWU9XCIgc206aGlkZGVuIG1lbnUtY29udGVudC1uYXYtYnV0dG9uIG1sLTIwIG1iLTEyIHRleHQtYWNjZW50XCIgdXJsPVwiL2ljb25zL3JpZ2h0QXJyb3dHcmF5LnN2Z1wiIC8+XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgICA8U2lkZU5hdiAvPlxuICAgIDwvZGl2PlxuICApO1xufTtcblxuIiwiaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgbmF2TWVudSB9IGZyb20gXCIuLi8uLi8uLi9jb25zdGFudHNcIjtcbmltcG9ydCB7IE5hdkl0ZW0sIEltYWdlIH0gZnJvbSBcIkBjb21wb25lbnRzXCI7XG5pbXBvcnQgeyBzb2NpYWxNZWRpYSB9IGZyb20gXCIuLi8uLi8uLi9jb25zdGFudHMvc29jaWFsTWVkaWFcIjtcbmltcG9ydCBCdXR0b24gZnJvbSBcIkBjb21wb25lbnRzL2J1dHRvbi9QcmltYXJ5QnV0dG9uSWNvblJpZ2h0XCI7XG5cbmV4cG9ydCBjb25zdCBTaWRlTmF2OiBSZWFjdC5GQyA9ICgpID0+IHtcbiAgY29uc3QgW3NlbGVjdGVkSW5kZXgsIHNldFNlbGVjdGVkSW5kZXhdID0gUmVhY3QudXNlU3RhdGUoMCk7XG5cbiAgY29uc3QgaXNTZWxlY3RlZCA9IChpbmRleDogbnVtYmVyKSA9PiB7XG4gICAgaWYgKGluZGV4ID09IHNlbGVjdGVkSW5kZXgpIHJldHVybiB0cnVlO1xuICAgIGVsc2UgcmV0dXJuIGZhbHNlO1xuICB9O1xuXG4gIHJldHVybiAoXG4gICAgPGRpdlxuICAgICAgY2xhc3NOYW1lPVwic2lkZS1uYXYgei0zMCBhYnNvbHV0ZSBiZy1hY2NlbnQtZGFyayB0ZXh0LXNlY29uZGFyeSAgZmxleCBmbGV4LWNvbCBqdXN0aWZ5LWJldHdlZW5cIlxuICAgICAgc3R5bGU9e3sgbGVmdDogMCwgZm9udFNpemU6IDU0LCBsaW5lSGVpZ2h0OiBcIjYycHhcIiB9fVxuICAgID5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwiYmxvY2tcIj5cbiAgICAgICAgPGRpdj5cbiAgICAgICAgICB7bmF2TWVudS5wcmltYXJ5Lm1hcCgobWVudUl0ZW06IGFueSwgaW5kZXgpID0+IHtcbiAgICAgICAgICAgIHJldHVybiAoXG4gICAgICAgICAgICAgIDxOYXZJdGVtXG4gICAgICAgICAgICAgICAgdGl0bGU9e21lbnVJdGVtLm5hbWV9XG4gICAgICAgICAgICAgICAgY2xhc3NOYW1lPXtcbiAgICAgICAgICAgICAgICAgICFpc1NlbGVjdGVkKGluZGV4KVxuICAgICAgICAgICAgICAgICAgICA/IFwiIHRleHQtc2Vjb25kYXJ5LWxpZ2h0IG9wYWNpdHktNTBcIlxuICAgICAgICAgICAgICAgICAgICA6IFwidGV4dC1zZWNvbmRhcnktbGlnaHQgb3BhY2l0eS0xMDBcIlxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBhcnJvdz17dHJ1ZX1cbiAgICAgICAgICAgICAgICBrZXk9e21lbnVJdGVtLmtleX1cbiAgICAgICAgICAgICAgICBpZD17bWVudUl0ZW0ua2V5fVxuICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IHNldFNlbGVjdGVkSW5kZXgoaW5kZXgpfVxuICAgICAgICAgICAgICAgIHNlbGVjdGVkPXtpc1NlbGVjdGVkKGluZGV4KX1cbiAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICk7XG4gICAgICAgICAgfSl9XG4gICAgICAgIDwvZGl2PlxuXG4gICAgICAgIDxkaXY+XG4gICAgICAgICAge25hdk1lbnUuc2Vjb25kYXJ5Lm1hcCgobWVudUl0ZW06IGFueSkgPT4ge1xuICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgPGRpdlxuICAgICAgICAgICAgICAgIGtleT17bWVudUl0ZW0ua2V5fVxuICAgICAgICAgICAgICAgIGNsYXNzTmFtZT1cImZsZXgganVzdGlmeS1iZXR3ZWVuXCJcbiAgICAgICAgICAgICAgICBzdHlsZT17eyBtYXJnaW5Cb3R0b206IDIxIH19XG4gICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICA8aDUgY2xhc3NOYW1lPVwibWVudS1zZWNvbmRhcnktbmF2LXRleHRcIj57bWVudUl0ZW0ubmFtZX08L2g1PlxuICAgICAgICAgICAgICAgIDxzcGFuIGNsYXNzTmFtZT1cIm1lbnUtc2Vjb25kYXJ5LW5hdi1pY29uXCI+IHtcIj5cIn0gPC9zcGFuPlxuICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICk7XG4gICAgICAgICAgfSl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT1cIiBtci0xNlwiPlxuICAgICAgICA8c3BhbiBjbGFzc05hbWU9XCJtbC00XCI+XG4gICAgICAgICAgPGg2IGNsYXNzTmFtZT1cIm10LTQgZm9udC1ub3JtYWwgdGV4dC1zZWNvbmRhcnlcIiBzdHlsZT17eyBmb250U2l6ZToyOCwgbGluZUhlaWdodDpcIjM0cHhcIn19PkxldCdzIHN0YXkgZW5nYWdlZCA8L2g2PlxuICAgICAgICAgIDxoNiBjbGFzc05hbWU9XCJmb250LW5vcm1hbCB0ZXh0LXhzIGNhcGl0YWxpemUgXCIgc3R5bGU9e3ttYXJnaW5Ub3A6MTAsbGluZUhlaWdodDpcIjE0cHhcIn19PlxuICAgICAgICAgICAgU0lHTiBVUCBGT1IgVEhFIE1BVFJJWCBNT01FTlRTIFNFUklFU1xuICAgICAgICAgIDwvaDY+XG4gICAgICAgICAgPGlucHV0XG4gICAgICAgICAgICBjbGFzc05hbWU9XCJtdC0yIHRleHQtc2Vjb25kYXJ5IGJnLWFjY2VudCB3LWZ1bGxcIlxuICAgICAgICAgICAgc3R5bGU9e3sgY29sb3I6IFwiI0ZCRjlGNVwiICwgbWFyZ2luVG9wOjE1LGZvbnRTaXplOjE1LCBsaW5lSGVpZ2h0OlwiMThweFwiLG9wYWNpdHk6MC44LCBoZWlnaHQ6Mzh9fVxuICAgICAgICAgICAgdHlwZT1cImVtYWlsXCJcbiAgICAgICAgICAgIHBsYWNlaG9sZGVyPVwiWW91ciBlbWFpbCBhZGRyZXNzIGdvZXMgaGVyZVwiXG4gICAgICAgICAgLz5cbiAgICAgICAgICA8QnV0dG9uXG4gICAgICAgICAgICB0aXRsZT1cIlN1YnNjcmliZVwiXG4gICAgICAgICAgICB1cmw9XCIvaWNvbnMvYXJyb3cuc3ZnXCJcbiAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGNvbnNvbGUubG9nKFwic3Vic2NyaWJlXCIpfVxuICAgICAgICAgICAgY2xhc3NOYW1lPVwidGV4dC1sZyBsZWFkaW5nLTZcIlxuICAgICAgICAgICAgc3R5bGU9e3tjb2xvcjogXCIjMEZCNkI4XCJ9fVxuICAgICAgICAgIC8+XG4gICAgICAgIDwvc3Bhbj5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4IFwiIHN0eWxlPXt7bWFyZ2luVG9wOjYwICwgbWFyZ2luQm90dG9tOjU4fX0+XG4gICAgICAgICAge3NvY2lhbE1lZGlhLm1hcCgoaXRlbSkgPT4ge1xuICAgICAgICAgICAgcmV0dXJuIChcbiAgICAgICAgICAgICAgPGEgY2xhc3NOYW1lPVwicC0xIG1yLTEwXCIgaHJlZj17aXRlbS5saW5rfT5cbiAgICAgICAgICAgICAgICA8SW1hZ2VcbiAgICAgICAgICAgICAgICAgIHNyYz17aXRlbS5pbWFnZVVybH1cbiAgICAgICAgICAgICAgICAgIGFsdD17aXRlbS5uYW1lfVxuICAgICAgICAgICAgICAgICAgY2xhc3NOYW1lPVwiIFwiXG4gICAgICAgICAgICAgICAgICBrZXk9e2l0ZW0ua2V5fVxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvYT5cbiAgICAgICAgICAgICk7XG4gICAgICAgICAgfSl9XG4gICAgICAgIDwvZGl2PlxuICAgICAgPC9kaXY+XG4gICAgPC9kaXY+XG4gICk7XG59O1xuIiwiaW1wb3J0IFJlYWN0IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgVGFnIH0gZnJvbSBcIkBjb21wb25lbnRzXCI7XG5cblxuZXhwb3J0IHR5cGUgUHJvcHMgPSB7XG4gICAgdGl0bGU6IHN0cmluZztcbiAgICB0YWdMaXN0OiBhbnk7XG4gICAgb25JdGVtQ2xpY2s6IChzZWxlY3RlZDogYW55KSA9PiB2b2lkO1xuICAgIGNsYXNzTmFtZSA6IHN0cmluZztcbn1cblxuZXhwb3J0IGNvbnN0IFRhZ0xpc3Q6IFJlYWN0LkZDPFByb3BzPiA9ICh7IHRpdGxlLCB0YWdMaXN0LCBvbkl0ZW1DbGljayxjbGFzc05hbWU9XCJcIiB9OiBQcm9wcykgPT4ge1xuICAgIGNvbnN0IFtzZWxlY3RlZCwgc2V0U2VsZWN0ZWRdID0gUmVhY3QudXNlU3RhdGUoW10pO1xuXG4gICAgY29uc3QgaXNTZWxlY3RlZCA9IChpZCkgPT4ge1xuICAgICAgICBpZiAoc2VsZWN0ZWQuaW5kZXhPZihpZCkgPiAtMSkge1xuICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gZmFsc2U7XG5cbiAgICB9XG5cbiAgICBjb25zdCB0b2dnbGUgPSAoaWQpID0+IHtcbiAgICAgICAgaWYgKGlzU2VsZWN0ZWQoaWQpID09PSB0cnVlKSB7XG4gICAgICAgICAgICBjb25zdCBpbmRleCA9IHNlbGVjdGVkLmluZGV4T2YoaWQpO1xuICAgICAgICAgICAgc2V0U2VsZWN0ZWQoc2VsZWN0ZWQuc3BsaWNlKGluZGV4KzEsIDEpKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHNldFNlbGVjdGVkKFsuLi5zZWxlY3RlZCwgaWRdKVxuICAgICAgICB9XG4gICAgICAgIG9uSXRlbUNsaWNrKHNlbGVjdGVkKVxuICAgIH1cbiAgICByZXR1cm4gKFxuICAgICAgICA8ZGl2IGNsYXNzTmFtZT17YHctZnVsbCAke2NsYXNzTmFtZX1gfT5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiZm9udC1saWdodCB0ZXh0LXhzIGxlYWRpbmctMyB0cmFja2luZy13aWRlciBwLTIgdGV4dC1hY2NlbnQtZGFya1wiPnt0aXRsZX08L2Rpdj5cbiAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwiIGZsZXggZmxleC1yb3cgZmxleC13cmFwIHRleHQtcHJpbWFyeS1kYXJrXCI+XG4gICAgICAgICAgICAgICAge1xuICAgICAgICAgICAgICAgICAgICB0YWdMaXN0Lm1hcCgodGFnKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gKDxUYWcgaWQ9e3RpdGxlK3RhZy5pZH0ga2V5PXt0YWcuaWR9IGNsYXNzTmFtZT1cIm1sLTMgbWItM1wiIHRpdGxlPXt0YWcudGl0bGV9IHNlbGVjdGVkPXtpc1NlbGVjdGVkKHRhZy5pZCl9IG9uQ2xpY2s9eygpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0b2dnbGUodGFnLmlkKVxuICAgICAgICAgICAgICAgICAgICAgICAgfX0gLz4pXG4gICAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvZGl2PlxuICAgIClcbn0iLCJpbXBvcnQgUmVhY3QsIHsgdXNlRWZmZWN0IH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBMYXlvdXQgfSBmcm9tIFwiQGNvbXBvbmVudHMvbGF5b3V0XCI7XG5pbXBvcnQgeyBNZW51IH0gZnJvbSBcIi4uL21lbnVcIjtcbmltcG9ydCB7IHVzZVF1ZXJ5IH0gZnJvbSBcIkBhcG9sbG8vY2xpZW50XCI7XG5pbXBvcnQge1xuICBhcHBDb25maWdNdXRhdGlvbixcbiAgYXBwQ29uZmlxUXVlcnksXG59IGZyb20gXCIuLi8uLi8uLi9vcGVyYXRpb25zL2FwcENvbmZpZ1wiO1xuaW1wb3J0IE5Qcm9ncmVzcyBmcm9tIFwibnByb2dyZXNzXCI7XG5pbXBvcnQgXCJucHJvZ3Jlc3MvbnByb2dyZXNzLmNzc1wiO1xuaW1wb3J0IFJvdXRlciBmcm9tIFwibmV4dC9yb3V0ZXJcIjtcbmltcG9ydCB7IEZvb3RlciB9IGZyb20gXCJAY29tcG9uZW50cy9mb290ZXJcIjtcbmltcG9ydCB7IEhlYWRlciB9IGZyb20gXCJAY29tcG9uZW50cy9oZWFkZXJcIjtcblxuZXhwb3J0IHR5cGUgUHJvcHMgPSB7XG4gIGNsYXNzTmFtZT86IHN0cmluZztcbiAgZGV2aWNlVHlwZToge1xuICAgIG1vYmlsZTogYm9vbGVhbjtcbiAgICB0YWJsZXQ6IGJvb2xlYW47XG4gICAgZGVza3RvcDogYm9vbGVhbjtcbiAgfTtcbiAgdG9rZW4/OiBzdHJpbmc7XG59O1xuXG5leHBvcnQgY29uc3QgUm9vdDogUmVhY3QuRkM8UHJvcHM+ID0gKHsgY2hpbGRyZW4gfSkgPT4ge1xuICBjb25zdCB7XG4gICAgZGF0YTogeyBhcHBDb25maWc6IG5hdk1lbnVTdGF0ZSB9LFxuICB9ID0gdXNlUXVlcnkoYXBwQ29uZmlxUXVlcnkuR0VUX05BVl9NRU5VX1NUQVRFKTtcbiAgdXNlRWZmZWN0KCgpID0+IHtcbiAgICBSb3V0ZXIuZXZlbnRzLm9uKFwicm91dGVDaGFuZ2VTdGFydFwiLCAodXJsKSA9PiB7XG4gICAgICBOUHJvZ3Jlc3Muc3RhcnQoKTtcbiAgICB9KTtcbiAgICBSb3V0ZXIuZXZlbnRzLm9uKFwicm91dGVDaGFuZ2VDb21wbGV0ZVwiLCAoKSA9PiBOUHJvZ3Jlc3MuZG9uZSgpKTtcbiAgICBSb3V0ZXIuZXZlbnRzLm9uKFwicm91dGVDaGFuZ2VFcnJvclwiLCAoKSA9PiBOUHJvZ3Jlc3MuZG9uZSgpKTtcbiAgICBOUHJvZ3Jlc3MuY29uZmlndXJlKHsgc2hvd1NwaW5uZXI6IGZhbHNlIH0pO1xuICB9LCBbXSk7XG4gIGNvbnN0IGNsYXNzTmFtZSA9ICFuYXZNZW51U3RhdGUubWVudVxuICAgID8gXCJ2aXNpYmxlXCJcbiAgICA6IFwiaW52aXNpYmxlIGhpZGRlbiBcIjtcblxuICByZXR1cm4gKFxuICAgIDw+XG4gICAgICA8ZGl2IGNsYXNzTmFtZT17YGZsZXggZmxleC1jb2wgZmxleC1ncm93IHctZnVsbCBoLWZ1bGwgICR7Y2xhc3NOYW1lfWB9PlxuICAgICAgICA8SGVhZGVyIHRvZ2dsZT17YXBwQ29uZmlnTXV0YXRpb24udG9vZ2xlTWVudX0gLz5cbiAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJmbGV4LWdyb3dcIj57Y2hpbGRyZW59PC9kaXY+XG4gICAgICAgIDxGb290ZXIgLz5cbiAgICAgIDwvZGl2PlxuICAgICAgPE1lbnUgLz5cbiAgICA8Lz5cbiAgKTtcbn07XG4iLCJcblxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gKHR5cGUpe1xuICAgIHN3aXRjaCAodHlwZSl7XG5cbiAgICB9XG4gICAgcmV0dXJuIFwiL2ljb25zL3ZpZGVvLnN2Z1wiXG59IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiQGFwb2xsby9jbGllbnRcIik7IiwibW9kdWxlLmV4cG9ydHMgPSByZXF1aXJlKFwiQGFwb2xsby9jbGllbnQvbGluay9jb250ZXh0XCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcImRlZXBtZXJnZVwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJtb2JpbGUtZGV0ZWN0XCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIm5leHQvcm91dGVyXCIpOyIsIm1vZHVsZS5leHBvcnRzID0gcmVxdWlyZShcIm5wcm9ncmVzc1wiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJyZWFjdFwiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJyZWFjdC1zbGlja1wiKTsiLCJtb2R1bGUuZXhwb3J0cyA9IHJlcXVpcmUoXCJyZWFjdC9qc3gtZGV2LXJ1bnRpbWVcIik7Il0sInNvdXJjZVJvb3QiOiIifQ==